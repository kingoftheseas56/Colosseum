from pathlib import Path
import os,shutil,subprocess,json,hashlib
b=Path(__file__).resolve().parent.parent;o=b/'switzer-route-closure';root=o/'replacement-test-private';src=b/'candidate/root/opt/colosseum';shutil.copytree(src,root,copy_function=os.link) if not root.exists() else None
p=root/'usr/lib/libQt6Core.so.6';p.unlink();os.link(src/'usr/lib/libQt6Core.so.6',p);old=p.read_bytes();from elftools.elf.elffile import ELFFile
with p.open('rb') as f:
 section=ELFFile(f).get_section_by_name('.comment');assert section is not None and not section['sh_flags'] & 2
 offset=section['sh_offset'];size=section['sh_size'];assert size>2
changed=bytearray(old);changed[offset+1]=ord('R') if old[offset+1]!=ord('R') else ord('S')
q=p.with_suffix('.modified');q.write_bytes(changed);q.chmod(p.stat().st_mode);p.unlink();q.rename(p)
def run(args):return subprocess.check_output(args,text=True)
# Same exported ABI and same dynamic-link metadata.
assert run(['nm','-D','--defined-only',str(src/'usr/lib/libQt6Core.so.6')])==run(['nm','-D','--defined-only',str(p)])
a=run(['readelf','-d',str(src/'usr/lib/libQt6Core.so.6')]);z=run(['readelf','-d',str(p)]);assert a==z
# Every loadable segment has identical bytes, virtual address and flags.
from elftools.elf.elffile import ELFFile
with (src/'usr/lib/libQt6Core.so.6').open('rb') as f,p.open('rb') as g:
 x=ELFFile(f);y=ELFFile(g);xx=[s for s in x.iter_segments() if s['p_type']=='PT_LOAD'];yy=[s for s in y.iter_segments() if s['p_type']=='PT_LOAD'];assert len(xx)==len(yy)
 for u,v in zip(xx,yy):assert u.data()==v.data() and u['p_vaddr']==v['p_vaddr'] and u['p_flags']==v['p_flags']
env=os.environ.copy();env.update(LD_BIND_NOW='1',LD_DEBUG='libs',HOME=str(o/'empty-home'))
r=subprocess.run([str(root/'AppRun'),'--version'],env=env,text=True,capture_output=True,timeout=30);(o/'replacement-loader.log').write_text(r.stderr);(o/'replacement-stdout.txt').write_text(r.stdout);assert r.returncode==0 and r.stdout.strip()=='Colosseum 1.1.9';assert str(p) in r.stderr
assert (src/'usr/lib/libQt6Core.so.6').read_bytes()==old
res={'status':'PASS: actual modified-library load and eager symbol binding; not full GUI behavioral qualification','original_qtcore_sha256':hashlib.sha256(old).hexdigest(),'modified_qtcore_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'exported_abi_identical':True,'dynamic_section_identical':True,'loadable_segments_identical':True,'modification':'one byte in existing non-allocated .comment ELF section','command':'isolated-copy/AppRun --version with LD_BIND_NOW=1 LD_DEBUG=libs','returncode':r.returncode,'stdout':r.stdout.strip(),'candidate_original_unchanged':True,'limitations':'No GUI startup, no behavior-changing library rebuild, no claim all hypothetical interface-compatible replacements were tested. Exact standard shared-library mechanism and one real byte-modified library accepted.'};(o/'LIBRARY-REPLACEMENT-TEST.json').write_text(json.dumps(res,indent=2)+'\n');print(json.dumps(res,indent=2))
