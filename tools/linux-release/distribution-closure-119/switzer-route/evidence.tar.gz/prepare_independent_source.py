#!/usr/bin/env python3
"""Create a NEW source tree; never overwrite baseline or publish. Python 3.11+."""
import argparse,hashlib,json,os,shutil
from pathlib import Path
APP_SHA='2b25937aa546a488db9f0caf44e94f888ff3e4c806ef89ab296f5a97f22008b3'
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def prepare(baseline,app,template,output):
 assert sha(app)==APP_SHA,'wrong application omission archive'
 original=json.loads((baseline/'SHA256-INDEX.json').read_text())
 for row in original:
  p=baseline/row['path'];assert p.is_file() and p.stat().st_size==row['bytes'] and sha(p)==row['sha256'],row['path']
 output.mkdir(exist_ok=False)
 for name in ['sources','upstream','supplements']:shutil.copytree(baseline/name,output/name,copy_function=os.link)
 for name in ['ubuntu-source-index.json','upstream-source-index.json','icu-candidate-source.json']:os.link(baseline/name,output/name)
 (output/'application').mkdir();os.link(app,output/'application/colosseum-7792bd1d9-independent-fonts-excluded.tar.gz')
 for name in ['accompanying-notices','receiving-route']:shutil.copytree(template/name,output/name)
 shutil.copy2(template/'README.txt',output/'README.txt')
 rows=[dict(path=str(p.relative_to(output)),bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(output.rglob('*')) if p.is_file()]
 (output/'SHA256-INDEX.json').write_text(json.dumps(rows,indent=2)+'\n')
 expected=template/'EXPECTED-SOURCE-INDEX.json'
 if expected.exists():assert (output/'SHA256-INDEX.json').read_bytes()==expected.read_bytes(),'source index differs from frozen expected artifact'
 print(json.dumps({'indexed_files':len(rows),'application_sha256':APP_SHA}))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--baseline',type=Path,required=True);p.add_argument('--application',type=Path,required=True);p.add_argument('--template',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();prepare(a.baseline,a.application,a.template,a.output)
