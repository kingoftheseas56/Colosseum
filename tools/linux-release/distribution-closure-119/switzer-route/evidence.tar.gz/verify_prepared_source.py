from pathlib import Path
import tarfile,json,hashlib
b=Path(__file__).resolve().parent.parent;r=b/'source-delivery-independent-fonts';a=b/'colosseum-1.1.9-7792bd1d9-independent-font-source.tar.gz';index=json.loads((r/'SHA256-INDEX.json').read_text());by={x['path']:x for x in index};seen=set()
with tarfile.open(a,'r:gz') as t:
 for m in t:
  if not m.isfile():continue
  rel=m.name.removeprefix('source-delivery-independent-fonts/');f=t.extractfile(m)
  if rel=='SHA256-INDEX.json':assert f.read()==(r/rel).read_bytes();continue
  assert rel in by and rel not in seen,rel;seen.add(rel);h=hashlib.file_digest(f,'sha256').hexdigest();assert m.size==by[rel]['bytes'] and h==by[rel]['sha256'],rel
assert seen==set(by)
with a.open('rb') as f:h=hashlib.file_digest(f,'sha256').hexdigest()
res={'status':'PASS','archive':a.name,'bytes':a.stat().st_size,'sha256':h,'all_indexed_members_verified':len(seen),'embedded_index_exact':True,'extra_missing_wrong_members':0};(b/'switzer-route-closure/SOURCE-ARCHIVE-VERIFICATION.json').write_text(json.dumps(res,indent=2)+'\n');print(json.dumps(res))
