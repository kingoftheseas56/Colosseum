#!/usr/bin/env python3
import tarfile,json,hashlib,io,lzma
from pathlib import Path
H=Path(__file__).resolve().parent;B=H.parent;O=H/'fixture-context';O.mkdir(exist_ok=True)
records=[]
def save(archive,name,data):
 sha=hashlib.sha256(data).hexdigest();p=O/(sha+'.bin');p.write_bytes(data)
 records.append({'archive':str(archive.relative_to(B)),'member':name,'bytes':len(data),'sha256':sha,'evidence_file':str(p.relative_to(H))})
for arc in [B/'source-delivery/upstream/qtwebengine/qtwebengine-everywhere-src-6.11.1.tar.xz',B/'source-delivery/upstream/qtbase/qtbase-everywhere-src-6.11.1.tar.xz']:
 print('reading',arc,flush=True)
 with tarfile.open(arc,'r|*') as t:
  for m in t:
   n=m.name
   if not m.isfile() or m.size>2*1024**2:continue
   keep=False
   if '/third_party/libzip/src/regress/' in n and (n.endswith(('.test','.zip','.c','.sh')) and any(s in n.rsplit('/',1)[-1] for s in ['encrypt','broken','testfile-xz','incons-'])):keep=True
   if '/third_party/lzma_sdk/google/' in n and n.endswith(('.cc','.h','.txt','.md')):keep=True
   if any(x in n for x in ['/qdecompresshelper/','/qnetworkreply/']) and n.endswith(('.cpp','.py','.sh','.txt')):keep=True
   if keep:save(arc,n,t.extractfile(m).read())
(O/'INDEX.json').write_text(json.dumps(records,indent=2)+'\n')
print('saved',len(records),'bytes',sum(r['bytes'] for r in records),flush=True)
