# Independent-font source boundary: technical audit

## Result

No Switzer font payload was detected. The target-specific exclusion is verified: exactly the four original Switzer OTF members are absent, while all 5,626 other application members are unchanged. The replacement application archive SHA-256 is `2b25937aa546a488db9f0caf44e94f888ff3e4c806ef89ab296f5a97f22008b3`.

This is a bounded technical audit, not a claim of zero blind spots, a licensing determination, Corresponding Source clearance, or release approval.

## Actual prepared source tree

The actual `source-delivery-independent-fonts` tree contains 4,181 physical files. All 4,180 indexed file sizes and hashes verify. The 3,895 unchanged prior inputs match the previous source index byte-for-byte; the one renamed replacement application archive matches the audited archive; and all 285 added or changed notice/route/index files were scanned separately. Only the replaced original application archive path is removed. No third-party source input was removed or rewritten.

## Recursive inspection

- 1,517,106 payload records, 35,317,287,565 bytes observed across 2,096 archive/compression layers.
- Tar, gzip, xz, bzip2, ZIP, ar, and zstd were inspected recursively; font magic as well as filename suffixes selected font inspection. Alternative libarchive/Brotli readers inspected additional formats.
- 2,461 initial font occurrences plus 9 recovered font occurrences were parsed. No original four-font hash or Switzer internal-name match was found.
- Archive paths were never extracted or followed. Inputs were not repacked. Peak archive spool use was 15,049,013 bytes (about 15 MB).
- A positive control placed an original Switzer font under a different name through tar → bzip2 → xz → gzip → ZIP. Both its exact hash and internal name were detected; absolute and parent-traversal archive names were not extracted.

## Application exceptions: fully closed by inspecting their complete bytes

All 313 application ZIP/CBZ parse warnings are tiny nonarchive placeholders. There are exactly four distinct payloads: `x` (301 occurrences, one byte), `vault-fixture-stub\n` (10 occurrences, 19 bytes), `fake-cbz-bytes` (one, 14 bytes), and a 49-byte plain garbage string ending in three control bytes. None is an encrypted or opaque archive. See `APPLICATION-EXCEPTIONS.json` for exact hashes and complete representations. There are no remaining opaque application archive inputs.

## Inherited third-party exceptions: explicitly retained, not claimed fully decoded

The initial scan recorded 321 third-party error records. Alternative readers resolved 41 original records; targeted fixture checks resolved 8 more. The remaining 272 records may repeat one fixture at multiple decoder layers or across independently retained upstream source archives. They are enumerated without suppression in `REMAINING-EXCEPTIONS.json`.

Important qualifications:

- Five original legacy/encrypted ZIP member failures remain, including the intentionally broken ZIP. Seven published encryption vectors were independently decrypted and inspected successfully.
- Two encrypted 7z fixture containers remain opaque to the alternative reader. Their accompanying source describes a 19-byte fake executable and provides a public test password. This source context is not a substitute for decryption.
- Other malformed or reader-incompatible 7z/ZIP/Lzip/ISO/compression regression inputs remain explicitly documented, including the ZIP member with unsupported compression. The test/fuzz path alone is not proof of its decoded contents.
- Four byte-identical 4G.br fixtures hit the five-second alternate-reader bound. Companion Qt test source identifies their expected 4 GiB expansion. They were not fully expanded.
- A 60,000,000,000-byte sparse virtual tar member hit the 4 GiB payload bound. Three error records describe this one fixture. No bulk sparse output was written.
- 82 malformed or nonfont test payloads still fail font-name parsing. Their complete raw payload hashes were checked; none matches the four original font files. No assertion is made that every malformed font name table is decodable.
- The LZO seed originally needing an unavailable decoder was independently resolved: its only block is stored, uncompressed ASCII, 109 bytes, with both header and data checksums verified.

No upstream fixture was deleted or transformed to force a clean scanner result. All original third-party source archives retain their exact prior hashes. The defensible conclusion is zero detected Switzer font payloads with decisive four-file application exclusion, not blanket recursive completeness.

## Evidence and reproduction

Primary compact evidence: `FINAL-AUDIT.json`, `ACTUAL-TREE-VERIFICATION.json`, `APPLICATION-EXCEPTIONS.json`, `REMAINING-EXCEPTIONS.json`, `ERRORS.json`, `ERROR-REVIEW.json`, `SUPPLEMENTAL-SUMMARY.json`, and `TARGETED-FIXTURE-CHECKS.json`. Full counts, font inventories, archive inventories, top-level digests, and self-tests are retained alongside these files.

Scripts: `recursive_audit.py`, `selftest.py`, `review_errors.py`, `verify_actual_tree.py`, `collect_fixture_context.py`, `targeted_fixture_checks.py`, and `finalize_report.py`. Supplementary parser dependencies were installed only under this audit directory (Brotli 1.2.0 and libarchive-c 5.3, using system libarchive 3.7.4). Main scanning additionally uses the environment's fontTools and zstandard.

Run the scripts from the parent `linux-distribution-119` directory. The recursive scan uses the original source tree with the exact logical application replacement; the actual-tree verifier separately proves correspondence and scans all new content. The reader limits are recorded in `SUMMARY.json` and are intentional safeguards, not silent omissions.

The large local `MEMBERS.jsonl` ledger is not intended for the safe review kit. Its SHA-256 is `cad2b4d5d3b7afa3973569fdcb4024cdeba49c9c418cebc8589fad1085fc6b35`. The link/special-member ledger SHA-256 is `d325a7d5f8b909a93100a44cf993143105b6f967ef3e6d13b4f84c479abdbbac`. Keep those local along with raw error/font witnesses; do not include the large ledger or witness font bytes in a review kit.
