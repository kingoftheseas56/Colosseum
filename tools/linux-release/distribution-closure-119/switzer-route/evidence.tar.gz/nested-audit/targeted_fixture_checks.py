#!/usr/bin/env python3
"""Narrow checks based on actual fixture bytes and accompanying test source."""
import json,hashlib,struct,zlib,sys,io,re
from pathlib import Path
H=Path(__file__).resolve().parent;sys.path.insert(0,str(H/'vendor'))
import libarchive
rows=json.load(open(H/'ERROR-REVIEW.json'));ctx=json.load(open(H/'fixture-context/INDEX.json'))
results=[]
# This particular lzop seed stores one uncompressed block. No decoder required.
e=next(x for x in rows if x['path'].endswith('!seed.lzo'))
b=(H/e['witness']).read_bytes();assert b[:9]==b'\x89LZO\x00\r\n\x1a\n'
assert len(b)==167
assert zlib.adler32(b[9:38])==int.from_bytes(b[38:42],'big')
original_len,stored_len,adler=struct.unpack('>III',b[42:54]);payload=b[54:-4]
assert original_len==stored_len==len(payload)==109
assert b[-4:]==b'\0'*4 and zlib.adler32(payload)==adler
assert b'switzer' not in payload.lower()
results.append({'path':e['path'],'result':'INSPECTED_COMPLETE_UNCOMPRESSED_LZOP_BLOCK','container_sha256':e['sha256'],'payload_bytes':len(payload),'payload_sha256':hashlib.sha256(payload).hexdigest(),'header_adler32_valid':True,'data_adler32_valid':True,'payload_type':'plain ASCII nursery-rhyme fixture','no_font_magic':True})
for rec in ctx:
 name=rec['member'].rsplit('/',1)[-1]
 if not re.fullmatch(r'encrypt-(aes(128|192|256)(-noentropy)?|pkware-noentropy)\.zip',name):continue
 password='no-entropy' if 'noentropy' in name else 'foofoofoo'
 # These are published test-vector passwords, not user/account credentials.
 out={'path':rec['member'],'container_sha256':rec['sha256'],'password_source':'libzip/src/regress/encryption-nonrandom-*.test or encryption-remove.test','members':[]}
 try:
  with libarchive.memory_reader((H/rec['evidence_file']).read_bytes(),format_name='zip',passphrase=password) as z:
   for ent in z:
    if not ent.isfile:continue
    data=b''.join(ent.get_blocks());assert len(data)<100000
    out['members'].append({'name':str(ent.pathname),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'no_switzer_marker':b'switzer' not in data.lower(),'plain_ascii':data.isascii()})
  out['result']='DECRYPTED_PUBLISHED_TEST_VECTOR'
 except Exception as x:out.update(result='REMAINS_OPAQUE',reason=str(x))
 results.append(out)
context=[]
for rec in ctx:
 if not rec['member'].endswith(('.cpp','.cc')):continue
 lines=(H/rec['evidence_file']).read_text(errors='replace').splitlines()
 for i,l in enumerate(lines):
  if ('encrypted.7z' in l or 'encrypted_header.7z' in l or 'brotli-4G' in l or 'brotli-4GB' in l):
   context.append({'source_member':rec['member'],'source_sha256':rec['sha256'],'line':i+1,'excerpt':'\n'.join(lines[max(0,i-2):i+4])})
(H/'TARGETED-FIXTURE-CHECKS.json').write_text(json.dumps({'checks':results,'source_context':context},indent=2)+'\n')
print(json.dumps(results,indent=2))
