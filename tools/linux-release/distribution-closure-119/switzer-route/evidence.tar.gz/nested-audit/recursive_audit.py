#!/usr/bin/env python3
"""Read-only, streaming source-delivery font audit with one logical overlay.

Never extracts archive paths, follows archive symlinks, runs member programs,
modifies input files, or repacks the proposed delivery. All evidence is placed
under this script's directory. Standard compression, tar, ZIP, and ar recurse.
"""
import argparse, bz2, collections, datetime, gzip, hashlib, io, json, lzma, os
from pathlib import Path
import re, shutil, sys, tarfile, tempfile, time, traceback, zipfile
from fontTools.ttLib import TTFont, TTCollection
import zstandard

HERE=Path(__file__).resolve().parent
BASE=HERE.parent
ROOT=BASE/'source-delivery'
REPLACEMENT=BASE/'switzer-correction-work/colosseum-7792bd1d9-no-switzer-PROPOSAL.tar.gz'
ORIGINAL='application/colosseum-7792bd1d9b3a41185cea522a9984ecd6586e3b44.tar.gz'
CHUNK=1024*1024
MAX_MEMBER=4*1024**3
MAX_TOTAL=150*1024**3
MAX_DEPTH=20
MAX_SPOOL=1024**3
MIN_FREE=512*1024**2
WITNESS=2*1024**2
FONT_EXT=('.otf','.ttf','.ttc','.otc','.woff','.woff2')
ZIP_EXT=('.zip','.jar','.whl','.cbz','.epub','.docx','.xlsx','.pptx','.apk','.kmz','.pk3','.xpi')
UNSUPPORTED_EXT=('.7z','.rar','.cbr','.cab','.iso','.lz','.lzo','.lz4','.br','.Z')
MARKERS=(b'switzer', 'switzer'.encode('utf-16le'), 'switzer'.encode('utf-16be'))
FONT_MAGIC=(b'\x00\x01\x00\x00',b'OTTO',b'ttcf',b'wOFF',b'wOF2',b'true',b'typ1')

class LimitError(Exception): pass

class Observed:
    """Observe each input's raw bytes exactly once; archive replay is separate."""
    def __init__(self, source, audit, label, limit=MAX_MEMBER):
        self.source=source;self.audit=audit;self.label=label;self.n=0
        self.h=hashlib.sha256();self.prefix=bytearray();self.tail=b''
        self.marker=False;self.limit=limit
    def read(self,n=-1):
        if n is None or n<0:n=CHUNK
        data=self.source.read(min(n,CHUNK))
        if not data:return b''
        self.n+=len(data);self.audit.counts['bytes_observed']+=len(data)
        if self.n>self.limit:raise LimitError(f'member limit {self.limit} exceeded')
        if self.audit.counts['bytes_observed']>MAX_TOTAL:raise LimitError('total byte budget exceeded')
        self.h.update(data)
        if len(self.prefix)<WITNESS:self.prefix.extend(data[:WITNESS-len(self.prefix)])
        sample=(self.tail+data).lower()
        if any(x in sample for x in MARKERS):self.marker=True
        self.tail=sample[-32:]
        return data
    def drain(self):
        while self.read(CHUNK):pass

class Replay(io.RawIOBase):
    """Prepend already-observed sniff bytes without observing them twice."""
    def __init__(self,head,rest):self.head=memoryview(head);self.offset=0;self.rest=rest
    def readable(self):return True
    def readinto(self,b):
        d=self.read(len(b));b[:len(d)]=d;return len(d)
    def read(self,n=-1):
        if n<0:
            parts=[]
            while True:
                q=self.read(CHUNK)
                if not q:return b''.join(parts)
                parts.append(q)
        if self.offset<len(self.head):
            d=self.head[self.offset:self.offset+n].tobytes();self.offset+=len(d);return d
        return self.rest.read(n)

def fixture_path(label):
    return bool(re.search(r'(?i)(^|/)(tests?|testdata|test-data|fixtures?|fuzz(?:ing)?|corpus|corpora|samples?)(/|!)',label))

def kind_of(head,label):
    low=label.lower()
    if head.startswith(b'\x1f\x8b'):return 'gzip'
    if head.startswith(b'\xfd7zXZ\x00'):return 'xz'
    if head.startswith(b'BZh') and head[3:4] in (b'1',b'2',b'3',b'4',b'5',b'6',b'7',b'8',b'9'):return 'bzip2'
    if head.startswith(b'\x28\xb5\x2f\xfd'):return 'zstd'
    if head.startswith(b'!<arch>\n'):return 'ar'
    if head.startswith((b'PK\x03\x04',b'PK\x05\x06',b'PK\x07\x08')) or low.endswith(ZIP_EXT):return 'zip'
    if head.startswith(b'7z\xbc\xaf\x27\x1c'):return 'unsupported:7z'
    if head.startswith(b'Rar!\x1a\x07'):return 'unsupported:rar'
    if head.startswith(b'MSCF'):return 'unsupported:cab'
    if head.startswith(b'\x1f\x9d'):return 'unsupported:compress-Z'
    if head.startswith(b'LZIP'):return 'unsupported:lzip'
    if head.startswith(b'\x04\x22\x4d\x18'):return 'unsupported:lz4'
    if head.startswith(FONT_MAGIC):return 'font'
    if low.endswith(FONT_EXT):return 'font'
    if len(head)>=512:
        try:
            ti=tarfile.TarInfo.frombuf(head[:512],'utf-8','surrogateescape')
            if ti is not None:return 'tar'
        except (tarfile.HeaderError,ValueError):pass
    if low.endswith(('.tar','.tgz','.tbz','.tbz2','.txz')):return 'tar'
    if low.endswith(('.gz','.gzip')):return 'gzip'
    if low.endswith('.xz'):return 'xz'
    if low.endswith(('.bz2','.bzip2')):return 'bzip2'
    if low.endswith(('.zst','.zstd')):return 'zstd'
    if low.endswith(UNSUPPORTED_EXT):return 'unsupported:extension'
    return 'ordinary'

class Audit:
    def __init__(self):
        self.started=time.time();self.counts=collections.Counter();self.kinds=collections.Counter()
        self.errors=[];self.fonts=[];self.hits=[];self.name_hits=[];self.raw_markers=[]
        self.archives=[];self.index_checks=[];self.spool_bytes=0;self.max_spool_bytes=0
        self.manifest=json.load(open(BASE/'switzer-correction-work/switzer-manifest.json'))
        self.forbidden={r['sha256']:r['path'] for r in self.manifest['files']}
        self.index={r['path']:r for r in json.load(open(ROOT/'SHA256-INDEX.json'))}
        self.ledger=open(HERE/'MEMBERS.jsonl','w',encoding='utf-8')
        self.links=open(HERE/'LINKS-AND-SPECIALS.jsonl','w',encoding='utf-8')
        self.tmp=HERE/'temporary';self.tmp.mkdir(exist_ok=True)
        self.witness_dir=HERE/'error-witnesses';self.witness_dir.mkdir(exist_ok=True)
        self.progress_last=0
    def progress(self,label):
        if time.time()-self.progress_last>20:
            print(json.dumps({'event':'progress','elapsed_s':round(time.time()-self.started),
                'files':self.counts['regular_payloads'],'bytes_observed':self.counts['bytes_observed'],
                'archives':len(self.archives),'fonts':len(self.fonts),'errors':len(self.errors),
                'current':label}),flush=True);self.progress_last=time.time()
    def error(self,label,kind,e,obs=None):
        row={'path':label,'kind':kind,'exception':type(e).__name__,'reason':str(e),
             'fixture_path_heuristic':fixture_path(label),'classification':'UNREVIEWED',
             'complete_payload_witness':False}
        if obs:
            row.update(bytes_read=obs.n,sha256=obs.h.hexdigest(),raw_switzer_marker=obs.marker)
            if obs.n<=WITNESS:
                p=self.witness_dir/(obs.h.hexdigest()+'.bin');p.write_bytes(obs.prefix)
                row['witness']=str(p.relative_to(HERE));row['complete_payload_witness']=True
        self.errors.append(row)
    def spool(self,stream):
        t=tempfile.TemporaryFile(dir=self.tmp);size=0
        try:
            while True:
                d=stream.read(CHUNK)
                if not d:break
                size+=len(d);self.spool_bytes+=len(d)
                self.max_spool_bytes=max(self.max_spool_bytes,self.spool_bytes)
                if size>MAX_SPOOL or self.spool_bytes>MAX_SPOOL:raise LimitError('temporary archive spool budget exceeded')
                if size%(64*CHUNK)<CHUNK and shutil.disk_usage(HERE).free<MIN_FREE:raise LimitError('minimum free disk budget reached')
                t.write(d)
            t.seek(0);return t,size
        except:
            t.close();self.spool_bytes-=size;raise
    def scan(self,source,label,expected_size=None,depth=0,physical=None):
        self.progress(label)
        obs=Observed(source,self,label)
        kind='unclassified';failure=None
        try:
            if depth>MAX_DEPTH:raise LimitError('maximum recursion depth exceeded')
            head=obs.read(512);kind=kind_of(head,label);self.kinds[kind]+=1
            replay=Replay(head,obs)
            if 'switzer' in label.rsplit('!',1)[-1].lower():self.name_hits.append({'path':label,'kind':kind})
            if kind in ('gzip','xz','bzip2','zstd'):
                rec={'path':label,'kind':kind,'depth':depth,'status':'running'};self.archives.append(rec)
                wrappers={'gzip':gzip.GzipFile,'xz':lzma.LZMAFile,'bzip2':bz2.BZ2File}
                if kind=='zstd':decompressed=zstandard.ZstdDecompressor().stream_reader(replay,closefd=False)
                else:decompressed=wrappers[kind](fileobj=replay,mode='rb') if kind=='gzip' else wrappers[kind](replay,mode='rb')
                lname=label
                for suffix in ('.gzip','.gz','.xz','.bz2','.bzip2','.zstd','.zst'):
                    if lname.lower().endswith(suffix):lname=lname[:-len(suffix)];break
                else:
                    for suffix in ('.tgz','.txz','.tbz2','.tbz'):
                        if lname.lower().endswith(suffix):lname=lname[:-len(suffix)]+'.tar';break
                    else:lname=label+'[decompressed]'
                try:self.scan(decompressed,label+'!<'+kind+'>/'+lname.rsplit('!',1)[-1].rsplit('/',1)[-1],None,depth+1)
                finally:decompressed.close()
                rec['status']='inspected'
            elif kind=='tar':
                rec={'path':label,'kind':kind,'depth':depth,'status':'running','members':0};self.archives.append(rec)
                with tarfile.open(fileobj=replay,mode='r|') as tf:
                    for member in tf:
                        rec['members']+=1;child=label+'!'+member.name
                        if member.isfile():
                            with tf.extractfile(member) as f:self.scan(f,child,member.size,depth+1)
                        else:
                            self.counts['non_regular_members']+=1
                            row={'path':child,'type':member.type.decode('ascii','replace'),'linkname':member.linkname}
                            self.links.write(json.dumps(row,ensure_ascii=True)+'\n')
                            if 'switzer' in (member.name+' '+member.linkname).lower():self.name_hits.append(row)
                rec['status']='inspected'
            elif kind=='zip':
                rec={'path':label,'kind':kind,'depth':depth,'status':'running','members':0};self.archives.append(rec)
                if physical:
                    obs.drain();zsource=open(physical,'rb');spool_size=0
                else:zsource,spool_size=self.spool(replay)
                try:
                    with zipfile.ZipFile(zsource) as zf:
                        for m in zf.infolist():
                            rec['members']+=1;child=label+'!'+m.filename
                            if m.is_dir():self.counts['non_regular_members']+=1;continue
                            try:
                                with zf.open(m) as f:self.scan(f,child,m.file_size,depth+1)
                            except Exception as e:self.error(child,'zip-member',e)
                    rec['status']='inspected'
                finally:zsource.close();self.spool_bytes-=spool_size
            elif kind=='ar':
                rec={'path':label,'kind':kind,'depth':depth,'status':'running','members':0};self.archives.append(rec)
                f=io.BufferedReader(replay);assert f.read(8)==b'!<arch>\n'
                longnames=b''
                while True:
                    header=f.read(60)
                    if not header:break
                    if len(header)!=60 or header[58:60]!=b'`\n':raise ValueError('invalid ar member header')
                    name=header[:16].decode('utf-8','replace').strip();size=int(header[48:58]);data=f.read(size)
                    if len(data)!=size:raise ValueError('truncated ar member')
                    if size%2:f.read(1)
                    rec['members']+=1
                    if name=='//':longnames=data;continue
                    if name=='/':continue
                    if name.startswith('#1/'):
                        n=int(name[3:]);name=data[:n].decode('utf-8','replace');data=data[n:]
                    elif re.fullmatch(r'/\d+',name):name=longnames[int(name[1:]):].split(b'/\n',1)[0].decode('utf-8','replace')
                    self.scan(io.BytesIO(data),label+'!'+name.rstrip('/'),len(data),depth+1)
                rec['status']='inspected'
            elif kind=='font':
                data=bytearray()
                while True:
                    d=replay.read(CHUNK)
                    if not d:break
                    data.extend(d)
                    if len(data)>128*1024**2:raise LimitError('font parsing size budget exceeded')
                fs=TTCollection(io.BytesIO(data),lazy=True).fonts if data[:4]==b'ttcf' else [TTFont(io.BytesIO(data),lazy=True)]
                names=set();family=set()
                try:
                    for font in fs:
                        if 'name' in font:
                            for n in font['name'].names:
                                value=n.toUnicode(errors='replace');names.add(value)
                                if n.nameID in (1,2,4,6,16,17):family.add(value)
                    fontrow={'path':label,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),
                             'names':sorted(family),'switzer_any_name':any('switzer' in n.lower() for n in names)}
                    self.fonts.append(fontrow)
                    if fontrow['switzer_any_name']:self.hits.append({'match':'font-internal-name',**fontrow})
                finally:
                    for font in fs:font.close()
            elif kind.startswith('unsupported:'):
                raise ValueError('unsupported archive/compression candidate requires explicit review')
            obs.drain()
        except Exception as e:
            failure=e
            try:obs.drain()
            except Exception as drain_error:
                self.error(label,kind+'-drain',drain_error)
            self.error(label,kind,e,obs)
            if kind in ('gzip','xz','bzip2','zstd','tar','zip','ar'):
                for rec in reversed(self.archives):
                    if rec['path']==label:rec['status']='parse-error';break
        if expected_size is not None and obs.n!=expected_size:
            self.error(label,'size-mismatch',ValueError(f'expected {expected_size}, observed {obs.n}'),obs)
        row={'path':label,'bytes':obs.n,'sha256':obs.h.hexdigest(),'kind':kind}
        if failure:row['parse_error']=type(failure).__name__
        self.ledger.write(json.dumps(row,ensure_ascii=True)+'\n');self.counts['regular_payloads']+=1
        if obs.h.hexdigest() in self.forbidden:self.hits.append({'match':'original-font-sha256','original_font':self.forbidden[obs.h.hexdigest()],**row})
        if obs.marker:self.raw_markers.append(row)
        return row
    def run(self):
        files=sorted(p for p in ROOT.rglob('*') if p.is_file())
        before={str(p.relative_to(ROOT)):(p.stat().st_size,p.stat().st_mtime_ns,p.stat().st_ino) for p in files}
        for p in files:
            relative=str(p.relative_to(ROOT));actual=REPLACEMENT if relative==ORIGINAL else p
            with actual.open('rb') as f:row=self.scan(f,'source-delivery/'+relative,actual.stat().st_size,0,actual)
            self.counts['physical_delivery_files']+=1
            if relative in self.index:
                expected=self.index[relative]
                self.index_checks.append({'path':relative,'status':'LOGICAL_REPLACEMENT' if relative==ORIGINAL else ('MATCH' if row['sha256']==expected['sha256'] and row['bytes']==expected['bytes'] else 'MISMATCH'),'observed_sha256':row['sha256'],'observed_bytes':row['bytes'],'original_index_sha256':expected['sha256']})
        after={str(p.relative_to(ROOT)):(p.stat().st_size,p.stat().st_mtime_ns,p.stat().st_ino) for p in files}
        self.ledger.close();self.links.close()
        for name,data in [('ARCHIVES.json',self.archives),('FONTS.json',self.fonts),('ERRORS.json',self.errors),('SWITZER-HITS.json',self.hits),('SWITZER-PATH-MENTIONS.json',self.name_hits),('SWITZER-RAW-MARKERS.json',self.raw_markers),('TOP-LEVEL-INDEX-CHECKS.json',self.index_checks)]:
            (HERE/name).write_text(json.dumps(data,indent=2,ensure_ascii=True)+'\n')
        ledgers={p.name:hashlib.file_digest(p.open('rb'),'sha256').hexdigest() for p in (HERE/'MEMBERS.jsonl',HERE/'LINKS-AND-SPECIALS.jsonl')}
        result={'status':'REVIEW_ERRORS' if self.errors else ('FAIL_SWITZER_FOUND' if self.hits else 'PASS_TECHNICAL_SCAN'),
            'started_utc':datetime.datetime.fromtimestamp(self.started,datetime.timezone.utc).isoformat(),
            'completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'elapsed_seconds':round(time.time()-self.started,2),
            'scope':'Every regular physical file in source-delivery, including its 3,897-file index, with exactly one logical application archive replacement; recursive archive inputs included. No repackaging, licensing clearance, or release approval.',
            'logical_replacement':{'path':ORIGINAL,'source':str(REPLACEMENT.relative_to(BASE)),'sha256':next(r['observed_sha256'] for r in self.index_checks if r['path']==ORIGINAL)},
            'counts':dict(self.counts),'kinds':dict(self.kinds),'font_files_parsed':len(self.fonts),'archive_layers':len(self.archives),'errors_requiring_review':len(self.errors),
            'original_hash_or_internal_font_name_matches':self.hits,'filename_mentions':len(self.name_hits),'raw_content_marker_files':len(self.raw_markers),
            'original_delivery_stat_snapshots_unchanged':before==after,'indexed_files':len(self.index),'index_checked_files':len(self.index_checks),
            'index_mismatches':[r for r in self.index_checks if r['status']=='MISMATCH'],
            'limits':{'max_member_bytes':MAX_MEMBER,'max_total_observed_bytes':MAX_TOTAL,'max_depth':MAX_DEPTH,'max_spool_bytes':MAX_SPOOL,'minimum_free_disk_bytes':MIN_FREE},
            'peak_archive_spool_bytes':self.max_spool_bytes,'ledger_sha256':ledgers,
            'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
        (HERE/'SUMMARY.json').write_text(json.dumps(result,indent=2)+'\n')
        print(json.dumps({'event':'complete',**result}),flush=True)

if __name__=='__main__':Audit().run()
