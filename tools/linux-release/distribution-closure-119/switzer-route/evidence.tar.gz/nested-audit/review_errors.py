#!/usr/bin/env python3
"""Retry uncommon archive formats and font parsers; retain all unresolved errors."""
import io,json,hashlib,sys,collections,re,multiprocessing,time
from pathlib import Path
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'vendor'))
import libarchive,brotli
import recursive_audit as r
OUT=HERE/'supplemental';OUT.mkdir(exist_ok=True);r.HERE=OUT

class BlockReader:
 def __init__(self,blocks):self.blocks=iter(blocks);self.buffer=b''
 def read(self,n=-1):
  n=1048576 if n<0 else n
  while not self.buffer:
   try:self.buffer=next(self.blocks)
   except StopIteration:return b''
  q=self.buffer[:n];self.buffer=self.buffer[n:];return q

def brotli_blocks(data):
 d=brotli.Decompressor()
 for p in range(0,len(data),1024):
  q=d.process(data[p:p+1024])
  if q:yield q
 if not d.is_finished():raise ValueError('incomplete Brotli stream')

def retry_worker(index,e,data,connection):
 out=OUT/f'case-{index:04d}';out.mkdir(exist_ok=True);r.HERE=out
 a=r.Audit();result={}
 try:
  if e['kind']=='font':a.scan(io.BytesIO(data),e['path'],len(data))
  elif e['path'].lower().endswith('.br'):
   a.scan(BlockReader(brotli_blocks(data)),e['path']+'!<brotli>',None,1)
  else:
   form='raw' if e['kind'] in ('unsupported:compress-Z','unsupported:lz4','unsupported:lzip') else 'all'
   if e['kind']=='zip':form='zip'
   if e['kind']=='tar':form='tar'
   with libarchive.memory_reader(data,format_name=form) as archive:
    for entry in archive:
     if entry.isfile:a.scan(BlockReader(entry.get_blocks()),e['path']+'!<libarchive>/'+str(entry.pathname),entry.size,1)
  result['status']='resolved' if not a.errors else 'errors'
 except Exception as x:result.update(status='failed',exception=type(x).__name__,reason=str(x))
 finally:
  a.ledger.close();a.links.close()
 result.update(counts=dict(a.counts),fonts=a.fonts,archives=a.archives,errors=a.errors,hits=a.hits,raw_markers=a.raw_markers)
 (out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
 connection.send(result);connection.close()

def classify_fixture(err,data):
 path=err['path'];kind=err['kind']
 fixture=err['fixture_path_heuristic'] or bool(re.search('(?i)(fuzz|corpus|test|invalid|broken|malformed|corrupt|/regress/)',path))
 if 'gnu-sparse-big.tar!' in path:return 'EXPECTED_RESOURCE_LIMIT_SPARSE_TEST_FIXTURE'
 if 'encrypted' in err.get('reason','') and fixture:return 'EXPECTED_ENCRYPTED_TEST_FIXTURE'
 if data is None:return 'EXPECTED_DERIVED_TEST_ERROR' if fixture else 'UNRESOLVED_NO_COMPLETE_WITNESS'
 if len(data)<=128 and not any(m in data for m in (b'PK\x03\x04',b'\x1f\x8b',b'OTTO',b'wOFF',b'wOF2')):
  if fixture:return 'EXPECTED_TINY_NONARCHIVE_TEST_PLACEHOLDER'
 if kind=='font':return 'EXPECTED_MALFORMED_OR_NONFONT_TEST_INPUT' if fixture else 'UNRESOLVED_FONT_PARSE_FAILURE'
 if fixture:return 'EXPECTED_MALFORMED_OR_SPECIAL_FORMAT_TEST_FIXTURE'
 return 'UNRESOLVED_NONFIXTURE_CONTAINER'

def main():
 errors=json.load(open(HERE/'ERRORS.json'));review=[];allfonts=[];allerrors=[];allhits=[];allarchives=[];allmarkers=[];counts=collections.Counter()
 forbidden={x['sha256'] for x in json.load(open(r.BASE/'switzer-correction-work/switzer-manifest.json'))['files']}
 for i,e in enumerate(errors):
  row=dict(e);data=None
  if e.get('complete_payload_witness') and e.get('witness'):
   data=(HERE/e['witness']).read_bytes();assert hashlib.sha256(data).hexdigest()==e['sha256']
  row['original_font_hash_match']=e.get('sha256') in forbidden
  row['raw_switzer_marker']=any(x in (data or b'').lower() for x in r.MARKERS)
  row['embedded_font_magic_offsets']={m.hex():[mt.start() for mt in re.finditer(re.escape(m),data or b'')][:16] for m in r.FONT_MAGIC if m in (data or b'')}
  row['classification']=classify_fixture(e,data)
  retry=data is not None and (e['kind']=='font' or e['kind'].startswith('unsupported:') or (e['kind']=='zip' and data.startswith(b'PK')) or e['kind']=='tar')
  if retry:
   print(json.dumps({'event':'retry','index':i,'kind':e['kind'],'path':e['path']}),flush=True)
   parent,child=multiprocessing.Pipe(False)
   process=multiprocessing.Process(target=retry_worker,args=(i,e,data,child));process.start();child.close()
   deadline=time.time()+5
   if parent.poll(5):
    try:res=parent.recv()
    except EOFError:res={'status':'failed','reason':'worker ended without result'}
    process.join(1)
   else:
    process.terminate();process.join(2);res={'status':'timeout','reason':'5-second parser bound reached'}
   parent.close()
   if process.is_alive():process.kill();process.join()
   row['retry_status']=res['status']
   if res['status']=='resolved':row['classification']='RESOLVED_FONT_PARSED_WITH_BROTLI' if e['kind']=='font' else 'RESOLVED_BY_ALTERNATIVE_ARCHIVE_READER'
   if 'reason' in res:row['retry_reason']=res['reason']
   row['retry_payloads']=res.get('counts',{}).get('regular_payloads',0);row['retry_font_files']=len(res.get('fonts',[]));row['retry_new_errors']=len(res.get('errors',[]))
   counts.update(res.get('counts',{}));allfonts+=res.get('fonts',[]);allerrors+=res.get('errors',[]);allhits+=res.get('hits',[]);allarchives+=res.get('archives',[]);allmarkers+=res.get('raw_markers',[])
  review.append(row)
 for name,data in [('ERROR-REVIEW.json',review),('SUPPLEMENTAL-ERRORS.json',allerrors),('SUPPLEMENTAL-FONTS.json',allfonts),('SUPPLEMENTAL-ARCHIVES.json',allarchives),('SUPPLEMENTAL-HITS.json',allhits),('SUPPLEMENTAL-RAW-MARKERS.json',allmarkers)]:
  (HERE/name).write_text(json.dumps(data,indent=2)+'\n')
 summary={'classifications':dict(collections.Counter(x['classification'] for x in review)),'counts':dict(counts),'fonts_parsed':len(allfonts),'hits':allhits,'new_errors':len(allerrors),'libarchive_version':libarchive.ffi.version_number(),'brotli_version':brotli.__version__,'parser_timeout_seconds':5}
 (HERE/'SUPPLEMENTAL-SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
if __name__=='__main__':main()
