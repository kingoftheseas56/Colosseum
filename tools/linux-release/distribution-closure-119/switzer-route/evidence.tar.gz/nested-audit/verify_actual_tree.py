#!/usr/bin/env python3
import json,hashlib,sys,collections
from pathlib import Path
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'vendor'))
import recursive_audit as r
OUT=HERE/'actual-tree-added-content';OUT.mkdir(exist_ok=True);r.HERE=OUT
NEW=r.BASE/'source-delivery-independent-fonts'
NEW_APP='application/colosseum-7792bd1d9-independent-fonts-excluded.tar.gz'
EXPECTED_APP='2b25937aa546a488db9f0caf44e94f888ff3e4c806ef89ab296f5a97f22008b3'
old=json.load(open(r.ROOT/'SHA256-INDEX.json'));prior={x['path']:x for x in old}
newidx=json.load(open(NEW/'SHA256-INDEX.json'));newidx={x['path']:x for x in newidx}
a=r.Audit();records=[];changes=[];mismatches=[]
paths=sorted(p for p in NEW.rglob('*') if p.is_file())
before={str(p.relative_to(NEW)):(p.stat().st_size,p.stat().st_mtime_ns,p.stat().st_ino) for p in paths}
for p in paths:
 name=str(p.relative_to(NEW));sha=hashlib.file_digest(p.open('rb'),'sha256').hexdigest();size=p.stat().st_size
 row={'path':name,'bytes':size,'sha256':sha}
 if name==NEW_APP:
  row['coverage']='previous-full-recursive-scan-logical-replacement'
  row['expected_sha256']=EXPECTED_APP
  if sha!=EXPECTED_APP:mismatches.append(row)
 elif name in prior and sha==prior[name]['sha256'] and size==prior[name]['bytes']:
  row['coverage']='previous-full-recursive-scan-byte-identical'
 else:
  row['coverage']='additional-content-scanned';changes.append(row)
  with p.open('rb') as f:a.scan(f,'source-delivery-independent-fonts/'+name,size,0,p)
 if name in newidx:
  row['new_index_matches']=sha==newidx[name]['sha256'] and size==newidx[name]['bytes']
  if not row['new_index_matches']:mismatches.append(row)
 elif name!='SHA256-INDEX.json':mismatches.append({'path':name,'reason':'not in new source index'})
 records.append(row)
a.ledger.close();a.links.close()
after={str(p.relative_to(NEW)):(p.stat().st_size,p.stat().st_mtime_ns,p.stat().st_ino) for p in NEW.rglob('*') if p.is_file()}
removed=sorted(set(prior)-{str(p.relative_to(NEW)) for p in paths})
result={'status':'PASS' if not mismatches and not a.errors and not a.hits and before==after and removed==[r.ORIGINAL] else 'REVIEW',
 'actual_tree':str(NEW),'actual_files':len(paths),'indexed_files':len(newidx),'coverage_counts':dict(collections.Counter(x['coverage'] for x in records)),
 'removed_original_paths':removed,'replacement_sha256':EXPECTED_APP,'all_actual_files_match_new_index':not mismatches,
 'tree_unchanged_during_check':before==after,'mismatches':mismatches,'added_content_scan_errors':a.errors,'added_content_scan_font_hits':a.hits,'added_content_font_files':a.fonts,'filename_mentions':a.name_hits,
 'raw_content_switzer_mentions':len(a.raw_markers),'important_scope':'License/route documents and source-code references may mention Switzer. That is not font-byte redistribution.'}
(HERE/'ACTUAL-TREE-VERIFICATION.json').write_text(json.dumps(result,indent=2)+'\n')
(HERE/'ACTUAL-TREE-FILES.json').write_text(json.dumps(records,indent=2)+'\n')
(HERE/'ACTUAL-TREE-ADDITIONS.json').write_text(json.dumps(changes,indent=2)+'\n')
print(json.dumps(result,indent=2))
