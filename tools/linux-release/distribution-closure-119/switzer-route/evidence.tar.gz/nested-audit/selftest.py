import io,json,gzip,bz2,lzma,tarfile,zipfile,sys,hashlib
from pathlib import Path
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'vendor'))
import recursive_audit as r
root=HERE/'selftest';root.mkdir(exist_ok=True);r.HERE=root
original=r.BASE/'app-source/assets/fonts/Switzer-Regular.otf'
if not original.is_file():
 with tarfile.open(r.ROOT/r.ORIGINAL,'r:gz') as t:
  m=next(m for m in t if m.name.endswith('/assets/fonts/Switzer-Regular.otf'))
  data=t.extractfile(m).read()
else:data=original.read_bytes()
assert hashlib.sha256(data).hexdigest() in {q['sha256'] for q in json.load(open(r.BASE/'switzer-correction-work/switzer-manifest.json'))['files']}
a=r.Audit();z=io.BytesIO()
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED) as f:f.writestr('../not-a-font.dat',data)
b=io.BytesIO()
with tarfile.open(fileobj=b,mode='w') as f:
 p=bz2.compress(lzma.compress(gzip.compress(z.getvalue())));m=tarfile.TarInfo('/outside.zip.gz.xz.bz2');m.size=len(p);f.addfile(m,io.BytesIO(p))
a.scan(io.BytesIO(b.getvalue()),'nested.tar',len(b.getvalue()))
assert not a.errors,a.errors
assert any(h['match']=='original-font-sha256' for h in a.hits)
assert any(h['match']=='font-internal-name' for h in a.hits)
assert not (root/'outside.zip.gz.xz.bz2').exists()
a.scan(io.BytesIO(b'not a zip fixture'), 'tests/malformed.zip',17)
assert a.errors and a.errors[-1]['kind']=='zip'
a.ledger.close();a.links.close()
result={'status':'PASS','assertions':['Renamed original font found by SHA-256','Renamed original font internal Switzer name detected by magic','Nested tar -> bzip2 -> xz -> gzip -> ZIP recursively inspected','Absolute and parent-traversal member names are never extracted','Malformed ZIP produced an explicit error record'], 'positive_control_font_sha256':hashlib.sha256(data).hexdigest(),'hits':a.hits,'errors':a.errors}
(root/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
