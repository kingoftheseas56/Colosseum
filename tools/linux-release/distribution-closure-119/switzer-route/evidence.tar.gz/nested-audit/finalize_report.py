#!/usr/bin/env python3
import json,hashlib,collections,datetime
from pathlib import Path
H=Path(__file__).resolve().parent
summary=json.load(open(H/'SUMMARY.json'));actual=json.load(open(H/'ACTUAL-TREE-VERIFICATION.json'))
review=json.load(open(H/'ERROR-REVIEW.json'));supp=json.load(open(H/'SUPPLEMENTAL-SUMMARY.json'));target=json.load(open(H/'TARGETED-FIXTURE-CHECKS.json'))
app=[x for x in review if x['path'].startswith('source-delivery/application/')]
checks=target['checks'];resolved_containers={x['path'] for x in checks if x['result']!='REMAINS_OPAQUE'}
def targeted_resolved(row):
 return row['path'] in resolved_containers or any(('!'+c+'!') in row['path'] for c in resolved_containers)
remaining=[r for r in review if r not in app and not r['classification'].startswith('RESOLVED') and not targeted_resolved(r)]
fonts=[r for r in remaining if r['kind']=='font'];others=[r for r in remaining if r['kind']!='font']
for row in remaining:
 row['qualification']='This record remains a decoder/resource exception; fixture naming is context, not proof of decoded content absence.'
(H/'REMAINING-EXCEPTIONS.json').write_text(json.dumps({'records':remaining,'font_parse_records':len(fonts),'other_records':len(others),'notes':['Records can repeat the same underlying fixture at different decoder layers or in independently retained upstream archives.','Names indicating tests, fuzzing, malformed input, or encryption do not by themselves prove contents.','All unchanged upstream source inputs remain byte-identical to the prior verified source index. No regression inputs were deleted or rewritten.']},indent=2)+'\n')
appbytes=[]
for sha in sorted(set(r['sha256'] for r in app)):
 row=next(r for r in app if r['sha256']==sha);data=(H/row['witness']).read_bytes()
 appbytes.append({'sha256':sha,'bytes':len(data),'occurrences':sum(r['sha256']==sha for r in app),'complete_payload_ascii_repr':repr(data),'contains_archive_or_font_payload':False})
(H/'APPLICATION-EXCEPTIONS.json').write_text(json.dumps({'archive_sha256':summary['logical_replacement']['sha256'],'parse_warnings':len(app),'unique_complete_payloads':appbytes,'conclusion':'All application ZIP parse warnings are fully inspected 1-, 14-, 19-, or 49-byte nonarchive placeholders. They are not encrypted or opaque archives. No application archive residual remains after those complete-byte checks.'},indent=2)+'\n')
ver=json.load(open(H.parent/'switzer-correction-work/EXCLUSION-VERIFICATION.json'))
result={'status':'PASS_TARGETED_EXCLUSION_WITH_DOCUMENTED_BOUNDED_SCAN_EXCEPTIONS','completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'safe_statement':'No detected Switzer font payloads. Exactly four original application fonts were removed, all other application members remain identical, and all prior third-party source inputs remain byte-identical. The broader recursive scan is bounded and retains documented inherited malformed, encrypted, unsupported, and expansion-fixture exceptions.',
 'not_claimed':['No claim of zero decoder blind spots or inspection of every opaque payload.','No licensing determination, Corresponding Source clearance, or release approval.','No exclusion, alteration, or rewriting of legitimate third-party regression inputs.'],
 'application_archive_sha256':summary['logical_replacement']['sha256'],'removed_original_font_files':ver['excluded_exact_paths'],'unchanged_other_application_members':ver['remaining_members_unchanged'],
 'full_recursive_counts':summary['counts'],'archive_layers':summary['archive_layers'],'successfully_parsed_font_occurrences_initial':summary['font_files_parsed'],'additional_font_occurrences_with_brotli':supp['fonts_parsed'],
 'detected_original_font_hash_matches':0,'detected_switzer_internal_font_name_matches':0,
 'application_parse_warnings':len(app),'application_unique_complete_nonarchive_placeholder_payloads':len(appbytes),'application_opaque_exceptions':0,
 'initial_third_party_error_records':len(review)-len(app),'alternative_reader_resolved_original_records':sum(r['classification'].startswith('RESOLVED') for r in review),
 'additional_targeted_resolved_original_records':sum(targeted_resolved(r) for r in review),'remaining_third_party_exception_records':len(remaining),'remaining_font_parser_exception_records':len(fonts),
 'actual_tree':actual,'limits':summary['limits'],'alternative_parser_time_bound_seconds':5,'peak_archive_spool_bytes':summary['peak_archive_spool_bytes'],
 'original_files_unchanged':summary['original_delivery_stat_snapshots_unchanged'],'indexed_prior_input_mismatches':summary['index_mismatches'],'large_local_evidence_ledger_sha256':summary['ledger_sha256'],
 'remaining_material_categories':['Five legacy/encrypted ZIP member failures remain (including the intentionally broken ZIP); seven published AES/PKWARE vectors were successfully decrypted and inspected.','Two encrypted 7z fixture containers remain opaque to libarchive. Their accompanying source documents a 19-byte fake executable and published test-vector password; source evidence is not an independent decryption.','Other damaged or unsupported 7z/ZIP/Lzip/ISO/compression fixtures remain explicitly listed, including a ZIP member using an unsupported compression method.','Four identical 4G.br fixtures reached the 5-second alternate parser bound. Companion Qt source identifies them as 4 GiB expansion tests.','One 60,000,000,000-byte sparse virtual tar member reached the 4 GiB per-payload limit, producing three records; the intact input fixture archive remains preserved.','82 malformed or nonfont test payloads still fail font-name parsing; their raw payload SHA-256 values were nevertheless checked and do not match any original Switzer font.'],
 'extra_fixture_findings':['The LZO seed is a completely verified single stored 109-byte ASCII block, not an opaque compressed font. Header/data Adler-32 checks pass.','The application archive’s 313 failed CBZ/ZIP parses are exactly four distinct complete ASCII/garbage placeholder byte sequences, never opaque containers.'],
 'evidence_files':['AUDIT-REPORT.md','FINAL-AUDIT.json','SUMMARY.json','ACTUAL-TREE-VERIFICATION.json','ACTUAL-TREE-FILES.json','ACTUAL-TREE-ADDITIONS.json','APPLICATION-EXCEPTIONS.json','REMAINING-EXCEPTIONS.json','ERRORS.json','ERROR-REVIEW.json','SUPPLEMENTAL-SUMMARY.json','SUPPLEMENTAL-ERRORS.json','TARGETED-FIXTURE-CHECKS.json','SWITZER-HITS.json','FONTS.json','SUPPLEMENTAL-FONTS.json','ARCHIVES.json','TOP-LEVEL-INDEX-CHECKS.json','selftest/RESULT.json']}
(H/'FINAL-AUDIT.json').write_text(json.dumps(result,indent=2)+'\n')
report=f'''# Independent-font source boundary: technical audit

## Result

No Switzer font payload was detected. The target-specific exclusion is verified: exactly the four original Switzer OTF members are absent, while all {ver['remaining_members_unchanged']:,} other application members are unchanged. The replacement application archive SHA-256 is `{summary['logical_replacement']['sha256']}`.

This is a bounded technical audit, not a claim of zero blind spots, a licensing determination, Corresponding Source clearance, or release approval.

## Actual prepared source tree

The actual `source-delivery-independent-fonts` tree contains {actual['actual_files']:,} physical files. All {actual['indexed_files']:,} indexed file sizes and hashes verify. The {actual['coverage_counts']['previous-full-recursive-scan-byte-identical']:,} unchanged prior inputs match the previous source index byte-for-byte; the one renamed replacement application archive matches the audited archive; and all {actual['coverage_counts']['additional-content-scanned']} added or changed notice/route/index files were scanned separately. Only the replaced original application archive path is removed. No third-party source input was removed or rewritten.

## Recursive inspection

- {summary['counts']['regular_payloads']:,} payload records, {summary['counts']['bytes_observed']:,} bytes observed across {summary['archive_layers']:,} archive/compression layers.
- Tar, gzip, xz, bzip2, ZIP, ar, and zstd were inspected recursively; font magic as well as filename suffixes selected font inspection. Alternative libarchive/Brotli readers inspected additional formats.
- {summary['font_files_parsed']:,} initial font occurrences plus {supp['fonts_parsed']} recovered font occurrences were parsed. No original four-font hash or Switzer internal-name match was found.
- Archive paths were never extracted or followed. Inputs were not repacked. Peak archive spool use was {summary['peak_archive_spool_bytes']:,} bytes (about 15 MB).
- A positive control placed an original Switzer font under a different name through tar → bzip2 → xz → gzip → ZIP. Both its exact hash and internal name were detected; absolute and parent-traversal archive names were not extracted.

## Application exceptions: fully closed by inspecting their complete bytes

All {len(app)} application ZIP/CBZ parse warnings are tiny nonarchive placeholders. There are exactly four distinct payloads: `x` (301 occurrences, one byte), `vault-fixture-stub\\n` (10 occurrences, 19 bytes), `fake-cbz-bytes` (one, 14 bytes), and a 49-byte plain garbage string ending in three control bytes. None is an encrypted or opaque archive. See `APPLICATION-EXCEPTIONS.json` for exact hashes and complete representations. There are no remaining opaque application archive inputs.

## Inherited third-party exceptions: explicitly retained, not claimed fully decoded

The initial scan recorded {len(review)-len(app)} third-party error records. Alternative readers resolved {sum(r['classification'].startswith('RESOLVED') for r in review)} original records; targeted fixture checks resolved {sum(targeted_resolved(r) for r in review)} more. The remaining {len(remaining)} records may repeat one fixture at multiple decoder layers or across independently retained upstream source archives. They are enumerated without suppression in `REMAINING-EXCEPTIONS.json`.

Important qualifications:

- Five original legacy/encrypted ZIP member failures remain, including the intentionally broken ZIP. Seven published encryption vectors were independently decrypted and inspected successfully.
- Two encrypted 7z fixture containers remain opaque to the alternative reader. Their accompanying source describes a 19-byte fake executable and provides a public test password. This source context is not a substitute for decryption.
- Other malformed or reader-incompatible 7z/ZIP/Lzip/ISO/compression regression inputs remain explicitly documented, including the ZIP member with unsupported compression. The test/fuzz path alone is not proof of its decoded contents.
- Four byte-identical 4G.br fixtures hit the five-second alternate-reader bound. Companion Qt test source identifies their expected 4 GiB expansion. They were not fully expanded.
- A 60,000,000,000-byte sparse virtual tar member hit the 4 GiB payload bound. Three error records describe this one fixture. No bulk sparse output was written.
- {len(fonts)} malformed or nonfont test payloads still fail font-name parsing. Their complete raw payload hashes were checked; none matches the four original font files. No assertion is made that every malformed font name table is decodable.
- The LZO seed originally needing an unavailable decoder was independently resolved: its only block is stored, uncompressed ASCII, 109 bytes, with both header and data checksums verified.

No upstream fixture was deleted or transformed to force a clean scanner result. All original third-party source archives retain their exact prior hashes. The defensible conclusion is zero detected Switzer font payloads with decisive four-file application exclusion, not blanket recursive completeness.

## Evidence and reproduction

Primary compact evidence: `FINAL-AUDIT.json`, `ACTUAL-TREE-VERIFICATION.json`, `APPLICATION-EXCEPTIONS.json`, `REMAINING-EXCEPTIONS.json`, `ERRORS.json`, `ERROR-REVIEW.json`, `SUPPLEMENTAL-SUMMARY.json`, and `TARGETED-FIXTURE-CHECKS.json`. Full counts, font inventories, archive inventories, top-level digests, and self-tests are retained alongside these files.

Scripts: `recursive_audit.py`, `selftest.py`, `review_errors.py`, `verify_actual_tree.py`, `collect_fixture_context.py`, `targeted_fixture_checks.py`, and `finalize_report.py`. Supplementary parser dependencies were installed only under this audit directory (Brotli 1.2.0 and libarchive-c 5.3, using system libarchive 3.7.4). Main scanning additionally uses the environment's fontTools and zstandard.

Run the scripts from the parent `linux-distribution-119` directory. The recursive scan uses the original source tree with the exact logical application replacement; the actual-tree verifier separately proves correspondence and scans all new content. The reader limits are recorded in `SUMMARY.json` and are intentional safeguards, not silent omissions.

The large local `MEMBERS.jsonl` ledger is not intended for the safe review kit. Its SHA-256 is `{summary['ledger_sha256']['MEMBERS.jsonl']}`. The link/special-member ledger SHA-256 is `{summary['ledger_sha256']['LINKS-AND-SPECIALS.jsonl']}`. Keep those local along with raw error/font witnesses; do not include the large ledger or witness font bytes in a review kit.
'''
(H/'AUDIT-REPORT.md').write_text(report)
# Compact delivery inventory excludes original font/error witnesses and the large ledger.
safe=[x for x in result['evidence_files'] if (H/x).is_file()]+['recursive_audit.py','selftest.py','review_errors.py','verify_actual_tree.py','collect_fixture_context.py','targeted_fixture_checks.py','finalize_report.py']
manifest=[]
for n in safe:
 p=H/n;manifest.append({'path':n,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(H/'SAFE-EVIDENCE-FILES.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'status':result['status'],'safe_evidence_files':len(manifest),'safe_evidence_bytes':sum(r['bytes'] for r in manifest),'final_audit_sha256':hashlib.sha256((H/'FINAL-AUDIT.json').read_bytes()).hexdigest(),'report_sha256':hashlib.sha256((H/'AUDIT-REPORT.md').read_bytes()).hexdigest(),'remaining_records':len(remaining)},indent=2))
