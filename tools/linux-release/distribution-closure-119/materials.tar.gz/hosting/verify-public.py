#!/usr/bin/env python3
"""Unauthenticated release GET verification using actual API URLs and trusted local files."""
import argparse,hashlib,json,pathlib,urllib.parse,urllib.request

def digest(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  while b:=f.read(1024*1024):h.update(b)
 return h.hexdigest()

def verify(pages_path,prepared,script,out):
 pages=json.loads(pathlib.Path(pages_path).read_text());rows=[r for page in pages for r in page]
 prepared=pathlib.Path(prepared);paths=list(prepared.iterdir())+[pathlib.Path(script)]
 expected={p.name:p for p in paths}
 if len(expected)!=len(paths) or any(not p.is_file() for p in paths):raise ValueError('duplicate names or non-files')
 out=pathlib.Path(out);out.mkdir(exist_ok=False);receipts=[]
 for name,path in sorted(expected.items()):
  matches=[a for a in rows if a['name']==name]
  if len(matches)!=1:raise ValueError(f'missing or duplicate asset: {name}')
  a=matches[0];url=a['browser_download_url'];u=urllib.parse.urlparse(url)
  if u.scheme!='https' or u.hostname!='github.com' or u.username or u.password:raise ValueError('unexpected download origin')
  if a.get('state')!='uploaded' or a['size']!=path.stat().st_size:raise ValueError('remote metadata mismatch')
  # No authorization header, cookies, token or gh credentials are sent.
  h=hashlib.sha256();size=0
  with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Colosseum-source-receiving-check'}),timeout=120) as response, (out/name).open('xb') as dst:
   if response.status!=200:raise ValueError('HTTP status is not 200')
   while buf:=response.read(1024*1024):h.update(buf);size+=len(buf);dst.write(buf)
  if size!=path.stat().st_size or h.hexdigest()!=digest(path):raise ValueError(f'download bytes differ: {name}')
  receipts.append({'name':name,'id':a['id'],'browser_download_url':url,'bytes':size,'sha256':h.hexdigest(),'authenticated':False})
 (out/'public-verification-receipt.json').write_text(json.dumps(receipts,indent=2)+'\n')

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('api_pages');p.add_argument('prepared');p.add_argument('--script',default='reassemble.py');p.add_argument('--output',required=True);a=p.parse_args()
 verify(a.api_pages,a.prepared,a.script,a.output)
