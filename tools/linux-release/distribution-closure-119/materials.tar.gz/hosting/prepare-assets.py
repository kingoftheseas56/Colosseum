#!/usr/bin/env python3
"""Local-only split and SHA256 manifest generation; never publishes."""
import argparse, hashlib, json, pathlib, re

def check_asset_count(parts):
    # Three generated manifests plus separately uploaded reassemble.py.
    if parts + 4 > 1000:
        raise ValueError('release exceeds 1000 asset cap including four support assets')

def prepare(inputs, output, chunk_size=400*1024*1024):
    if not 1 <= chunk_size <= 400*1024*1024:
        raise ValueError('chunk size must be 1..419430400 bytes')
    paths=[pathlib.Path(p) for p in inputs]
    names=[p.name for p in paths]
    if len(set(names))!=len(names) or any(not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9._-]*',n) for n in names):
        raise ValueError('unique portable basenames required')
    if any(not p.is_file() or p.stat().st_size==0 for p in paths):
        raise ValueError('all inputs must be nonempty regular files')
    check_asset_count(sum((p.stat().st_size + chunk_size - 1)//chunk_size for p in paths))
    output=pathlib.Path(output); output.mkdir(exist_ok=False)
    records=[]; assets=[]
    for path in paths:
        whole=hashlib.sha256(); total=0; parts=[]
        with path.open('rb') as src:
            idx=0
            while data:=src.read(chunk_size):
                name=f'{path.name}.part{idx:04d}'
                (output/name).write_bytes(data)
                row={'name':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
                parts.append(row); assets.append(row); whole.update(data);total+=len(data);idx+=1
        records.append({'name':path.name,'bytes':total,'sha256':whole.hexdigest(),'parts':parts})
    check_asset_count(len(assets))
    manifest={'schema':1,'chunk_size':chunk_size,'published':False,'files':records}
    (output/'asset-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    (output/'SHA256SUMS.parts').write_text(''.join(f"{a['sha256']}  {a['name']}\n" for a in assets))
    (output/'SHA256SUMS.files').write_text(''.join(f"{a['sha256']}  {a['name']}\n" for a in records))
    return manifest

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',required=True);p.add_argument('inputs',nargs='+');a=p.parse_args()
    prepare(a.inputs,a.output)
