# Colosseum 1.1.9 Linux: durable delivery approval plan

Prepared 2026-10-19. This is a plan and tested local preparation tooling, NOT a publication, a written source offer, or a completeness certification. No release, tag, repository setting or production upload was created. No public asset URL is asserted. The final candidate is commit `7792bd1d9b3a41185cea522a9984ecd6586e3b44`, package SHA256 `ddf011d2955de39e19375d492284867db09d48a80f3b4fe717da086a3b3ec67b`, 333715118 bytes. The parent investigation owns independently verifying that package and qualifying the final materials.

## Verified route and limits

Live authenticated GitHub `get_repo` on 2026-10-19 returned:
- `kingoftheseas56/Colosseum`, repository ID 1281950460, owner kingoftheseas56, public, not archived, linked owner admin/push true. This existing owned public repository is the selected eventual release hosting route.
- `kingoftheseas56/Dots-Colosseum`, repository ID 1408421660, same owner, private, not archived, linked owner admin/push true. Appropriate for the requested receiving/approval entry, NOT sufficient public source delivery for freely downloadable binaries. Do not change visibility.

Primary provider documentation checked on 2026-10-19:
1. https://docs.github.com/en/repositories/releasing-projects-on-github/about-releases : up to 1000 assets per release, each strictly under 2 GiB (2147483648 bytes); no aggregate release-size or bandwidth limit stated. This is not a perpetual service or retention guarantee.
2. https://docs.github.com/en/rest/releases/assets : public release assets can be fetched without authentication; private assets need repository Contents read access. Use actual returned `browser_download_url`, asset ID, size and digest, never guessed published links. API binary downloads may return HTTP 200 or 302.
3. https://docs.github.com/en/actions/how-tos/manage-workflow-runs/remove-workflow-artifacts and https://docs.github.com/en/organizations/managing-organization-settings/configuring-the-retention-period-for-github-actions-artifacts-and-logs-in-your-organization : Actions artifacts expire and can be removed with their run. Default retention is 90 days, configurable public 1–90/private 1–400 days; custom changes do not retroactively repair old artifacts. This collection is reported as 14 days. Read actual `expires_at` before determining the transfer deadline, do not infer it solely from today's date.
4. Upload/view commands documented at https://cli.github.com/manual/gh_release_upload and https://cli.github.com/manual/gh_release_view . Upload to an existing approved release, never use `--clobber`.

The existing acquired-source ZIP is 2002420956 bytes, 145062692 bytes below the provider's 2 GiB boundary. It therefore fits GitHub Releases as one file. Its supplied SHA256 is `0ef75bd1de3b0a45c6f9f77b18b47716a7562152febf565b78b85419b5753c57`; the parent subsequently confirmed independent verification of that ZIP hash, plus 7937 indexed files with zero mismatches. This worker has not independently repeated the historical ZIP receipt. The parent reported a separate GitHub download connector ceiling of 512 MiB; do not mislabel this a GitHub hosting limit.

## Concrete large-bundle alternative

Select split delivery, even when a whole ZIP fits: parts at most 419430400 bytes (400 MiB), plus a small JSON manifest, SHA256 lists and reassembly script. This remains on the same already-owned public repository; no new service, account, bill, credentials or access grants required. Five parts suffice for the existing ZIP: four 419430400-byte parts and one 324699356-byte part. Part hashes cannot be calculated from the whole hash and are intentionally NOT invented. Final corrected source bundles may differ in size and hash; prepare their actual bytes, never reuse these historical ZIP pins as final.

The original indexes enumerate 585 Ubuntu files and 15 upstream archive records (600 file/archive entries; not a claim that only 15 upstream components exist). The largest indexed archive is `upstream/qtwebengine/qtwebengine-everywhere-src-6.11.1.tar.xz`, 578914356 bytes. Individually splitting this produces 419430400 + 159483956 bytes. `indexed-source-assets.json` preserves index paths, lengths, hashes and provenance URLs, not public delivery URLs.

If the corrected aggregate exceeds 2 GiB, the same 400 MiB multipart scheme works without a new host. If the asset count approaches 1000, package the approved source tree into fewer source archives before splitting, reserving capacity for the package, notices, manifests and scripts. Do not put hundreds of giant archives into Git blobs or Git LFS merely to work around release assets. A private fork/cache/Actions artifact remains temporary receiving storage only.

## Distribution/access and retention acceptance gates

The actual bundled original license texts are available under `review/retained/payload/opt/colosseum/licenses/Common-License-Texts/`. The following is a routing analysis, not a blanket legal clearance or assignment of licenses to every component:
- GPL-2 section 3's final paragraph permits equivalent access to source from the same designated place as object downloads. File SHA256 `8177f97513213526df2cf6184d8ff986c675afb514d4e68a404010521b880643`.
- GPL-3 section 6(d) requires equivalent no-extra-charge access and clear directions near object code if another server hosts source; availability remains the distributor's responsibility. File SHA256 `3972dc9744f6499f0f9b2dbf76696f2ae7ad8af9b23dde66d6af86c9dfb36986`.
- LGPL-2.1 section 6(d) concerns equivalent access from the same place to the specified relinking materials; section 4 concerns library object/source distribution. File SHA256 `dc626520dcd53a22f727af3ee42c770e56c97a64fe3adb063799d8ab032fe551`.
- LGPL-3 supplements GPL-3; section 4's Combined Work requirements and chosen relinking mechanism require component-specific evaluation. File SHA256 `e3a994d82e644b03a792a930f574002658412f62407f5fee083f2555c5f23118`.

Use the accompanying-source download route, with final notices/recipes/component indexes linked next to the exact binary, rather than creating a written-offer obligation. Do not say all components require source; use the notices review's actual licenses. Do not announce a three-year cutoff borrowed from written-offer alternatives: that is not the selected mechanism. Recommended owner policy for approval: preserve these exact source assets and notices without scheduled expiry, at least throughout binary availability and thereafter for as long as the applicable terms require; retain a second owner-controlled byte-identical backup and migrate links before host loss. GitHub retention alone does not discharge this responsibility. Policy is proposed, not adopted or promised on the user's behalf.

A review packet or checksum index is not itself complete corresponding source. Current source collection relates to the prior package and must be reconciled by the parent work. The eventual deliverable must include corrected application source at the current pin, retained dependency sources, explicit Chromium corrections if required, recipes/relink inputs, original notices, and the new manifests. Publish no installer before equivalent source access is ready. Approval entry in private Dots is not the public source location. Actual unauthenticated download and SHA256 verification of every public asset is the acceptance test.

## Local preparation (safe, no publication)

Run only once final source and notice bundles have been validated. Names below are local role variables, not claims that these files already exist. Use unique portable basenames.

```sh
python3 prepare-assets.py --output prepared-assets "$FINAL_SOURCE_BUNDLE" "$FINAL_NOTICES_BUNDLE"
python3 reassemble.py prepared-assets/asset-manifest.json --output receiving-test
(cd receiving-test && sha256sum -c ../prepared-assets/SHA256SUMS.files)
(cd prepared-assets && sha256sum -c SHA256SUMS.parts)
```

`prepare-assets.py` writes actual per-part/whole SHA256 values and sizes and refuses an existing output folder. `reassemble.py` verifies every part and final reconstructed byte stream; it deliberately does not unpack archives. Failed runs may leave partial output; never treat that directory as validated. Four local tests cover split/reassemble equality, corrupted-part rejection, bounds/name validation, and the 1000-asset boundary including all four support assets, recorded in `test-results.txt` (exit 0). Tests used synthetic small input, NOT the large source ZIP. Manifest `published:false` records local generation, not remote verification.

## After separate final approval only: upload and verify

These are prepared commands, NOT executed. Hemanth/Codex chooses and verifies the destination existing release/tag. Creating a release or tag is outside this task; if there is no approved destination, stop. Do not guess a tag or use latest release implicitly. Do not change existing assets.

```sh
set -euo pipefail
REPO=kingoftheseas56/Colosseum
: "${APPROVED_RELEASE_TAG:?Set the exact separately approved existing release tag}"
gh release view "$APPROVED_RELEASE_TAG" --repo "$REPO" --json tagName,isDraft,url,assets > before-upload.json
# Inspect before-upload.json, require the exact approved tag and no asset-name collisions.
# Confirm all material gates above before this consequential command.
gh release upload "$APPROVED_RELEASE_TAG" prepared-assets/* reassemble.py --repo "$REPO"
gh release view "$APPROVED_RELEASE_TAG" --repo "$REPO" --json tagName,isDraft,url,assets > after-upload.json
# A draft is not public delivery. Publication remains a separate human approval/action.
```

After publication authorized and completed by the release owner, retrieve release assets from the actual API, not a constructed download URL:

```sh
: "${APPROVED_RELEASE_ID:?Use numeric release ID returned by GitHub for the approved release}"
gh api --paginate "repos/$REPO/releases/$APPROVED_RELEASE_ID/assets?per_page=100" --slurp > published-asset-pages.json
python3 verify-public.py published-asset-pages.json prepared-assets --script reassemble.py --output public-receiving
python3 reassemble.py public-receiving/asset-manifest.json --output public-reassembled
(cd public-reassembled && sha256sum -c ../public-receiving/SHA256SUMS.files)
```

`verify-public.py` performs unauthenticated streamed GETs using the returned URLs and checks every downloaded byte against the separately retained local approved asset, including manifests and script. It was syntax-checked, not exercised against unpublished assets. It writes a receipt only after all expected assets pass. Retain API receipts and downloaded-byte hashes in the final packet. Page through all assets. Compare the expected names/counts, reject duplicate or absent entries, require actual public unauthenticated GET success (not merely a HEAD or authenticated CLI success), and compare downloaded manifest/script hashes to the separately retained approved hashes. Store the exact verified release URL and individual returned asset URLs alongside the binary in release notes. This plan contains no invented public URL.

## Status

Hosting route/size/access analysis and local preparation tool tests: READY FOR REVIEW. The parent reports the prior source ZIP received, its exact hash verified, and 7937 indexed files checked with zero mismatches. Current-candidate source material has been assembled in source-delivery; local tar/split/reassembly results are recorded separately in PREPARATION-RECEIPT.json when complete. Actual notice/source completeness and owner retention acceptance remain separate gates. Public hosted-and-verified state: NOT DONE, explicitly excluded until final approval. Do not mark public delivery complete from local preparation.

## Completed local source preparation

The current-candidate source archive is now actually split and independently reassembled. `PREPARATION-RECEIPT.json` records all commands with exit 0, the five actual part SHA256 values, and full-file `cmp` equality. Archive: `colosseum-1.1.9-7792bd1d9-source-materials.tar.gz`, 2003416952 bytes, SHA256 `ed66bb813829fb2ddf8976d952006dac320a02bba623fa3f094a71eabaf92d03`. Parts 0000–0003 are 419430400 bytes each; part 0004 is 325695352 bytes. Actual files/manifests are in `../hosting-assets/`. The proposed source-only upload is 9 assets including the separately supplied reassembly script. No notices bundle is asserted completed here. Use `hosting-assets` instead of the illustrative `prepared-assets` directory in the upload commands for this actual source set. Additional approved notices/package assets must also fit the 1000-asset ceiling. Transport preparation is complete for these bytes; material sufficiency and publication remain separate.
