import importlib.util,pathlib,tempfile,unittest
ROOT=pathlib.Path(__file__).parent

def load(name):
 s=importlib.util.spec_from_file_location(name,ROOT/(name+'.py'));m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
p=load('prepare-assets');r=load('reassemble')
class Tests(unittest.TestCase):
 def test_roundtrip(self):
  with tempfile.TemporaryDirectory(dir=ROOT) as d:
   d=pathlib.Path(d);f=d/'example.tar';f.write_bytes(bytes(range(256))*33)
   m=p.prepare([f],d/'parts',1024);self.assertEqual(len(m['files'][0]['parts']),9)
   self.assertTrue(r.reassemble(d/'parts/asset-manifest.json',d/'out'));self.assertEqual(f.read_bytes(),(d/'out/example.tar').read_bytes())
 def test_corrupt_rejected(self):
  with tempfile.TemporaryDirectory(dir=ROOT) as d:
   d=pathlib.Path(d);f=d/'example';f.write_bytes(b'abcd');p.prepare([f],d/'parts',2);(d/'parts/example.part0000').write_bytes(b'zz')
   with self.assertRaises(ValueError):r.reassemble(d/'parts/asset-manifest.json',d/'out')
 def test_asset_count_includes_script(self):
  p.check_asset_count(996)
  with self.assertRaises(ValueError):p.check_asset_count(997)
 def test_bounds_and_names(self):
  with self.assertRaises(ValueError):p.prepare([],ROOT/'never',419430401)
  with self.assertRaises(ValueError):r.safe_name('../x')
  with self.assertRaises(ValueError):r.safe_name('')
if __name__=='__main__':unittest.main()
