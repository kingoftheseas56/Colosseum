#!/usr/bin/env python3
"""Verify each part, then reassemble and verify whole-file hash. No extraction."""
import argparse,hashlib,json,pathlib,re

def safe_name(n):
    if not isinstance(n,str) or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9._-]*',n):raise ValueError('unsafe asset name')
    return n

def reassemble(manifest,output):
    manifest=pathlib.Path(manifest);base=manifest.parent;data=json.loads(manifest.read_text())
    if data.get('schema')!=1:raise ValueError('unsupported schema')
    output=pathlib.Path(output);output.mkdir(exist_ok=False)
    for row in data['files']:
        name=safe_name(row['name']);whole=hashlib.sha256();size=0
        with (output/name).open('xb') as dst:
            for part in row['parts']:
                path=base/safe_name(part['name']);h=hashlib.sha256();count=0
                with path.open('rb') as src:
                    while buf:=src.read(1024*1024):h.update(buf);count+=len(buf);whole.update(buf);size+=len(buf);dst.write(buf)
                if count!=part['bytes'] or h.hexdigest()!=part['sha256']:raise ValueError(f'part mismatch: {path.name}')
        if size!=row['bytes'] or whole.hexdigest()!=row['sha256']:raise ValueError(f'whole-file mismatch: {name}')
    return True

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('manifest');p.add_argument('--output',required=True);a=p.parse_args()
    reassemble(a.manifest,a.output);print('All part and whole-file hashes verified; no archives extracted.')
