import pathlib,subprocess,hashlib,tarfile,json
w=pathlib.Path(__file__).resolve().parent
expected={}
for row in (w/'chromium-git-tree.z').read_bytes().split(b'\0'):
 if not row:continue
 meta,p=row.split(b'\t',1);mode,kind,oid=meta.decode().split();expected[p.decode()]={'mode':mode,'kind':kind,'git_sha1':oid}
seen={};different=[];extra=[];count=0
with tarfile.open(w/'qtwebengine-everywhere-src-6.11.1.tar.xz','r|xz') as t:
 for m in t:
  bits=m.name.split('/',1)
  if len(bits)<2 or not (m.isfile() or m.issym()):continue
  p=bits[1];size=len(m.linkname.encode()) if m.issym() else m.size
  g=hashlib.sha1(f'blob {size}\0'.encode());s=hashlib.sha256();data=[]
  if m.issym():raw=m.linkname.encode();g.update(raw);s.update(raw);data=[raw]
  else:
   f=t.extractfile(m)
   while chunk:=f.read(1048576):
    g.update(chunk);s.update(chunk)
    if size<5000000:data.append(chunk)
  seen[p]={'bytes':size,'git_sha1':g.hexdigest(),'sha256':s.hexdigest(),'type':'symlink' if m.issym() else 'file'}
  if p.startswith('src/3rdparty/'):
   q=p[len('src/3rdparty/'):];e=expected.get(q)
   if not e:extra.append(q)
   elif e['git_sha1']!=g.hexdigest():
    different.append({'path':q,'expected':e, 'observed':seen[p]})
    if data:
     out=w/'different-release-files'/q;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(b''.join(data))
  count+=1
  if count%20000==0: print(count,flush=True)
absent=[{'path':p,**e} for p,e in expected.items() if 'src/3rdparty/'+p not in seen]
summary={'commit':'58c11ad487f8a237cf0ac71cc3e818b52db150df','expected_count':len(expected),'archive_file_count':len(seen),'different':different,'absent':absent,'extra':extra,'matched':len(expected)-len(different)-len(absent),'gitlinks':[{'path':p,**e} for p,e in expected.items() if e['kind']=='commit']}
(w/'release-file-inventory.json').write_text(json.dumps(seen,indent=2)+'\n');(w/'chromium-coverage.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({k:v if not isinstance(v,list) else len(v) for k,v in summary.items()},indent=2))
