import json,pathlib,subprocess,posixpath,hashlib
w=pathlib.Path(__file__).resolve().parent;x=json.loads((w/'chromium-coverage.json').read_text());i=json.loads((w/'release-file-inventory.json').read_text());oids=sorted(set(a['expected']['git_sha1'] for a in x['different'])|set(a['git_sha1'] for a in x['absent']))
p=subprocess.run(['git','-C',str(w/'chromium.git'),'fetch','--no-tags','--filter=blob:none','origin',*oids],capture_output=True);(w/'supplement-fetch.log').write_bytes(p.stdout+p.stderr);p.check_returncode()
proof=[];supp=[]
for a in x['different']+x['absent']:
 oid=a.get('expected',a)['git_sha1'];raw=subprocess.check_output(['git','-C',str(w/'chromium.git'),'cat-file','blob',oid]);out=w/'git-supplement'/'src'/'3rdparty'/a['path'];out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(raw)
 supp.append({'path':'src/3rdparty/'+a['path'],'git_sha1':oid,'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw),'mode':a.get('expected',a)['mode']})
 if 'expected' in a:
  target=posixpath.normpath(posixpath.join(posixpath.dirname(a['path']),raw.decode()));visited=[]
  while 'src/3rdparty/'+target in i and any(d['path']==target for d in x['different']):
   if target in visited:raise RuntimeError('cycle')
   visited.append(target);d=next(d for d in x['different'] if d['path']==target);link=subprocess.check_output(['git','-C',str(w/'chromium.git'),'cat-file','blob',d['expected']['git_sha1']]).decode();target=posixpath.normpath(posixpath.join(posixpath.dirname(target),link))
  t=i.get('src/3rdparty/'+target);proof.append({'path':a['path'],'git_link_text':raw.decode(),'resolved_target':target,'release_file_sha256':a['observed']['sha256'],'target_sha256':None if not t else t['sha256'],'identical_to_target':bool(t and t['sha256']==a['observed']['sha256'])})
(w/'transformations.json').write_text(json.dumps(proof,indent=2)+'\n');(w/'supplement-index.json').write_text(json.dumps(supp,indent=2)+'\n');print('dereferences verified',sum(a['identical_to_target'] for a in proof),'/',len(proof));print('supplement entries',len(supp))
