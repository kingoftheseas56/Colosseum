import pathlib,json,hashlib,re,tarfile,io,posixpath,gzip
w=pathlib.Path(__file__).resolve().parent;r=w.parent/'review';inventory=json.loads((w/'release-file-inventory.json').read_text());proof=json.loads((w/'transformations.json').read_text());coverage=json.loads((w/'chromium-coverage.json').read_text());supp=list({a['path']:a for a in json.loads((w/'supplement-index.json').read_text()) if a['path'] not in {'.gitattributes','.gitignore','.tag'}}.values());rows=[]
for kind in ['webengine','pdf']:
 p=r/f'retained/payload/opt/colosseum/licenses/Qt-SBOM/qtwebengine-chromium-{kind}-6.11.1.spdx.json';d=json.loads(p.read_text())
 for package in d['packages']:
  match=re.search(r'Location within source: ([^\n]+)',package.get('comment',''))
  row={'sbom':p.name,'package':package['name'],'licenseDeclared':package.get('licenseDeclared'),'downloadLocation':package.get('downloadLocation')}
  if match:
   source=match[1];prefix='src/3rdparty/chromium/'+source+'/';paths=[p for p in inventory if p.startswith(prefix)];row.update(source_location=source,archive_prefix=prefix,file_count=len(paths),covered=bool(paths))
  else:row.update(source_location=None,note='Aggregate package, no source location supplied by publisher')
  rows.append(row)
(w/'chromium-sbom-coverage.json').write_text(json.dumps(rows,indent=2)+'\n')
# Independently repeat main-module tree comparison from received tree.
main=[]
for line in (r/'upstream/qtwebengine-git-tree.txt').read_text().splitlines():
 meta,path=line.split('\t',1);mode,kind,oid=meta.split();o=inventory.get(path);main.append({'path':path,'mode':mode,'kind':kind,'git_sha1':oid,'archive_git_sha1':o['git_sha1'] if o else None,'matches':bool(o and o['git_sha1']==oid)})
(w/'main-module-coverage.json').write_text(json.dumps(main,indent=2)+'\n')
for path in ['.gitattributes','.gitignore','.tag']:
 raw=(w/('main-module'+path)).read_bytes();exp=next(a for a in main if a['path']==path);oid=hashlib.sha1(f'blob {len(raw)}\0'.encode()+raw).hexdigest();assert oid==exp['git_sha1'];out=w/'git-supplement'/path;out.write_bytes(raw);supp.append({'path':path,'git_sha1':oid,'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw),'mode':exp['mode']})
(w/'supplement-index.json').write_text(json.dumps(supp,indent=2)+'\n')
with (w/'qtwebengine-git-metadata-and-symlinks.tar.gz').open('wb') as output, gzip.GzipFile(filename='', mode='wb', fileobj=output, mtime=0) as compressed, tarfile.open(fileobj=compressed,mode='w|') as t:
 for row in supp:
  raw=(w/'git-supplement'/row['path']).read_bytes();ti=tarfile.TarInfo(row['path']);ti.mode=int(row['mode'],8)&0o777;ti.mtime=0
  if row['mode']=='120000':ti.type=tarfile.SYMTYPE;ti.linkname=raw.decode();t.addfile(ti)
  else:ti.size=len(raw);t.addfile(ti,io.BytesIO(raw))
assert all(a['identical_to_target'] for a in proof)
assert not [a for a in rows if a.get('covered') is False]
assert not coverage['gitlinks'] and not coverage['extra']
main_different=[a for a in main if a['kind']=='blob' and not a['matches']];assert {a['path'] for a in main_different}=={'.tag','.gitignore','.gitattributes'}
# Export-subst .tag is publisher substitution of module commit.
commit='eb0793cc4b76e93cf669f586fd68c76019f40ec9'
assert inventory['.tag']['sha256']==hashlib.sha256((commit+'\n').encode()).hexdigest()
print(json.dumps({'main_matched':sum(a['matches'] for a in main),'main_export_transformations':3,'chromium_exact_blobs':coverage['matched'],'chromium_dereferenced_links':len(proof),'chromium_omitted_metadata':len(coverage['absent']),'nested_gitlinks':0,'sbom_entries':len(rows),'sbom_located_entries':sum(a.get('covered',False) for a in rows),'sbom_uncovered_entries':0,'supplement_entries':len(supp)},indent=2))
