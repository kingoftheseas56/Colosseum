"""Verify exact ICU producer -> SDK -> candidate byte identities, without execution."""
import hashlib,json,struct
from pathlib import Path
P=Path(__file__).resolve().parent
R=P.parent/'review'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def rpath(buf):
 assert buf[:6]==b'\x7fELF\x02\x01','ELF64 little endian required'
 phoff=struct.unpack_from('<Q',buf,32)[0];ents,num=struct.unpack_from('<HH',buf,54)
 ph=[struct.unpack_from('<IIQQQQQQ',buf,phoff+i*ents) for i in range(num)]
 dyn=next(x for x in ph if x[0]==2)
 tags={}
 for off in range(dyn[2],dyn[2]+dyn[5],16):
  tag,val=struct.unpack_from('<qQ',buf,off)
  if tag==0:break
  tags[tag]=val
 st=tags[5];seg=next(x for x in ph if x[0]==1 and x[3]<=st<x[3]+x[5])
 off=seg[2]+st-seg[3]+tags[15]
 end=buf.index(0,off)
 return off,buf[off:end]
proofs=json.loads((R/'qt-sdk-file-proofs.json').read_text())
results=[]
for p in proofs:
 if p['archive']!='icu-linux-Rhel8.6-x86_64.7z':continue
 name=p['archive_member'];a=P/'provisioning'/name;dev=P/'devel/lib'/name;sdk=P/'installer'/name
 assert a.read_bytes()==dev.read_bytes()
 old=a.read_bytes();new=sdk.read_bytes();off,val=rpath(old);off2,val2=rpath(new)
 assert val==b'libicudata.so.73' and val2==b'$ORIGIN' and off==off2
 replay=bytearray(old);replay[off:off+len(val)]=b'$ORIGIN'.ljust(len(val),b'\0')
 assert bytes(replay)==new
 assert sha(sdk)==p['original_sha256']
 candidate=P.parent/'candidate/root'/p['payload'];assert sha(candidate)==p['shipped_sha256']
 results.append(dict(member=name,provisioning_sha256=sha(a),devel_sha256=sha(dev),sdk_sha256=sha(sdk),rpath_offset=off,old_rpath=val.decode(),new_rpath=val2.decode(),replayed_sdk_match=True,current_candidate_sha256=sha(candidate),candidate_matches_retained_shipped_proof=True))
assert len(results)==3
archives=[]
for name,pin in [('qt-provisioning-icu73.2.7z','d2bbb7b2a9a9ee00dba5cc6a68137f6c8a98c27e'),('qt-provisioning-icu73.2-devel.7z','edc9cba31ffeac28bf7360c52b85b5e4d2f39043'),('qt-installer-icu73.2.7z','aef06d3070fcbda2d07f2a95a929f58a4474df25')]:
 p=P/name;assert hashlib.sha1(p.read_bytes()).hexdigest()==pin
 archives.append(dict(path=name,sha1=pin,sha256=sha(p),bytes=p.stat().st_size))
license=P/'devel/share/icu/73.2/LICENSE';assert license.read_bytes()==(R/'upstream/icu-candidate/notices/LICENSE').read_bytes()
out=dict(status='PASS',scope='Three Qt SDK ICU73.2 libraries; no claim of original source patch equivalence',archives=archives,files=results,producer_license_sha256=sha(license))
(P/'icu-byte-proof.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
