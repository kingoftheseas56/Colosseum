import pathlib,unittest,subprocess,tempfile,shutil,tarfile,io,json,hashlib
W=pathlib.Path(__file__).resolve().parent
class EvidenceTests(unittest.TestCase):
 def test_repeated_finish_is_idempotent(self):
  hashes=[]
  for _ in range(2):
   p=subprocess.run(['python',str(W/'finish_evidence.py')],capture_output=True,text=True);self.assertEqual(p.returncode,0,p.stderr)
   self.assertEqual(len(json.loads((W/'supplement-index.json').read_text())),93)
   with tarfile.open(W/'qtwebengine-git-metadata-and-symlinks.tar.gz') as t:
    names=t.getnames();self.assertEqual(len(names),93);self.assertEqual(len(set(names)),93)
   hashes.append(hashlib.sha256((W/'qtwebengine-git-metadata-and-symlinks.tar.gz').read_bytes()).hexdigest())
  self.assertEqual(hashes[0],hashes[1])
 def test_complete_reconstruction(self):
  p=subprocess.run(['python',str(W/'verify_reconstructed.py')],capture_output=True,text=True);self.assertEqual(p.returncode,0,p.stderr);r=json.loads(p.stdout);self.assertEqual(r['verified_reconstructed_git_blobs'],269220);self.assertEqual(r['unresolved'],[])
 def test_symlink_transformations(self):
  p=json.loads((W/'transformations.json').read_text());self.assertEqual(len(p),85);self.assertTrue(all(x['identical_to_target'] and x['target_sha256']==x['release_file_sha256'] for x in p))
 def test_supplement_payloads(self):
  rows=json.loads((W/'supplement-index.json').read_text());self.assertEqual(len(rows),93)
  for r in rows:
   b=(W/'git-supplement'/r['path']).read_bytes();self.assertEqual(hashlib.sha256(b).hexdigest(),r['sha256']);self.assertEqual(hashlib.sha1(f'blob {len(b)}\0'.encode()+b).hexdigest(),r['git_sha1'])
 def test_sbom_all_located_packages_covered(self):
  rows=json.loads((W/'chromium-sbom-coverage.json').read_text());self.assertEqual(sum(r.get('covered',False) for r in rows),141);self.assertFalse(any(r.get('covered') is False for r in rows))
 def test_corrupt_overlay_rejected(self):
  with tempfile.TemporaryDirectory() as tmp:
   p=pathlib.Path(tmp)
   for name in ['verify_reconstructed.py','release-file-inventory.json','main-module-coverage.json','chromium-git-tree.z']:shutil.copyfile(W/name,p/name)
   with tarfile.open(W/'qtwebengine-git-metadata-and-symlinks.tar.gz') as src,tarfile.open(p/'qtwebengine-git-metadata-and-symlinks.tar.gz','w:gz') as dst:
    changed=False
    for m in src:
     b=None if m.issym() else src.extractfile(m).read()
     if b is not None and not changed:b+=b'corruption';m.size=len(b);changed=True
     dst.addfile(m,None if b is None else io.BytesIO(b))
   r=subprocess.run(['python',str(p/'verify_reconstructed.py')],capture_output=True,text=True);self.assertNotEqual(r.returncode,0);self.assertIn('AssertionError',r.stderr)
if __name__=='__main__':unittest.main(verbosity=2)
