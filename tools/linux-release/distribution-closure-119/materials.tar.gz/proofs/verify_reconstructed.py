import hashlib,json,pathlib,tarfile
w=pathlib.Path(__file__).resolve().parent
inventory=json.loads((w/'release-file-inventory.json').read_text())
expected={}
for row in (w/'chromium-git-tree.z').read_bytes().split(b'\0'):
 if row:
  meta,p=row.split(b'\t',1);mode,kind,oid=meta.decode().split();expected['src/3rdparty/'+p.decode()]=oid
for row in json.loads((w/'main-module-coverage.json').read_text()):
 if row['kind']=='blob':expected[row['path']]=row['git_sha1']
with tarfile.open(w/'qtwebengine-git-metadata-and-symlinks.tar.gz') as t:
 for m in t:
  assert not m.name.startswith('/') and '..' not in pathlib.PurePosixPath(m.name).parts
  raw=m.linkname.encode() if m.issym() else t.extractfile(m).read();inventory[m.name]={'git_sha1':hashlib.sha1(f'blob {len(raw)}\0'.encode()+raw).hexdigest()}
wrong=[p for p,oid in expected.items() if inventory.get(p,{}).get('git_sha1')!=oid]
result={'expected_recursive_git_blobs':len(expected),'verified_reconstructed_git_blobs':len(expected)-len(wrong),'unresolved':wrong}
assert not wrong,result
(w/'reconstructed-validation.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
