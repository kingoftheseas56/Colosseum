# QtWebEngine Chromium source completeness

## Verdict

CLOSED for the exact publisher source pins and the current candidate Qt SDK binaries. The separately generated candidate-comparison.json establishes 4,933 unchanged payload files, with only the application executable changed among ELF files; no dependency ELF changed, no files were added or removed. This includes WebEngine/PDF and their original notices/SBOMs. Current candidate: commit 7792bd1d9b3a41185cea522a9984ecd6586e3b44; .deb SHA256 ddf011d2955de39e19375d492284867db09d48a80f3b4fe717da086a3b3ec67b. This is source-content coverage and transformation verification, not a full rebuild or a blanket legal clearance. Candidate-specific binary identity is established by the separate reconciliation report; this report must not itself be relabeled as evidence of a new binary build.

QtWebEngine module: eb0793cc4b76e93cf669f586fd68c76019f40ec9.
src/3rdparty: qt/qtwebengine-chromium, 58c11ad487f8a237cf0ac71cc3e818b52db150df.
Chromium commit tree: 7ef30355f87038a8e4d911959b6482a585668fb6.

## Acquired material

Official release source archive, 578,914,356 bytes:
https://download.qt.io/archive/qt/6.11/6.11.1/submodules/qtwebengine-everywhere-src-6.11.1.tar.xz
Actual mirror: https://qt.mirror.constant.com/archive/qt/6.11/6.11.1/submodules/qtwebengine-everywhere-src-6.11.1.tar.xz
SHA256: 679c66ccc6c158fc215e9c58ef160331ecd29974232e345c05161889f8667083.
Publisher checksum authority is the same official URL plus .sha256; a fresh copy is retained as publisher-archive.sha256.

The complete pinned Git tree was obtained with a shallow, blobless fetch from https://github.com/qt/qtwebengine-chromium.git. No complete Chromium repository/history download or WebEngine build was needed. The pinned commit object and recursive NUL-delimited tree listing are retained. Ninety original metadata/symlink blobs were then fetched by exact object IDs. Their Git SHA1 object identities and SHA256 payload hashes are recorded.

## Measured coverage and transformations

- All 267,442 tracked entries of the Chromium gitlink were inspected. There are no nested gitlinks.
- 267,352 archive members exactly match Git blob identities.
- The 85 remaining present members are Git symlinks exported by the publisher as regular files. Every archive file is byte-identical to its resolved target in the same archive. transformations.json records each link, target and both SHA256 values. No C/C++ or build-script source content divergence was found.
- Five absent paths are Git export metadata: root .gitattributes and .gitignore, two libavif Android .gitignore files and microsoft_dxheaders/src/.gitignore. All original bytes are supplied in the supplement.
- The main QtWebEngine module independently reproduces the original collector's 1,775 exact blob matches. Its only omitted paths are .gitattributes/.gitignore. Its .tag is exactly the module commit followed by newline, replacing the tracked $Format:%H$ template as directed by .gitattributes export-subst. All three original blobs are supplied for exact Git-tree reconstruction.
- The complete reconstructed main module plus Chromium tree verifies 269,220 tracked Git blobs, zero unresolved mismatches, using the source archive inventory and the 93-entry overlay.
- All 141 package source-location entries across the two original WebEngine/PDF Chromium SBOMs resolve to files under the archive's src/3rdparty/chromium tree. Eight aggregate package entries have no individual source location; their original NOASSERTION fields remain unchanged. Package-path presence alone is not the principal completeness proof; the full recursive Git-blob comparison above is.

Qt downstream changes are contained in the exact pinned tree, including its backported patch commits. A separate patch series is not necessary to recover their resulting source bytes. The recorded commit object identifies the last backport and its upstream review reference. Do not substitute stock Chromium source of the same version for this patched Qt tree.

## Build configuration scope

The original upstream-source-index.json qtwebengine entry retains the publisher's complete recorded CMake configure invocation, including FFMPEG_DIR=/usr/local/FFmpeg-n7.1.3, QT_DEPLOY_FFMPEG=TRUE, system libxml/libtiff OFF, precompiled headers OFF, CMake 3.30.5 and RelWithDebInfo. The release archive contains the exact CMake files, GN templates, Chromium BUILD.gn/GNI files, bundled third-party configuration and source. The main module pin is linked from the retained Qt publisher SPDX document; the original SDK archive/file/RPATH proofs supply binary correspondence. These receipts do not establish bit-for-bit reproducibility or supply an original generated args.gn/CMakeCache. Any separate toolchain/external-FFmpeg/build-relink issue remains in the build-materials review, not hidden by this source-tree verdict.

## Receiving and reconstruction

Keep the original publisher archive unmodified as the primary source asset. Deliver qtwebengine-git-metadata-and-symlinks.tar.gz alongside it and the checksum manifest. The overlay is only 93 small original Git metadata/link entries, not a duplicate source repository. Extract the publisher archive into an empty directory. To obtain its exact tracked Git representation, apply the overlay at the extracted qtwebengine-everywhere-src-6.11.1 root, replacing the 85 exported regular files with their original symlinks. Ordinary builds may instead use the publisher's already dereferenced files. Preserve the original publisher .tag separately if using the exact-Git overlay, which restores its template.

Verification scripts: verify_coverage.py streams the publisher archive and hashes every member; resolve_transformations.py obtains the original missing/link blobs and proves dereferencing; finish_evidence.py verifies main-module transformations and SBOM locations and generates the overlay; verify_reconstructed.py independently reads the overlay and checks every reconstructed Git blob. All four completed with exit 0. Raw download/fetch/progress logs and validation-summary.json are retained. Scripts expect the sibling original review directory. The Git tree receipt can be independently regenerated with:

    git init --bare chromium.git
    git -C chromium.git fetch --filter=blob:none --depth=1 https://github.com/qt/qtwebengine-chromium.git 58c11ad487f8a237cf0ac71cc3e818b52db150df
    git -C chromium.git ls-tree -r -z 58c11ad487f8a237cf0ac71cc3e818b52db150df > chromium-git-tree.z

Use the explicit commit, not FETCH_HEAD after fetching supplement blobs. The .gz inventory and tree receipts are lossless compressed versions of their corresponding files. No production repository write, tag, release, source offer or final public upload occurred in this investigation.

Six automated evidence tests passed, including deterministic two-run idempotence and deliberate overlay corruption rejected by the reconstructed-tree verifier; tests.log records the results.

## Additional build-input investigation

See WEBENGINE-BUILD-INPUTS.md and its primary-source/hash receipts. The generic FFMPEG_DIR/QT_DEPLOY_FFMPEG flags do not establish an external FFmpeg-n7.1.3 requirement for WebEngine. The pinned feature defaults, GN selection, publisher Chromium SBOM and actual candidate DT_NEEDED inspection support the bundled FFmpeg source path. No missing mandatory project-specific input was found; general-purpose tools and compatible development libraries are documented, without claiming a rebuilt binary.
