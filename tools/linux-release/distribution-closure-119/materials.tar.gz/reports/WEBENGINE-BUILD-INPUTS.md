# QtWebEngine build-input review

## External FFmpeg-n7.1.3 is not a demonstrated missing WebEngine input

The publisher's recorded generic configure invocation includes FFMPEG_DIR=/usr/local/FFmpeg-n7.1.3 and QT_DEPLOY_FFMPEG=TRUE. Neither variable is read by any of the pinned WebEngine CMake inputs inspected. Their presence does not establish that the module uses that prebuilt FFmpeg package.

Positive primary-source evidence identifies the actual WebEngine selection:

1. configure.cmake:684–688 defines webengine-system-ffmpeg with AUTODETECT FALSE. External FFmpeg requires the explicit WebEngine feature; the recorded publisher invocation does not enable it. The optional package search at lines 102–105 uses pkg-config, not FFMPEG_DIR.
2. src/core/CMakeLists.txt:471–478 maps QT_FEATURE_webengine_system_ffmpeg to the GN use_system_ffmpeg flag. It does not map either generic variable. Lines 435–441 separately select proprietary codecs and Chrome branding; do not turn that on merely to replicate the unrelated FFmpeg directory flag.
3. src/3rdparty/chromium/third_party/ffmpeg/BUILD.gn:438–477 uses external libavcodec/libavformat/libavutil only inside use_system_ffmpeg. Lines 514–522 select ffmpeg_internal when false. The entire internal source, architecture-specific config and build files are present and Git-verified in the supplied release archive.
4. The unchanged publisher Chromium WebEngine SPDX package named QtWebEngine-Chromium-WebEngine-ffmpeg locates the component at third_party/ffmpeg. Its original NOASSERTION declarations remain untouched.
5. The actual current candidate's libQt6WebEngineCore.so.6 was extracted and readelf -d inspected. None of its 36 DT_NEEDED entries is libavcodec, libavformat, libavutil or libffmpeg. webengine-dynamic-section.txt and webengine-binary-check.json retain the evidence, including matching SDK proof hash. This corroborates the source/default/configuration evidence; absence of DT_NEEDED alone would not prove static source provenance.

Conclusion: do not add an unsubstantiated FFmpeg-n7.1.3 source/build prerequisite or demand a WebEngine rebuild. For a recipient rebuilding this module with bundled FFmpeg, explicitly use -DFEATURE_webengine_system_ffmpeg=OFF to avoid environmental ambiguity. This is distinct from the Ubuntu ffmpeg/ffprobe/libav* used by the application/MpvQt lane, whose exact source packages and proofs are already separately indexed. No assertion about Qt Multimedia, which is not the module under review, is needed.

## Actual build prerequisites and supplied project-specific inputs

- .cmake.conf sets WebEngine minimum CMake 3.19. configure.cmake:14–20 declares Ninja >=1.7.2, Python >=3.8, 64-bit Node >=20, GCC >=10 or Clang >=17. Actual publisher metadata records CMake 3.30.5 and Ninja 1.12.1. Use compatible tools rather than assuming these general-purpose tools are missing project source.
- configure.cmake:341–400 checks Node/Python/Ninja, Python html5lib, gperf, bison, flex and pkg-config. Linux checks require development headers/libraries including Mesa/Khronos, fontconfig, NSS, DBus and the X11/platform dependencies. Their discovery and failure messages are supplied in source. The selected Qt Core/Gui/Quick/Qml and other Qt modules must be built/installed first; root CMakeLists.txt:19–44 records discovery and version requirements.
- GN is not an undisclosed binary-only prerequisite: configure.cmake:627–630 enables building the internal GN if a matching one is unavailable; cmake/FindGn.cmake records the check; src/gn/CMakeLists.txt:24–28 and 72 onward build the included src/3rdparty/gn sources using the included gen.py. Those source files are covered by the recursive Git proof.
- cmake/QtToolchainHelpers.cmake:251–264 sets is_component_build=false, use_sysroot=false, use_custom_libcxx=false and use_custom_libcxx_for_host=false. Its generated target-toolchain templates and helpers are supplied. No mandatory downloaded Chromium sysroot or proprietary compiler is demonstrated for this Linux GCC build.
- Rust is optional, not a missing mandatory pinned binary: configure.cmake:787–790 uses AUTODETECT OFF and requires Rust/bindgen/libclang only when explicitly enabled. The publisher invocation does not enable it.
- The release archive includes the full GN/GNI/CMake rules, scripts, bundled Node dependencies, FFmpeg configurations and downstream patched source. The complete tracked-content proof covers these, not just library implementation files.
- sccache is an optional compiler launcher in the recorded producer invocation. Recipient builds can omit the two CMAKE_*_COMPILER_LAUNCHER=sccache settings without altering source. The many QT_SBOM_* options request publisher report-generation/verification tools; their Python tools are prerequisites if reproducing that optional report-generation workflow, not additional linked runtime source.

## Remaining limits

No build was performed. The original generated CMakeCache.txt/args.gn and complete producer machine state are not retained. This leaves exact environmental optional-feature selection and bit-for-bit reproducibility unclaimed, but does not identify missing source files or a necessary FFmpeg-n7.1.3 dependency. The project-specific build inputs and scripts inspected are supplied. Application relinking and Linux dependency/license-specific requirements remain subject to the separate build/relink review. Do not convert this technical finding into blanket legal clearance.

## Validation

Extracted primary CMake/GN inputs were hash-checked against the previously streamed publisher archive inventory. BUILD-INPUT-EVIDENCE.json records their paths and hashes. One exploratory tar command requested two nonexistent optional glob patterns and returned exit 2; its other requested files extracted correctly. Those missing patterns are not missing required files and were not used as evidence. All files cited here passed subsequent inventory hash verification. Binary extraction and readelf completed with exit 0.
