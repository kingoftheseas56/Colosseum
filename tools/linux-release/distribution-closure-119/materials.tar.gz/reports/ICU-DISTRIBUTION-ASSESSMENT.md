# ICU 73.2: candidate-specific provenance and distribution assessment

## Conclusion

**NOT REQUIRED FOR DISTRIBUTION:** Rebuilding ICU or establishing a bit-for-bit original-source rebuild solely because the Qt SBOM records `NOASSERTION`. The actual producer license materials inspected do not impose that requirement on these ICU binaries. This is a narrowly scoped text/evidence assessment, not blanket legal clearance for Colosseum, Qt, Chromium, or unknown modifications.

**CLOSED (technical binary/notice provenance):** The three current-candidate ICU73 files are the same shipped bytes as the earlier independently proven files. Their exact SDK archive members are reproduced from Qt's checksum-pinned runtime and devel prebuilts by replacing only the pre-existing ELF DT_RPATH string. The devel prebuilt includes the full unchanged ICU license, which exactly matches the retained official Unicode source candidate's license. The notice is no longer justified merely by a matching version string.

**Prepared, not yet delivered with a production release:** `delivery/ICU-73.2/LICENSE` and the accompanying README/config evidence must be incorporated into the final accompanying distribution materials. The original candidate is unchanged. No exact full copy of this 25,505-byte ICU73 LICENSE was found embedded in any candidate license file (1,574 files scanned); this is a byte-presence finding, not a claim that every constituent notice is missing. Do not mark release notice delivery complete until the supplemental assets are delivered alongside the binary and covered by the final verified manifest.

**Remaining uncertainty:** Exact Qt source inputs, any original source patches/data modifications, original full configure invocation and build logs are not established. These are historical provenance/reproducibility limits. No reviewed primary ICU license clause makes their recovery an independent prerequisite to binary distribution. Do not reinterpret this as proof that no patches exist or that an unseen patch can never introduce obligations.

## Scope and pins

Current candidate: `Colosseum-1.1.9-linux-amd64.deb`, declared SHA256 `ddf011d2955de39e19375d492284867db09d48a80f3b4fe717da086a3b3ec67b`, application commit `7792bd1d9b3a41185cea522a9984ecd6586e3b44`. Whole-package verification is owned by the receiving coordinator; this investigation directly hashes the three files extracted in `candidate/root`.

Earlier proof packet: `review/qt-sdk-file-proofs.json`, `review/qt-sdk-archive-index.json`, `review/elf-provenance-inventory.json`. Earlier whole-package SHA256 `e35e704c901cd67421679fdc82fe4925f6fd28518a1c926c477bcb471df034ad` is not substituted for the current package.

The conclusion covers only the separately shipped Qt SDK ICU73.2 libraries. Ubuntu ICU74 files and Chromium's embedded ICU/ICU4X instances have independent identities and notices. Do not substitute this assessment for them.

## New independently replayable chain

Run from the workspace:

    python linux-distribution-119/icu-work/verify_icu.py

Actual exit: 0. Machine-readable result: `icu-byte-proof.json`, retained output: `verification-output.txt`.

The verifier uses ELF64 program headers and dynamic tags to locate DT_STRTAB/DT_RPATH, checks the old and new strings, replaces exactly the old string's byte span with `$ORIGIN` plus NUL padding, and requires whole-file equality to the SDK archive member. No external binary or downloaded ICU executable is run. All other bytes must be identical. It additionally requires runtime/devel member equality and current candidate equality to the prior shipped-file proof.

Archives independently downloaded from the official Qt URLs:

1. `https://download.qt.io/development_releases/prebuilt/icu/prebuilt/73.2/icu-linux-g++-Rhel8.6-x64.7z`
   - SHA1 `d2bbb7b2a9a9ee00dba5cc6a68137f6c8a98c27e`, matching retained Qt v6.11.1 provisioning script.
   - SHA256 `67c31f27a29194d2d226fd2b1b9f531beab7f292608bdffc23bc3c5bd62e90ae`.
2. `https://download.qt.io/development_releases/prebuilt/icu/prebuilt/73.2/icu-linux-g++-Rhel8.6-x64-devel.7z`
   - SHA1 `edc9cba31ffeac28bf7360c52b85b5e4d2f39043`, matching that script's devel pin.
   - SHA256 `45e72002aa85b647d46c2cdfd8762778cf5123c0d08e2be2b8306e7e0e9673f0`.
3. `https://download.qt.io/online/qtsdkrepository/linux_x64/desktop/qt6_6111/qt6_6111/qt.qt6.6111.linux_gcc_64/6.11.1-0-202605090529icu-linux-Rhel8.6-x86_64.7z`
   - SHA1 `aef06d3070fcbda2d07f2a95a929f58a4474df25`, matching retained official SDK archive checksum.
   - SHA256 `6ea4a612560b6eb39173bcfaa35abc08904fc124e4c0f93e1b39dd22368c33c8`, matching prior SDK proof.

The similarly named prebuilt-directory `icu-linux-Rhel8.6-x86_64.7z` was also checked. It has the runtime archive's SHA256, not the installer archive's SHA256. Do not conflate the two URLs based on basename.

For each of `libicudata.so.73.2`, `libicui18n.so.73.2`, `libicuuc.so.73.2`, the provisioned member and installer member differ in exactly 16 bytes: the existing `libicudata.so.73` RPATH becomes `$ORIGIN` with NUL padding. Offsets are 558, 811828 and 279969 respectively. The files have identical lengths (32,035,888; 4,477,136; 2,571,736 bytes). This proves byte transformation, not which historical command Qt used to perform it.

Current shipped hashes, directly rechecked:

- `opt/colosseum/usr/lib/libicudata.so.73`: `b007d9f747ea204e60fe1c4d4ef0d3e62e586647bcfb3ec8889effc06df09017`
- `opt/colosseum/usr/lib/libicui18n.so.73`: `b2d2e8a499189c51ca35d425a4660c9e142415d63d39bd744e266a65a31671f0`
- `opt/colosseum/usr/lib/libicuuc.so.73`: `3e000be2b3acac91940e71c7351c7993a3a51fc2b4af301aa2fdf5254e158943`

The prior collector's SDK-to-shipped RPATH proof is reusable because both endpoint hashes match. The new proof does not claim to rerun the collector's relocation implementation.

## Actual license requirements and practical handling

Primary local text: `devel/share/icu/73.2/LICENSE`, SHA256 `f3005e195ff74d8812cc1f182a1c446fab678d70a10e3dada497585befee5416`. It is byte-identical to `review/upstream/icu-candidate/notices/LICENSE`; official upstream record: https://github.com/unicode-org/icu/blob/release-73-2/icu4c/LICENSE . Line references below refer to the retained 25,505-byte local file, not browser-rendered line numbers.

- Lines 14–46, Unicode copyright/permission: retain the copyright/permission notice with software/data or accompanying documentation; do not promote using copyright-holder names without permission. Preserve the full text, including disclaimers.
- Lines 58–91, inherited ICU/IBM notice: preserve copyright and permission notices in copies and supporting documentation; avoid unauthorized name-based promotion.
- Lines 95–299, Chinese/Japanese dictionaries, including Google, Libtabe, Academia Sinica, IPADIC/ICOT: retain the listed notices, conditions, and disclaimers in binary documentation/materials. The IPADIC/ICOT section also contains its own warranty/legal conditions. Keeping the entire unchanged LICENSE avoids selectively dropping nested notices.
- Lines 301–381, Lao/Burmese dictionaries: preserve the named copyright, conditions, and disclaimer texts; comply with the stated non-endorsement terms.
- Lines 385–406, time-zone data: upstream identifies this data as public domain. Preserve the producer explanation, without extending it to the rest of ICU.
- Lines 410–437, Google double-conversion: retain the binary-distribution copyright/conditions/disclaimer and non-endorsement terms.
- Lines 441–503, build helper `aclocal.m4`/`config.guess`: these have GPL notices with explicit Autoconf distribution exceptions. The text states that ICU's included configure script fulfills the condition. Do not classify the ICU shared-library runtime as GPL solely because these build-helper notices are present. Preserve the source archive and notices unchanged if shipping optional source materials.
- Lines 506 onward, install-sh: retain the MIT copyright/permission notice and observe its naming restriction when distributing this source helper.

None of those inspected runtime notice clauses requires distributing an ICU build recipe, proving binary reproducibility, supplying relinkable ICU objects, or making a written source offer. Other components' LGPL/GPL duties must be evaluated separately. This conclusion is not a blanket classification of all runtime dependencies.

## Producer configuration evidence recovered

The checksum-pinned devel archive contains `lib/icu/73.2/Makefile.inc`, `share/icu/73.2/config/mh-linux`, `bin/icu-config`, and `include/unicode/uconfig.h`; copies are under `delivery/ICU-73.2/producer-*`.

Observed generated settings include `/home/qt/icu_install` prefix, ICU 73.2/Unicode 15.0, x86_64-pc-linux-gnu host, gcc/g++, C++11, dynamic-library mode and little-endian configuration. The runtime `.comment` section records GCC 10.3.1 20210422 (Red Hat 10.3.1-1). These are concrete supporting evidence but do not recover the complete original configure command, patch set or environment. Do not present generated consumer compiler flags as the full original build flags.

The official Qt source directory https://download.qt.io/development_releases/prebuilt/icu/src/ lists older ICU sources through 56.1, not a corresponding 73.2 source/build recipe. The version-specific prebuilt directory https://download.qt.io/development_releases/prebuilt/icu/prebuilt/73.2/ lists binary/devel packages. This bounded directory observation does not prove no source recipe exists anywhere.

The original Qt provisioning script has its own Qt licensing alternatives. Those license the script and must not be assigned to the ICU libraries. Original SBOM fields remain `NOASSERTION`; this separately sourced assessment does not overwrite publisher declarations.

## Minimal remaining action

No producer contact is indispensable to the ICU notice-based distribution conclusion above. Integrate `delivery/ICU-73.2` into accompanying notices/source materials; keep the exact producer LICENSE available alongside the distributed package, with verified checksums and links in the release submission. Carry the historical provenance caveat into the closure matrix. The separate whole-candidate and final hosting/notices checks remain the coordinator's responsibility.

If the receiving owner independently requires complete historical reproducibility (rather than the license requirements identified here), the missing producer input is the exact source archive/commit, patch set (including data changes), build command/toolchain recipe and logs for runtime SHA1 `d2bbb7b2a9a9ee00dba5cc6a68137f6c8a98c27e` / devel SHA1 `edc9cba31ffeac28bf7360c52b85b5e4d2f39043`.

Optional ready-to-send question, NOT sent: “For the ICU 73.2 RHEL 8.6 runtime/devel prebuilts pinned by Qt 6.11.1 (SHA1 d2bbb7b2a9a9ee00dba5cc6a68137f6c8a98c27e and edc9cba31ffeac28bf7360c52b85b5e4d2f39043), can you provide the exact source archive/commit, any patches or data changes, and original build recipe/toolchain record? We verified the three SDK libraries differ from those prebuilt members only by RPATH replacement and retained the devel package's complete LICENSE. Please identify any additional notices required for producer modifications.”
