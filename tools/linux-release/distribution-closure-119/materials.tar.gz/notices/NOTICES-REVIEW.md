> HISTORICAL / SUPERSEDED: Earlier checkpoint only. Fraunces derivation is now CLOSED by exact upstream reconstruction and its authentic OFL is integrated. Current status and the one remaining Switzer source-scope decision are in ../reports/CLOSURE-REPORT.md and ../font-correction/switzer/ASSESSMENT.md.

# Linux 1.1.9 notices submission: review-ready, not yet complete for publication

Exact candidate: `Colosseum-1.1.9-linux-amd64.deb`, SHA256 `ddf011d2955de39e19375d492284867db09d48a80f3b4fe717da086a3b3ec67b`. Application source: `7792bd1d9b3a41185cea522a9984ecd6586e3b44`.

## What has been supplied and checked

The `overlay/` directory contains unchanged, exact archive copyright texts for the 223 Ubuntu binary packages actually represented by 248 shipped ELF files. It is generated from proved bundled files, NOT the much larger installed-host package list. Each package/version/source-version and its shipped paths is listed in `bundled-ubuntu-notices-index.json`. Original archive evidence paths and hashes are retained for independent review. Full common license texts are included alongside those copyright files, making `/usr/share/common-licenses/...` references readable without depending on an end-user's OS.

The overlay also supplies the original application MIT text, the previously omitted miniz copyright/permission text, and Inter/Literata copyright plus full OFL-1.1 text grounded in actual embedded declarations. These are supplemental notices; the original candidate bytes were not changed. Merely creating this folder does not make the old .deb contain these additions. A companion notices asset can be prepared for approval; integration into a changed installer requires new artifact qualification.

Qt and MpvQt retain their actual alternative license expressions. The existing candidate's `licenses/Qt-SBOM`, `dependency-0-notices/MpvQt-LICENSES`, `dependency-0-notices/QtImageFormats-LICENSES`, `libtiff-COPYRIGHT`, and the review packet's upstream component notice trees must accompany this submission. `qt-publisher-declarations-UNFILTERED.json` preserves the publisher's complete declarations, including unknown fields, but does not claim SDK-only tools are shipped. `candidate-elf-inventory.json` is the exact shipped-ELF boundary; selected Qt archives and proof mappings remain in `review/qt-sdk-file-proofs.json`. The review's full third-party notice trees are retained as source context, not blindly relabeled as the final dependency list.

Original Colosseum MIT licensing does not apply to all runtime contents. In particular the exact Ubuntu libmpv2 declaration is GPL-3+ and the app directly links it. The combined-executable terms and corresponding-source delivery need an explicit release presentation consistent with that dependency, not the generic historical Windows notice. See BUILD-RELINK-REVIEW.md for primary sections and linkage evidence.

## Final targeted follow-up and remaining gates

See ASSET-FOLLOWUP-RESULTS.md, which supersedes the preliminary questions. Recovered exact Switzer official byte identities and full FFL, exact Anx/Foliate imported-file provenance, exact vendor zip.js/fflate origin, Prism core/component/theme proofs, and original JavaScript runtime notices. Two PDF.js bundles reproduce exactly. Main webpack bundle historical non-reproduction is explicitly NOT asserted to be a license-required blocker.

The remaining concrete receiving inputs are (1) confirmation that the stripped Fraunces TTFs derive solely from the recovered OFL family so the provisional original attribution can be applied; and (2) a scope decision or producer clarification that Switzer raw font resources inside the source archive/repository fit FFL section 01's application permission despite section 02's repository/redistribution limitations. Exact font transform reproducibility is not itself required by OFL. Precise ready-to-send questions and primary evidence are in the follow-up report; none were sent.

Actual combined-work/source presentation is prepared in overlay/licenses/LINUX-DISTRIBUTION-NOTICE-DRAFT.txt. It preserves original Colosseum MIT source permissions while accurately addressing the directly linked GPL-3+ libmpv build, LGPL permissions and equivalent source-access publication route. It is a draft for final approval, not a source offer, relicense operation or public release.

The historical generic THIRD_PARTY_NOTICES.md also names Android/Windows/remote services; do not use that as the actual Linux bundled-only index. All-artwork/data rights are not established by an ELF inventory.

## Public supplemental-material boundary

Only files explicitly listed in PUBLIC-SUPPLEMENTAL-MANIFEST.json are proposed supplemental materials. SHA256-INDEX.json covers this selected output, not private scratch. Excluded: official full Switzer ZIP, raw comparison font binaries, fetched npm archive, clone/webpack working directories, website JavaScript, and large build stats. Keep those only as private receiving evidence. Do not recursively publish this work directory. PRIVATE-COMPARISON-INPUTS.json retains their hashes for receiving where appropriate, without granting redistribution permission.

## Independent receiving checks

Run `python notices-work/generate_notices.py` in the same packet layout. It fails on any changed dependency SHA256 or original Ubuntu copyright checksum and verifies the full .deb hash. FontTools is required only to read font metadata. The resulting validation records 458 ELF files, 457 identical dependencies, 223 exact Ubuntu binary-package notices, 13 fonts, and 13 original Qt configure records. `readelf` was run successfully on all 458 files; no library or application code was executed.

Check every `OVERLAY-SHA256-INDEX.json` member against its bytes. The original review SHA256 index remains unchanged. Final selected-output hashes are in `SHA256-INDEX.json`; that index excludes itself. The parent must integrate these artifacts with current source identity, WebEngine/ICU analyses and durable hosting plan before submission. No publishing URL or public release completion is claimed.
