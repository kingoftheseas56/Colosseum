#!/usr/bin/env python3
"""Candidate-specific review output; never rewrites candidate or upstream notices."""
import json, hashlib, pathlib, shutil, subprocess, collections, re
from fontTools.ttLib import TTFont
B=pathlib.Path(__file__).resolve().parent.parent; R=B/'review'; O=B/'notices-work'; C=B/'candidate/root'; A=B/'app-source'
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def emit(n,d): (O/n).write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n')
def cp(p,d): d.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,d)
expected='ddf011d2955de39e19375d492284867db09d48a80f3b4fe717da086a3b3ec67b'
assert sha(B/'candidate/Colosseum-1.1.9-linux-amd64.deb')==expected
old=json.loads((R/'elf-provenance-inventory.json').read_text()); rows=[]; packages={}; links=[]
for r in old:
 p=C/r['path'];actual=sha(p); row=dict(r);row['candidate_sha256']=actual
 row['proof_reuse']=actual==r['shipped_sha256']
 if r['family']!='colosseum':assert row['proof_reuse'],r['path']
 else:row['source_commit']='7792bd1d9b3a41185cea522a9984ecd6586e3b44';row['status']='current-candidate-build-identity';row['shipped_sha256']=actual
 rows.append(row)
 proc=subprocess.run(['readelf','-d',str(p)],capture_output=True,text=True);assert proc.returncode==0
 lines=[x.strip() for x in proc.stdout.splitlines() if any(y in x for y in ['(NEEDED)','(RUNPATH)','(RPATH)'])]
 links.append({'path':r['path'],'sha256':actual,'command':['readelf','-d',r['path']],'exit':proc.returncode,'dynamic_entries':lines})
 if r['family']=='ubuntu':
  pr=r['proof'];k=pr['binary_package'];rec=packages.setdefault(k,{'binary_package':k,'binary_version':pr['binary_version'],'source_package':pr['source_package'],'source_version':pr['source_version'],'files':[],'notices':[]});rec['files'].append(r['path'])
  for n in pr['binary_copyright_texts']:
   assert sha(R/n['path'])==n['sha256']; dst=O/'overlay/licenses/bundled-ubuntu'/k/pathlib.Path(n['path']).name;cp(R/n['path'],dst)
   ref={'path':str(dst.relative_to(O)),'sha256':sha(dst),'original_evidence':n['path']}
   if ref not in rec['notices']:rec['notices'].append(ref)
for p in (C/'opt/colosseum/licenses/Common-License-Texts').iterdir():
 if p.is_file():cp(p,O/'overlay/licenses/Common-License-Texts'/p.name)
cp(A/'native/third_party/miniz/LICENSE',O/'overlay/licenses/miniz/LICENSE')
cp(A/'LICENSE',O/'overlay/licenses/Colosseum-MIT.txt')
cp(R/'qt-sbom-package-declarations.json',O/'qt-publisher-declarations-UNFILTERED.json')
configs=[r for r in json.loads((R/'qt-sbom-package-declarations.json').read_text()) if 'was configured with:' in r.get('comment','')];emit('qt-publisher-build-configurations.json',configs)
fonts=[]
for p in sorted((C/'opt/colosseum/assets/fonts').glob('*')):
 if p.suffix not in ['.otf','.ttf']:continue
 names=TTFont(p)['name'].names; rec={'path':str(p.relative_to(C)),'sha256':sha(p),'metadata':{}}
 for n in names:
  if n.nameID in [0,1,2,3,5,13,14]:rec['metadata'].setdefault(str(n.nameID),[]);v=n.toUnicode(); rec['metadata'][str(n.nameID)]+= [] if v in rec['metadata'][str(n.nameID)] else [v]
 fonts.append(rec)
fonttext='Font declarations extracted from actual candidate bytes. These are not replacement license grants.\n\n'
for r in fonts:
 fonttext+=r['path']+'\nSHA256 '+r['sha256']+'\n'+'\n'.join(f'nameID {k}: '+ ' | '.join(v) for k,v in r['metadata'].items())+'\n\n'
(O/'FONT-DECLARATIONS.txt').write_text(fonttext)
# Reuse full OFL text, not Unifont's project-specific copyright header.
unif=(C/'opt/colosseum/assets/fonts/Unifont-17.0.05-OFL.txt').read_text();start=unif.index('SIL OPEN FONT LICENSE');ofl=unif[start:]
for family,copyright in [('Inter','Copyright 2016 The Inter Project Authors'),('Literata','Copyright 2017 The Literata Project Authors (https://github.com/googlefonts/literata)')]:
 p=O/'overlay/licenses/fonts'/f'{family}-OFL.txt';p.parent.mkdir(parents=True,exist_ok=True);p.write_text(copyright+'\n\nFont license declaration: SIL Open Font License, Version 1.1, from embedded nameID 13.\n\n'+ofl)
emit('candidate-elf-inventory.json',rows);emit('bundled-ubuntu-notices-index.json',list(packages.values()));emit('candidate-dynamic-linkage.json',links);emit('candidate-font-inventory.json',fonts)
manifest=[{'path':str(p.relative_to(O)),'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted((O/'overlay').rglob('*')) if p.is_file()];emit('OVERLAY-SHA256-INDEX.json',manifest)
emit('VALIDATION.json',{'candidate_sha256':expected,'elf_files':len(rows),'unchanged_dependency_elf_proofs':sum(r['proof_reuse'] for r in rows),'ubuntu_bundled_binary_packages':len(packages),'ubuntu_elf_files':sum(r['family']=='ubuntu' for r in rows),'font_files':len(fonts),'overlay_files':len(manifest),'qt_configuration_records':len(configs),'checks':'Candidate SHA256, each dependency SHA256, Ubuntu copyright SHA256, readelf exit status, output overlay hashes verified. No runtime replacement test or complete asset license clearance claimed.'})
print((O/'VALIDATION.json').read_text())
