from fontTools.ttLib import TTFont
from fontTools.varLib.instancer import instantiateVariableFont
from pathlib import Path
import json, io
O=Path(__file__).parent/'upstream-checks';C=Path(__file__).parent.parent/'candidate/root/opt/colosseum/assets/fonts';rows=[]
for sty in ['Regular','Italic']:
 c=TTFont(C/f'Fraunces-{sty}.ttf');vn='Fraunces'+('-Italic' if sty=='Italic' else '')+'[SOFT,WONK,opsz,wght].ttf'
 for prefix in ['','google-']:
  if not (O/(prefix+vn)).exists():continue
  v=TTFont(O/(prefix+vn))
  for opsz in [9,14,18,24,32,48,72,144]:
   f=instantiateVariableFont(v,{'wght':400,'opsz':opsz,'SOFT':0,'WONK':0},inplace=False)
   buf=io.BytesIO();f.save(buf);buf.seek(0);f=TTFont(buf)
   same=0
   for cg,fg in zip(c.getGlyphOrder(),f.getGlyphOrder()):
    if c['glyf'][cg].getCoordinates(c['glyf'])==f['glyf'][fg].getCoordinates(f['glyf']):same+=1
   r={'style':sty,'source':prefix+vn,'axes':{'wght':400,'opsz':opsz,'SOFT':0,'WONK':0},'matching_glyphs_by_gid':same,'compared':len(c.getGlyphOrder())};rows.append(r);print(r,flush=True)
(O/'fraunces-coordinate-comparison.json').write_text(json.dumps(rows,indent=2))
