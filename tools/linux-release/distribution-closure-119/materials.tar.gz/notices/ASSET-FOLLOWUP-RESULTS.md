> HISTORICAL / SUPERSEDED: Earlier checkpoint only. Fraunces derivation is now CLOSED by exact upstream reconstruction and its authentic OFL is integrated. Current status and the one remaining Switzer source-scope decision are in ../reports/CLOSURE-REPORT.md and ../font-correction/switzer/ASSESSMENT.md.

# Targeted original-asset follow-up: final receiving findings

This supersedes the preliminary asset questions in the initial review. No candidate bytes were changed. Original exact package/source identities remain fixed.

## Switzer: exact bytes and terms recovered; source-delivery scope needs acceptance review

All four shipped OTFs exactly match the original members of the official current Fontshare Switzer download: `upstream-checks/switzer-file-comparison.json`. The official API identifies Switzer 1.2 as `itf_ffl`. Both the website's actual served JavaScript and the official ZIP supply ITF Free Font License v2.0, 17 August 2026. `overlay/licenses/fonts/Switzer-FFL-2.0.txt` is the original unmodified ZIP text, not a paraphrase. The generic MIT/OFL substitution problem is resolved.

Primary routes:
- https://api.fontshare.com/v2/fonts/slug/switzer
- https://api.fontshare.com/v2/fonts/download/switzer
- https://www.fontshare.com/licenses/itf-ffl
- https://www.fontshare.com/js/main.d962d2d8.js

FFL section 01 expressly permits embedding in mobile/desktop applications and using/self-hosting fonts in the licensee's own applications. Section 02 prohibits modification and distribution beyond permitted uses, explicitly mentioning repositories and download services; its final paragraph preserves section 01's permitted own-application uses. These clauses are not equivalent to an unconditional license to redistribute raw fonts in a standalone source/font repository. The app's fixed HUD display use is identified by original import commit `fb446d0d3d96269a955d5380e54ddf405e33e7c6`; the source archive additionally exposes raw OTF app-resource files. Final receiving must decide that this source-resource delivery fits the permitted application use, or obtain clarification / select another qualified delivery or font approach. Do not claim its scope is automatically resolved by matching bytes.

Minimal ready-to-send question, NOT SENT: “We distribute a desktop application using unmodified Switzer only for its own interface, and provide the application's source archive containing the same OTF app resources needed for its build. Does FFL v2 sections 01/02 permit those font files inside that app source archive/repository, rather than as a standalone font distribution? If not, what source-delivery arrangement do you authorize?” This can first be assessed by the owner's receiving/licensing reviewer; no third-party outreach is authorized by this draft.

Acquisition disclosure: the official download states that downloading/accessing accepts its terms, without a separate checkbox. The authorized provenance download occurred and that implicit acceptance must be disclosed. No account or paid license was created. No third party was contacted.

The original full-font ZIP and comparison font binaries are private receiving evidence only. They are excluded from the public supplemental-material manifest. This is particularly important because the official ZIP includes styles not shipped in Colosseum.

## Fraunces: source attribution candidate recovered; exact origin remains unestablished

Both TTFs first appear in application backup commit `81d859d1557657fc76c1b25ec95bdc0ec891f152`, whose retained commit message supplies no download URL or generation recipe. Full accessible application Git history was searched. Actual font name tables retain the Fraunces family/style but omit copyright, license, version and license-URL fields. Each has 698 glyphs and variable-font-derived STAT axes.

Primary undercasetype/Fraunces tree `7ccdec31c6028118dce3e47fe864e3744460371d` and Google Fonts current plus initial Fraunces source commit `581699fcc0df7715a0f944e28b1a18d38e4aad62` were retrieved. Exact static font hashes/table comparisons and 48 sampled variable-to-static glyph-coordinate comparisons did not establish the candidate's exact derivation. Results, trees and acquisition URLs are retained under `upstream-checks/fraunces-*`. These failed comparisons are not proof that the fonts are unrelated or unauthorized; they are evidence that the precise transform cannot be asserted.

The official Fraunces OFL text names Copyright 2018 The Fraunces Project Authors and declares no Reserved Font Name in its header. It is supplied as `Fraunces-OFL-PROVISIONAL.txt`, not represented as proof of these files' original acquisition. OFL permits derivatives and does not require source archives or bit-for-bit build reproduction. Exact reconstruction is therefore optional historical provenance, not itself a mandatory build-input gate. The remaining necessary input is credible confirmation that these stripped files derive from the identified OFL Fraunces family with no additional third-party material/conditions, so the authentic attribution can be applied confidently. This can be supplied by the original contributor's source/transform record; it does not require a font rebuild merely for ceremony.

Minimal ready-to-send question, NOT SENT: “The two shipped Fraunces TTFs entered backup commit 81d859d1 without copyright/license metadata. Can the original contributor identify the downloaded Fraunces source and transformation, or confirm they are derivatives solely of the official OFL Fraunces family? We have recovered that family's original OFL/copyright for the notices. Exact historical build reproduction is not required.” If no such source record exists, a separately qualified replacement from a verified OFL distribution is a concrete alternative, not a change already made.

## Foliate and bundled JavaScript: import and recovered notices

Original application import `e1b1c35fd98414eb03940a716eabebee8d0cdd58` explicitly names Anxcye/anx-reader commit `107f4fa74db0e7247c846c49d6211df3edf9887c`. All 117 imported files match that upstream tree's Git blob identities exactly (`foliate-upstream-file-comparison.json`). Only five source files later differ; the three shipped dist bundles retain the original upstream bytes. The exact pinned Anx root MIT notice and historical John Factotum MIT notice are now preserved. The imported package.json's ISC declaration is also retained as metadata; it is not silently rewritten and does not erase the original MIT grants.

The vendored `zip.js` and `fflate.js` match original Foliate commit `7dcbc6921a46d16c1ac622bee180f0089a0875e6` exactly, where README explicitly identifies zip.js BSD-3-Clause and fflate MIT. Original upstream copyright/license texts are supplied in overlay/licenses/javascript. The historical fflate v0.8.0 license is retained as dated upstream attribution context, without claiming a version-only proof of the minified vendor byte stream.

Prism README explicitly names 1.29.0. Its core, autoloader and 62 language components match the official npm prismjs 1.29.0 archive exactly. All 12 theme files now match official npm archive bytes exactly, including renamed aliases: solarized-dark → solarized-dark-atom, default → prism, vs-dark → vsc-dark-plus, github → ghcolors. The complete mapping is `prism-theme-alias-comparison.json` (11 themes from prism-themes 1.9.0, one from prismjs 1.29.0). Both original MIT notices are supplied. No theme remains an unmatched provenance row.

An isolated `npm ci --ignore-scripts --no-audit --no-fund` used the exact retained package-lock integrity pins, followed by webpack from copied inputs, not the application repository. The two PDF.js bundles reproduce byte-for-byte. Main bundle does not reproduce byte-for-byte even from original imported source; the original distributed bundle itself is nevertheless an exact member of the pinned MIT-licensed upstream import. No MIT/Apache rule requiring historical webpack byte reproduction has been identified, so this is NOT treated as a release-blocking missing build input. Actual webpack module stats identify core-js and Babel runtime; the shipped main bundle independently identifies core-js 3.43.0 and the retained notice identifies regenerator-runtime. Complete license texts from those exact installed package versions are supplied. PDF.js's existing Apache notices and the common Apache-2.0 text remain required.

The supplemental notices cure concrete missing attribution texts but do not assert an exhaustive all-artwork/data rights audit. The exact imported JavaScript source evidence and original license declarations are stronger than guessed package names. No full application or WebEngine rebuild was run.
