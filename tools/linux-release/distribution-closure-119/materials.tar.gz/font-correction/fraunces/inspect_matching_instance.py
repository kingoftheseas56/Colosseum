from pathlib import Path
from fontTools.ttLib import TTFont
from fontTools.varLib.instancer import instantiateVariableFont
import io,json,hashlib,copy
B=Path(__file__).resolve().parent.parent;S=B/'notices-work/upstream-checks';O=B/'font-correction-work';C=B/'candidate/root/opt/colosseum/assets/fonts';out=[]
meta=json.loads((S/'google-fraunces-files.json').read_text())
for sty,w in [('Regular',450),('Italic',420)]:
 name='Fraunces'+('-Italic' if sty=='Italic' else '')+'[SOFT,WONK,opsz,wght].ttf';p=S/('google-'+name);b=p.read_bytes();blob=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();record=next(r for r in meta if r['name']==name);assert record['sha']==blob
 c=TTFont(C/f'Fraunces-{sty}.ttf');f=instantiateVariableFont(TTFont(p),{'wght':w,'opsz':40,'SOFT':0,'WONK':0});buf=io.BytesIO();f.save(buf);buf.seek(0);f=TTFont(buf)
 same=[];different=[]
 for tag in c.keys():
  if tag=='GlyphOrder':continue
  (same if f.getTableData(tag)==c.getTableData(tag) else different).append(tag)
 print(sty,'same',same,'different',different)
 for tag in different:
  if tag not in ['name','glyf','GPOS','GSUB','STAT','cmap','loca','post']:
   print(tag,[(k,v,getattr(c[tag],k,None)) for k,v in vars(f[tag]).items() if v!=getattr(c[tag],k,None)])
 # Trace-only reconstruction using strictly isolated metadata from candidate.
 trace=copy.deepcopy(f)
 for tag in ['name','head']:trace[tag]=copy.deepcopy(c[tag])
 trace.recalcTimestamp=False;buf=io.BytesIO();trace.save(buf);rb=buf.getvalue()
 print('metadata-only reconstruction hash match',rb==(C/f'Fraunces-{sty}.ttf').read_bytes())
 out.append({'style':sty,'axes':{'wght':w,'opsz':40,'SOFT':0,'WONK':0},'upstream_git_blob':blob,'upstream_sha256':hashlib.sha256(b).hexdigest(),'upstream_primary_blob_api':record['git_url'],'upstream_metadata_download_url':record['download_url'],'candidate_sha256':hashlib.sha256((C/f'Fraunces-{sty}.ttf').read_bytes()).hexdigest(),'identical_tables':same,'different_tables':different,'metadata_only_reconstruction_exact':rb==(C/f'Fraunces-{sty}.ttf').read_bytes(),'reconstruction_sha256':hashlib.sha256(rb).hexdigest()})
(O/'matching-instance-tables.json').write_text(json.dumps(out,indent=2))
