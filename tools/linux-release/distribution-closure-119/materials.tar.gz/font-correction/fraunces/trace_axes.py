from pathlib import Path
from fontTools.ttLib import TTFont
from fontTools.varLib.instancer import instantiateVariableFont
import json,io
B=Path(__file__).resolve().parent.parent;S=B/'notices-work/upstream-checks';O=B/'font-correction-work';C=B/'candidate/root/opt/colosseum/assets/fonts';rows=[]
for sty,w in [('Regular',450),('Italic',420)]:
 c=TTFont(C/f'Fraunces-{sty}.ttf');v=TTFont(S/('google-Fraunces'+('-Italic' if sty=='Italic' else '')+'[SOFT,WONK,opsz,wght].ttf'));target=c['glyf'][c.getBestCmap()[65]].getCoordinates(c['glyf'])[0];print(sty,'target',target[:2],flush=True)
 for opsz in [9,12,14,18,24,28,32,36,40,48,60,72,96,144]:
  f=instantiateVariableFont(v,{'wght':w,'opsz':opsz,'SOFT':0,'WONK':0});buf=io.BytesIO();f.save(buf);buf.seek(0);f=TTFont(buf)
  same=sum(c['glyf'][a].getCoordinates(c['glyf'])==f['glyf'][b].getCoordinates(f['glyf']) for a,b in zip(c.getGlyphOrder(),f.getGlyphOrder()));r={'style':sty,'wght':w,'opsz':opsz,'SOFT':0,'WONK':0,'matching_glyphs':same,'total_glyphs':len(c.getGlyphOrder())};rows.append(r);print(r,'A',f['glyf'][f.getBestCmap()[65]].getCoordinates(f['glyf'])[0][:2],flush=True)
(O/'axis-trace.json').write_text(json.dumps(rows,indent=2))
