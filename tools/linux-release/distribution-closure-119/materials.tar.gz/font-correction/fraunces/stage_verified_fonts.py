#!/usr/bin/env python3
"""Local proposed-only staging. Never touches original package/application."""
from pathlib import Path
from fontTools.ttLib import TTFont
from fontTools.varLib.instancer import instantiateVariableFont
import io,json,hashlib,copy,shutil
B=Path(__file__).resolve().parent.parent;O=B/'font-correction-work';S=B/'notices-work/upstream-checks';C=B/'candidate/root/opt/colosseum/assets/fonts';P=O/'proposed/assets/fonts';P.mkdir(parents=True,exist_ok=True);I=O/'verified-inputs';I.mkdir(exist_ok=True)
def sha(b):return hashlib.sha256(b).hexdigest()
def gitblob(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
metadata=json.loads((S/'google-fraunces-files.json').read_text());rows=[];inputs=[]
for sty,w in [('Regular',450),('Italic',420)]:
 name='Fraunces'+('-Italic' if sty=='Italic' else '')+'[SOFT,WONK,opsz,wght].ttf';src=S/('google-'+name);b=src.read_bytes();mr=next(r for r in metadata if r['name']==name);assert gitblob(b)==mr['sha'];shutil.copyfile(src,I/name)
 f=instantiateVariableFont(TTFont(src),{'wght':w,'opsz':40,'SOFT':0,'WONK':0});c=TTFont(C/f'Fraunces-{sty}.ttf')
 # Retain original upstream copyright/license/version and all STAT names.
 # Preserve the app's established family/style/PostScript selectors exactly.
 selectors={1,2,3,4,6,16,17}
 f['name'].names=[n for n in f['name'].names if n.nameID not in selectors]+[copy.deepcopy(n) for n in c['name'].names if n.nameID in selectors]
 # Fixed review build date for deterministic proposal, not a historical build claim.
 f['head'].modified=3875212800;f.recalcTimestamp=False
 dst=P/f'Fraunces-{sty}.ttf';f.save(dst);g=TTFont(dst);same=[tag for tag in c.keys() if tag not in ['GlyphOrder','head','name'] and c.getTableData(tag)==g.getTableData(tag)];assert len(same)==13
 # The original candidate is reconstructed exactly by the already established metadata transformation.
 t=copy.deepcopy(g);t['name']=copy.deepcopy(c['name']);t['head']=copy.deepcopy(c['head']);t.recalcTimestamp=False;buf=io.BytesIO();t.save(buf);assert buf.getvalue()==(C/f'Fraunces-{sty}.ttf').read_bytes()
 rows.append({'path':str(dst.relative_to(O)),'style':sty,'axes':{'wght':w,'opsz':40,'SOFT':0,'WONK':0},'sha256':sha(dst.read_bytes()),'candidate_sha256':sha((C/f'Fraunces-{sty}.ttf').read_bytes()),'identical_layout_tables':same,'retained_original_notice_name_ids':[0,5,13,14],'candidate_exact_reconstruction':True,'upstream_git_blob':mr['sha'],'upstream_blob_url':mr['git_url'],'upstream_sha256':sha(b)})
 inputs.append({'path':str((I/name).relative_to(O)),'sha256':sha(b),'git_blob':mr['sha'],'primary_url':mr['git_url']})
lic=S/'Fraunces-OFL.txt';lb=lic.read_bytes();lm=next(r for r in metadata if r['name']=='OFL.txt');assert gitblob(lb)==lm['sha'];shutil.copyfile(lic,P/'Fraunces-OFL.txt');shutil.copyfile(lic,I/'OFL.txt');inputs.append({'path':'verified-inputs/OFL.txt','sha256':sha(lb),'git_blob':lm['sha'],'primary_url':lm['git_url']})
(O/'PROPOSED-FONTS.json').write_text(json.dumps(rows,indent=2)+'\n');(O/'VERIFIED-UPSTREAM-INPUTS.json').write_text(json.dumps(inputs,indent=2)+'\n')
print(json.dumps(rows,indent=2))
