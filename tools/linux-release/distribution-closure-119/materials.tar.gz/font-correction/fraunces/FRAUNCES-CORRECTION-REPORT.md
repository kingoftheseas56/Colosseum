# Fraunces correction: existing font derivation established, no geometry replacement needed

Scope: unchanged Colosseum application `7792bd1d9b3a41185cea522a9984ecd6586e3b44` and unchanged Linux candidate `.deb` SHA256 `ddf011d2955de39e19375d492284867db09d48a80f3b4fe717da086a3b3ec67b`. All work in this correction was local, proposed-only, under `font-correction-work`. No remote requests, commits, pushes, CI/upload, publication or edits to the pinned app/package or previous notices artifacts occurred. Previously acquired primary inputs were read and independently checked.

## Corrected conclusion

**Existing-font source derivation: CLOSED by byte evidence, not by user confirmation.**

The earlier comparison assumed nominal weight 400 and did not establish correspondence. That limitation has now been corrected: the actual candidate OS/2 tables record weight **450 for Regular** and **420 for Italic**. Instancing the verified official Google Fonts variable files with those weights, **optical size 40, SOFT 0, WONK 0**, reproduces all 698 glyphs in each file and all 13 non-metadata font tables exactly.

Only `name` and `head` differ. The `head` differences are modification timestamp and checksum adjustment. Applying the existing candidate's naming table and head metadata to these official-derived instances in memory produces the **entire candidate TTF byte-for-byte**, including these exact SHA256 identities:

- Existing `Fraunces-Regular.ttf`: `4063dec09ee3d7170bd8c6bf1f66a6bec01a3630390a922cdb9bcfbcb7e89bbc`
- Existing `Fraunces-Italic.ttf`: `38ecc4ffec0848602b4bafb6778494ceb173b89262d030d056efc32f29b2720d`

This establishes a concrete derivation for the actual files. It does not invent the original developer's download history; that historical acquisition record is now optional background, not a remaining attribution/release prerequisite. The user did not confirm provenance, and no such confirmation is needed to support this independently demonstrated transformation.

Evidence: `matching-instance-tables.json`, `axis-trace.json`, `inspect_matching_instance.py`, `stage_verified_fonts.py`. The exact reconstruction is asserted again while creating the proposal, without modifying the original fonts.

## Verified official inputs and notices

The inputs were acquired previously from Google Fonts and now checked against the immutable Git blob identifiers in the retained official contents response. Copies and all SHA256 values are retained in `verified-inputs/` and `VERIFIED-UPSTREAM-INPUTS.json`.

| Input | Immutable upstream Git blob | SHA256 |
|---|---|---|
| Regular variable source | `8210f9488d3c732359a9292dd09aca3f2bae830e` | `177ff6c0f14e5550a3c624247cd1189611d4eb65d000b14944c63d967958abbb` |
| Italic variable source | `2ddf59a11b89a3d6b2816ea6ae7965026c08143a` | `b24448c43702fac4ee856781d461a0dfba8d8e594b6e8e190234b75fed2c0e01` |
| Official OFL/copyright text | `22fa7ce5733434d0c634f6e55116f410858e938c` | `bdf4c22802eaf804f998195871c6b8938aac2ac14b2d78a8bd66a6f1eced833b` |

Primary immutable URL format: `https://api.github.com/repos/google/fonts/git/blobs/<blob>`. These are verified blob pins, not a claim that a mutable `main` URL pins a release. The authentic notice is **Copyright 2018 The Fraunces Project Authors (https://github.com/undercasetype/Fraunces)**, followed by SIL OFL 1.1. No Reserved Font Name is declared in its copyright header.

**Genuine distribution requirement remaining:** accompany each distributed copy with the authentic copyright and OFL text under OFL condition 2. That condition permits standalone text or suitable easily viewed metadata. The old candidate lacks the Fraunces copyright/license metadata; an optional source-page link alone is not assumed to accompany every binary copy. Adding the supplied `Fraunces-OFL.txt` to the packaged assets is the minimal concrete correction. Do not describe the original uncorrected notice inventory as already fixed.

## Proposed-only choices, ready for review

### A. Minimal notice correction, existing font bytes unchanged

Apply only `PROPOSED-NOTICE-ONLY.patch` after approval. It adds the authentic original `assets/fonts/Fraunces-OFL.txt`; no font bytes, shapes or layout settings change. This is sufficient to prepare the missing copyright/license accompaniment for the now-proved source derivation; historical reconstruction or font replacement is not an additional OFL source obligation.

### B. Optional metadata restoration plus the same notice

`PROPOSED-METADATA-AND-NOTICE.patch` additionally stages fonts regenerated from the verified official sources. Their family/style/PostScript selection names remain exactly those the application expects. Original upstream copyright, license, version and license-URL metadata are preserved instead of stripped. The geometry/metrics tables are unchanged:

- Proposed Regular: `4742e67c03c6d012262f295959ac134658480e5b2c5a8a5255defe02a8a34722`
- Proposed Italic: `26193de8dd911002d52e7222d1cd76463ea8cfc59bf7874e3e220429afa93df8`

Files: `proposed/assets/fonts/Fraunces-Regular.ttf`, `Fraunces-Italic.ttf`, and `Fraunces-OFL.txt`. A deterministic review timestamp is used for the newly generated proposal, not claimed as the historical build timestamp. `PROPOSED-FONTS.json` records exact parameters and identities. Both patch applicability and applied bytes were tested only in `font-correction-work/patch-test`, not in the application repository; `PATCH-VALIDATION.json` records exits 0.

## Typography/layout results

For both styles, these candidate/proposal tables are identical: `hhea`, `maxp`, `OS/2`, `hmtx`, `cmap`, `prep`, `loca`, `glyf`, `post`, `gasp`, `GPOS`, `GSUB`, `STAT`. Every one of the combined 1,396 glyph advance/bearing records is identical; character coverage is identical. Upem, ascent, descent, line gap, x-height and cap-height are unchanged. Regular/Italic retain weights 450/420, not a guessed 400.

Local Pillow/RAQM comparison: 168 shaped samples across both styles and sizes 12, 14, 24, 29, 40, 48 and 72 pixels have exactly equal advances and bounds. `LAYOUT-METRICS.json` and `TYPOGRAPHY-COMPARISON-PILLOW.png` document this; that image is not a native application screenshot.

**Actual native Qt 6.11.1 test, separately executed by the receiving coordinator:** `../font-native-qa/COMPARISON.json` records 960px and 560px surfaces. At each width, all 168 metric cases, QML wrapping/elision/layout records and rendered PNG bytes match exactly; resolved family is Fraunces in both processes. The matching PNG SHA256 values are `bd22dd03a36325f27e1583e0df81608c3ab42f52a5fa13291db10320e31dbe34` (960px) and `05ea1d3bee2286a704dec595fc317835d4407804ae06a0b2c2df460a3c58276c` (560px). This is a focused native QML typography qualification, not a full application/installer GUI or platform-wide qualification.

## Application/installer impact

Application `qml/Theme.qml` defines the display family as Fraunces. Direct file loads occur in Main.qml, SagaUniversePage, ShelvesUniversePage, OnePieceEastBlueAtlas and reader harnesses. Theme.display/direct family uses include One Piece titles/arc cards and Biblio reader controls/footnotes. Existing CSS also loads these font paths. No font-family or QML change is needed for either proposal.

`tools/linux-release/assemble.py` line 53 copies the complete `assets` tree. Thus adding the OFL text and/or adopting restored font metadata changes the assembled Linux payload and the .deb identity. **No provenance-driven geometry replacement or emergency replacement installer is necessary.** If either proposal is integrated into the installer, produce a newly identified installer and rerun bounded packaging and installed-smoke checks; do not silently replace or relabel the preserved candidate. The minimal notice-only approach does not require recompiling the application executable just because this font attribution is corrected, subject to the actual packaging workflow and any other approved changes.

An alternative distribution wrapper that always includes the authentic notice with every binary copy may preserve the old .deb bytes, but its concrete delivery mechanism must be reviewed; merely making a source/notices link optional is not assumed sufficient. Current release acceptance remains with the owner.

## Precise remaining native QML / package test plan if a changed installer is approved

1. Keep reference candidate and proposal in separate directories/processes to avoid application-font registration cache collisions. Register the corresponding Regular/Italic files, confirm FontLoader.Ready and resolved Fraunces family; repeat explicit regular/italic selection at weights 400, 420 and 450 where used.
2. Preserve the already completed 560px/960px native comparison. Add the actual UI surfaces after staging the approved package: Saga and Shelves universe display headers; One Piece arc dock/cards/catalogue; Biblio font card, reader heading and italic footnote. Use long titles, ligatures, accented Latin, numerals and punctuation, and the original view sizes/scales.
3. Capture before/after screenshots and TextMetrics/layout records for elision, wrapping, clipping, line count, baseline and card bounds at 100% and 150% device scale. Confirm unsupported-script fallback coverage has not changed. Do not infer a full real-app pass from the small comparison harness.
4. Package-level checks: font/OFL hashes and actual .deb membership, updated package identity/checksums, package dependency gate, install to clean Ubuntu without SDK, start/quit as non-root, and uninstall preserving user data. Keep the old installer and its prior qualification immutable.

No further external origin question is required for Fraunces. The decision is whether to adopt minimal notice accompaniment or also restore metadata, followed by the corresponding bounded delivery/package qualification. Switzer is a separate analysis, not resolved by these Fraunces results.
