from pathlib import Path
from fontTools.ttLib import TTFont
from PIL import ImageFont,Image,ImageDraw,features
import json,hashlib
B=Path(__file__).resolve().parent.parent;O=B/'font-correction-work';C=B/'candidate/root/opt/colosseum/assets/fonts';P=O/'proposed/assets/fonts';samples=['One Piece','East Blue','The Grand Line','Saga Universe','Feria','To Final Sea','Chapter 123 — The Adventure Continues','ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz','0123456789 ±10s','fi fl ffi ffl café naïve Ångström','(Footnote 42) An italic passage.'];rows=[];glyphs=[]
for style in ['Regular','Italic']:
 a=C/f'Fraunces-{style}.ttf';b=P/f'Fraunces-{style}.ttf';fa=TTFont(a);fb=TTFont(b);assert fa.getBestCmap()==fb.getBestCmap()
 delta=[g for g in fa.getGlyphOrder() if fa['hmtx'][g]!=fb['hmtx'][g]];glyphs.append({'style':style,'glyphs':len(fa.getGlyphOrder()),'cmap_entries':len(fa.getBestCmap()),'changed_advances_or_bearings':delta,'coverage_exact':True})
 for px in [12,14,24,29,40,48,72]:
  x=ImageFont.truetype(a,px,layout_engine=ImageFont.Layout.RAQM);y=ImageFont.truetype(b,px,layout_engine=ImageFont.Layout.RAQM)
  for s in samples:
   ra={'style':style,'px':px,'text':s,'candidate_advance':x.getlength(s),'proposed_advance':y.getlength(s),'candidate_bbox':x.getbbox(s),'proposed_bbox':y.getbbox(s)};assert ra['candidate_advance']==ra['proposed_advance'];assert ra['candidate_bbox']==ra['proposed_bbox'];rows.append(ra)
(O/'LAYOUT-METRICS.json').write_text(json.dumps({'engine':'Pillow RAQM (not Qt)','raqm_available':features.check('raqm'),'font_tables':glyphs,'samples':rows,'all_measured_advances_and_bounds_equal':True},indent=2)+'\n')
print('All',len(rows),'shaped text samples identical; all1396glyph metrics identical.')
# Modest side-by-side proof image; this is explicitly not an application/QML screenshot.
im=Image.new('RGB',(1200,740),'#11151b');d=ImageDraw.Draw(im);label=ImageFont.load_default();d.text((20,15),'Candidate (left) vs metadata-corrected proposal (right) | Pillow RAQM, not native QML',font=label,fill='white')
y=50
for sty in ['Regular','Italic']:
 for px,s in [(29,'One Piece · East Blue'),(40,'The Grand Line'),(48,'Saga Universe'),(24,'Chapter 123 — fi fl café')]:
  d.text((20,y),s,font=ImageFont.truetype(C/f'Fraunces-{sty}.ttf',px),fill='#f7f7f5');d.text((620,y),s,font=ImageFont.truetype(P/f'Fraunces-{sty}.ttf',px),fill='#f7f7f5');d.text((20,y+px+6),sty+' '+str(px)+'px',font=label,fill='#aaaaaa');y+=80
im.save(O/'TYPOGRAPHY-COMPARISON-PILLOW.png')
