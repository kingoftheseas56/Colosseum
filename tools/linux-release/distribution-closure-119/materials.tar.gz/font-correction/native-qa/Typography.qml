import QtQuick
Rectangle {
    id: root
    width: 960; height: 820; color: "#0c0f18"
    property string layoutReport: JSON.stringify([
        {name:"Appearance", width:appearance.implicitWidth, height:appearance.implicitHeight},
        {name:"Sea gate", width:gate.implicitWidth, height:gate.implicitHeight},
        {name:"Reader title", width:title.implicitWidth, height:title.implicitHeight, truncated:title.truncated},
        {name:"Footnote", width:footnote.contentWidth, height:footnote.contentHeight, lineCount:footnote.lineCount},
        {name:"Italic", width:italicText.implicitWidth, height:italicText.implicitHeight},
        {name:"Display", width:displayText.implicitWidth, height:displayText.implicitHeight}
    ])
    Text { x:32; y:24; text:"NATIVE QT TYPOGRAPHY COMPARISON"; color:"#9a99a5"; font.pixelSize:12 }
    Rectangle { x:24; y:64; width:parent.width-48; height:706; radius:16; color:"#171a25"; border.color:"#41434d"
        Text { id:appearance; x:24; y:24; text:"Appearance"; color:"#f7f7f5"; font.family:"Fraunces"; font.weight:Font.Medium; font.pixelSize:16 }
        Text { id:gate; x:24; y:70; text:"REVERSE MOUNTAIN"; color:"#f0c44a"; font.family:"Fraunces"; font.pixelSize:15; style:Text.Outline; styleColor:"black" }
        Text { id:title; x:24; y:116; width:parent.width-48; text:"The Adventures of Sherlock Holmes — An Extended Editorial Title"; color:"#f7f7f5"; font.family:"Fraunces"; font.weight:Font.Medium; font.pixelSize:17; elide:Text.ElideRight }
        Rectangle { x:24; y:170; width:Math.min(420,parent.width-48); height:190; color:"#202330"; border.color:"#454854"
            Text { id:footnote; anchors.fill:parent; anchors.margins:18; text:"Footnotes preserve the rhythm of reading. A narrow panel should wrap gracefully without losing punctuation, italics, or descenders. À bientôt — café, naïve, façade. 0123456789"; font.family:"Fraunces"; font.pixelSize:14; lineHeight:1.4; wrapMode:Text.WordWrap; color:"#f7f7f5" }
        }
        Text { id:italicText; x:24; y:394; width:parent.width-48; text:"A quiet moment between chapters."; font.family:"Fraunces"; font.italic:true; font.pixelSize:28; color:"#c9c8d0"; elide:Text.ElideRight }
        Text { id:displayText; x:24; y:468; width:parent.width-48; text:"Stories live here."; font.family:"Fraunces"; font.pixelSize:48; color:"#f7f7f5"; wrapMode:Text.WordWrap }
        Text { x:24; y:618; width:parent.width-48; text:"Actual application sizes: 14px footnotes · 15px sea gate · 16px Appearance · 17px reader title. Larger specimen sizes expose shape and spacing differences."; font.pixelSize:12; color:"#9a99a5"; wrapMode:Text.WordWrap }
    }
}
