import os
os.environ.setdefault('QT_QPA_PLATFORM','offscreen');os.environ.setdefault('QT_QUICK_BACKEND','software');os.environ.setdefault('QT_FONT_DPI','96')
import argparse,hashlib,json,pathlib,sys
from PySide6.QtCore import QUrl,QTimer,qVersion
from PySide6.QtGui import QGuiApplication,QFontDatabase,QFont,QFontInfo,QFontMetricsF
from PySide6.QtQuick import QQuickView
p=argparse.ArgumentParser();p.add_argument('--regular',required=True);p.add_argument('--italic',required=True);p.add_argument('--out',required=True);p.add_argument('--width',type=int,default=960);a=p.parse_args();out=pathlib.Path(a.out);out.mkdir(parents=True,exist_ok=True)
app=QGuiApplication([]);registered=[]
for path in [a.regular,a.italic]:
 idx=QFontDatabase.addApplicationFont(path)
 if idx<0:raise RuntimeError('Font load failed '+path)
 registered.append({'path':str(pathlib.Path(path).resolve()),'sha256':hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest(),'families':QFontDatabase.applicationFontFamilies(idx)})
font=QFont('Fraunces');font.setPixelSize(17);info=QFontInfo(font)
report={'qt_version':qVersion(),'fixture':'Native QML typography fixture reproducing actual font settings; not full application runtime','requested_family':'Fraunces','resolved_family':info.family(),'exact_match':info.exactMatch(),'registered':registered,'width':a.width,'dpi':app.primaryScreen().logicalDotsPerInch(),'metrics':[]}
strings=['Appearance','REVERSE MOUNTAIN','ROMANCE DAWN','The Adventures of Sherlock Holmes','Footnotes preserve the rhythm of reading. A narrow panel should wrap gracefully without losing punctuation, italics, or descenders.','À bientôt — café, naïve, façade. 0123456789']
for italic in [False,True]:
 for size in [14,15,16,17,18,28,48]:
  for weight in [QFont.Weight.Normal,QFont.Weight.Medium]:
   font=QFont('Fraunces');font.setPixelSize(size);font.setItalic(italic);font.setWeight(weight);fm=QFontMetricsF(font)
   for text in strings:report['metrics'].append({'italic':italic,'size':size,'weight':int(weight),'text':text,'advance':fm.horizontalAdvance(text),'height':fm.height(),'ascent':fm.ascent(),'descent':fm.descent(),'bounds':[fm.boundingRect(text).x(),fm.boundingRect(text).y(),fm.boundingRect(text).width(),fm.boundingRect(text).height()]})
view=QQuickView();view.setResizeMode(QQuickView.SizeRootObjectToView);view.resize(a.width,820);view.setSource(QUrl.fromLocalFile(str(pathlib.Path(__file__).with_name('Typography.qml').resolve())))
if view.status()==QQuickView.Error:raise RuntimeError('\n'.join(e.toString() for e in view.errors()))
view.show()
def capture():
 root=view.rootObject(); report['qml_layout']=json.loads(root.property('layoutReport'));img=view.grabWindow()
 if img.isNull():raise RuntimeError('No native Qt snapshot')
 img.save(str(out/'native-typography.png'));report['png_sha256']=hashlib.sha256((out/'native-typography.png').read_bytes()).hexdigest();report['image_size']=[img.width(),img.height()];(out/'metrics.json').write_text(json.dumps(report,indent=2)+'\n');app.quit()
QTimer.singleShot(500,capture);sys.exit(app.exec())
