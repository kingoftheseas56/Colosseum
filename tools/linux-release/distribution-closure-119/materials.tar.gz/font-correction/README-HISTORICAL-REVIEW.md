# Corrected font review: release candidate preserved

This local review packet supersedes the previous Fraunces-origin blocker. It does not replace the original Linux candidate or its frozen evidence packet. No new commit/ref update, CI run, receiving entry, publication or Fontshare outreach occurred during this correction.

## Decisions and results

1. **Fraunces derivation CLOSED.** Official Google Fonts variable sources, instantiated at the actual weights 450/420 and opsz 40 / SOFT 0 / WONK 0, match all 13 nonmetadata tables and all 698 glyphs per font. Applying only existing name/head metadata reproduces both entire current TTFs byte-for-byte. The user's message was not treated as confirmation. Historical download records are optional now; authentic OFL/copyright accompaniment remains required.
2. **Native typography unchanged.** Actual Qt 6.11.1 QML tests at 560px and 960px: 168 metrics cases per width, wrap/elision/layout records, and PNG bytes all match between candidate fonts and optional metadata-restored files. Screenshots are focused native typography fixtures using actual app settings, not a full-app/installer qualification.
3. **Minimal correction ready.** `fraunces/PROPOSED-NOTICE-ONLY.patch` adds the authentic OFL notice without changing fonts. Optional `PROPOSED-METADATA-AND-NOTICE.patch` restores original font copyright/license metadata while preserving geometry and family selectors. Neither patch was applied to the candidate/app tree.
4. **Installer impact.** No font replacement is needed to resolve provenance. A notice wrapper that actually accompanies every binary copy can preserve the existing .deb, subject to delivery review. Adding notices inside the installer or adopting changed font bytes creates a new package identity and requires bounded package/installed-smoke qualification; no automatic full application rebuild is claimed necessary for a data-only notice change.
5. **Switzer source-delivery scope remains unresolved.** FFL section 01 expressly supports own desktop-application use; section 02 restricts redistribution outside permitted uses and preserves section 01. Actual files are loose QML UI resources. This is strong support for own-app use, not an unqualified raw-source redistribution grant. The exact terms, technical layout and GPL/LGPL scope analysis are in `switzer/ASSESSMENT.md`.

## Conditional no-Switzer source proposal: actually created and verified

Archive name: `colosseum-7792bd1d9-no-switzer-PROPOSAL.tar.gz`
Bytes: 229,022,505
SHA256: `2b25937aa546a488db9f0caf44e94f888ff3e4c806ef89ab296f5a97f22008b3`

The large source archive is retained separately and is not duplicated in this compact review attachment. `switzer/source_option.py` reproduces the exclusion operation from the pinned original application archive; timestamps may differ for a new proposal archive, so always generate and retain its actual hash. The existing proposal's exact hash and validation are recorded here.

Exactly four Switzer OTF members were removed. All other 5,626 members are unchanged. Font-family inspection and recursive ZIP/CBZ/EPUB checks found no remaining Switzer font. Official acquisition instructions and hash-pinned restoration tooling are supplied. No comparison ZIP or Switzer binaries are included in this review attachment.

This verifies the technical alternative, NOT complete Corresponding Source compliance. A third-party download instruction is not automatically a substitute for material legally required in Corresponding Source. The deciding question is whether these independently designed UI fonts are separate data works outside the GPL-covered whole and applicable application/relink-data route; if not, the necessary permissions/source or a compatible-font candidate are still needed. Fontshare clarification cannot waive GPL obligations.

## Precise remaining question

For receiving/licensing review: Given four unmodified Switzer fonts shipped as loose fixed-UI resources, loaded through standard QML font interfaces, and the app's direct GPL-3+ libmpv linkage, may those fonts be treated as independent works outside Corresponding Source (and the selected LGPL application-data route), permitting source that omits them and restores independently acquired exact files? If not, identify the rights/materials needed or choose a separately qualified compatible-font alternative.

No external question has been sent. Do not publish either the old source bundle containing raw Switzer files or this conditional omission proposal as approved source delivery until that question is resolved.

## Preserved release identities and earlier technical work

- Application: `7792bd1d9b3a41185cea522a9984ecd6586e3b44`.
- Installer: 333,715,118 bytes; SHA256 `ddf011d2955de39e19375d492284867db09d48a80f3b4fe717da086a3b3ec67b`.
- Original application source archive: SHA256 `69222a8fd32dee331849a2a1a160001b5d47c7e79b390fb25ee21c939298dac1`.
- Earlier candidate source-material tar: SHA256 `ed66bb813829fb2ddf8976d952006dac320a02bba623fa3f094a71eabaf92d03`, unchanged and not approved for publication.
- Earlier ICU assessment, complete Chromium reconstruction and 457 unchanged dependency ELF proofs remain valid; no dependency or installer bytes changed in this font review.

The earlier five-gap status becomes: ICU exact historical reconstruction not required under inspected ICU terms; Chromium CLOSED; current installer reconciliation CLOSED; build/notices source acceptance BLOCKED only on the Switzer rights/delivery scope (with concrete Fraunces notice integration still requiring the chosen distribution mechanism); durable delivery transport prepared but final asset selection/publication held. No blanket legal clearance is claimed.

## Verify

`SHA256-INDEX.json` covers every file in this compact packet except itself. Hash each listed file and check its byte size. Detailed reports include commands, input pins and actual tests. The optional font patches, verified upstream inputs and authentic OFL text are included for private review. No proposal is silently adopted.
