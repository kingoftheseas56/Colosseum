#!/usr/bin/env python3
"""LOCAL proposal tooling only. Does not establish redistribution compliance."""
import argparse, hashlib, json, pathlib, tarfile, zipfile
HERE=pathlib.Path(__file__).resolve().parent
M=json.loads((HERE/'switzer-manifest.json').read_text())
def digest(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def archive(source, output):
 if digest(source)!=M['original_archive_sha256']:raise SystemExit('Wrong original source archive')
 expected={M['archive_root']+r['path']:r['sha256'] for r in M['files']}
 found={}
 with tarfile.open(source,'r:gz') as src:
  for member in src:
   if member.name in expected:
    if member.name in found or not member.isfile():raise SystemExit('Duplicate/non-file target')
    found[member.name]=hashlib.sha256(src.extractfile(member).read()).hexdigest()
 if found!=expected:raise SystemExit('Missing or different source fonts')
 if output is None:
  print(json.dumps({'status':'AUDIT PASS; no output created','excluded_members':found},indent=2));return
 output=pathlib.Path(output).resolve()
 if HERE not in output.parents:raise SystemExit('Write only inside switzer-correction-work')
 # Exclusive create: never overwrite the existing candidate or a prior proposal.
 with open(output,'xb') as target, tarfile.open(fileobj=target,mode='w:gz') as dest, tarfile.open(source,'r:gz') as src:
  for member in src:
   if member.name not in expected:dest.addfile(member,src.extractfile(member) if member.isfile() else None)
 print(json.dumps({'status':'UNAPPROVED PROPOSAL ONLY','archive':str(output),'sha256':digest(output),'excluded_members':found},indent=2))
def restore(zip_path,source_root,write):
 root=pathlib.Path(source_root).resolve(); verified=[]
 with zipfile.ZipFile(zip_path) as z:
  for r in M['files']:
   if z.namelist().count(r['official_zip_member'])!=1:raise SystemExit('Missing/duplicate official ZIP member')
   data=z.read(r['official_zip_member'])
   if hashlib.sha256(data).hexdigest()!=r['sha256']:raise SystemExit('Official font changed; stop, do not substitute')
   p=root/r['path']
   if p.exists() or p.is_symlink():raise SystemExit('Use a fresh no-font proposal checkout; refusing overwrite')
   if any(q.is_symlink() for q in [root,p.parent,p.parent.parent]):raise SystemExit('Refusing symlink destination')
   verified.append((p,data))
 if write:
  for p,data in verified:
   p.parent.mkdir(parents=True,exist_ok=True)
   with open(p,'xb') as f:f.write(data)
 print(json.dumps({'status':'RESTORED' if write else 'VERIFIED ONLY; add --write after accepting official license', 'count':len(verified)}))
p=argparse.ArgumentParser();sub=p.add_subparsers(dest='mode',required=True)
a=sub.add_parser('exclude');a.add_argument('original_archive');a.add_argument('--output',help='New proposal archive inside this work directory; absent means audit only')
r=sub.add_parser('restore');r.add_argument('official_zip');r.add_argument('fresh_source_root');r.add_argument('--write',action='store_true')
x=p.parse_args()
if x.mode=='exclude':archive(x.original_archive,x.output)
else:restore(x.official_zip,x.fresh_source_root,x.write)
