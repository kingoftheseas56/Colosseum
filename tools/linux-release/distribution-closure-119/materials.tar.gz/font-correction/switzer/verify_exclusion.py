import tarfile,hashlib,json,pathlib,io,zipfile
from fontTools.ttLib import TTFont
p=pathlib.Path(__file__).resolve().parent;m=json.loads((p/'switzer-manifest.json').read_text());src=p.parent/'colosseum-7792bd1d9b3a41185cea522a9984ecd6586e3b44.tar.gz';dst=p/'colosseum-7792bd1d9-no-switzer-PROPOSAL.tar.gz'
exclude={m['archive_root']+x['path'] for x in m['files']};fonts=[];nested=[];bad=[]
def digest(f):
 with f.open('rb') as s:return hashlib.file_digest(s,'sha256').hexdigest()
def inspect_font(name,data):
 if data[:4] in [b'OTTO',b'\0\1\0\0',b'wOFF',b'wOF2']:
  try:
   f=TTFont(io.BytesIO(data));names=sorted({x.toUnicode() for x in f['name'].names if x.nameID in (1,16)});fonts.append({'path':name,'families':names,'sha256':hashlib.sha256(data).hexdigest()})
   if any('switzer' in s.lower() for s in names):bad.append(name)
  except Exception as e:bad.append(name+' font inspection error '+str(e))
 if data[:4] in (b'PK\x03\x04',b'PK\x05\x06'):
  nested.append(name)
  with zipfile.ZipFile(io.BytesIO(data)) as z:
   for x in z.infolist():
    if not x.is_dir():inspect_font(name+'!'+x.filename,z.read(x))
 if data[:2]==b'\x1f\x8b':
  nested.append(name)
  try:
   with tarfile.open(fileobj=io.BytesIO(data),mode='r:gz') as t:
    for x in t:
     if x.isfile():inspect_font(name+'!'+x.name,t.extractfile(x).read())
  except tarfile.ReadError:pass

def inventory(path,inspect=False):
 rows={}
 with tarfile.open(path,'r:gz') as t:
  for x in t:
   data=t.extractfile(x).read() if x.isfile() else b''
   rows[x.name]={'type':x.type.decode('latin1'),'size':x.size,'mode':x.mode,'linkname':x.linkname,'sha256':hashlib.sha256(data).hexdigest() if x.isfile() else None}
   if inspect and x.isfile():inspect_font(x.name,data)
 return rows
old=inventory(src);new=inventory(dst,True);assert set(old)-set(new)==exclude;assert not set(new)-set(old)
changed=[k for k in new if new[k]!=old[k]];assert not changed;assert not bad
r={'status':'PASS: technical exclusion only; not Corresponding Source clearance','original_archive_sha256':digest(src),'proposal_archive_sha256':digest(dst),'proposal_bytes':dst.stat().st_size,'original_members':len(old),'proposal_members':len(new),'excluded_exact_paths':sorted(exclude),'remaining_members_unchanged':len(new),'font_files_inspected':fonts,'nested_archives_inspected':nested,'switzer_fonts_remaining':bad}
(p/'EXCLUSION-VERIFICATION.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items() if k!='font_files_inspected'},indent=2))
