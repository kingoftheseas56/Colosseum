# ICU 73.2 accompanying materials

The three bundled Qt SDK libraries `libicudata.so.73`, `libicui18n.so.73` and `libicuuc.so.73` are ICU 73.2. Their unchanged producer-supplied license is in `LICENSE`, including the complete third-party terms. Preserve it with the software or accompanying distribution documentation/materials. Copyright-owner names are not endorsements.

The files named `producer-*` are actual generated configuration/helper files from Qt's pinned ICU devel prebuilt, not a newly invented original build recipe. The provisioning script installs prebuilt binaries; it does not build ICU. Its own SPDX declaration applies to the script, not to the ICU shared libraries.

Exact Qt source patches, original full configure invocation and original build log have not been established. The Unicode 73.2 source archive is an authenticated upstream candidate, not asserted to be a byte-reproducible source for Qt's prebuilts. No source offer is made here. The Qt SBOM's NOASSERTION fields are preserved separately and are not rewritten by this supplement.

Producer runtime: https://download.qt.io/development_releases/prebuilt/icu/prebuilt/73.2/icu-linux-g++-Rhel8.6-x64.7z
Producer development package: https://download.qt.io/development_releases/prebuilt/icu/prebuilt/73.2/icu-linux-g++-Rhel8.6-x64-devel.7z
Provisioning script: https://github.com/qt/qt5/blob/v6.11.1/coin/provisioning/qtci-linux-RHEL-9.6-x86_64/30-install_icu.sh
Unicode source: https://github.com/unicode-org/icu/releases/download/release-73-2/icu4c-73_2-src.tgz
Unicode license: https://github.com/unicode-org/icu/blob/release-73-2/icu4c/LICENSE
