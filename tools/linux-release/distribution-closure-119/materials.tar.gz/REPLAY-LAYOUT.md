# Evidence replay layout

The preparation workflow and `prepare_sources.py`, `reconcile_candidate.py`, and `verify_packet.py` accept explicit input paths. They are the supported complete-packet receiving path.

The dedicated ICU/Chromium scripts are retained as the original focused investigation tools, not falsely described as runnable without their inputs. For an independent replay, use sibling folders `review/` (unpack the original verified review/source artifacts), `candidate/root/` (extract the verified current .deb), `icu-work/`, and `chromium-work/`. Place each relevant proof script and its named reports in its corresponding work folder. Retrieve exact public producer archives and pinned Git objects at the URLs/hashes in the assessments. No runtime binary execution is required.

ICU `verify_icu.py` expects the three recorded .7z archives plus extracted `provisioning/`, `devel/`, and `installer/` folders. The generated proof JSON records all archive/member hashes and the precise ELF RPATH edit. The original archive/member notices/configuration are supplied in supplements, but comparison binary archives are not claimed to be source assets.

Chromium replay starts with the exact publisher source archive from `source-delivery/upstream/qtwebengine/` and a regenerated pinned `chromium-git-tree.z` plus blobless `chromium.git` per CHROMIUM-CLOSURE.md. Three main-module Git metadata blobs are available in the small reconstruction supplement and must be named `main-module.gitattributes`, `main-module.gitignore`, and `main-module.tag`. Run verify_coverage.py, resolve_transformations.py, finish_evidence.py, then verify_reconstructed.py. The scripts generate the large full-file inventories rather than silently substituting the compact report for byte-level proof. Network access is needed only to acquire missing pinned Git objects.

The separate source preparation workflow does not repeat the upstream acquisitions or full Chromium analysis. It verifies the complete prior index, current candidate bytes, supplemental evidence index, and deterministic final source-archive hash. Tests of a collector are never a substitute for the actual-output hash/proof checks.
