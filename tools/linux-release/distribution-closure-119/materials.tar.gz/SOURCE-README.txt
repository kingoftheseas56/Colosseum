Colosseum 1.1.9 candidate-specific source materials, prepared for review only.
Application: 7792bd1d9b3a41185cea522a9984ecd6586e3b44.
Installer SHA256: ddf011d2955de39e19375d492284867db09d48a80f3b4fe717da086a3b3ec67b.
The original 180 Ubuntu source sets are reused by unchanged dependency-file proofs; none were reacquired. Exact publisher Qt source archives and retained git snapshots are preserved. The Chromium supplement restores original Git symlink and metadata representation. ICU candidate source remains explicitly unproven as exact original patched producer source; its notice/build evidence supplement is separate.
This is not a source offer, licensing clearance, published release or claim of bit-for-bit rebuild. Read the accompanying review packet for obligations, remaining notice prerequisites, source/build scope and publication gates. Original older application source is NOT substituted here: application/ contains only the pinned current candidate source.
