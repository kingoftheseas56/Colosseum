# Full Linux 1.1.9 receiving packet

Start with reports/CLOSURE-REPORT.md for the five-gap disposition and the single unresolved Switzer source-scope decision. This is a full technical receiving packet, not only the font review. It includes ICU and Chromium proofs, current installer reconciliation, accompanying notices, build/relink records, hosting preparation and corrected font evidence. Bulk sources and binaries are referenced by exact hashes, not duplicated or newly published. No production acceptance is claimed.

The font-correction historical review README describes the earlier local-only checkpoint. This final packet contains no font binaries or optional font replacement patch. Replaying font derivation requires the exact official inputs identified in VERIFIED-UPSTREAM-INPUTS.json.

The candidate inventory retains hashes of original broad host/SDK notices, but duplicate retained payloads are not embedded here. CI regenerates them from the exact package. The bundled-only accompanying notice set is under notices/overlay.
