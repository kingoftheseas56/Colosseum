import QtQuick
import QtQuick.Window
import QtTest
import "../../qml" as App

TestCase {
    id: suite
    name: "Android022VolumeFlow"
    when: windowShown
    Window {
        id: host
        visible: true
        width: 792
        height: 354
        property bool androidHost: true
    }
    Component { id: libraryComponent; App.MangaTankobanLibrary { anchors.fill: parent } }
    property var library: null

    function cleanup() {
        if (library) library.destroy()
        library = null
        wait(0)
    }
    function makeLibrary(width, height, touch) {
        host.width = width
        host.height = height
        host.androidHost = touch
        library = libraryComponent.createObject(host.contentItem)
        verify(library !== null)
        let rows = []
        for (let i = 1; i <= 12; ++i)
            rows.push({id: "volume-" + i, number: i, state: "none", cover: "", title: "Volume " + i})
        library.volumeRows = rows
        library.focusAtNumber(1)
        wait(300)
        return findChild(library, "volumeFlow")
    }
    function firstCoverX(flow) {
        const card = findChild(library, "tankobanVolumeCard_1")
        verify(card !== null)
        return card.mapToItem(flow, 0, 0).x
    }
    function verifyPhoneCoversAlign(flow) {
        const first = findChild(library, "tankobanVolumeCard_1")
        const second = findChild(library, "tankobanVolumeCard_2")
        verify(first !== null && second !== null)
        const firstTop = first.mapToItem(flow, 0, 0).y
        const secondTop = second.mapToItem(flow, 0, 0).y
        verify(Math.abs(firstTop - secondTop) <= 1,
               "The first volume must share the next volume's alignment: " + firstTop + " vs " + secondTop)
    }
    function test_phone_landscape_starts_at_left_and_keeps_selected_book_visible() {
        const flow = makeLibrary(792, 354, true)
        verify(firstCoverX(flow) <= 64, "phone shelf must start within the page margin")
        verifyPhoneCoversAlign(flow)
        library.focusAtNumber(8)
        wait(300)
        const card = findChild(library, "tankobanVolumeCard_8")
        verify(card !== null)
        const point = card.mapToItem(flow, 0, 0)
        verify(point.x >= -1 && point.x + card.width <= flow.width + 1,
               "keyboard/jump navigation must retain the selected book in the phone viewport")
    }
    function test_phone_portrait_starts_at_left() {
        const flow = makeLibrary(354, 792, true)
        verify(firstCoverX(flow) <= 64)
        verifyPhoneCoversAlign(flow)
    }
    function test_desktop_keeps_centered_volume_presentation() {
        const flow = makeLibrary(1280, 800, false)
        verify(firstCoverX(flow) > flow.width / 4)
    }
}
