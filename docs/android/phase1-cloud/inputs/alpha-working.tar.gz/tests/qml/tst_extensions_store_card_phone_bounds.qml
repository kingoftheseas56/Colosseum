import QtQuick
import QtQuick.Window
import QtTest
import "../../qml" as App

TestCase {
    id: tests
    name: "ExtensionsStoreCardPhoneBounds"
    when: windowShown

    Window {
        id: host
        width: 354
        height: 792
        visible: true
        property bool androidHost: true
    }
    Component { id: cardComponent; App.ExtensionsStoreCard {} }
    SignalSpy { id: activationSpy; signalName: "activated" }

    function test_actions_align_and_details_remain_readable_data() {
        return [
            {tag: "small-phone", width: 320, installed: false},
            {tag: "oneplus", width: 354, installed: false},
            {tag: "small-installed", width: 320, installed: true},
            {tag: "oneplus-installed", width: 354, installed: true},
            {tag: "landscape", width: 792, installed: false}
        ]
    }

    function test_actions_align_and_details_remain_readable(data) {
        host.width = data.width
        const card = createTemporaryObject(cardComponent, host.contentItem, {
            width: host.width - 36,
            phoneLayout: true,
            installed: data.installed,
            addon: {
                slug: "torrentio",
                name: "Torrentio",
                title: "Streaming Catalogs",
                configurable: true,
                description: "Browse trending movies and series across streaming providers. "
                    + "A deliberately long description keeps More available without squeezing "
                    + "the title or moving either action outside the card. ".repeat(4)
            }
        })
        verify(card !== null)
        waitForRendering(card)
        const title = findChild(card, "extensionsPhoneTitle")
        const description = findChild(card, "extensionsPhoneDescription")
        const more = findChild(card, "extensionsPhoneMore")
        const primary = findChild(card, "extensionsPhonePrimaryAction")
        verify(title && description && more && primary)
        verify(more.visible)
        verify(title.width >= card.width / 2,
               "The title needs at least half the narrow card rather than an action-sized sliver")
        const morePosition = more.mapToItem(card, 0, 0)
        const primaryPosition = primary.mapToItem(card, 0, 0)
        verify(Math.abs(morePosition.y - primaryPosition.y) <= 1,
               "More and Set up must share one action row")
        verify(morePosition.x + more.width <= primaryPosition.x,
               "The existing actions must not overlap")
        for (const button of [more, primary]) {
            const position = button.mapToItem(card, 0, 0)
            verify(button.width >= 48 && button.height >= 48)
            verify(position.x >= 0 && position.x + button.width <= card.width + 0.5)
            verify(position.y >= 0 && position.y + button.height <= card.height + 0.5)
        }
        activationSpy.target = card
        activationSpy.clear()
        const collapsedHeight = card.height
        mouseClick(more, more.width / 2, more.height / 2)
        tryCompare(card, "phoneDescriptionExpanded", true)
        tryVerify(function() { return card.height > collapsedHeight }, 1500,
                  "Expanding the description must grow the card after layout settles")
        compare(activationSpy.count, 0)
        mouseClick(more, more.width / 2, more.height / 2)
        tryCompare(card, "phoneDescriptionExpanded", false)
        tryCompare(card, "height", collapsedHeight)
        mouseClick(primary, primary.width / 2, primary.height / 2)
        compare(activationSpy.count, 1, "Set up must still activate the existing card action")
    }
}
