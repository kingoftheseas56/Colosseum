// AddonClient.js — the generic Stremio-extension caller (spec slice E).
// Where Torrentio.js speaks to ONE addon, this speaks to EVERY installed stream
// extension: Harbor's resource-matching algorithm (src/lib/addons.ts:50-71) +
// parallel fetch with partial results (src/lib/streams/addons.ts), with
// Torrentio.js's proven quality/seeders/language parsing generalized so every
// extension's answers rank the same way. Torrentio.js stays for the
// season-download resolver; the SourcesSheet asks through here.
//
// URL-stream convention: rows with a direct `url` (debrid, HTTP hosts, live tv)
// carry infoHash = "url:<url>" so they flow through the existing play chain
// (playRequested → playTorrent → playStreamAt) with NO signal changes — the
// same routing-prefix trick as the western lane's "gc:" series ids. The player
// branches on the prefix and hands the url straight to mpv.
.pragma library

// per-extension answer window: the slow family gets Harbor's long leash
var FAST_TIMEOUT_MS = 8000;
var SLOW_TIMEOUT_MS = 22000;
var SLOW_RE = /mediafusion|comet|torrentio|knightcrawler|aiostreams|jackettio|torbox/i;

function _get(url, timeoutMs, done) {
    var xhr = new XMLHttpRequest();
    var settled = false;
    function finish(v) { if (!settled) { settled = true; done(v); } }
    xhr.onreadystatechange = function() {
        if (xhr.readyState !== XMLHttpRequest.DONE) return;
        if (xhr.status < 200 || xhr.status >= 300) { finish(null); return; }
        try { finish(JSON.parse(xhr.responseText)); } catch (e) { finish(null); }
    };
    xhr.onerror = function() { finish(null); };
    try { xhr.timeout = timeoutMs; xhr.ontimeout = function() { finish(null); }; } catch (e) { /* older QML XHR */ }
    try {
        xhr.open("GET", url);
        xhr.send();
    } catch (e) {
        finish(null);
    }
    return function() {
        if (settled) return;
        settled = true;
        try { xhr.abort(); } catch (e) { /* already closed */ }
    };
}

// ---------------------------------------------------------------- matching
// Harbor's algorithm: specific resource entries ({name,types,idPrefixes}) win;
// bare string resources fall back to the manifest-level types/idPrefixes.

function _prefixOk(prefixes, id) {
    if (!prefixes || !prefixes.length) return true;
    for (var i = 0; i < prefixes.length; i++)
        if (String(id).indexOf(prefixes[i]) === 0) return true;
    return false;
}

function accepts(manifest, resource, type, id) {
    if (!manifest) return false;
    var resources = manifest.resources || [];
    var specific = [];
    for (var i = 0; i < resources.length; i++)
        if (typeof resources[i] === "object" && resources[i] && resources[i].name === resource)
            specific.push(resources[i]);
    if (specific.length > 0) {
        for (var j = 0; j < specific.length; j++) {
            var r = specific[j];
            var typeOk = r.types && r.types.indexOf(type) !== -1;
            if (typeOk && _prefixOk(r.idPrefixes, id)) return true;
        }
        return false;
    }
    var named = false;
    for (var k = 0; k < resources.length; k++)
        if (resources[k] === resource) { named = true; break; }
    if (!named) return false;
    if (!manifest.types || manifest.types.indexOf(type) === -1) return false;
    return _prefixOk(manifest.idPrefixes, id);
}

// ------------------------------------------------------- parsing (Torrentio.js lineage)

function _quality(s) {
    var hay = ((s.name || "") + " " + (s.title || "")).toLowerCase();
    if (/2160p|\b4k\b|uhd/.test(hay)) return "4K";
    if (/1080p/.test(hay)) return "1080p";
    if (/720p/.test(hay)) return "720p";
    if (/480p/.test(hay)) return "480p";
    return "SD";
}

function _rank(q) {
    return q === "4K" ? 4 : q === "1080p" ? 3 : q === "720p" ? 2 : q === "480p" ? 1 : 0;
}

function _seeders(s) {
    var m = (s.title || "").match(/\u{1F464}\s*(\d+)/u);
    return m ? parseInt(m[1], 10) : -1;
}

function _size(s) {
    var m = (s.title || "").match(/\u{1F4BE}\s*([\d.]+\s*[KMGT]B)/u);
    return m ? m[1].replace(/\s+/g, " ").trim() : "";
}

function _release(s) {
    return (s.title || s.name || s.description || "").split("\n")[0].trim();
}

function _hay(s) {
    return ((s.name || "") + " " + (s.title || "") + " " +
            ((s.behaviorHints && s.behaviorHints.filename) || "")).toLowerCase();
}

function _contains(arr, v) {
    for (var i = 0; i < arr.length; ++i)
        if (arr[i] === v) return true;
    return false;
}

function _videoMatches(text, pattern) {
    var re = new RegExp(pattern, "gi");
    var out = [];
    var match;
    while ((match = re.exec(text)) !== null) {
        out.push({ index: match.index, length: match[0].length, text: match[0] });
        if (!match[0].length) ++re.lastIndex;
    }
    return out;
}

function _videoMarkerNearCodec(text, marker, codec, maxDistance, allowWords) {
    var markerStart = marker.index;
    var markerEnd = markerStart + marker.length;
    var codecStart = codec.index;
    var codecEnd = codecStart + codec.length;
    var gapStart = markerStart >= codecEnd ? codecEnd : markerEnd;
    var gapEnd = markerStart >= codecEnd ? markerStart : codecStart;
    if (gapEnd - gapStart > maxDistance) return false;
    return allowWords || !/[a-z0-9]/i.test(text.slice(gapStart, gapEnd));
}

function _videoProfile(mime, marker) {
    var value = marker.toLowerCase().replace(/[^a-z0-9]/g, "");
    if (mime === "video/hevc" || mime === "video/av01") {
        if (value.indexOf("main10") >= 0 || value.indexOf("10main") >= 0
                || value.indexOf("10bit") >= 0 || value === "10b"
                || value.indexOf("hdr10") === 0) return "main10";
        if (value === "main" || value === "main8" || value === "8main") return "main";
        return "";
    }
    if (mime === "video/avc") {
        if (value.indexOf("baseline") >= 0) return "baseline";
        if (value.indexOf("high444") >= 0) return "high444";
        if (value.indexOf("high422") >= 0) return "high422";
        if (value.indexOf("high10") >= 0) return "high10";
        if (value.indexOf("constrainedhigh") >= 0 || value.indexOf("highconstrained") >= 0
                || value === "high" || value === "main") return value === "main" ? "main" : "high";
        return "";
    }
    return "";
}

// Stremio has no standard video-codec fields. Parse explicit evidence from its
// name/title or filename hint; absent or contradictory hints remain unknown.
function _videoDescriptor(s) {
    var hints = [String(s.name || ""), String(s.title || ""),
                 String((s.behaviorHints && s.behaviorHints.filename) || "")];
    var specs = [
        { mime: "video/hevc", pattern: "\\bhevc\\b|\\bh[\\s._-]?265\\b|\\bx265\\b" },
        { mime: "video/avc", pattern: "\\bavc\\b|\\bh[\\s._-]?264\\b|\\bx264\\b" },
        { mime: "video/av01", pattern: "\\bav0?1\\b" },
        { mime: "video/dolby-vision", pattern: "\\bdv\\b|\\bdovi\\b|dolby[\\s._-]?vision" }
    ];
    var matchesByMime = ({});
    for (var h = 0; h < hints.length; ++h) {
        var text = hints[h].toLowerCase();
        for (var f = 0; f < specs.length; ++f) {
            var matches = _videoMatches(text, specs[f].pattern);
            if (!matches.length) continue;
            if (!matchesByMime[specs[f].mime]) matchesByMime[specs[f].mime] = [];
            for (var m = 0; m < matches.length; ++m)
                matchesByMime[specs[f].mime].push({ text: text, index: matches[m].index, length: matches[m].length });
        }
    }

    var foundMimes = [];
    for (var mime in matchesByMime)
        if (Object.prototype.hasOwnProperty.call(matchesByMime, mime)) foundMimes.push(mime);
    // DV has its own MediaCodec family; its label is the operative constraint
    // when the same name also mentions its HEVC/AV1 base layer.
    var selectedMime = _contains(foundMimes, "video/dolby-vision")
        ? "video/dolby-vision" : (foundMimes.length === 1 ? foundMimes[0] : "");
    var ambiguous = foundMimes.length > 1 && selectedMime !== "video/dolby-vision";
    var profiles = [];
    var levels = [];

    if (selectedMime && selectedMime !== "video/dolby-vision") {
        var profilePattern = selectedMime === "video/avc"
            ? "\\bconstrained[\\s._-]*baseline\\b|\\bbaseline[\\s._-]*constrained\\b"
                + "|\\bconstrained[\\s._-]*high\\b|\\bhigh[\\s._-]*constrained\\b"
                + "|\\bhigh[\\s._-]*4\\s*:\\s*2\\s*:\\s*2\\b|\\bhigh[\\s._-]*422\\b"
                + "|\\bhigh[\\s._-]*4\\s*:\\s*4\\s*:\\s*4\\b|\\bhigh[\\s._-]*444\\b"
                + "|\\bhigh[\\s._-]*10\\b|\\bbaseline\\b|\\bmain\\b"
                + "|\\bhigh\\b(?![\\s._-]*(?:10\\b|422\\b|444\\b|4\\s*:\\s*[24]\\s*:\\s*[24]\\b))"
            : "\\bmain[\\s._-]*10\\b|\\b10[\\s._-]*main\\b|\\bmain[\\s._-]*8\\b"
                + "|\\bmain\\b|\\b10[\\s._-]*bit\\b|\\b10b\\b|\\bhdr10\\+?(?![a-z0-9])";
        for (var p = 0; p < matchesByMime[selectedMime].length; ++p) {
            var codecMatch = matchesByMime[selectedMime][p];
            var nearProfiles = _videoMatches(codecMatch.text, profilePattern);
            for (var n = 0; n < nearProfiles.length; ++n) {
                if (!_videoMarkerNearCodec(codecMatch.text, nearProfiles[n], codecMatch, 24, false)) continue;
                var normalizedProfile = _videoProfile(selectedMime, nearProfiles[n].text);
                if (normalizedProfile && !_contains(profiles, normalizedProfile)) profiles.push(normalizedProfile);
            }
            if (selectedMime === "video/avc") {
                var nearLevels = _videoMatches(codecMatch.text,
                    "\\blevel[\\s:=._-]*(\\d{1,2}\\.\\d{1,2})\\b|\\bl(\\d{1,2}\\.\\d{1,2})\\b");
                for (var l = 0; l < nearLevels.length; ++l) {
                    if (!_videoMarkerNearCodec(codecMatch.text, nearLevels[l], codecMatch, 64, true)) continue;
                    var numberMatch = nearLevels[l].text.match(/(\d{1,2}\.\d{1,2})/);
                    var parsedLevel = numberMatch ? Number(numberMatch[1]) : 0;
                    if (parsedLevel > 0 && levels.indexOf(parsedLevel) < 0) levels.push(parsedLevel);
                }
            }
        }
    }

    if (profiles.length > 1 || levels.length > 1) ambiguous = true;
    return {
        mime: selectedMime,
        profile: profiles.length === 1 ? profiles[0] : "",
        level: levels.length === 1 ? levels[0] : 0,
        ambiguous: ambiguous
    };
}

function _codecName(mime) {
    return mime === "video/hevc" ? "HEVC"
        : mime === "video/avc" ? "H.264"
        : mime === "video/av01" ? "AV1"
        : mime === "video/dolby-vision" ? "Dolby Vision" : "video codec";
}

function _profileName(profile) {
    if (profile === "main") return "Main";
    if (profile === "main10") return "Main10";
    if (profile === "baseline") return "Baseline";
    if (profile === "high") return "High";
    if (profile === "high10") return "High10";
    if (profile === "high422") return "High422";
    if (profile === "high444") return "High444";
    return "";
}

function _normalizedCapabilityProfile(mime, profile) {
    var value = String(profile || "").toLowerCase().replace(/[^a-z0-9]/g, "");
    if (value === "constrainedbaseline") value = "baseline";
    if (value === "constrainedhigh") value = "high";
    if (mime === "video/hevc" && value === "mainstill") {
        // Android reports HEVC Main Still separately; it is not Main or Main10 coverage.
        return value;
    }
    if (mime === "video/hevc" || mime === "video/av01") {
        return value === "main" || value === "main10" ? value : "";
    }
    if (mime === "video/avc")
        return _contains(["baseline", "main", "high", "high10", "high422", "high444"], value) ? value : "";
    return "";
}

function _decoderProfileCovers(mime, decoderProfile, sourceProfile) {
    if (decoderProfile === sourceProfile) return true;
    if ((mime === "video/hevc" || mime === "video/av01")
            && decoderProfile === "main10" && sourceProfile === "main") return true;
    if (mime === "video/avc") {
        var avcCoverage = {
            main: ["baseline"],
            high: ["baseline", "main"],
            high10: ["baseline", "main", "high"],
            high422: ["baseline", "main", "high", "high10"],
            high444: ["baseline", "main", "high", "high10", "high422"]
        };
        return _contains(avcCoverage[decoderProfile] || [], sourceProfile);
    }
    return false;
}

function _compatibility(state, reason) { return { state: state, reason: reason || "" }; }

// Imported .pragma library code cannot read the caller's QML context properties.
// QML callers pass PlatformRuntime explicitly through loadStreams/parseStream.
function _videoCompatibility(descriptor, platformRuntime) {
    if (!descriptor || !descriptor.mime || descriptor.ambiguous)
        return _compatibility("unknown", "Codec profile is not explicit");
    if (!platformRuntime || platformRuntime.android !== true)
        return _compatibility("unknown", "Android decoder capabilities are not applicable");

    var capabilities = null;
    try { capabilities = platformRuntime.videoDecodeCapabilities; } catch (e) { capabilities = null; }
    if (!capabilities || capabilities.available !== true || capabilities.complete !== true
            || !capabilities.decoders || typeof capabilities.decoders.length !== "number")
        return _compatibility("unknown", "Android decoder inventory is unavailable or incomplete");

    var familyDecoders = [];
    for (var i = 0; i < capabilities.decoders.length; ++i) {
        var decoder = capabilities.decoders[i];
        if (!decoder || typeof decoder !== "object" || typeof decoder.mime !== "string")
            return _compatibility("unknown", "Android decoder inventory is invalid");
        if (decoder.mime.toLowerCase() === descriptor.mime) familyDecoders.push(decoder);
    }
    if (!familyDecoders.length && descriptor.mime === "video/dolby-vision") {
        var fallbackMimes = ["video/avc", "video/hevc", "video/av01"];
        for (var f = 0; f < capabilities.decoders.length; ++f) {
            var fallbackDecoder = capabilities.decoders[f];
            if (fallbackDecoder && typeof fallbackDecoder.mime === "string"
                    && _contains(fallbackMimes, fallbackDecoder.mime.toLowerCase()))
                return _compatibility("unknown", "Dolby Vision base-layer playback depends on the source profile");
        }
    }
    if (!familyDecoders.length)
        return _compatibility("unsupported", "No " + _codecName(descriptor.mime) + " decoder is available");
    if (descriptor.mime === "video/dolby-vision")
        return _compatibility("supported", "A Dolby Vision decoder is available");

    var records = [];
    var incompleteProfiles = false;
    for (var d = 0; d < familyDecoders.length; ++d) {
        var decoderProfiles = familyDecoders[d].profiles;
        var decoderComplete = familyDecoders[d].profilesComplete === true;
        if (familyDecoders[d].profilesComplete === undefined
                && decoderProfiles && decoderProfiles.length > 0) decoderComplete = true;
        if (!decoderProfiles || typeof decoderProfiles.length !== "number" || decoderProfiles.length === 0)
            decoderComplete = false;
        if (!decoderComplete) incompleteProfiles = true;
        if (!decoderProfiles || typeof decoderProfiles.length !== "number") continue;
        for (var j = 0; j < decoderProfiles.length; ++j) {
            var entry = decoderProfiles[j];
            if (!entry || typeof entry !== "object") { incompleteProfiles = true; continue; }
            var normalized = _normalizedCapabilityProfile(descriptor.mime, entry.profile);
            if (!normalized) { incompleteProfiles = true; continue; }
            var level = (typeof entry.level === "number" && isFinite(entry.level) && entry.level > 0)
                ? entry.level : 0;
            records.push({ profile: normalized, level: level });
        }
    }

    var codecLabel = _codecName(descriptor.mime);
    if (!descriptor.profile)
        return _compatibility("unknown", "Source profile is not explicit");

    var matching = [];
    for (var k = 0; k < records.length; ++k)
        if (_decoderProfileCovers(descriptor.mime, records[k].profile, descriptor.profile)) matching.push(records[k]);
    if (!matching.length) {
        if (incompleteProfiles) return _compatibility("unknown", "Decoder profile inventory is incomplete");
        return _compatibility("unsupported", "No " + codecLabel + " " + _profileName(descriptor.profile) + " decoder is available");
    }
    if (!descriptor.level)
        return _compatibility("unknown", "Source level is not explicit");

    var levelSupported = false;
    var levelUnknown = incompleteProfiles;
    for (var m = 0; m < matching.length; ++m) {
        if (!matching[m].level) levelUnknown = true;
        else if (matching[m].level >= descriptor.level) levelSupported = true;
    }
    if (levelSupported) return _compatibility("supported", "A compatible decoder profile and level are available");
    if (levelUnknown) return _compatibility("unknown", "Decoder level inventory is incomplete");
    return _compatibility("unsupported", codecLabel + " " + _profileName(descriptor.profile)
        + " level " + descriptor.level + " exceeds decoder support");
}

function _pushTag(arr, v) {
    if (v && !_contains(arr, v)) arr.push(v);
}

function _tags(s, q) {
    var hay = _hay(s);
    var out = [];
    _pushTag(out, q);
    if (/web[\s.\-]?dl/.test(hay)) _pushTag(out, "WEB-DL");
    else if (/web[\s.\-]?rip/.test(hay)) _pushTag(out, "WEBRip");
    else if (/blu[\s.\-]?ray|bdrip|br[\s.\-]?rip/.test(hay)) _pushTag(out, "BluRay");
    if (/hevc|h[\s.\-]?265|x265/.test(hay)) _pushTag(out, "HEVC");
    else if (/avc|h[\s.\-]?264|x264/.test(hay)) _pushTag(out, "H.264");
    if (/\bav0?1\b/.test(hay)) _pushTag(out, "AV1");
    if (/\bdv\b|dolby[\s.\-]?vision/.test(hay)) _pushTag(out, "DV");
    if (/hdr10\+/.test(hay)) _pushTag(out, "HDR10+");
    else if (/\bhdr\b/.test(hay)) _pushTag(out, "HDR");
    if (/atmos/.test(hay)) _pushTag(out, "ATMOS");
    return out;
}

function _qualityLine(tags, q) {
    var left = q;
    if (_contains(tags, "DV")) left += " DV";
    if (_contains(tags, "HDR10+")) return left + " | HDR10+";
    if (_contains(tags, "HDR")) return left + " | HDR";
    return left;
}

function _sourceName(s, fallback) {
    var lines = (s.title || "").split("\n");
    for (var i = 1; i < lines.length; ++i) {
        var line = lines[i].replace(/\u{1F464}\s*\d+/gu, "")
                           .replace(/\u{1F4BE}\s*[\d.]+\s*[KMGT]B/gu, "")
                           .replace(/[|•]/g, " ")
                           .replace(/\s+/g, " ")
                           .trim();
        if (line.length > 0 && line.length < 40) return line;
    }
    if (s.name && s.name.length && s.name.length < 40) return s.name;
    return fallback || "P2P";
}

function _languages(s) {
    var t = String(s.title || "");
    var chars = Array.from(t);
    var out = [];
    for (var i = 0; i < chars.length - 1; ++i) {
        var a = chars[i].codePointAt(0);
        var b = chars[i + 1].codePointAt(0);
        if (a >= 0x1F1E6 && a <= 0x1F1FF && b >= 0x1F1E6 && b <= 0x1F1FF) {
            var code = String.fromCharCode(65 + (a - 0x1F1E6)) + String.fromCharCode(65 + (b - 0x1F1E6));
            if (out.indexOf(code) === -1) out.push(code);
            ++i;
        }
    }
    return out;
}

function _host(url) {
    var m = String(url).match(/^[a-z]+:\/\/([^/]+)/i);
    return m ? m[1] : "";
}

// Resolve a Stremio stream resource from the exact transport URL that was
// installed. Configured add-ons commonly encode state in the path and some
// carry it in the query; both must survive the manifest-to-resource rewrite.
function _transportParts(transportUrl) {
    var raw = String(transportUrl || "").trim();
    if (!raw || /^colosseum:\/\//i.test(raw)
        || !/^https?:\/\//i.test(raw))
        return null;

    var split = raw.length;
    var query = raw.indexOf("?");
    var hash = raw.indexOf("#");
    if (query >= 0 && query < split) split = query;
    if (hash >= 0 && hash < split) split = hash;

    var path = raw.slice(0, split).replace(/\/+$/, "");
    var suffix = raw.slice(split);
    if (!/\/manifest\.json$/i.test(path))
        path += "/manifest.json";
    return {
        base: path.replace(/\/manifest\.json$/i, ""),
        suffix: suffix
    };
}

// Public to the deterministic contract harness. Stremio ids intentionally
// retain their colons because the existing add-on contract uses them raw.
function streamEndpoint(transportUrl, type, id) {
    var parts = _transportParts(transportUrl);
    if (!parts || !type || id === undefined || id === null || !String(id).length)
        return "";
    var sType = type === "series" ? "series" : "movie";
    return parts.base + "/stream/" + sType + "/" + String(id) + ".json" + parts.suffix;
}

// Direct Stremio URLs may carry origin request headers under the standard
// behaviorHints.proxyHeaders.request wrapper. Colosseum's mpv seam consumes a flat map.
// Keep the historical flat proxyHeaders form as a compatibility fallback, but never
// mistake proxy response headers for origin request headers.
function _isObjectMap(value) {
    return value && typeof value === "object" && !Array.isArray(value);
}

function _requestHeaders(s) {
    var hints = (s && s.behaviorHints) || ({});
    var proxy = hints.proxyHeaders || ({});
    if (!_isObjectMap(proxy)) return ({});

    if (_isObjectMap(proxy.request))
        return proxy.request;

    // A standard wrapper with no usable request map contributes no origin headers.
    // In particular, response-only hints belong to proxy response handling, not mpv.
    if (proxy.request !== undefined || proxy.response !== undefined)
        return ({});

    return proxy;
}

// One stream from one extension → a sheet row. Returns null for rows the player
// can't carry (no infoHash AND no direct url — e.g. externalUrl-only addons).
function parseStream(s, addonName, addonPriority, addonId, platformRuntime) {
    if (!s || typeof s !== "object" || Array.isArray(s)) return null;
    var isTorrent = !!(s.infoHash && String(s.infoHash).length);
    var directUrl = !isTorrent && s.url ? String(s.url) : "";
    if (!isTorrent && !directUrl) return null;

    var q = _quality(s);
    var tags = _tags(s, q);
    var videoCodec = _videoDescriptor(s);
    var videoCompatibility = _videoCompatibility(videoCodec, platformRuntime);
    var langs = _languages(s);
    var multi = /\bmulti\b|multi[\s.\-]?audio|dual[\s.\-]?audio/.test(_hay(s));
    return {
        quality: q,
        rank: _rank(q),
        seeders: isTorrent ? _seeders(s) : -1,
        size: _size(s),
        release: _release(s),
        tags: tags,
        qualityLine: _qualityLine(tags, q),
        videoCodec: videoCodec,
        videoCompatibility: videoCompatibility,
        sourceName: isTorrent ? _sourceName(s, "P2P") : (_host(directUrl) || addonName),
        languages: langs,
        audio: (multi || langs.length > 1) ? "Multi Audio" : "English",
        streamKind: isTorrent ? "Torrent" : "Direct",
        streamLabel: isTorrent ? "P2P stream" : "HTTP stream",
        addonName: addonName,
        // Stable extension provenance survives into Player 1 for Watch Party eligibility.
        // Deliberately do NOT carry transportUrl: configured extension URLs may embed
        // provider configuration or credentials and are not room/source identity.
        addonId: addonId || "",
        addonPriority: addonPriority,
        // the routing convention: url rows ride the torrent chain under a prefix
        infoHash: isTorrent ? s.infoHash : ("url:" + directUrl),
        url: directUrl,
        fileIdx: (s.fileIdx !== undefined && s.fileIdx !== null) ? s.fileIdx : 0,
        bingeGroup: (s.behaviorHints && s.behaviorHints.bingeGroup) || "",
        // HTTP hosts that gate on a Referer/Origin deliver the required headers here; the player
        // installs them via mpv.loadFileWithHeaders. Torrent rows carry none. (House HTTP, slice 1.)
        headers: isTorrent ? ({}) : _requestHeaders(s),
        filename: (s.behaviorHints && s.behaviorHints.filename) || ""
    };
}

// ------------------------------------------------------------ season packs

// Season-pack test (season checkout picker, 2026-07-19). A row answers an
// EPISODE ask, so a pack is a torrent whose NAME doesn't pin that single
// episode but does claim the season — or a complete/batch/episode-range run.
// The filename hint (the file inside the torrent) is ignored on purpose: packs
// carry the episode's file, the torrent name is the truth about the container.
// A false positive degrades gracefully — the resolver falls back to rank-best
// for any episode the picked torrent doesn't actually carry.
function isSeasonPack(row, season) {
    if (row.streamKind !== "Torrent") return false;   // a direct url is one file
    var name = String(row.release || "").toLowerCase();
    if (!name.length) return false;
    // an episode RANGE reads as a run, not one episode: S01E01-E26, (001-1071).
    // Two forms because \b can't sit inside "s01e01-e26" (all word chars): the
    // e-anchored form rides mid-token, the bare-number form needs boundaries.
    var eRange = /e\d{1,4}\s*[-~]\s*e?\d{1,4}\b/.test(name)
              || /\b\d{1,4}\s*[-~]\s*\d{1,4}\b/.test(name);
    // a single-episode pin: S01E05 / 1x05
    var sxe = /s\d{1,2}\s*[._\- ]?e\d{1,4}/.test(name) || /\b\d{1,2}x\d{2,4}\b/.test(name);
    if (sxe && !eRange) return false;
    // anime single-file style: "EP0001", "Ep. 12", " - 1071 " with no season claim
    if (/\bep\.?\s*\d{1,4}\b/.test(name) && !eRange) return false;
    var s = Number(season) || 0;
    if (s > 0) {
        var padded = (s < 10 ? "0" : "") + s;
        if (new RegExp("\\bs" + padded + "\\b").test(name)) return true;       // bare S01
        if (new RegExp("season\\s*" + s + "\\b").test(name)) return true;      // Season 1
    }
    if (/complete|batch|integrale|full\s*season|all\s*episodes/.test(name)) return true;
    return eRange;
}

// ------------------------------------------------------------ aggregation

function _rowKey(r) {
    return r.url ? ("u:" + r.url)
                 : ("t:" + String(r.infoHash).toLowerCase() + ":" + Number(r.fileIdx || 0));
}

function _sortRows(rows) {
    rows.sort(function(a, b) {
        var aUnsupported = !!(a.videoCompatibility && a.videoCompatibility.state === "unsupported");
        var bUnsupported = !!(b.videoCompatibility && b.videoCompatibility.state === "unsupported");
        if (aUnsupported !== bUnsupported) return aUnsupported ? 1 : -1;
        if (a.addonPriority !== b.addonPriority) return a.addonPriority - b.addonPriority;
        if (b.rank !== a.rank) return b.rank - a.rank;
        return b.seeders - a.seeders;
    });
    return rows;
}

// ------------------------------------------------------------ catalogs (spec Phase 3)

function _baseUrl(ext) {
    return String(ext.transportUrl).replace(/\/manifest\.json$/i, "");
}

// True when a catalog can be browsed without extra input (Harbor's rule:
// catalogs whose extra carries isRequired are search/config-only — skip them).
function _browsable(catalog) {
    var extras = (catalog && catalog.extra) || [];
    for (var i = 0; i < extras.length; i++)
        if (extras[i] && extras[i].isRequired) return false;
    return true;
}

// The shelf list a content type gets from the installed extensions, in installed
// order: [{extName, title, url}]. Core rows are skipped — the house's own
// catalogs (Cinemeta) already feed the built-in rows; this is for NEW shelves.
// contentType: "movie" | "series" | "anime".
function catalogSpecs(installedList, contentType) {
    var out = [];
    for (var i = 0; i < (installedList || []).length; i++) {
        var e = installedList[i];
        if (!e || e.enabled !== true || e.core === true) continue;
        var m = e.manifest || ({});
        var cats = m.catalogs || [];
        for (var j = 0; j < cats.length; j++) {
            var c = cats[j];
            if (!c || !c.id || !c.type) continue;
            if (c.type !== contentType) continue;
            if (!_browsable(c)) continue;
            out.push({
                extName: m.name || e.id,
                transportUrl: String(e.transportUrl),
                catalogId: String(c.id),
                title: c.name || m.name || "Catalog",
                url: _baseUrl(e) + "/catalog/" + c.type + "/" + encodeURIComponent(c.id) + ".json"
            });
        }
    }
    return out;
}

// One catalog fetch → its meta previews (the standard {metas:[…]} shape).
function fetchCatalog(spec, done) {
    return _get(spec.url, FAST_TIMEOUT_MS, function(json) {
        done(json && json.metas ? json.metas : []);
    });
}

// ---------------------------------------------------- service classification (Theatre §8)
// A FIXED table that recognises branded streaming-service catalogues from an extension's
// IDENTITY and its manifest/catalogue NAMES only — never from an arbitrary item title (a
// title like "The Netflix Job" must not brand a random addon). First match wins; no match
// leaves serviceKey "" (the catalogue lands under "From Your Extensions").
var SERVICE_TABLE = [
    { key: "netflix", re: /netflix|\bnfx\b/ },
    { key: "hbo",     re: /hbo\s*max|hbomax|\bhbo\b|\bmax\b/ },
    { key: "appletv", re: /apple\s*tv|appletv|\batv\+?\b/ },
    { key: "disney",  re: /disney|hotstar/ },
    { key: "prime",   re: /prime\s*video|primevideo|amazon\s*prime/ },
    { key: "amc",     re: /\bamc\+?\b/ },
    { key: "fx",      re: /\bfxnow\b|\bfx\b/ }
];

function classifyService(ext, catalog) {
    var m = (ext && ext.manifest) || ({});
    var host = _host(String((ext && ext.transportUrl) || ""));
    var hay = (String((ext && ext.id) || "") + " " + String(m.name || "") + " " + host + " "
               + String((catalog && catalog.name) || "")).toLowerCase();
    for (var i = 0; i < SERVICE_TABLE.length; i++)
        if (SERVICE_TABLE[i].re.test(hay)) return SERVICE_TABLE[i].key;
    return "";
}

// Service-aware catalogue descriptors for the Theatre deep catalogue, in installed order.
// Same enabled/non-core/browsable (no required-extra) filtering as catalogSpecs — transport
// behaviour is unchanged — but each descriptor also carries a classified serviceKey, its
// content type, and a See-all url. The legacy catalogSpecs()/discoverCatalogSpecs() outputs
// are deliberately left untouched for their existing callers.
function theatreCatalogSpecs(installedList, contentType) {
    var out = [];
    for (var i = 0; i < (installedList || []).length; i++) {
        var e = installedList[i];
        if (!e || e.enabled !== true || e.core === true) continue;
        var m = e.manifest || ({});
        var cats = m.catalogs || [];
        for (var j = 0; j < cats.length; j++) {
            var c = cats[j];
            if (!c || !c.id || !c.type || c.type !== contentType) continue;
            if (!_browsable(c)) continue;
            out.push({
                serviceKey: classifyService(e, c),
                extName: m.name || e.id,
                transportUrl: String(e.transportUrl),
                type: c.type,
                catalogId: String(c.id),
                title: c.name || m.name || "Catalog",
                url: _baseUrl(e) + "/catalog/" + c.type + "/" + encodeURIComponent(c.id) + ".json"
            });
        }
    }
    return out;
}

// Meta fallback for ids the house sources don't know (spec Phase 3): ask the
// installed extensions that claim this id's meta, first answer wins.
function loadMetaFromExtensions(installedList, type, id, done) {
    var exts = [];
    for (var i = 0; i < (installedList || []).length; i++) {
        var e = installedList[i];
        if (!e || e.enabled !== true || e.core === true) continue;
        if (accepts(e.manifest, "meta", type, id)) exts.push(e);
    }
    var sType = (type === "series") ? "series" : "movie";
    function tryNext(index) {
        if (index >= exts.length) { done(null); return; }
        _get(_baseUrl(exts[index]) + "/meta/" + sType + "/" + id + ".json",
             FAST_TIMEOUT_MS, function(json) {
            if (json && json.meta) done(json.meta);
            else tryNext(index + 1);
        });
    }
    tryNext(0);
}

// The ONE place that answers "may we still fall back to Torrentio?".
//
// Torrentio ships seeded but removable (core:false, ExtensionsStore.cpp seed()).
// Several paths reach torrentio.strem.fun by hardcoded URL via Torrentio.js, so
// without this check the store's Remove and off-switch are cosmetic for it: the
// app keeps calling a source the user threw out. Every one of those fallbacks
// asks here first. (2026-07-25, A5 — Torrentio-honesty fix.)
var TORRENTIO_ID = "com.stremio.torrentio.addon";
function torrentioEnabled(installedList) {
    for (var i = 0; i < (installedList || []).length; i++) {
        var e = installedList[i];
        if (e && e.id === TORRENTIO_ID)
            return e.enabled === true;
    }
    return false;   // not installed at all
}

// The extensions that would answer a stream ask, in installed (ask) order.
// installedList = Extensions.installed(); type "movie"|"series"; id "tt…"/"tt…:s:e"/"kitsu:…".
function streamExtensions(installedList, type, id) {
    var out = [];
    for (var i = 0; i < (installedList || []).length; i++) {
        var e = installedList[i];
        if (!e || e.enabled !== true) continue;
        if (accepts(e.manifest, "stream", type, id)) out.push(e);
    }
    return out;
}

// Ask every extension in parallel; onPartial(rows) fires as each one answers
// (rows = accumulated, deduped, sorted); onDone(rows, askedNames) once all have
// answered or timed out. rows is [] when nothing answers.
function loadStreams(extensions, type, id, onPartial, onDone, platformRuntime) {
    var exts = [];
    for (var ei = 0; ei < (extensions || []).length; ei++) {
        if (extensions[ei] && extensions[ei].enabled === true)
            exts.push(extensions[ei]);
    }
    if (!type || !id || !exts.length) { onDone([], []); return; }
    var sType = (type === "series") ? "series" : "movie";

    var seen = ({});
    var rows = [];
    var names = [];
    var pending = exts.length;

    function settle(list, ext, priority) {
        var name = (ext.manifest && ext.manifest.name) || ext.id;
        if (list && list.length) {
            for (var i = 0; i < list.length; i++) {
                var row = parseStream(list[i], name, priority, ext.id || "", platformRuntime);
                if (!row) continue;
                var key = _rowKey(row);
                if (seen[key]) continue;   // first (higher-priority) answer keeps the row
                seen[key] = true;
                rows.push(row);
            }
            _sortRows(rows);
        }
        pending--;
        if (pending > 0) onPartial(rows.slice());
        else onDone(rows.slice(), names.slice());
    }

    for (var i = 0; i < exts.length; i++) {
        (function(ext, priority) {
            var name = (ext.manifest && ext.manifest.name) || ext.id;
            names.push(name);
            // the id goes into the path raw — Stremio ids need their colons
            var url = streamEndpoint(ext.transportUrl, sType, id);
            if (!url) {
                settle(null, ext, priority);
                return;
            }
            var timeoutMs = SLOW_RE.test(ext.transportUrl) ? SLOW_TIMEOUT_MS : FAST_TIMEOUT_MS;
            _get(url, timeoutMs, function(json) {
                settle(json && json.streams ? json.streams : null, ext, priority);
            });
        })(exts[i], i);
    }
}

// ---------------------------------------------------- Discover (arc 2026-07-23)

// Discover's picker wants EVERY installed addon's catalogs INCLUDING core rows
// (Cinemeta's Popular/New are the picker's backbone — unlike the tab shelves,
// which skip core because the house rows already carry Cinemeta).
// A catalog qualifies when every isRequired extra can be auto-answered from its
// options (search-required catalogs stay excluded until the search stage).
function discoverBrowsable(catalog) {
    var extras = (catalog && catalog.extra) || [];
    for (var i = 0; i < extras.length; i++) {
        var x = extras[i];
        if (!x || !x.isRequired) continue;
        if (x.name === "skip") continue;
        var opts = x.options || (x.name === "genre" ? (catalog.genres || []) : []);
        if (x.name === "search" || !opts.length) return false;
    }
    return true;
}

// [{extName, extId, logo, transportUrl, type, catalogId, title, extra, genres, core}] for one
// content type, in installed (ask) order. Used by DiscoverApi only.
function discoverCatalogSpecs(installedList, contentType) {
    var out = [];
    for (var i = 0; i < (installedList || []).length; i++) {
        var e = installedList[i];
        if (!e || e.enabled !== true) continue;
        var m = e.manifest || ({});
        var cats = m.catalogs || [];
        for (var j = 0; j < cats.length; j++) {
            var c = cats[j];
            if (!c || !c.id || !c.type || c.type !== contentType) continue;
            if (!discoverBrowsable(c)) continue;
            out.push({
                extName: m.name || e.id,
                extId: m.id || e.id || "",
                logo: m.logo || "",
                transportUrl: String(e.transportUrl),
                type: c.type,
                catalogId: String(c.id),
                title: c.name || m.name || "Catalog",
                extra: c.extra || [],
                genres: c.genres || [],
                core: e.core === true
            });
        }
    }
    return out;
}

// /catalog/{type}/{id}[/{extraProps}].json — extraPairs = [["genre","Action"]],
// skip appended when > 0. Values are URI-encoded; the path id too.
function catalogUrl(transportUrl, type, catalogId, extraPairs, skip) {
    var base = String(transportUrl).replace(/\/manifest\.json$/i, "");
    var url = base + "/catalog/" + type + "/" + encodeURIComponent(catalogId);
    var parts = [];
    for (var i = 0; i < (extraPairs || []).length; i++) {
        var p = extraPairs[i];
        if (p && p[0] && p[1] !== null && p[1] !== undefined && String(p[1]).length)
            parts.push(p[0] + "=" + encodeURIComponent(p[1]));
    }
    if (skip && skip > 0) parts.push("skip=" + skip);
    if (parts.length) url += "/" + parts.join("&");
    return url + ".json";
}

// One page of one catalog → metas array (defensive cap 100).
function fetchCatalogUrl(url, done) {
    return _get(url, FAST_TIMEOUT_MS, function(json) {
        var metas = (json && json.metas) ? json.metas : [];
        done(metas.slice(0, 100));
    });
}
