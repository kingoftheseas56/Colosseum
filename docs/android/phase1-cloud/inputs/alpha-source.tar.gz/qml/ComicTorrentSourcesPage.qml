// ComicTorrentSourcesPage — the full-screen "Find alternate sources" picker for a
// collected edition, in the Colosseum house language (the SourcesSheet visual
// stack: black base, key-art hero washing down, gold eyebrow + Fraunces title,
// a glass result table). Comics-specific: an edition identity rail (canonical
// title / ISBN / collected range) and per-row matched-clue evidence so the user
// sees WHY a result ranks where it does. The user always chooses the torrent;
// weak matches require an explicit confirmation; ambiguous packs open the
// second-stage archive picker. Nothing here auto-picks.
//
// Belongs to ComicSeriesPage (lazy in practice — ComicSeriesPage is lazy-loaded);
// never touches root startup. All acquisition rides the global Comics object
// under the original ledger chId — this page emits no reader signal.
pragma ComponentBehavior: Bound   // delegates bind outer ids (theme/sheet/row) at creation — clears qmllint unqualified-access
import QtQuick
import QtQuick.Controls

Item {
    id: sheet
    objectName: "comicTorrentSourcesPage"
    AdaptiveLayout { id: layout; page: sheet }
    readonly property bool phonePortrait: layout.phoneLayout
    readonly property real pageInset: sheet.phonePortrait ? layout.pageMargin : theme.margin
    anchors.fill: parent
    focus: true
    activeFocusOnTab: true

    property var comicsApi: typeof Comics !== "undefined" ? Comics : null
    property Item backdrop: null
    property var context: ({})
    property var rows: []
    property var errors: []
    property var archiveFiles: []          // ambiguous: eligible candidates
    property var missingIssues: []         // incomplete: named missing issues
    property var combinedFiles: []         // combined: the whole-archive candidate
    property string queryText: ""
    property bool open: false
    property bool loading: false
    property bool complete: false
    property bool confirmingWeak: false
    property bool acquiring: false        // a torrent has been chosen and is being acquired
    property var pendingRow: null
    // ONE typed-state driver for everything past "a torrent was tapped":
    //   results     — browsing/query, nothing chosen yet (also the confirmingWeak gate)
    //   inspecting  — automatic pack path is resolving metadata / just resumed after a choice
    //   ambiguous   — two+ eligible files, user must pick (ComicTorrentArchivePicker)
    //   incomplete  — the pack is missing required issues; no auto-download
    //   combined    — only a combined multi-edition archive covers this edition
    property string selectionState: "results"
    readonly property var visibleRows: rows
    readonly property string identityLine: buildIdentityLine()

    signal closed()
    Keys.onPressed: torrentSourcesKeys.handle(event)
    Keys.onReleased: torrentSourcesKeys.handleRelease(event)

    visible: sheet.open || sheet.opacity > 0.01
    opacity: sheet.open ? 1 : 0
    Behavior on opacity { NumberAnimation { duration: 180 } }

    Theme { id: theme }

    // ── state contract ───────────────────────────────────────────────────────
    function buildIdentityLine() {
        var parts = []
        if (context.editionTitle) parts.push(String(context.editionTitle))
        if (context.isbn) parts.push("ISBN " + String(context.isbn))
        if (context.collects) parts.push(String(context.collects))
        return parts.join("      ·      ")
    }

    function show(contextObject) {
        context = contextObject
        rows = []; errors = []; archiveFiles = []; missingIssues = []; combinedFiles = []
        queryText = ""
        loading = true; complete = false
        confirmingWeak = false; selectionState = "results"; acquiring = false; pendingRow = null
        open = true
        if (comicsApi)
            comicsApi.searchTorrentSources(context.issueId, context.seriesTitle,
                context.editionTitle, context.isbn, context.collects,
                String(context.format || ""))
    }

    function hide() {
        if (comicsApi && context.issueId) {
            comicsApi.cancelTorrentSourceSearch(context.issueId)
            // Backing out of a live acquisition (resolving/choosing/downloading/
            // assembling — anything past "results", not yet handed off to the
            // ledger) tears down the torrent + temp files too. Exactly one call:
            // any handler that closes the page on a SAFE outcome clears
            // `acquiring` itself before calling hide().
            if (acquiring) comicsApi.cancelDownload(context.issueId)
        }
        open = false; rows = []; pendingRow = null
        confirmingWeak = false; selectionState = "results"; acquiring = false
        archiveFiles = []; missingIssues = []; combinedFiles = []
        closed()
    }

    function submitManualQuery() {
        if (!queryText || !queryText.trim().length) return
        rows = []; errors = []; loading = true; complete = false
        confirmingWeak = false; pendingRow = null
        if (comicsApi) comicsApi.searchTorrentSourcesQuery(context.issueId, queryText)
    }

    function applySources(issueId, newRows, isComplete) {
        if (issueId !== context.issueId) return   // stale handle from a replaced search
        rows = newRows; complete = isComplete; loading = !isComplete
    }

    function applyFailure(issueId, reason) {
        if (issueId !== context.issueId) return
        rows = []; complete = true; loading = false; errors = [String(reason)]
    }

    function selectRow(row) {
        pendingRow = row
        if (row && row.confidence === "weak") { confirmingWeak = true; return }
        confirmWeakSelection()
    }

    function confirmWeakSelection() {
        confirmingWeak = false
        if (!comicsApi || !pendingRow) return
        comicsApi.cancelTorrentSourceSearch(context.issueId)
        beginAutomaticDownload(pendingRow)
    }

    function cancelWeakSelection() { confirmingWeak = false; pendingRow = null }

    function cancelInspection() {
        if (!acquiring || selectionState !== "inspecting") return
        acquiring = false; selectionState = "results"; pendingRow = null
        if (comicsApi) comicsApi.cancelDownload(context.issueId)
    }

    // Tap a coverage/identity-matched result -> auto isolate + download the
    // edition (the shared-infohash pack transport), NO manual file pick. The
    // CANONICAL edition title/isbn/collects are the identity the transport
    // matches against; the row's release title/magnet are display/source only.
    function beginAutomaticDownload(row) {
        acquiring = true
        selectionState = "inspecting"
        comicsApi.downloadTorrentEdition(context.issueId, context.seriesId, context.seriesTitle,
            context.editionTitle, context.isbn, context.collects,
            String(context.format || ""), row.infoHash, row.magnetUri)
    }

    // ── typed outcomes from the automatic pack path ──────────────────────────

    function applyArchiveChoices(issueId, files) {
        if (issueId !== context.issueId) return
        archiveFiles = files; selectionState = "ambiguous"
    }

    function chooseArchive(index) {
        if (comicsApi) comicsApi.chooseTorrentFiles(context.issueId, [index])
        selectionState = "inspecting"   // resumes; closes on the next safe progress/finish
    }

    function applyIncomplete(issueId, missing) {
        if (issueId !== context.issueId) return
        missingIssues = missing || []; selectionState = "incomplete"
    }

    // "Try another source" and "Search manually" both give up on this pack —
    // there is no backend capability to hand-pick individual files out of an
    // incomplete set — and return to browsing; the manual variant also focuses
    // the query field so the user can type a more complete release right away.
    function rejectIncomplete(focusManualQuery) {
        if (comicsApi) comicsApi.cancelDownload(context.issueId)
        acquiring = false; selectionState = "results"; missingIssues = []
        if (focusManualQuery) queryInput.forceActiveFocus()
    }

    function applyCombined(issueId, files) {
        if (issueId !== context.issueId) return
        combinedFiles = files || []; selectionState = "combined"
    }

    function confirmCombined() {
        if (comicsApi) comicsApi.confirmCombinedArchive(context.issueId)
        selectionState = "inspecting"   // resumes; closes on the next safe progress/finish
    }

    function rejectCombined() {
        if (comicsApi) comicsApi.cancelDownload(context.issueId)
        acquiring = false; selectionState = "results"; combinedFiles = []
    }

    // A safe, unique auto-decision (or a resumed manual choice) has started
    // moving bytes — hand off to the normal ledger-row progress and close.
    // Cleared BEFORE hide() so its cancel-on-Back guard does not fire.
    function closeOnSafeProgress(issueId) {
        if (issueId !== context.issueId) return
        if (selectionState !== "inspecting") return
        acquiring = false
        hide()
    }

    // Any typed failure while a pack attempt is live (TargetMissing,
    // UnsupportedPayload, an assembly error after a manual choice, …) — never
    // leave the user stuck mid-state; fall back to browsing the same results.
    function applyAcquisitionFailure(issueId) {
        if (issueId !== context.issueId) return
        if (selectionState === "results") return
        acquiring = false; selectionState = "results"
    }

    function confidenceColor(c) {
        if (c === "strong") return theme.gold
        if (c === "possible") return "#8ea3c0"   // muted blue-grey
        return "#c98a8a"                          // muted red — weak, still visible
    }
    function confidenceLabel(c) {
        if (c === "strong") return "STRONG MATCH"
        if (c === "possible") return "POSSIBLE MATCH"
        return "WEAK MATCH"
    }

    // ── facade signals: guarded by the live edition id (stale handles ignored) ──
    Connections {
        target: sheet.comicsApi
        ignoreUnknownSignals: true
        function onTorrentSourcesUpdated(issueId, rows, complete) { sheet.applySources(issueId, rows, complete) }
        function onTorrentSourceSearchFailed(issueId, reason) { sheet.applyFailure(issueId, reason) }
        // Reused for the pack transport's Ambiguous case too (same "pick one of
        // these files" shape — see ComicTorrentDownloader.h).
        function onTorrentArchiveSelectionRequired(issueId, files) { sheet.applyArchiveChoices(issueId, files) }
        function onTorrentCombinedArchiveConfirmationRequired(issueId, files) { sheet.applyCombined(issueId, files) }
        function onTorrentIncompleteIssueSetDetected(issueId, missingIssues) { sheet.applyIncomplete(issueId, missingIssues) }
        // A safe, unique auto-decision (or a resumed manual choice) has begun
        // moving bytes, or has already finished outright — either way the
        // ledger row owns it now; close without cancelling.
        function onProgress(issueId, done, total) { sheet.closeOnSafeProgress(issueId) }
        function onFinished(issueId) { sheet.closeOnSafeProgress(issueId) }
        function onFailed(issueId, reason) { sheet.applyAcquisitionFailure(issueId) }
    }

    // ── base: float over the wallpaper, not a flat void ──
    Rectangle { anchors.fill: parent; color: "#000000" }
    ShaderEffectSource {
        anchors.fill: parent
        sourceItem: sheet.backdrop
        live: true; hideSource: false
        visible: sheet.backdrop !== null
        opacity: 0.5
    }
    MouseArea { anchors.fill: parent }   // absorb clicks from below

    // ── key-art hero across the top, washing down ──
    Item {
        id: bannerStrip
        anchors.left: parent.left; anchors.right: parent.right; anchors.top: parent.top
        height: layout.touch && layout.shortLandscape ? 72
            : sheet.phonePortrait ? Math.max(220, heroBlock.implicitHeight + 96) : 300
        Image {
            anchors.fill: parent
            source: sheet.context.cover ? sheet.context.cover : ""
            fillMode: Image.PreserveAspectCrop
            asynchronous: true; cache: true
            visible: source !== ""
            opacity: status === Image.Ready ? 1.0 : 0.0
            Behavior on opacity { NumberAnimation { duration: 320; easing.type: Easing.OutCubic } }
        }
        Rectangle {
            anchors.fill: parent
            gradient: Gradient {
                GradientStop { position: 0.0; color: Qt.rgba(0, 0, 0, 0.25) }
                GradientStop { position: 0.55; color: Qt.rgba(0, 0, 0, 0.5) }
                GradientStop { position: 1.0; color: Qt.rgba(0, 0, 0, 0.92) }
            }
        }
    }
    Rectangle {
        anchors.left: parent.left; anchors.right: parent.right
        anchors.top: bannerStrip.bottom; anchors.bottom: parent.bottom
        color: Qt.rgba(0, 0, 0, 0.9)
    }

    BackAction {
        x: sheet.pageInset; y: sheet.phonePortrait ? 16 : 30; z: 20
        onTriggered: sheet.hide()
    }

    // ── title block + edition identity rail, pinned to the bottom of the banner ──
    Column {
        id: heroBlock
        anchors.left: parent.left; anchors.right: parent.right
        anchors.leftMargin: sheet.pageInset + (layout.touch && layout.shortLandscape ? 100 : 0); anchors.rightMargin: sheet.pageInset
        anchors.top: parent.top; anchors.topMargin: bannerStrip.height - height - 26
        spacing: sheet.phonePortrait ? 8 : 12
        Text {
            width: parent.width
            text: "ALTERNATE SOURCES · COLLECTED EDITION"
            visible: !(layout.touch && layout.shortLandscape)
            color: theme.gold; font.family: theme.ui; font.pixelSize: theme.fontSize(12)
            font.letterSpacing: sheet.phonePortrait ? 1 : 4; elide: Text.ElideRight
        }
        Text {
            objectName: "comicTorrentSourcesTitle"
            width: parent.width
            text: sheet.context.editionTitle ? String(sheet.context.editionTitle)
                  : (sheet.context.seriesTitle ? String(sheet.context.seriesTitle) : "Alternate sources")
            color: theme.ink; font.family: theme.display
            font.pixelSize: theme.fontSize(layout.touch && layout.shortLandscape ? 22 : sheet.phonePortrait ? 28 : 56); font.weight: Font.DemiBold
            wrapMode: sheet.phonePortrait ? Text.WrapAtWordBoundaryOrAnywhere : Text.NoWrap
            maximumLineCount: layout.touch && layout.shortLandscape ? 1 : sheet.phonePortrait ? 3 : 1; elide: Text.ElideRight
            style: Text.Raised; styleColor: Qt.rgba(0, 0, 0, 0.35)
        }
        Text {
            width: parent.width
            visible: sheet.identityLine.length > 0 && !(layout.touch && layout.shortLandscape)
            text: sheet.identityLine
            color: theme.inkDim; font.family: theme.ui; font.pixelSize: theme.fontSize(sheet.phonePortrait ? 12 : 14)
            wrapMode: sheet.phonePortrait ? Text.WrapAtWordBoundaryOrAnywhere : Text.NoWrap
            maximumLineCount: sheet.phonePortrait ? 3 : 1
            font.letterSpacing: sheet.phonePortrait ? 0 : 1; elide: Text.ElideRight
        }
    }

    // ── editable query + Search ──
    Item {
        id: queryBar
        anchors.left: parent.left; anchors.right: parent.right
        objectName: "comicTorrentSourcesQuery"
        anchors.leftMargin: sheet.pageInset; anchors.rightMargin: sheet.pageInset
        anchors.top: bannerStrip.bottom; anchors.topMargin: layout.touch && layout.shortLandscape ? 8 : 20
        height: (sheet.phonePortrait && !layout.shortLandscape) ? 108 : 56
        visible: sheet.selectionState === "results"

        Rectangle {
            id: queryField
            anchors.left: parent.left
            anchors.right: (sheet.phonePortrait && !layout.shortLandscape) ? parent.right : searchBtn.left
            anchors.rightMargin: (sheet.phonePortrait && !layout.shortLandscape) ? 0 : 14
            height: (sheet.phonePortrait && !layout.shortLandscape) ? 48 : parent.height; radius: 14
            color: Qt.rgba(1, 1, 1, 0.06)
            border.width: 1
            border.color: queryInput.activeFocus ? Qt.rgba(0.94, 0.77, 0.29, 0.55) : theme.edge
            Behavior on border.color { ColorAnimation { duration: 140 } }
            TextInput {
                id: queryInput
                anchors.fill: parent
                objectName: "comicTorrentSourcesQueryInput"
                anchors.leftMargin: (sheet.phonePortrait && !layout.shortLandscape) ? 12 : 22; anchors.rightMargin: (sheet.phonePortrait && !layout.shortLandscape) ? 12 : 22
                verticalAlignment: TextInput.AlignVCenter
                clip: true
                color: theme.ink; font.family: theme.ui; font.pixelSize: theme.fontSize(16)
                selectByMouse: true
                selectionColor: Qt.rgba(0.94, 0.77, 0.29, 0.35)
                text: sheet.queryText
                onTextEdited: sheet.queryText = text
                onAccepted: sheet.submitManualQuery()
                Text {
                    anchors.verticalCenter: parent.verticalCenter
                    visible: queryInput.text.length === 0
                    width: parent.width
                    elide: Text.ElideRight
                    text: "Search another title or ISBN"
                    color: theme.inkDimmer; font.family: theme.ui; font.pixelSize: theme.fontSize(16)
                }
            }
        }
        Rectangle {
            id: searchBtn
            objectName: "comicTorrentSourcesSearch"
            anchors.right: parent.right
            anchors.verticalCenter: (sheet.phonePortrait && !layout.shortLandscape) ? undefined : parent.verticalCenter
            y: (sheet.phonePortrait && !layout.shortLandscape) ? 60 : 0
            width: 120; height: layout.touch ? layout.touchTargetSize : 44; radius: 14
            color: sbMa.containsMouse ? theme.gold : Qt.rgba(0.94, 0.77, 0.29, 0.85)
            Behavior on color { ColorAnimation { duration: 140 } }
            Text {
                anchors.centerIn: parent; text: "Search"; color: "#1a1306"
                font.family: theme.ui; font.pixelSize: theme.fontSize(15); font.weight: Font.DemiBold
            }
            MouseArea {
                id: sbMa; anchors.fill: parent; hoverEnabled: true
                cursorShape: Qt.PointingHandCursor; onClicked: sheet.submitManualQuery()
            }
            KeyboardAction {
                id: searchKeyboard
                anchors.fill: parent
                pointerEnabled: false
                accessibleName: "Search alternate sources"
                onTriggered: sheet.submitManualQuery()
            }
        }
    }

    // ── the glass table: results OR the archive picker ──
    Glass {
        id: table
        backdrop: sheet.backdrop
        anchors.left: parent.left; anchors.right: parent.right
        objectName: "comicTorrentSourcesTable"
        anchors.leftMargin: sheet.pageInset; anchors.rightMargin: sheet.pageInset
        anchors.top: queryBar.bottom; anchors.topMargin: layout.touch && layout.shortLandscape ? 8 : 16
        anchors.bottom: parent.bottom; anchors.bottomMargin: layout.touch && layout.shortLandscape ? 8 : 26
        radius: 18
        track: 0

        // ---- results view ----
        Item {
            anchors.fill: parent
            visible: sheet.selectionState === "results"

            Item {
                id: tableHead
                anchors.left: parent.left; anchors.right: parent.right; anchors.top: parent.top
                height: layout.touch && layout.shortLandscape ? 48 : sheet.phonePortrait ? resultCount.implicitHeight + sourceNames.implicitHeight + 28 : 52
                visible: sheet.visibleRows.length > 0
                Text {
                    id: resultCount
                    anchors.left: parent.left; anchors.leftMargin: sheet.phonePortrait ? 12 : 26
                    anchors.verticalCenter: sheet.phonePortrait ? undefined : parent.verticalCenter
                    y: sheet.phonePortrait ? 10 : 0
                    width: sheet.phonePortrait ? parent.width - 24 : implicitWidth
                    wrapMode: sheet.phonePortrait ? Text.WordWrap : Text.NoWrap
                    text: sheet.visibleRows.length + (sheet.visibleRows.length === 1 ? " result" : " results")
                          + (sheet.loading ? "   ·   still searching…" : "")
                    color: theme.ink; font.family: theme.display; font.pixelSize: theme.fontSize(16); font.weight: Font.DemiBold
                }
                Text {
                    id: sourceNames
                    visible: !(layout.touch && layout.shortLandscape)
                    anchors.right: parent.right; anchors.rightMargin: sheet.phonePortrait ? 12 : 26
                    anchors.verticalCenter: sheet.phonePortrait ? undefined : parent.verticalCenter
                    y: sheet.phonePortrait ? resultCount.y + resultCount.height + 4 : 0
                    width: sheet.phonePortrait ? parent.width - 24 : implicitWidth
                    wrapMode: sheet.phonePortrait ? Text.WordWrap : Text.NoWrap
                    text: "Pirate Bay · ExtraTorrents · Torrents-CSV"
                    color: theme.inkDimmer; font.family: theme.ui; font.pixelSize: theme.fontSize(12); font.letterSpacing: 1
                }
                Rectangle { anchors.bottom: parent.bottom; width: parent.width; height: 1; color: theme.edge }
            }

            Text {
                anchors.centerIn: parent
                width: parent.width - 80
                horizontalAlignment: Text.AlignHCenter
                wrapMode: Text.WordWrap
                visible: sheet.visibleRows.length === 0
                text: sheet.loading ? "Searching comic sources…"
                      : (sheet.errors.length > 0
                         ? "Some sources did not answer. Showing the results that arrived."
                         : "No torrents matched this query. Try another title or ISBN.")
                color: sheet.errors.length > 0 ? "#e6a3a3" : theme.inkDim
                font.family: theme.ui; font.pixelSize: theme.fontSize(16)
            }

            SourcePickerList {
                id: list
                objectName: "comicTorrentSourcesResults"
                anchors.left: parent.left; anchors.right: parent.right
                anchors.top: tableHead.bottom; anchors.bottom: parent.bottom
                anchors.topMargin: 4; anchors.bottomMargin: 8
                clip: true
                visible: sheet.visibleRows.length > 0
                model: sheet.visibleRows
                boundsBehavior: Flickable.StopAtBounds
                ScrollBar.vertical: HouseScrollBar { flick: list }

                delegate: Item {
                    id: row
                    required property var modelData
                    required property int index
                    objectName: "comicTorrentSourceRow_" + index
                    width: ListView.view.width
                    height: sheet.phonePortrait ? phoneCard.implicitHeight : 150

                    Item {
                        anchors.fill:parent
                        visible:!sheet.phonePortrait
                    Rectangle {
                        anchors.fill: parent
                        color: rowMa.containsMouse ? Qt.rgba(1, 1, 1, 0.05) : "transparent"
                    }

                    Rectangle {
                        id: srcBadge
                        anchors.left: parent.left; anchors.leftMargin: sheet.phonePortrait ? 12 : 26
                        anchors.verticalCenter: sheet.phonePortrait ? undefined : parent.verticalCenter
                        y: sheet.phonePortrait ? 14 : 0
                        width: sheet.phonePortrait ? 32 : 54; height: width; radius: 12
                        color: Qt.rgba(1, 1, 1, 0.05); border.width: 1; border.color: theme.edge
                        Text {
                            anchors.centerIn: parent
                            text: String(row.modelData.sourceName || "?").charAt(0).toUpperCase()
                            color: theme.ink; font.family: theme.display; font.pixelSize: 24; font.weight: Font.DemiBold
                        }
                    }

                    Column {
                        id: resultContent
                        objectName: sheet.phonePortrait ? "" : "comicTorrentSourceCopy_" + row.index
                        anchors.left: srcBadge.right; anchors.leftMargin: sheet.phonePortrait ? 12 : 24
                        anchors.right: sheet.phonePortrait ? parent.right : pickBtn.left
                        anchors.rightMargin: sheet.phonePortrait ? 12 : 20
                        anchors.verticalCenter: sheet.phonePortrait ? undefined : parent.verticalCenter
                        y: sheet.phonePortrait ? 14 : 0
                        spacing: 7

                        Flow {
                            width: parent.width
                            spacing: 12
                            Text {
                                width: sheet.phonePortrait ? Math.min(implicitWidth, parent.width) : implicitWidth
                                wrapMode: sheet.phonePortrait ? Text.WordWrap : Text.NoWrap
                                text: row.modelData.sourceName || "Torrent"
                                color: theme.ink; font.family: theme.ui; font.pixelSize: theme.fontSize(15); font.weight: Font.DemiBold
                            }
                            Text {
                                width: sheet.phonePortrait ? Math.min(implicitWidth, parent.width) : implicitWidth
                                wrapMode: sheet.phonePortrait ? Text.WordWrap : Text.NoWrap
                                text: sheet.confidenceLabel(row.modelData.confidence)
                                color: sheet.confidenceColor(row.modelData.confidence)
                                font.family: theme.ui; font.pixelSize: theme.fontSize(13); font.weight: Font.DemiBold; font.letterSpacing: 0.5
                            }
                        }
                        Text {
                            objectName: "comicTorrentSourceTitle_" + row.index
                            width: parent.width
                            text: row.modelData.title || ""
                            wrapMode: sheet.phonePortrait ? Text.WrapAtWordBoundaryOrAnywhere : Text.NoWrap
                            maximumLineCount: sheet.phonePortrait ? 3 : 1
                            color: theme.ink; font.family: theme.ui; font.pixelSize: theme.fontSize(14); elide: Text.ElideRight
                        }
                        // Restrained evidence: a FORMAT RANGE / coverage badge, an ISSUES
                        // badge, and an uploader-trust marker — the SAME gold evidence
                        // styling as the confidence label above, no new color/emoji.
                        Flow {
                            width: parent.width
                            spacing: 7
                            Rectangle {
                                visible: !!row.modelData.coverage
                                width: sheet.phonePortrait ? Math.min(parent.width, covText.implicitWidth + 16) : covText.implicitWidth + 16; height: 20; radius: 6
                                color: Qt.rgba(0.94, 0.77, 0.29, 0.12); border.width: 1
                                border.color: Qt.rgba(0.94, 0.77, 0.29, 0.4)
                                Text {
                                    id: covText; anchors.centerIn: parent; text: "FORMAT RANGE"
                                    color: theme.gold; font.family: theme.ui; font.pixelSize: theme.fontSize(10)
                                    font.weight: Font.DemiBold; font.letterSpacing: 0.6
                                }
                            }
                            Rectangle {
                                visible: (row.modelData.evidence || []).indexOf("ISSUES") >= 0
                                width: sheet.phonePortrait ? Math.min(parent.width, issText.implicitWidth + 16) : issText.implicitWidth + 16; height: 20; radius: 6
                                color: Qt.rgba(1, 1, 1, 0.05); border.width: 1; border.color: theme.edge
                                Text {
                                    id: issText; anchors.centerIn: parent; text: "ISSUES"
                                    color: theme.inkDim; font.family: theme.ui; font.pixelSize: theme.fontSize(10)
                                    font.weight: Font.DemiBold; font.letterSpacing: 0.6
                                }
                            }
                            Rectangle {
                                visible: !!row.modelData.uploader && Number(row.modelData.trustTier) <= 2
                                width: sheet.phonePortrait ? Math.min(parent.width, upText.implicitWidth + 16) : upText.implicitWidth + 16; height: 20; radius: 6
                                color: Qt.rgba(0.94, 0.77, 0.29, 0.12); border.width: 1
                                border.color: Qt.rgba(0.94, 0.77, 0.29, 0.4)
                                Text {
                                    id: upText; anchors.centerIn: parent
                                    width: sheet.phonePortrait ? parent.width - 16 : implicitWidth
                                    elide: Text.ElideRight
                                    text: "TRUSTED · " + String(row.modelData.uploader || "")
                                    color: theme.gold; font.family: theme.ui; font.pixelSize: theme.fontSize(10)
                                    font.weight: Font.DemiBold; font.letterSpacing: 0.6
                                }
                            }
                        }
                        Text {
                            width: parent.width
                            wrapMode: sheet.phonePortrait ? Text.WordWrap : Text.NoWrap
                            text: {
                                var p = []
                                if (row.modelData.sizeText) p.push(String(row.modelData.sizeText))
                                if (row.modelData.seeders !== undefined) p.push("\u{1F464} " + row.modelData.seeders)
                                return p.join("   ·   ")
                            }
                            color: theme.inkDimmer; font.family: theme.ui; font.pixelSize: theme.fontSize(12); font.weight: Font.DemiBold
                        }
                    }

                    Rectangle {
                        id: pickBtn
                        objectName: sheet.phonePortrait ? "" : "comicTorrentSourceChoose_" + row.index
                        anchors.right: parent.right; anchors.rightMargin: sheet.phonePortrait ? 12 : 30
                        anchors.verticalCenter: sheet.phonePortrait ? undefined : parent.verticalCenter
                        y: sheet.phonePortrait ? resultContent.y + resultContent.height + 12 : 0
                        width: sheet.phonePortrait ? 48 : 56; height: width; radius: width / 2; color: theme.gold
                        scale: rowMa.containsMouse ? 1.05 : 1.0
                        Behavior on scale { NumberAnimation { duration: 120; easing.type: Easing.OutCubic } }
                        Text {
                            anchors.centerIn: parent; text: "↓"; color: "#1a1306"
                            font.pixelSize: 18; font.weight: Font.DemiBold
                        }
                    }
                    MouseArea {
                        id: rowMa; anchors.fill: parent; hoverEnabled: true
                        cursorShape: Qt.PointingHandCursor
                        onClicked: sheet.selectRow(row.modelData)
                    }
                    KeyboardAction {
                        id: sourceKeyboard
                        anchors.fill: parent
                        pointerEnabled: false
                        accessibleName: "Choose " + String(row.modelData.title || row.modelData.sourceName || "source")
                        onTriggered: sheet.selectRow(row.modelData)
                    }
                                    }
                    SourceCard {
                        id:phoneCard
                        objectName:"comicTorrentSourceCard_"+row.index
                        width:parent.width
                        visible:sheet.phonePortrait
                        contentObjectName:"comicTorrentSourceCopy_"+row.index
                        provider:String(row.modelData.sourceName || "")
                        quality:String(row.modelData.confidence || "")
                        title:String(row.modelData.title || row.modelData.releaseTitle || "")
                        details:[row.modelData.sizeText, row.modelData.seeders!==undefined ? row.modelData.seeders+" seeders" : "",row.modelData.uploader].filter(value=>!!value).join(" · ")
                        badges:row.modelData.evidence || []
                        actionText:qsTr("Choose")
                        actionObjectName:"comicTorrentSourceChoose_"+row.index
                        onTriggered:sheet.selectRow(row.modelData)
                    }
                }
            }
            ScrollGlide { id: torrentSourcesGlide; flick: list }
        }

        // ---- inspecting: the automatic pack path is resolving metadata ----
        Item {
            anchors.fill: parent
            visible: sheet.selectionState === "inspecting"
            Column {
                anchors.centerIn: parent
                width: parent.width - 80
                spacing: 14
                Text {
                    width: parent.width; horizontalAlignment: Text.AlignHCenter
                    text: "Inspecting pack…"
                    color: theme.ink; font.family: theme.display; font.pixelSize: theme.fontSize(20); font.weight: Font.DemiBold
                }
                Text {
                    width: parent.width; horizontalAlignment: Text.AlignHCenter; wrapMode: Text.WordWrap
                    visible: !!(sheet.pendingRow && sheet.pendingRow.title)
                    text: sheet.pendingRow ? String(sheet.pendingRow.title || "") : ""
                    color: theme.inkDim; font.family: theme.ui; font.pixelSize: theme.fontSize(14)
                }
                Rectangle {
                    objectName: "comicTorrentCancelInspection"
                    anchors.horizontalCenter: parent.horizontalCenter
                    width: Math.min(180, parent.width); height: 48; radius: 12
                    color: cancelInspectionAction.interactionActive ? Qt.rgba(1, 1, 1, 0.12) : Qt.rgba(1, 1, 1, 0.05)
                    border.width: 1; border.color: theme.edge
                    Text {
                        anchors.centerIn: parent; text: "Cancel"
                        color: theme.gold; font.family: theme.ui; font.pixelSize: theme.fontSize(14)
                    }
                    KeyboardAction {
                        id: cancelInspectionAction
                        anchors.fill: parent
                        accessibleName: "Cancel comic download"
                        onTriggered: sheet.cancelInspection()
                    }
                }
            }
        }

        // ---- archive picker (ambiguous manifest — pack candidates {index,path,bytes}) ----
        ComicTorrentArchivePicker {
            anchors.fill: parent
            visible: sheet.selectionState === "ambiguous"
            files: sheet.archiveFiles
            onArchiveChosen: (fileIndex) => sheet.chooseArchive(fileIndex)
        }

        // ---- incomplete: names the missing issues, never auto-downloads ----
        Item {
            anchors.fill: parent
            visible: sheet.selectionState === "incomplete"
            Column {
                anchors.left: parent.left; anchors.right: parent.right
                anchors.leftMargin: 40; anchors.rightMargin: 40
                anchors.verticalCenter: parent.verticalCenter
                spacing: 18
                Text {
                    width: parent.width
                    text: "This pack is missing issues this edition needs."
                    color: theme.ink; font.family: theme.ui; font.pixelSize: theme.fontSize(17); wrapMode: Text.WordWrap
                }
                Text {
                    width: parent.width
                    text: (sheet.missingIssues || []).join("   ·   ")
                    color: theme.gold; font.family: theme.ui; font.pixelSize: theme.fontSize(14); wrapMode: Text.WordWrap
                }
                Row {
                    spacing: 14
                    Rectangle {
                        width: 190; height: layout.targetSize(44); radius: 12
                        color: anotherMa.containsMouse ? Qt.rgba(1, 1, 1, 0.10) : Qt.rgba(1, 1, 1, 0.05)
                        border.width: 1; border.color: theme.edge
                        Text { anchors.centerIn: parent; text: "Try another source"; color: theme.ink
                            font.family: theme.ui; font.pixelSize: theme.fontSize(14) }
                        MouseArea { id: anotherMa; anchors.fill: parent; hoverEnabled: true
                            cursorShape: Qt.PointingHandCursor; onClicked: sheet.rejectIncomplete(false) }
                        KeyboardAction { anchors.fill: parent; pointerEnabled: false; accessibleName: "Try another source"
                            onTriggered: sheet.rejectIncomplete(false) }
                    }
                    Rectangle {
                        width: 190; height: layout.targetSize(44); radius: 12
                        color: manualMa.containsMouse ? Qt.rgba(1, 1, 1, 0.10) : Qt.rgba(1, 1, 1, 0.05)
                        border.width: 1; border.color: theme.edge
                        Text { anchors.centerIn: parent; text: "Search manually"; color: theme.ink
                            font.family: theme.ui; font.pixelSize: theme.fontSize(14) }
                        MouseArea { id: manualMa; anchors.fill: parent; hoverEnabled: true
                            cursorShape: Qt.PointingHandCursor; onClicked: sheet.rejectIncomplete(true) }
                        KeyboardAction { anchors.fill: parent; pointerEnabled: false; accessibleName: "Search manually"
                            onTriggered: sheet.rejectIncomplete(true) }
                    }
                }
            }
        }

        // ---- combined: only a whole multi-edition archive covers this edition ----
        Item {
            anchors.fill: parent
            visible: sheet.selectionState === "combined"
            Column {
                anchors.left: parent.left; anchors.right: parent.right
                anchors.leftMargin: 40; anchors.rightMargin: 40
                anchors.verticalCenter: parent.verticalCenter
                spacing: 18
                Text {
                    width: parent.width
                    text: "Only a combined archive covers this edition — it likely includes other editions too."
                    color: theme.ink; font.family: theme.ui; font.pixelSize: theme.fontSize(17); wrapMode: Text.WordWrap
                }
                Row {
                    spacing: 14
                    Rectangle {
                        width: 150; height: layout.targetSize(44); radius: 12
                        color: combBackMa.containsMouse ? Qt.rgba(1, 1, 1, 0.10) : Qt.rgba(1, 1, 1, 0.05)
                        border.width: 1; border.color: theme.edge
                        Text { anchors.centerIn: parent; text: "Go back"; color: theme.ink
                            font.family: theme.ui; font.pixelSize: theme.fontSize(15) }
                        MouseArea { id: combBackMa; anchors.fill: parent; hoverEnabled: true
                            cursorShape: Qt.PointingHandCursor; onClicked: sheet.rejectCombined() }
                        KeyboardAction { anchors.fill: parent; pointerEnabled: false; accessibleName: "Go back"
                            onTriggered: sheet.rejectCombined() }
                    }
                    Rectangle {
                        width: 260; height: layout.targetSize(44); radius: 12
                        color: combGoMa.containsMouse ? theme.gold : Qt.rgba(0.94, 0.77, 0.29, 0.85)
                        Behavior on color { ColorAnimation { duration: 140 } }
                        Text { anchors.centerIn: parent; text: "Download whole archive anyway"; color: "#1a1306"
                            font.family: theme.ui; font.pixelSize: theme.fontSize(14); font.weight: Font.DemiBold }
                        MouseArea { id: combGoMa; anchors.fill: parent; hoverEnabled: true
                            cursorShape: Qt.PointingHandCursor; onClicked: sheet.confirmCombined() }
                        KeyboardAction { anchors.fill: parent; pointerEnabled: false; accessibleName: "Download whole archive anyway"
                            onTriggered: sheet.confirmCombined() }
                    }
                }
            }
        }
    }

    // ── weak-match confirmation ──
    Item {
        anchors.fill: parent
        visible: sheet.confirmingWeak
        z: 40
        MouseArea { anchors.fill: parent }   // swallow clicks behind the prompt
        Rectangle {
            anchors.centerIn: parent
            width: Math.min(560, parent.width - 2 * theme.margin)
            height: promptCol.implicitHeight + 56
            radius: 18
            color: Qt.rgba(0.08, 0.08, 0.09, 0.98)
            border.width: 1; border.color: theme.edge
            Column {
                id: promptCol
                anchors.left: parent.left; anchors.right: parent.right
                anchors.verticalCenter: parent.verticalCenter
                anchors.leftMargin: 28; anchors.rightMargin: 28
                spacing: 18
                Text {
                    width: parent.width
                    text: "This release does not closely match the collected edition."
                    color: theme.ink; font.family: theme.ui; font.pixelSize: theme.fontSize(17); wrapMode: Text.WordWrap
                }
                Text {
                    width: parent.width
                    visible: !!(sheet.pendingRow && sheet.pendingRow.title)
                    text: sheet.pendingRow ? String(sheet.pendingRow.title || "") : ""
                    color: theme.inkDim; font.family: theme.ui; font.pixelSize: theme.fontSize(13); wrapMode: Text.WordWrap
                }
                Row {
                    anchors.right: parent.right
                    spacing: 14
                    Rectangle {
                        width: 120; height: layout.targetSize(44); radius: 12
                        color: backMa.containsMouse ? Qt.rgba(1, 1, 1, 0.10) : Qt.rgba(1, 1, 1, 0.05)
                        border.width: 1; border.color: theme.edge
                        Text { anchors.centerIn: parent; text: "Go back"; color: theme.ink
                            font.family: theme.ui; font.pixelSize: theme.fontSize(15) }
                        MouseArea { id: backMa; anchors.fill: parent; hoverEnabled: true
                            cursorShape: Qt.PointingHandCursor; onClicked: sheet.cancelWeakSelection() }
                        KeyboardAction { anchors.fill: parent; pointerEnabled: false; accessibleName: "Go back"
                            onTriggered: sheet.cancelWeakSelection() }
                    }
                    Rectangle {
                        width: 150; height: layout.targetSize(44); radius: 12; color: caMa.containsMouse ? theme.gold : Qt.rgba(0.94, 0.77, 0.29, 0.85)
                        Behavior on color { ColorAnimation { duration: 140 } }
                        Text { anchors.centerIn: parent; text: "Choose anyway"; color: "#1a1306"
                            font.family: theme.ui; font.pixelSize: theme.fontSize(15); font.weight: Font.DemiBold }
                        MouseArea { id: caMa; anchors.fill: parent; hoverEnabled: true
                            cursorShape: Qt.PointingHandCursor; onClicked: sheet.confirmWeakSelection() }
                        KeyboardAction { anchors.fill: parent; pointerEnabled: false; accessibleName: "Choose source anyway"
                            onTriggered: sheet.confirmWeakSelection() }
                    }
                }
            }
        }
    }

    KeyboardScrollController {
        id: torrentSourcesKeys
        flick: list
        glide: torrentSourcesGlide
    }
}
