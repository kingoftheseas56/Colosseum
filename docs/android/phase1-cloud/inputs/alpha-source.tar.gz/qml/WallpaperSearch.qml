pragma ComponentBehavior: Bound

import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import "WallpaperApi.js" as WallpaperApi

BrowseScaffold {
    id: root
    desktopPageMargin:theme.margin
    objectName: "wallpaperSearch"

    Theme { id: theme }

    property Item backdrop
    property string targetWorld: "Home"
    property string inheritedImageUrl: ""
    property var selectedPick: ({})
    property var results: []
    property string statusText: ""
    // Axis 1+2 (2026-07-18; Konachan dropped 2026-07-20): paged Wallhaven search.
    // One opaque state from WallpaperApi carries the cursor; Load more appends pages.
    property var searchState: null
    property string sorting: "relevance"     // "relevance" | "top" | "random"
    property bool loading: false
    readonly property bool canLoadMore: !loading && searchState !== null
                                        && WallpaperApi.hasMore(searchState)
    readonly property bool compactPhoneLayout: Qt.platform.os === "android"
        && Math.min(width, height) < 600
    readonly property int resultColumns: grid.width > 0
        ? (compactPhoneLayout ? Math.max(1, Math.ceil(grid.width / 210))
            : Math.max(1, Math.floor(grid.width / 154))) : 1
    readonly property real selectedPanelWidth: compactPhoneLayout
        ? Math.max(1, Math.min(360, width - 24)) : 360
    readonly property real selectedPanelHeight: compactPhoneLayout
        ? Math.max(1, Math.min(142, height - 24)) : 142
    readonly property real selectedPanelX: compactPhoneLayout
        ? (width - selectedPanelWidth) / 2 : width - selectedPanelWidth - 52
    readonly property real selectedPanelY: compactPhoneLayout
        ? height - selectedPanelHeight - 12 : height - selectedPanelHeight - 52
    readonly property real selectedButtonWidth: compactPhoneLayout
        ? Math.max(1, Math.min(150, (selectedPanelWidth - 34) / 2)) : 150
    readonly property real selectedButtonY: selectedPanelY
        + (compactPhoneLayout ? 61 : 72)

    signal closeRequested()                  // the panel "x" — closes the picker, back to the world
    signal applyRequested(string scope, string world, var pick)
    // Window chrome (2026-07-20): this overlay covers the shell top bar, so it carries its
    // own minimize · fullscreen-toggle · power like every other page. closeRequested stays
    // the picker's back; quitRequested is the app-quit power button.
    signal minimizeRequested()
    signal fullscreenRequested()
    signal quitRequested()

    function runSearch() {
        statusText = "Searching..."
        results = []
        searchState = WallpaperApi.freshState(searchField.text, sorting)
        fetchMore()
    }

    function fetchMore() {
        if (loading || !searchState)
            return
        loading = true
        var state = searchState
        WallpaperApi.fetchPage(state, function(rows, st, err) {
            if (state !== root.searchState) { root.loading = false; return }   // a newer search superseded this reply
            root.results = root.results.concat(rows)
            root.loading = false
            root.statusText = err || (root.results.length + " wallpapers"
                                      + (WallpaperApi.hasMore(st) ? " · more available" : ""))
        })
    }

    function setSorting(mode) {
        // Random re-rolls on every press (fresh seed) — that's its point.
        if (sorting === mode && mode !== "random")
            return
        sorting = mode
        runSearch()
    }
    function revealResultIndex(index) {
        Qt.callLater(function() {
            if (!grid.currentItem) return
            const y = grid.y + grid.currentItem.y
            const target = y - Math.max(0, (bodyFlick.height - grid.currentItem.height) / 2)
            bodyFlick.contentY = Math.max(0, Math.min(Math.max(0, bodyFlick.contentHeight - bodyFlick.height), target))
        })
    }

    Component.onCompleted: {
        searchField.text = WallpaperApi.defaultQueryFor(targetWorld)
        runSearch()
    }

    // full-bleed preview: an Image for searchable picks, the live scene for native ones
    readonly property string previewUrl: root.selectedPick.image_url || root.inheritedImageUrl
    Image {
        anchors.fill: parent
        source: WallpaperApi.isNativePick(root.previewUrl) ? "" : root.previewUrl
        visible: !WallpaperApi.isNativePick(root.previewUrl)
        fillMode: Image.PreserveAspectCrop
        asynchronous: true
        cache: true
    }
    Loader {
        anchors.fill: parent
        active: WallpaperApi.isNativePick(root.previewUrl)
        source: active ? WallpaperApi.nativeSceneFor(root.previewUrl) : ""
    }

    Rectangle {
        anchors.fill: parent
        color: Qt.rgba(0, 0, 0, 0.34)
    }

    // Window chrome cluster — minimize · fullscreen-toggle · power. Top-right, over the
    // empty preview area (the search panel is on the left), matching every other page.
    Row {
        visible: Qt.platform.os !== "android"
        z: 50
        anchors.right: parent.right
        anchors.rightMargin: 40
        anchors.top: parent.top
        anchors.topMargin: 34
        spacing: 20
        Item {
            width: root.layout.targetSize(22); height: root.layout.targetSize(22)
            Image {
                anchors.centerIn:parent; width:22; height:22
                source: "../assets/icons/minimize.svg"
                sourceSize.width: 22; sourceSize.height: 22
                fillMode: Image.PreserveAspectFit
                opacity: wpMinMa.containsMouse || wpMinKey.activeFocus ? 1.0 : 0.72
            }
            MouseArea {
                id: wpMinMa
                anchors.fill: parent; hoverEnabled: true
                cursorShape: Qt.PointingHandCursor
                onClicked: root.minimizeRequested()
            }
            KeyboardAction { id: wpMinKey; anchors.fill: parent; pointerEnabled: false
                accessibleName: "Minimize"; onTriggered: root.minimizeRequested() }
        }
        Item {
            width: root.layout.targetSize(22); height: root.layout.targetSize(22)
            Image {
                anchors.centerIn:parent; width:22; height:22
                source: (typeof WindowMode !== "undefined" && WindowMode.shellWindowed)
                        ? "../assets/icons/fullscreen.svg"
                        : "../assets/icons/fullscreen-exit.svg"
                sourceSize.width: 22; sourceSize.height: 22
                fillMode: Image.PreserveAspectFit
                opacity: wpFsMa.containsMouse || wpFsKey.activeFocus ? 1.0 : 0.72
            }
            MouseArea {
                id: wpFsMa
                anchors.fill: parent; hoverEnabled: true
                cursorShape: Qt.PointingHandCursor
                onClicked: root.fullscreenRequested()
            }
            KeyboardAction { id: wpFsKey; anchors.fill: parent; pointerEnabled: false
                accessibleName: "Toggle fullscreen"; onTriggered: root.fullscreenRequested() }
        }
        Item {
            width: root.layout.targetSize(22); height: root.layout.targetSize(22)
            Image {
                anchors.centerIn:parent; width:22; height:22
                source: "../assets/icons/power.svg"
                sourceSize.width: 22; sourceSize.height: 22
                fillMode: Image.PreserveAspectFit
                opacity: wpPowMa.containsMouse || wpPowKey.activeFocus ? 1.0 : 0.72
            }
            MouseArea {
                id: wpPowMa
                anchors.fill: parent; hoverEnabled: true
                cursorShape: Qt.PointingHandCursor
                onClicked: root.quitRequested()
            }
            KeyboardAction { id: wpPowKey; anchors.fill: parent; pointerEnabled: false
                accessibleName: "Close Colosseum"; onTriggered: root.quitRequested() }
        }
    }

    Glass {
        id: panel
        backdrop: root.backdrop
        width: root.compactPhoneLayout
            ? Math.max(1, Math.min(520, root.width - 24))
            : Math.min(520, root.width - 80)
        height: root.compactPhoneLayout
            ? Math.max(1, root.height - 24) : root.height - 120
        x: root.compactPhoneLayout ? (root.width - width) / 2 : 40
        y: root.compactPhoneLayout ? 12 : 60
        radius: root.compactPhoneLayout ? 14 : 18

        ColumnLayout {
            anchors.fill: parent
            anchors.margins: root.compactPhoneLayout ? 12 : 22
            spacing: root.compactPhoneLayout ? 6 : 14

            RowLayout {
                Layout.fillWidth: true
                spacing: root.compactPhoneLayout ? 2 : 0

                Text {
                    text: "Wallpapers"
                    color: "#f3f0e8"
                    font.family: theme.display
                    font.pixelSize: theme.fontSize(root.compactPhoneLayout ? 18 : 34)
                    elide: Text.ElideRight
                    Layout.fillWidth: true
                    Layout.minimumWidth: 0
                }

                Text {
                    objectName: "wallpaperSearchClose"
                    text: "x"
                    color: closeMa.containsMouse ? "#ffffff" : "#aaa7a0"
                    font.pixelSize: theme.fontSize(root.compactPhoneLayout ? 18 : 20)
                    horizontalAlignment: Text.AlignHCenter
                    verticalAlignment: Text.AlignVCenter
                    Layout.preferredWidth: root.compactPhoneLayout ? 48 : implicitWidth
                    Layout.minimumWidth: root.compactPhoneLayout ? 48 : 0
                    Layout.preferredHeight: root.compactPhoneLayout ? 48 : implicitHeight
                    Layout.minimumHeight: root.compactPhoneLayout ? 48 : 0

                    MouseArea {
                        id: closeMa
                        anchors.fill: parent
                        anchors.margins: root.compactPhoneLayout ? 0 : -10
                        hoverEnabled: true
                        cursorShape: Qt.PointingHandCursor
                        onClicked: root.closeRequested()
                    }
                    KeyboardAction { anchors.fill: parent; anchors.margins: root.compactPhoneLayout ? 0 : -10; pointerEnabled: false
                        accessibleName: "Close wallpaper picker"; onTriggered: root.closeRequested() }
                }
            }

            RowLayout {
                Layout.fillWidth: true

                Rectangle {
                    Layout.fillWidth: true
                    Layout.preferredHeight: root.compactPhoneLayout ? 48 : 42
                    radius: 999
                    color: Qt.rgba(0, 0, 0, 0.28)
                    border.width: 1
                    border.color: Qt.rgba(255, 255, 255, 0.16)

                    TextInput {
                        id: searchField
                        anchors.fill: parent
                        anchors.leftMargin: 16
                        anchors.rightMargin: 16
                        verticalAlignment: TextInput.AlignVCenter
                        color: "#f7f4ee"
                        selectionColor: "#c9a44a"
                        selectedTextColor: "#101010"
                        font.pixelSize: theme.fontSize(15)
                        Keys.onReturnPressed: root.runSearch()
                    }
                }

                Rectangle {
                    Layout.preferredWidth: root.compactPhoneLayout ? 72 : 92
                    Layout.preferredHeight: root.compactPhoneLayout ? 48 : 42
                    radius: 999
                    color: searchMa.containsMouse ? "#d6b357" : "#c9a44a"

                    Text {
                        anchors.centerIn: parent
                        text: "Search"
                        color: "#15110a"
                        font.pixelSize: theme.fontSize(14)
                        font.weight: Font.DemiBold
                    }

                    MouseArea {
                        id: searchMa
                        anchors.fill: parent
                        hoverEnabled: true
                        cursorShape: Qt.PointingHandCursor
                        onClicked: root.runSearch()
                    }
                    KeyboardAction { anchors.fill: parent; pointerEnabled: false
                        accessibleName: "Search wallpapers"; onTriggered: root.runSearch() }
                }
            }

            // sort pills: Relevance / Top / Random (Random re-rolls on every press)
            Row {
                spacing: 8

                Repeater {
                    model: [ { "label": "Relevance", "mode": "relevance" },
                             { "label": "Top", "mode": "top" },
                             { "label": "Random", "mode": "random" } ]
                    delegate: Item {
                        id: sortTarget
                        required property var modelData
                        width: root.layout.targetSize(sortLabel.implicitWidth + (root.compactPhoneLayout ? 18 : 26))
                        height: root.layout.targetSize(root.compactPhoneLayout ? 48 : 30)

                        Rectangle {
                            id: sortPill
                            anchors.centerIn: parent
                            width: parent.width
                            height: 30
                            radius: 999
                            color: root.sorting === sortTarget.modelData.mode ? "#c9a44a"
                             : sortMa.containsMouse ? Qt.rgba(255, 255, 255, 0.16)
                             : Qt.rgba(255, 255, 255, 0.08)
                            border.width: root.sorting === sortTarget.modelData.mode ? 0 : 1
                            border.color: Qt.rgba(255, 255, 255, 0.14)

                            Text {
                                id: sortLabel
                                anchors.centerIn: parent
                                text: sortTarget.modelData.label
                                color: root.sorting === sortTarget.modelData.mode ? "#15110a" : "#e8e4dc"
                                font.pixelSize: theme.fontSize(12)
                                font.weight: root.sorting === sortTarget.modelData.mode ? Font.DemiBold : Font.Normal
                            }
                        }

                        MouseArea {
                            id: sortMa
                            anchors.fill: parent
                            hoverEnabled: true
                            cursorShape: Qt.PointingHandCursor
                            onClicked: root.setSorting(sortTarget.modelData.mode)
                        }
                        KeyboardAction { anchors.fill: parent; pointerEnabled: false
                            accessibleName: "Sort wallpapers by " + sortTarget.modelData.label
                            onTriggered: root.setSorting(sortTarget.modelData.mode) }
                    }
                }
            }

            Text {
                Layout.fillWidth: true
                text: root.statusText
                color: "#b8b2a8"
                font.pixelSize: theme.fontSize(root.compactPhoneLayout ? 11 : 12)
                elide: Text.ElideRight
                maximumLineCount: 1
            }

            // ---- Everything below the search controls — both Colosseum shelves, the KDE
            //      Plasma shelf, and the Wallhaven results — lives in ONE vertical scroller,
            //      so the panel never overflows at the bottom as the shelves grow
            //      (2026-07-25, Hemanth). Each native strip still scrolls sideways on its
            //      own wheel; the results grid is non-interactive so this outer Flickable
            //      drives all the vertical scrolling. ----
            Flickable {
                id: bodyFlick
                objectName: "wallpaperSearchBody"
                Layout.fillWidth: true
                Layout.fillHeight: true
                clip: true
                activeFocusOnTab: true
                Keys.onPressed: (event) => bodyKeys.handle(event)
                Keys.onReleased: (event) => bodyKeys.handleRelease(event)
                contentWidth: width
                contentHeight: bodyCol.implicitHeight
                boundsBehavior: Flickable.StopAtBounds
                ScrollBar.vertical: HouseScrollBar { flick: bodyFlick }
                KeyboardScrollController { id: bodyKeys; flick: bodyFlick }

                ColumnLayout {
                    id: bodyCol
                    width: bodyFlick.width
                    spacing: 14

            // one tile delegate, shared by both native shelves
            Component {
                id: nativeTileDelegate
                Rectangle {
                    id: nativeTile
                    required property var modelData
                    objectName: "wallpaperPick_"
                                + String(nativeTile.modelData.source_id || nativeTile.modelData.title)
                                  .replace(/[^A-Za-z0-9_]/g, "_")
                    width: 144
                    height: 92
                    radius: 8
                    color: "#07070a"
                    border.width: root.selectedPick.source_id === nativeTile.modelData.source_id ? 2 : 1
                    border.color: root.selectedPick.source_id === nativeTile.modelData.source_id ? "#c9a44a" : Qt.rgba(255, 255, 255, 0.14)
                    clip: true

                    Loader {
                        anchors.fill: parent
                        source: WallpaperApi.nativeSceneFor(nativeTile.modelData.image_url)
                    }

                    Rectangle {
                        anchors.left: parent.left
                        anchors.right: parent.right
                        anchors.bottom: parent.bottom
                        height: 22
                        color: Qt.rgba(0, 0, 0, 0.55)

                        Text {
                            anchors.verticalCenter: parent.verticalCenter
                            anchors.left: parent.left
                            anchors.leftMargin: 8
                            anchors.right: parent.right
                            anchors.rightMargin: 8
                            text: nativeTile.modelData.title
                            color: "#e8e2d4"
                            font.pixelSize: theme.fontSize(10)
                            elide: Text.ElideRight
                        }
                    }

                    MouseArea {
                        anchors.fill: parent
                        cursorShape: Qt.PointingHandCursor
                        onClicked: root.selectedPick = nativeTile.modelData
                    }
                }
            }

            // Colosseum Animated — the living, moving scenes
            Text {
                text: "Colosseum Animated"
                color: "#d8d2c4"
                font.family: theme.display
                font.pixelSize: theme.fontSize(16)
            }

            ListView {
                id: animatedStrip
                Layout.fillWidth: true
                Layout.preferredHeight: 92
                orientation: ListView.Horizontal
                spacing: 10
                clip: true
                model: WallpaperApi.nativeAnimatedPicks()
                boundsBehavior: Flickable.StopAtBounds
                delegate: nativeTileDelegate
                activeFocusOnTab: count > 0
                onActiveFocusChanged: if (activeFocus && currentIndex < 0 && count > 0) currentIndex = 0
                Keys.onPressed: (event) => animatedKeys.handle(event)
                highlight: Rectangle { color: "transparent"; radius: 8; border.width: 2; border.color: "#f0c44a"; visible: animatedStrip.activeFocus }
                KeyboardCollectionController {
                    id: animatedKeys; view: animatedStrip; orientation: "horizontal"
                    onActivated: (index) => { const row = animatedStrip.model[index]; if (row) root.selectedPick = row }
                }

                WheelHandler {
                    acceptedDevices: PointerDevice.Mouse | PointerDevice.TouchPad
                    onWheel: (ev) => {
                        var d = (ev.angleDelta.y !== 0 ? ev.angleDelta.y : ev.angleDelta.x)
                        animatedStrip.contentX = Math.max(0, Math.min(
                            Math.max(0, animatedStrip.contentWidth - animatedStrip.width),
                            animatedStrip.contentX - d))
                    }
                }
            }

            // Colosseum Native — the still QML gradients
            Text {
                text: "Colosseum Native"
                color: "#d8d2c4"
                font.family: theme.display
                font.pixelSize: theme.fontSize(16)
            }

            ListView {
                id: nativeStrip
                Layout.fillWidth: true
                Layout.preferredHeight: 92
                orientation: ListView.Horizontal
                spacing: 10
                clip: true
                model: WallpaperApi.nativeStaticPicks()
                boundsBehavior: Flickable.StopAtBounds
                delegate: nativeTileDelegate
                activeFocusOnTab: count > 0
                onActiveFocusChanged: if (activeFocus && currentIndex < 0 && count > 0) currentIndex = 0
                Keys.onPressed: (event) => nativeKeys.handle(event)
                highlight: Rectangle { color: "transparent"; radius: 8; border.width: 2; border.color: "#f0c44a"; visible: nativeStrip.activeFocus }
                KeyboardCollectionController {
                    id: nativeKeys; view: nativeStrip; orientation: "horizontal"
                    onActivated: (index) => { const row = nativeStrip.model[index]; if (row) root.selectedPick = row }
                }

                WheelHandler {
                    acceptedDevices: PointerDevice.Mouse | PointerDevice.TouchPad
                    onWheel: (ev) => {
                        var d = (ev.angleDelta.y !== 0 ? ev.angleDelta.y : ev.angleDelta.x)
                        nativeStrip.contentX = Math.max(0, Math.min(
                            Math.max(0, nativeStrip.contentWidth - nativeStrip.width),
                            nativeStrip.contentX - d))
                    }
                }
            }

            // ---- KDE Plasma shelf: real OS-desktop wallpapers under a free licence
            //      (CC-BY-SA-4.0 / LGPLv3), from KDE/plasma-workspace-wallpapers. A
            //      horizontal strip, one row tall, scrolls sideways (wheel/drag). Each
            //      tile carries its artist for credit; remote thumb + remote full on
            //      apply, the same path as a Wallhaven pick. ----
            Text {
                text: "KDE Plasma"
                color: "#d8d2c4"
                font.family: theme.display
                font.pixelSize: theme.fontSize(16)
            }

            ListView {
                id: kdeStrip
                Layout.fillWidth: true
                Layout.preferredHeight: 92
                orientation: ListView.Horizontal
                spacing: 10
                clip: true
                model: WallpaperApi.kdePicks()
                boundsBehavior: Flickable.StopAtBounds
                activeFocusOnTab: count > 0
                onActiveFocusChanged: if (activeFocus && currentIndex < 0 && count > 0) currentIndex = 0
                Keys.onPressed: (event) => kdeKeys.handle(event)
                highlight: Rectangle { color: "transparent"; radius: 8; border.width: 2; border.color: "#f0c44a"; visible: kdeStrip.activeFocus }
                KeyboardCollectionController {
                    id: kdeKeys; view: kdeStrip; orientation: "horizontal"
                    onActivated: (index) => { const row = kdeStrip.model[index]; if (row) root.selectedPick = row }
                }

                // a horizontal list ignores the vertical wheel by default — map it to
                // sideways travel so the mouse wheel scrolls the strip.
                WheelHandler {
                    acceptedDevices: PointerDevice.Mouse | PointerDevice.TouchPad
                    onWheel: (ev) => {
                        var d = (ev.angleDelta.y !== 0 ? ev.angleDelta.y : ev.angleDelta.x)
                        kdeStrip.contentX = Math.max(0, Math.min(
                            Math.max(0, kdeStrip.contentWidth - kdeStrip.width),
                            kdeStrip.contentX - d))
                    }
                }

                delegate: Rectangle {
                    id: kdeTile
                    required property var modelData
                    width: 144
                    height: 92
                    radius: 8
                    color: "#07070a"
                    border.width: root.selectedPick.source_id === kdeTile.modelData.source_id ? 2 : 1
                    border.color: root.selectedPick.source_id === kdeTile.modelData.source_id ? "#c9a44a" : Qt.rgba(255, 255, 255, 0.14)
                    clip: true

                    Image {
                        anchors.fill: parent
                        source: kdeTile.modelData.thumb_url
                        fillMode: Image.PreserveAspectCrop
                        asynchronous: true
                        cache: true
                    }

                    // title + artist credit
                    Rectangle {
                        anchors.left: parent.left
                        anchors.right: parent.right
                        anchors.bottom: parent.bottom
                        height: 32
                        color: Qt.rgba(0, 0, 0, 0.6)

                        Column {
                            anchors.verticalCenter: parent.verticalCenter
                            anchors.left: parent.left
                            anchors.leftMargin: 8
                            anchors.right: parent.right
                            anchors.rightMargin: 8
                            spacing: 1

                            Text {
                                width: parent.width
                                text: kdeTile.modelData.title
                                color: "#e8e2d4"
                                font.pixelSize: theme.fontSize(10)
                                elide: Text.ElideRight
                            }
                            Text {
                                width: parent.width
                                text: kdeTile.modelData.artist
                                color: "#9a958c"
                                font.pixelSize: theme.fontSize(8)
                                elide: Text.ElideRight
                            }
                        }
                    }

                    MouseArea {
                        anchors.fill: parent
                        cursorShape: Qt.PointingHandCursor
                        onClicked: root.selectedPick = kdeTile.modelData
                    }
                }
            }

            GridView {
                id: grid
                Layout.fillWidth: true
                // non-interactive and sized to its content — the outer bodyFlick does the
                // scrolling, so the results flow straight on under the shelves.
                Layout.preferredHeight: grid.contentHeight
                interactive: false
                clip: false
                cellWidth: root.compactPhoneLayout && grid.width > 0
                    ? grid.width / root.resultColumns : 154
                cellHeight: root.compactPhoneLayout ? grid.cellWidth * 104 / 154 : 104
                model: root.results
                boundsBehavior: Flickable.StopAtBounds
                activeFocusOnTab: count > 0
                onActiveFocusChanged: if (activeFocus && currentIndex < 0 && count > 0) currentIndex = 0
                Keys.onPressed: (event) => resultKeys.handle(event)
                highlight: Rectangle { color: "transparent"; radius: 8; border.width: 2; border.color: "#f0c44a"; visible: grid.activeFocus }
                KeyboardCollectionController {
                    id: resultKeys
                    view: grid
                    orientation: "grid"
                    columns: root.resultColumns
                    positionIndexFn: (index) => root.revealResultIndex(index)
                    onActivated: (index) => { const row = root.results[index]; if (row) root.selectedPick = row }
                }

                delegate: Rectangle {
                    id: resultTile
                    required property var modelData
                    width: root.compactPhoneLayout ? Math.max(1, grid.cellWidth - 10) : 144
                    height: root.layout.targetSize(root.compactPhoneLayout ? Math.max(1, grid.cellHeight - 12) : 92)
                    radius: 8
                    color: "#101014"
                    border.width: root.selectedPick.source_id === resultTile.modelData.source_id ? 2 : 1
                    border.color: root.selectedPick.source_id === resultTile.modelData.source_id ? "#c9a44a" : Qt.rgba(255, 255, 255, 0.14)
                    clip: true

                    Image {
                        anchors.fill: parent
                        source: resultTile.modelData.thumb_url
                        fillMode: Image.PreserveAspectCrop
                        asynchronous: true
                        cache: true
                    }

                    // source badge — the chip says whose art it is (Wallhaven, or the Colosseum shelf)
                    Rectangle {
                        anchors.left: parent.left
                        anchors.bottom: parent.bottom
                        anchors.margins: 5
                        width: badgeText.implicitWidth + 10
                        height: 16
                        radius: 8
                        color: Qt.rgba(0, 0, 0, 0.62)

                        Text {
                            id: badgeText
                            anchors.centerIn: parent
                            text: resultTile.modelData.source
                            color: "#d8d4cc"
                            font.pixelSize: theme.fontSize(9)
                        }
                    }

                    MouseArea {
                        anchors.fill: parent
                        cursorShape: Qt.PointingHandCursor
                        onClicked: root.selectedPick = resultTile.modelData
                    }
                }

                // Load more — appends Wallhaven's next page
                footer: Item {
                    width: grid.width
                    height: root.canLoadMore || root.loading ? (root.compactPhoneLayout ? 64 : 56) : 0

                    Rectangle {
                        anchors.centerIn: parent
                        visible: root.canLoadMore || root.loading
                        width: 148
                        height: root.layout.targetSize(root.compactPhoneLayout ? 48 : 36)
                        radius: 999
                        color: root.loading ? Qt.rgba(255, 255, 255, 0.08)
                             : moreMa.containsMouse ? "#d6b357" : "#c9a44a"

                        Text {
                            anchors.centerIn: parent
                            text: root.loading ? "Loading..." : "Load more"
                            color: root.loading ? "#b8b2a8" : "#15110a"
                            font.pixelSize: theme.fontSize(13)
                            font.weight: Font.DemiBold
                        }

                        MouseArea {
                            id: moreMa
                            anchors.fill: parent
                            enabled: root.canLoadMore
                            hoverEnabled: true
                            cursorShape: Qt.PointingHandCursor
                            onClicked: root.fetchMore()
                        }
                        KeyboardAction {
                            anchors.fill: parent
                            pointerEnabled: false
                            enabled: root.canLoadMore
                            accessibleName: "Load more wallpapers"
                            onTriggered: root.fetchMore()
                        }
                    }
                }
            }
                }
            }
        }

        ScrollGlide { flick: bodyFlick }
    }

    Rectangle {
        // Coerced: the bare && yields the image_url STRING (or undefined), and QML warns
        // "Unable to assign [undefined] to bool" on every evaluation with nothing selected.
        visible: !!(root.selectedPick && root.selectedPick.image_url)
        width: root.selectedPanelWidth
        height: root.selectedPanelHeight
        radius: 18
        x: root.selectedPanelX
        y: root.selectedPanelY
        color: Qt.rgba(0.04, 0.04, 0.06, 0.88)
        border.width: 1
        border.color: Qt.rgba(255, 255, 255, 0.16)

        Column {
            anchors.fill: parent
            anchors.margins: root.compactPhoneLayout ? 12 : 16
            spacing: root.compactPhoneLayout ? 8 : 10

            Text {
                width: parent.width
                text: root.selectedPick.title || "Selected wallpaper"
                elide: Text.ElideRight
                color: "#f6f2ea"
                font.family: theme.display
                font.pixelSize: theme.fontSize(root.compactPhoneLayout ? 16 : 18)
            }

            Text {
                text: root.selectedPick.spec || ""
                color: "#aaa59c"
                font.pixelSize: theme.fontSize(12)
            }

            Row {
                width: parent.width
                spacing: 10

                Repeater {
                    model: [
                        { label: "For All Worlds", scope: "all" },
                        { label: "For " + root.targetWorld, scope: "world" }
                    ]

                    delegate: Rectangle {
                        id: scopeButton
                        required property var modelData
                        width: root.selectedButtonWidth
                        height: root.layout.targetSize(root.compactPhoneLayout ? 48 : 40)
                        radius: 999
                        color: buttonMa.containsMouse ? "#d6b357" : (scopeButton.modelData.scope === "all" ? "#c9a44a" : Qt.rgba(255, 255, 255, 0.10))
                        border.width: scopeButton.modelData.scope === "all" ? 0 : 1
                        border.color: Qt.rgba(255, 255, 255, 0.18)

                        Text {
                            anchors.fill: parent
                            anchors.margins: 8
                            verticalAlignment: Text.AlignVCenter
                            horizontalAlignment: Text.AlignHCenter
                            text: scopeButton.modelData.label
                            wrapMode: Text.WordWrap
                            color: scopeButton.modelData.scope === "all" || buttonMa.containsMouse ? "#15110a" : "#f0eee8"
                            font.pixelSize: theme.fontSize(13)
                            font.weight: Font.DemiBold
                        }

                        MouseArea {
                            id: buttonMa
                            anchors.fill: parent
                            hoverEnabled: true
                            cursorShape: Qt.PointingHandCursor
                            onClicked: root.applyRequested(scopeButton.modelData.scope, root.targetWorld, root.selectedPick)
                        }
                        KeyboardAction {
                            anchors.fill: parent
                            pointerEnabled: false
                            accessibleName: "Apply wallpaper " + scopeButton.modelData.label
                            onTriggered: root.applyRequested(scopeButton.modelData.scope, root.targetWorld, root.selectedPick)
                        }
                    }
                }
            }
        }
    }

    // Lanista automation layer: the rendered apply buttons above remain the production
    // controls. These transparent hit targets follow the responsive buttons while
    // retaining their signal path.
    Item {
        objectName: "wallpaperApply_all"
        visible: !!(root.selectedPick && root.selectedPick.image_url)
        z: 60
        x: root.selectedPanelX + (root.compactPhoneLayout ? 12 : 16)
        y: root.selectedButtonY
        width: root.selectedButtonWidth; height: root.layout.targetSize(root.compactPhoneLayout ? 48 : 40)
        MouseArea {
            anchors.fill: parent
            onClicked: root.applyRequested("all", root.targetWorld, root.selectedPick)
        }
    }
    Item {
        objectName: "wallpaperApply_world"
        visible: !!(root.selectedPick && root.selectedPick.image_url)
        z: 60
        x: root.selectedPanelX + (root.compactPhoneLayout ? 12 : 16)
            + root.selectedButtonWidth + 10
        y: root.selectedButtonY
        width: root.selectedButtonWidth; height: root.layout.targetSize(root.compactPhoneLayout ? 48 : 40)
        MouseArea {
            anchors.fill: parent
            onClicked: root.applyRequested("world", root.targetWorld, root.selectedPick)
        }
    }
}
