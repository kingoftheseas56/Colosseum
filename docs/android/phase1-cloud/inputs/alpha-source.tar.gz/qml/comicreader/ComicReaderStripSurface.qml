// ComicReaderStripSurface — the Long Strip reading surface (Task 10).
//
// The manga-default vertical reader: one continuously-scrolling column of full-bleed pages on
// black. It is a THIN painter over the Task-7 backend — "QML paints, C++ decides":
//
//   * GEOMETRY IS AUTHORITATIVE. A ListView is bound to `core.stripModel` (the Task-6
//     ComicReaderStripModel, roles pageIndex/top/displayWidth/displayHeight/ready/errorCode). Each
//     delegate takes its height/width from the MODEL roles, never from the loaded Image's implicit
//     size — so a page decoding to a taller-than-estimated size never reflows/jerks the column.
//   * VIRTUALIZED. ListView keeps only near-viewport delegates (modest cacheBuffer); on scroll the
//     surface reports the viewport to core.setStripViewport(top,height) + setStripViewportWidth(w)
//     THROTTLED to at most once per frame (a 16ms coalescing timer, not one call per contentY tick).
//   * ANTI-JUMP. core.stripCompensation(delta) — emitted when a page above the fold decodes to a new
//     height — is added straight to contentY so the read position doesn't shift under the reader.
//   * SMOOTH WHEEL. The family's float accumulator — ported from the reader this one replaced
//     (MangaReader.qml's FrameAnimation drain, itself TB2's), NOT re-derived. ~168px/notch intake
//     into a bounded backlog, 38% of that backlog drained per frame, sub-pixel float contentY.
//     THIS is the reading feel, and every clause of it is load-bearing — see the drain below.
//   * PER-PAGE FAILURE. core.pageFailed(page,code) shows a typed placard on THAT page's delegate
//     only (missing / decode / unsupported); the rest of the column keeps reading.
//
// INJECTABLE + GUARDED. `core` is injected by the shell (its ComicReaderCore seam). Every `core.`
// use is guarded, so the surface also survives the shell's Task-9 fake (which has no imageUrl /
// stripModel / setStripViewport) — it simply renders nothing until a real core is present.
//
// STATE-MUTATING SIGNALS ARE PROVENANCE-BLIND, GATED ONLY ON _programmatic. pageInView/scrolled fire
// on ANY real move of the column — wheel, keyboard (Space/PageUp/PageDown), a scrub-bar drag, Home/
// End — throttled to at most once per ~80ms window (Reader 1's pageTrack), never once per contentY
// tick. They fire NEVER on construction, resume, or compensation (those write contentY with
// _programmatic held true) — so mounting this surface never clobbers the shell's resumed page/
// fraction. The shell consumes pageInView/scrolled out; it puts the column somewhere by CALLING
// seekToPage()/haltScrollAt(), never by binding a fraction in (that would be a scroll -> fraction ->
// apply -> scroll loop).

import QtQuick
import QtQuick.Window   // Screen — the decode cap must not move when the WINDOW does

Item {
    id: root

    // ---- injectable seam + inputs (bound by the shell) ----
    property var core: null
    property bool active: true
    property bool rtl: false                 // strip is vertical; kept for parity / future affordances
    property int cacheScreens: 2             // cacheBuffer in viewport-heights (modest -> virtualized)
    // THE WHEEL BELONGS TO SOMETHING ELSE (Task 9). Raised by the shell while the Loupe is up, where
    // a notch magnifies the lens; the column must not move under it, because the approved rule is
    // that the Loupe never changes the reading position. See _intakeWheel for why the guard lives
    // on the intake function as well as on the handler.
    property bool wheelLocked: false

    // ---- AUTO-SCROLL (Task 8). MOTION ONLY. ----
    // The approved rule, verbatim: "Long Strip creates the vertical page flow; Auto-scroll only
    // supplies motion at the already chosen width. Starting or resuming Auto-scroll must never
    // resize the page." Structurally, not by promise: the drive below writes contentY and NOTHING
    // ELSE. There is no call to applyLayout / core.setStripLayout anywhere on this path, and the
    // width is not an input to any of it.
    //
    // The SHELL owns whether it is running (it is session-only state and every pause source lives
    // up there); this surface owns the pixels-per-frame. Both flow one way: in.
    property bool autoScrollRunning: false
    property real autoScrollSpeed: 1.0       // 0.25..3.0, clamped where it is used
    // 120px/s at 1x — a comfortable webtoon pace, and the number the plan fixes. At the default 78%
    // portrait width a page is roughly two viewport heights, so 1x reads a page in about 15s.
    readonly property real autoScrollBasePps: 120
    readonly property real autoScrollPixelsPerSecond:
        autoScrollBasePps * Math.max(0.25, Math.min(3.0, autoScrollSpeed))

    // ---- DECODE CAP (the lineage's sourceSize.width; the strip had none) ----
    // Without a cap, every page decodes and uploads its FULL source resolution — a scanned tankobon
    // page is routinely 2000-3000px wide — while it is displayed at a fraction of that. The cost is
    // paid on the render thread, once per page arriving on screen, which is why an uncapped strip
    // reads as smooth-but-intermittently-laggy rather than uniformly harsh: you only feel it when a
    // fresh page comes into view. The reader this one replaced capped its strip at 1100px.
    //
    // DELIBERATE DEVIATION from that flat 1100: it would be visibly soft on a large display, where
    // a page is shown wider than that. This caps to the SCREEN width instead — never smaller than
    // the lineage's 1100, never more than 2048 — so it can't be soft and can't be wasteful.
    //
    // The SCREEN, emphatically not the viewport. sourceSize is part of an Image's cache key, so
    // every change to this number re-decodes every visible page — each one paying a full-resolution
    // downscale in the provider. Tying it to the window meant entering fullscreen re-decoded the
    // whole visible column, and leaving it did so again: Hemanth's "going in and out of fullscreen
    // looks incredibly rough" (2026-07-26). The screen is the widest a page can ever be displayed,
    // so it is the correct upper bound AND it holds still while the window moves.
    readonly property int srcCapW:
        Math.max(1100, Math.min(2048, Math.ceil(Math.max(320, Screen.width) / 256) * 256))
    // ...and the PREVIEW tier's cap. Half the width AND the fast transform (Task 2's `preview` tier
    // picks both), which is the whole of "first pixels, soonest". Same rule and the same arithmetic
    // as the Single surface, so the three surfaces ask the delivery path for the same shape of work.
    //
    // A quarter of the pixels for the first paint matters MORE here than in the paged layouts: this
    // is the surface that meets new pages continuously, so the wait for hq is not once per page turn
    // but once per page scrolled past. The scaled tier was sized for this pair from the start —
    // ComicReaderCore's kScaledEntriesPerPage is 2 and says so out loud.
    readonly property int previewCapW: Math.max(320, Math.round(srcCapW / 2))

    // ---- outputs consumed by the shell / HUD (Task 11) ----
    // These three are PROVENANCE-BLIND: they fire for any non-programmatic move — wheel, keyboard,
    // scrub drag, Home/End. Only _programmatic writes (resume, compensation, layout anchoring) stay
    // silent. Gating them on "was it a wheel gesture" is what made reading with the spacebar file a
    // Continue record of page 1.
    signal pageInView(int page)              // 1-based page at the vertical center
    signal visiblePages(var indices)         // 0-based indices currently on screen
    signal scrolled(real fraction)           // 0..1 scroll fraction
    // The page whose pixels are ACTUALLY on screen, and how far down that page the viewport centre
    // sits (0 at its top edge, 1 at its bottom). Task 4's cross-surface seam: all three reading
    // surfaces speak this one shape so Task 11 can gate progress-saving on real presentation with a
    // single handler. In Long Strip the fraction is the only one of the three that is ever non-zero —
    // you genuinely stop part way down a page here — which is why it is in the signature at all.
    // Nothing consumes it yet; that is Task 11.
    signal presented(int anchorPage, real withinPageFraction)
    // Activity presentation (§9 Lane C): fires ONLY for a USER-DRIVEN move that brings the
    // viewport centre into a NEW successfully rendered physical page — never for a programmatic
    // resume/compensation/layout-anchor write (those hold `_programmatic` true and never reach
    // _emitUserScroll, the one caller below) and never for a page merely visible at the edge of
    // the viewport (only the CENTRE index counts — the same index pageInView already reports).
    // 0-based — the shell's/ComicActivityHelpers page-key namespace; pageInView above is
    // 1-based for the shell's currentPage scale, this is not.
    signal activityPagesPresented(var pageKeys)
    // Unlike the three above this one IS wheel-only — it means "a real gesture happened", not
    // "the position changed". Task 8 gave it its consumer at last: the shell pauses Auto-scroll on
    // it, which is exactly the question it was always answering ("was this a hand, or the machine")
    // and the reason it survived unconsumed for three tasks.
    signal manualNavigation()
    // The column reached the bottom while Auto-scroll was driving it. The shell clears its running
    // flag on this — the surface never writes that flag, so there is one owner and no way for the
    // two to disagree about whether the motion is live.
    signal autoScrollEnded()
    // The placard's two ways out (Task 11), raised straight through from whichever ROW's card was
    // pressed — never from the page under the viewport centre, because in a column the broken page
    // and the page you are looking at are routinely not the same one. The surface performs neither:
    // Retry is a backend re-read and Skip is a navigation, and both belong to the shell. 1-based,
    // like every other page number this surface reports.
    signal retryRequested(int page)
    signal skipRequested(int page)

    clip: true

    // full-bleed black stage — the page owns the screen
    Rectangle { anchors.fill: parent; color: "#000000" }

    // ---- test/observation surface (harness reads these; also handy for the HUD later) ----
    property alias contentY: list.contentY
    readonly property int rowCount: list.count
    readonly property real contentHeight: list.contentHeight
    // Is the column parked at the bottom — or already gliding into it? The shell asks this to decide
    // whether a page-down should scroll or announce the end of the volume. It counts the IN-FLIGHT
    // backlog deliberately: without that, a second Space pressed while the first is still gliding
    // would read the not-yet-arrived position and announce the end while the page is still moving.
    //
    // AND IT REFUSES TO ANSWER ON ESTIMATED GEOMETRY (hardened after Codex's cross-review, which
    // caught this as a real defect). Until a page is decoded the column uses an ESTIMATED height for
    // it, so contentHeight is an underestimate and the scrollable span is short. Scroll down faster
    // than the decodes land and you reach "the end" while there is still book left — and the reader
    // announces the end of a volume you are in the middle of. Lying is worse than saying nothing, so
    // an unmeasured tail reports false and the shell simply scrolls instead.
    //
    // `readyRev` is read purely as a reactive dependency: it bumps on every pageReady, which is the
    // only signal QML gets that the backend learned a real page size (the per-page rev it folds into
    // imageUrl is a C++-side read QML cannot see). Same trick the `source` bindings below use.
    readonly property bool atEnd: {
        var _dep = readyRev                       // re-evaluate as decodes land
        var n = list.count
        if (n <= 0) return false                  // nothing loaded yet is NOT the end of anything
        if (!_lastRowMeasured()) return false     // geometry still an estimate — never announce
        var span = Math.max(0, list.contentHeight - list.height)
        if (span <= 0) return true                // the whole (measured) book fits the viewport
        return (list.contentY + _pendingWheelPx) >= span - 1
    }
    // Has the backend learned the LAST page's true size? pageInfo() omits geometry it has not
    // learned yet (ComicReaderCore::onMetaReady fills it from the file header ahead of the decode),
    // so a present, positive sourceHeight is the honest "this row's height is real, not estimated"
    // signal. A partial seam or a fake without sizes answers "not measured", which fails CLOSED.
    function _lastRowMeasured() {
        var n = list.count
        if (n <= 0 || !core || !core.pageInfo) return false
        var pi = core.pageInfo(n - 1)
        return !!pi && pi.sourceHeight !== undefined && Number(pi.sourceHeight) > 0
    }
    function itemAt(i) { return list.itemAtIndex(i) }
    function forceRelayout() { list.forceLayout() }

    // ---- WHAT THIS SURFACE IS DRAWING, and where (Task 9, the Loupe's one question) ----
    // [{ page (0-based), url, x, y, width, height }] in THIS surface's coordinates — the shape all
    // three surfaces answer in, so the lens has one code path for Single, Pair and Long Strip. Here
    // it is however many rows are on screen, which is what makes the lens behave correctly while the
    // column moves: the boxes shift under a stationary anchor, so the page you are inspecting
    // changes because the BOOK moved, never because the lens did.
    //
    // Walks the REALIZED delegates only. An unrealized row has no geometry to report and returns
    // null from itemAtIndex; a row outside the viewport is not being drawn. The walk starts from the
    // row under the top edge and stops at the first row past the bottom, so it is bounded by what is
    // visible (two or three rows) and never by the book's length.
    //
    // The url carries no decode cap: the caller states its own request size, and the Loupe
    // deliberately asks for far more than the screen shows.
    function visiblePageRects() {
        if (!active || list.count <= 0 || !core || !core.imageUrl) return []
        var top = list.contentY
        var bottom = top + list.height
        // Find a row under the viewport, then walk BACK to the first one that reaches the top edge.
        // A gap between pages (Breathing room) is a real hole in the column, so a probe at the very
        // top edge can legitimately hit nothing — the mid-viewport probe is the fallback.
        var i = list.indexAt(list.width / 2, top + 1)
        if (i < 0) i = list.indexAt(list.width / 2, (top + bottom) / 2)
        if (i < 0) i = list.indexAt(list.width / 2, bottom - 1)
        if (i < 0) return []
        while (i > 0) {
            var prev = list.itemAtIndex(i - 1)
            if (prev && prev.y + prev.height > top) i -= 1
            else break
        }
        var out = []
        for (; i < list.count; i++) {
            var it = list.itemAtIndex(i)
            if (!it) break                       // unrealized: nothing beyond here is drawn either
            if (it.y >= bottom) break
            if (it.y + it.height <= top) continue
            if (!(it.rowPageWidth > 0) || !(it.height > 0)) continue
            out.push({ page: it.rowPageIndex,
                       url: core.imageUrl(it.rowPageIndex, "hq"),
                       x: it.rowPageX, y: it.y - top,
                       width: it.rowPageWidth, height: it.height })
        }
        return out
    }

    // ---- internal flags ----
    property bool _programmatic: false       // suppress user-signal emission for resume/compensation
    property bool _draining: false           // the wheel drain is authoring contentY (don't resync smoothY)
    // a wheel gesture has occurred this session. NARROWED (B3): this used to ALSO gate
    // pageInView/scrolled emission in onContentYChanged — that was bug 1 (keyboard/scrub reading
    // never reported until one incidental wheel notch anywhere in the session silently "fixed" it).
    // Tracking is now provenance-blind (gated on _programmatic only, see onContentYChanged below).
    // Kept as wheel-specific session provenance for manualNavigation()'s potential future consumers
    // (e.g. HUD auto-hide reacting only to a real gesture, not every strip move) — currently
    // unconsumed by the shell (grep shows no onManualNavigation handler), so this flag has no live
    // reader today, but nothing else duplicates "did a wheel gesture happen" and removing it would
    // be an unrelated cleanup outside this bug fix's scope.
    property bool _userInteracted: false
    // The last page the viewport CENTRE genuinely entered and reported activity for (§9 Lane C
    // dedupe at the surface level — "avoid obviously duplicate spam"). -1 = nothing noted yet
    // this entry; reset in the Connections block's onEntryChanged, alongside _rangeFirst/Last.
    property int _activityLastCentrePage: -1

    // Decode-refresh dependency. The C++ provider returns a NULL image for a not-yet-decoded page
    // and imageUrl() embeds a per-page rev that bumps on pageReady — but imageUrl() reading that rev
    // is a C++-side read QML CANNOT see, so an Image `source` bound only to {core,page} would never
    // re-request after the decode lands (page stays blank until the delegate is recreated). This
    // counter, bumped on every pageReady and folded into each `source` via the comma-sequence trick,
    // is the reactive dependency that re-drives the binding so the fresh (?rev=N) url is re-fetched.
    property int readyRev: 0

    // ================= per-page failure tracking =================
    property var failedPages: ({})           // 0-based page -> code string
    property int failedRev: 0                 // bumped so delegates re-evaluate _failText()
    function _markFailed(page, code) {
        failedPages[page] = String(code)
        failedRev += 1
    }
    function _clearFailed(page) {
        if (failedPages[page] !== undefined) {
            delete failedPages[page]
            failedRev += 1
        }
    }
    // The backend's snake_case wire CODE for a page, or "" when it is fine. It used to return the
    // finished HEADLINE, which meant this surface owned a second copy of the error wording — the
    // same three strings ComicReaderUnitError already carries. Task 11 gave that card two actions,
    // at which point a hand-copied twin stopped being a tidiness question: a Long Strip reader would
    // have been the one reader still left with a dead end. So the strip now mounts the SAME card,
    // and this returns the one thing the card cannot work out for itself.
    //
    // The int fallback is the model's ErrorCodeRole, which is how a page that failed before this
    // surface existed (or before its Connections attached) still reports honestly.
    function _failCode(page, errorCode) {
        var code = failedPages[page]
        if (code === undefined || code === "") {
            var e = Number(errorCode) || 0     // model ErrorCodeRole int: 1 missing / 2 decode / 3 unsupported
            code = e === 1 ? "missing_file" : e === 2 ? "decode_failed" : e === 3 ? "unsupported_image" : ""
        }
        // An unrecognised code draws NO card here, exactly as before: the column is a continuous
        // read, and a card for a state nothing can name would be worse than the page simply not
        // being there yet.
        return (code === "missing_file" || code === "decode_failed" || code === "unsupported_image")
               ? code : ""
    }

    Connections {
        target: root.core
        ignoreUnknownSignals: true
        function onPageFailed(page, code) { root._markFailed(page, code) }
        // A retry cleared the backend's verdict for this page. The surface keeps its OWN failure map
        // (it has to — the strip model's role is an int and arrives on its own clock), so the memo
        // has to be dropped here as well or the card would stay up over a page that is re-decoding.
        function onPageRetried(page)      { root._clearFailed(page) }
        // decode landed: clear any failure AND bump readyRev so the page's `source` re-requests the
        // freshly-decoded pixels (the ?rev= url changed C++-side, invisibly to QML).
        function onPageReady(page)        { root._clearFailed(page); root.readyRev += 1 }
        // The Image panel adjusted the picture (Task 7). Same refresh dependency as a
        // decode landing, and for the same reason: imageUrl() now folds the render
        // revision, and that read happens in C++ where a QML binding cannot see it. Without
        // this bump the `source` binding never re-evaluates, the url never changes, and QML's
        // own pixmap cache serves the pre-adjustment page for the rest of the session.
        function onRenderProfileChanged() { root.readyRev += 1 }
        function onStripCompensation(delta) { root._applyCompensation(delta) }
        // A fresh book (or a crossing) invalidates the retention memo. ComicReaderCore resets its
        // own last-swept range on every openEntry for exactly this reason — "a new book always
        // sweeps even if it opens on the page numbers the last one closed at" — and a QML memo that
        // did not reset alongside it would swallow the new entry's FIRST call and leave the window
        // wherever the previous volume left it.
        function onEntryChanged() {
            root._rangeFirst = -1
            root._rangeLast = -1
            root._activityLastCentrePage = -1
            // A fresh book can arrive while Long Strip remains the active layout. In that case
            // active/width/height/contentY do not have to change, so none of the usual viewport
            // triggers is guaranteed to fire. The provider only serves pages already decoded by
            // core.setStripViewport(), therefore re-prime the viewport on every entry crossing.
            // _scheduleReport() already fails closed while this surface is inactive.
            root._scheduleReport()
        }
    }

    function _applyCompensation(delta) {
        // a page above the fold changed height — shift our scroll position by the same delta so the
        // read position holds. Programmatic (never a user gesture).
        //
        // CLAMPED (E6): this was the last unclamped contentY write in the surface. Near the top of a
        // book a page above the fold can shrink, producing a negative delta larger than the scroll
        // position — contentY goes negative and the reader shows a black band above page 1 until
        // something else moves the view. Every other write already clamps; this one was simply
        // missed. The clamp is inert wherever there is room, so ordinary mid-book compensation is
        // unchanged.
        var maxY = Math.max(0, list.contentHeight - list.height)
        _programmatic = true
        list.contentY = Math.max(0, Math.min(maxY, list.contentY + delta))
        _smoothY = list.contentY
        _programmatic = false
    }

    // ================= the strip =================
    ListView {
        id: list
        anchors.fill: parent
        model: root.core ? root.core.stripModel : null
        orientation: ListView.Vertical
        cacheBuffer: Math.round(Math.max(1, root.height) * root.cacheScreens)
        boundsBehavior: Flickable.StopAtBounds
        interactive: false                    // wheel drives the smooth accumulator; drag/flick is Task 11
        pixelAligned: false                   // preserve the sub-pixel float feel

        delegate: Item {
            id: del
            width: ListView.view ? ListView.view.width : root.width
            height: model.displayHeight > 0 ? model.displayHeight : 0   // MODEL-authoritative geometry

            readonly property string errorCode: (root.failedRev, root._failCode(model.pageIndex, model.errorCode))
            readonly property bool hasError: errorCode.length > 0
            // ---- what THIS row is, and where its paper actually sits inside the row (Task 9) ----
            // The row is full-width; the page is centred inside it at the model's display width. The
            // Loupe needs the PAPER's box, not the row's, or a magnified page would sit offset from
            // the page it is magnifying by half the letterbox. Read off the drawn Image rather than
            // re-derived, so it cannot drift from what is on screen.
            readonly property int rowPageIndex: model.pageIndex
            readonly property real rowPageX: pageImg.x
            readonly property real rowPageWidth: pageImg.width
            readonly property alias imageSource: pageImg.source   // exposed so the decode-refresh test can see it re-evaluate
            readonly property alias previewSource: previewImg.source
            readonly property alias previewCap: previewImg.sourceSize.width
            readonly property alias hqCap: pageImg.sourceSize.width
            // The hq fade as a RULE, not as the animated number. A Behavior makes `opacity`
            // untestable — a synchronous read straight after a target flip still returns the OLD
            // value (measured on the Single surface, which carries the same note) — so the rule is
            // the named property and `opacity` merely follows it.
            readonly property bool hqShown: pageImg.status === Image.Ready || pageImg._hqEverReady
            // "successfully rendered" for ACTIVITY purposes — real pixels up (either tier), NOT
            // the error placard. Distinct from hqShown (the fade rule) because §9 Lane C
            // excludes it explicitly: "Error/terminal placeholder -> no successful physical
            // page fact" — unlike presented() below, which counts a placard as an honest
            // "the reader is here" for resume purposes.
            readonly property bool pixelsShown: !hasError
                    && (previewImg.status === Image.Ready || pageImg.status === Image.Ready)

            // ---- TWO TIERS, stacked (Task 8), exactly as Single and Pair stack them ----
            // A fast half-width PREVIEW underneath, the real page faded over it as it completes.
            // The column is the surface that meets new pages continuously, so what a single-tier
            // strip cost was not one wait per page turn but one per page scrolled past: black band,
            // then the whole page at once. Geometry is unaffected — both tiers take their box from
            // the MODEL (see the delegate's height above), never from an Image's implicit size, so a
            // tier arriving can never reflow the column.

            // PREVIEW tier: first pixels on screen.
            Image {
                id: previewImg
                anchors.horizontalCenter: parent.horizontalCenter
                y: 0
                width: model.displayWidth > 0 ? model.displayWidth : parent.width
                height: parent.height
                visible: !del.hasError
                source: (root.readyRev, (root.core && root.core.imageUrl)
                        ? root.core.imageUrl(model.pageIndex, "preview") : "")
                asynchronous: true
                cache: true
                retainWhileLoading: true
                fillMode: Image.PreserveAspectFit
                sourceSize.width: root.previewCapW
                mipmap: true
            }

            // HQ tier: the reader's real page, over the preview.
            Image {
                id: pageImg
                anchors.horizontalCenter: parent.horizontalCenter
                y: 0
                width: model.displayWidth > 0 ? model.displayWidth : parent.width
                height: parent.height
                visible: !del.hasError
                // readyRev folded in so the binding re-runs (and re-fetches the bumped ?rev= url) on decode
                source: (root.readyRev, (root.core && root.core.imageUrl)
                        ? root.core.imageUrl(model.pageIndex, "hq") : "")
                asynchronous: true
                cache: true    // SAFE and load-bearing: the ?rev= in the url self-busts on a real redecode, and
                               // WITHOUT the pixmap cache every delegate rebuild re-pays the provider's full-res
                               // SmoothTransformation downscale — the "scroll back up and it stutters" cost.
                retainWhileLoading: true      // hold the current pixels through a redecode (no flash)
                fillMode: Image.PreserveAspectFit
                sourceSize.width: root.srcCapW   // decode what it LOOKS like, not what it IS
                mipmap: true                     // it is still a downscale — without this it shimmers while scrolling
                // The SAME 90ms cross-fade the paged surfaces use, so a page sharpening reads the
                // same wherever you meet it. `_hqEverReady` latches per delegate: once this page's
                // hq has landed, a later redecode holds at 1 and lets retainWhileLoading show the
                // old pixels going soft rather than dimming the page (the Single surface's scar).
                property bool _hqEverReady: false
                onStatusChanged: if (status === Image.Ready) _hqEverReady = true
                opacity: del.hqShown ? 1 : 0
                Behavior on opacity { NumberAnimation { duration: 90; easing.type: Easing.OutCubic } }
            }

            // typed error placard — this page only; the rest of the column keeps reading. THE SAME
            // card the two paged surfaces mount (Task 11): the strip carried a hand-copy of it since
            // Task 4, and the moment the card grew Retry/Skip that copy would have left Long Strip —
            // the layout you meet the most pages in — as the one place with no way out.
            ComicReaderUnitError {
                id: rowError
                objectName: "unitError"
                anchors.fill: parent
                visible: del.hasError
                code: del.errorCode
                pageIndex: model.pageIndex
                onRetryRequested: function (page) { root.retryRequested(page + 1) }
                onSkipRequested: function (page) { root.skipRequested(page + 1) }
            }
            // The card's OWN rule, exposed on the delegate so the surfaces gate can read it without
            // relying on effective visibility (an offscreen tree reports every item invisible).
            readonly property bool errorActionsShown: rowError.actionsShown
        }

        onContentYChanged: {
            root._scheduleReport()
            if (!root._draining) root._smoothY = list.contentY   // resync on any external move
            // Tracking is provenance-BLIND: keyboard, scrub, wheel — a move is a move. Only
            // _programmatic writes (resume, compensation, layout anchoring) stay silent, so
            // mounting or restoring never clobbers the shell's page.
            if (!root._programmatic) root._scheduleEmit()
        }
        // A WIDTH change reflows the whole column, so it is reported SYNCHRONOUSLY — never through
        // the throttle. See _flushViewportReportNow: deferring this by even one frame is what made
        // Hemanth's fullscreen transition shake.
        onWidthChanged: root._flushViewportReportNow()
        onHeightChanged: root._scheduleReport()
    }

    // ================= throttled viewport report (<= once per frame) =================
    property bool _reportPending: false
    property int _lastReportedWidth: -1
    Timer { id: reportTimer; interval: 16; repeat: false; onTriggered: root._flushViewportReport() }
    function _scheduleReport() {
        // Both surfaces are mounted at once against the SAME core; a HIDDEN strip must not drive the
        // shared decode pool / cache. Only the active strip reports its viewport.
        if (!active) return
        _reportPending = true
        if (!reportTimer.running) reportTimer.start()
    }
    // Report NOW, in this same beat, bypassing the 16ms throttle.
    //
    // WHY (measured, tests/comicreader_fullscreen_timing_probe.qml, 2026-07-26). Every fullscreen
    // flip in the app goes through the shared FullscreenTransitionShield: cover fades in, the window
    // mode flips behind it, and the cover lifts on the window's very NEXT frameSwapped. That is
    // honest for Player 2 — one textured quad that letterboxes to the new size within that same
    // frame, which is exactly why Hemanth calls its transition the smooth one. The strip does not
    // settle in one frame: the width change rescales the entire page column and scales contentY to
    // hold the reading position. Routed through the throttle, that landed 2 frames after the cover
    // began lifting entering fullscreen and 5 frames after it leaving — the probe recorded contentY
    // jumping 12000 -> 17067 in full view. The settle was happening in FRONT of the cover instead of
    // behind it. That is the shake, and it is why the earlier decode-cap fix (a real but separate
    // cost) did not cure it.
    //
    // The throttle exists to coalesce SCROLL reports, which arrive at 60Hz while reading. A width
    // change is rare and must never be coalesced, so only the width path is made synchronous; the
    // scroll and height paths keep the throttle exactly as before.
    function _flushViewportReportNow() {
        if (!active) return
        reportTimer.stop()
        _flushViewportReport()
    }
    function _flushViewportReport() {
        _reportPending = false
        if (!active || !core) return
        if (core.setStripViewport) core.setStripViewport(list.contentY, list.height)
        _noteRange()      // the retention window rides the SAME door, on its own slower clock
        if (core.setStripViewportWidth && list.width !== _lastReportedWidth) {
            // A width change (fullscreen, window resize) rescales the page column. The backend does this
            // IN PLACE (dataChanged, not a model reset), so the ListView keeps its delegates and its
            // contentY and simply reflows — no blink, no jump to page 1. The whole column scaled by
            // `ratio`, so scale the (preserved) scroll by the same factor to hold the read position.
            // forceLayout settles the new contentHeight first so the scaled value isn't clamped short.
            // Skip the first report (_lastReportedWidth < 0): initial layout, resume owns the position.
            var ratio = (_lastReportedWidth > 0) ? (list.width / _lastReportedWidth) : 1
            _lastReportedWidth = list.width
            core.setStripViewportWidth(list.width)
            if (ratio > 0 && ratio !== 1 && list.contentY > 0) {
                _programmatic = true
                list.forceLayout()
                list.contentY = list.contentY * ratio
                _smoothY = list.contentY
                _programmatic = false
            }
        }
    }

    // ================= the RETENTION window: core.requestRange (Task 8) =================
    // Task 2 built the viewport-shaped retention window and left it with no production caller. This
    // is that caller, and it is written against the warning requestRange's own doc comment carries:
    //
    //   "a call whose clamped range DIFFERS from the last one walks both cache hashes under both
    //    mutexes and frees QImages ON THE CALLING (GUI) THREAD, and the decoded walk contends the
    //    same mutex every provider worker takes for every page fetch. ... debounce or send it on
    //    settle, and send PAGE indices, not pixels."
    //
    // This reader exists BECAUSE of a stutter whose root cause was a per-frame GUI-thread cascade.
    // Wiring a per-frame scroll signal straight to a bulk free on the GUI thread would be the same
    // shape again, so there are three separate brakes and each one is doing different work:
    //
    //   1. PAGE INDICES, NOT PIXELS. A range only changes when the viewport crosses a page
    //      boundary. At the default 78% width a page is roughly two viewport heights, so an
    //      ordinary read changes the range every few seconds, not every frame.
    //   2. A QML-SIDE MEMO (_rangeFirst/_rangeLast). An unchanged range never crosses the C++
    //      boundary at all. The core has its own identical early-out; this one means we do not even
    //      pay the invoke, which is what makes a 60Hz caller safe.
    //   3. A LEADING+TRAILING THROTTLE. The first move of a fling sweeps immediately (the window
    //      must not lag the reader), then everything inside the window coalesces and the LAST of it
    //      lands when the window closes. Nothing is dropped; a fast fling through fifty pages costs
    //      four sweeps a second instead of sixty. The timer only stays alive while movement
    //      continues — a closing window with nothing waiting simply stops.
    //
    // A settle-only debounce (restart on every move, fire on quiet) was the other candidate and is
    // WRONG here for one specific reason: Auto-scroll moves the column continuously for minutes, so
    // "quiet" never arrives and the window would never update for the entire run.
    property int rangeThrottleMs: 250
    property bool _rangePending: false
    property int _rangeFirst: -1
    property int _rangeLast: -1
    Timer { id: rangeThrottle; interval: root.rangeThrottleMs; repeat: false; onTriggered: root._flushRangeWindow() }

    // The visible run as MODEL INDICES, or null when the column cannot honestly answer. Null rather
    // than a guess: indexAt returns -1 for a position with no realized delegate (mid-relayout, or
    // straight after a resume jumped the column thousands of pixels), and telling the backend to
    // retain a window we invented would evict the pages actually on screen.
    function _visibleRange() {
        if (list.count <= 0) return null
        var lo = list.indexAt(list.width / 2, list.contentY + 1)
        var hi = list.indexAt(list.width / 2, list.contentY + list.height - 1)
        if (lo < 0 || hi < 0 || hi < lo) return null
        return { first: lo, last: hi }
    }
    // THE guard that matters is here, not on the callers: the throttle TIMER can fire after a
    // layout switch has already taken this strip off screen, and both reading surfaces share one
    // backend — a hidden strip sweeping the retention window would evict what the visible one is
    // showing. (_noteRange has no second copy of this test on purpose; its only caller,
    // _flushViewportReport, is already gated, and _flushRangeWindow arrives from a timer that is
    // not.)
    function _sendRange() {
        if (!active || !core || !core.requestRange) return
        var r = _visibleRange()
        if (!r) return
        if (r.first === _rangeFirst && r.last === _rangeLast) return   // brake 2: never pay the invoke twice
        _rangeFirst = r.first
        _rangeLast = r.last
        core.requestRange(r.first, r.last)
    }
    function _noteRange() {
        if (!core || !core.requestRange) return
        if (rangeThrottle.running) { _rangePending = true; return }
        _sendRange()
        rangeThrottle.start()
    }
    // CLOSE the window. The one door, whether the 250ms timer reached it or a caller wants the
    // window shut now — stopping the timer first means "the window is closed" is true on the way
    // out either way, which is what lets the gate drive this deterministically instead of sleeping.
    function _flushRangeWindow() {
        rangeThrottle.stop()              // a no-op when the (non-repeating) timer itself got here
        if (!_rangePending) return        // nothing waiting: stop, and leave no timer running
        _rangePending = false
        _sendRange()
        rangeThrottle.start()             // still moving: hold the window open
    }

    // ================= throttled tracking emit (<= once per ~80ms window) =================
    // Reader 1's pageTrack (MangaReader.qml, pre-cutover): "onContentYChanged: if
    // (!pageTrack.running) pageTrack.start()", a single-shot 80ms Timer. _emitUserScroll() does three
    // list.indexAt() probes and builds the visible-index array — per-frame during a glide that is
    // pure overhead on the one thread that has to hold 60fps, so it is scheduled, not called inline.
    property bool _emitPending: false
    Timer { id: emitTimer; interval: 80; repeat: false; onTriggered: root._flushEmit() }
    function _scheduleEmit() {
        _emitPending = true
        if (!emitTimer.running) emitTimer.start()
    }
    function _flushEmit() {
        _emitPending = false
        _emitUserScroll()
    }
    // presented(), on its own. Split out from _emitUserScroll because the two have DIFFERENT rules
    // about provenance: scrolled()/pageInView() are suppressed for a programmatic move, because they
    // write back into the shell's page/fraction and a restore that emitted them would clobber the very
    // spot it was restoring to. presented() writes back into nothing — it is an outbound notice that
    // the reader can now see this position — so a restore SHOULD emit it. Without that, the landing
    // page of a resumed book was never reported at all, and Task 11 banks progress on this signal.
    //
    // A page showing its typed failure placard COUNTS: the one rule all three surfaces now follow is that
    // presented() means "the reader can see this position's content, or an explicit account of why
    // not". Task 11 must not sit waiting to bank a position that can never render; whether to offer a
    // retry is a separate question from where the reader is.
    //
    // GATED ON `active`, like the other two surfaces' _notePresented(). An UNMOUNTED strip still holds
    // a laid-out column and still receives seekToPage/haltScrollAt from the shell across a layout
    // switch; reporting from there would tell Task 11 the reader saw a page that is not on screen.
    //
    // IT ASKS THE BACKEND, NOT THE DRAWN COLUMN, and that is the difference between a report that
    // works on a restore and one that does not. A resume or a layout switch jumps contentY thousands
    // of pixels in one write, and the ListView only holds items around where it WAS: measured
    // 2026-07-30, indexAt() and itemAtIndex() both answer nothing at the new position, and neither
    // forceLayout() nor a later event-loop pass brought them back in the offscreen harness. This is
    // the SAME trap seekToPage documents on the way in ("the ListView only realizes delegates near
    // the viewport, so a page you are switching TO has no y to read yet"), and the shell already
    // answers this exact question the same way (core.stripPageAtCenter, for the scrub bubble).
    // The drawn column stays as the FALLBACK, for a partial core that has no strip geometry seam.
    function _emitPresented() {
        if (!active) return
        if (list.count <= 0) return
        var centreY = list.contentY + list.height / 2
        var idx = -1
        var frac = -1
        if (core && core.stripPageAtCenter) {
            idx = core.stripPageAtCenter(list.contentY, list.height)
            if (idx >= 0 && core.stripPageHeight && core.stripPageTop) {
                var h = core.stripPageHeight(idx)
                if (h > 0) frac = (centreY - core.stripPageTop(idx)) / h
            }
        }
        if (idx < 0) {
            idx = list.indexAt(list.width / 2, centreY)
            if (idx < 0) return
        }
        if (frac < 0) {
            var it = list.itemAt(list.width / 2, centreY)
            frac = (it && it.height > 0) ? (centreY - it.y) / it.height : 0
        }
        root.presented(idx + 1, Math.max(0, Math.min(1, frac)))
    }
    // Change the strip's page width / gap WITHOUT losing the reader's place. The backend owns the
    // geometry (QML paints, C++ decides): it anchors the page under the viewport centre across the
    // relayout and hands back the top to land on. forceLayout settles the new contentHeight first,
    // so assigning that top is not clamped short against a stale one.
    function applyLayout(widthPct, gap) {
        if (!core || !core.setStripLayout) return
        var newTop = core.setStripLayout(widthPct, gap, list.contentY, list.height)
        // A partial seam (an older backend, a harness fake) returns nothing — hold the current
        // position rather than assigning NaN into contentY and blanking the strip.
        if (typeof newTop !== "number" || !isFinite(newTop)) newTop = list.contentY
        _programmatic = true
        list.forceLayout()
        var maxY = Math.max(0, list.contentHeight - list.height)
        list.contentY = Math.max(0, Math.min(maxY, newTop))
        _smoothY = list.contentY
        _programmatic = false
    }

    // Becoming active (mode switched back to strip) — push the current viewport once so the backend
    // resumes decoding the right window (geometry changes while hidden were intentionally ignored)...
    // ...and report the position the reader is now looking at. Mounting a surface onto a position the
    // column is already parked at IS a presentation, and it is the same rule the two paged surfaces
    // follow in their own onActiveChanged. Without it, switching layout back to Long Strip left the
    // landing page unreported until the reader happened to scroll.
    onActiveChanged: if (active) { _scheduleReport(); Qt.callLater(root._emitPresented) }

    // ================= smooth-wheel float accumulator (Tankoban-Max / QTGW SmoothScrollArea) =================
    property real _pendingWheelPx: 0         // bounded backlog of intake still to drain
    property real _smoothY: 0                // float sub-pixel scroll position — contentY IS this
    property bool _drainFresh: false         // first tick after an idle start
    readonly property real _drainFraction: 0.38   // TB2: 38% of the backlog per frame
    readonly property real _maxBacklogPx: 6000    // a wheel flurry can't queue forever

    // The drain is a FrameAnimation, NOT a Timer. It is the single biggest thing separating smooth
    // from harsh: a FrameAnimation ticks ON the render loop, so each step lands exactly once per
    // presented frame. A 16ms Timer free-runs against the compositor instead — it beats with the
    // vsync, so steps double up or drop out and the column judders no matter how good the easing is.
    FrameAnimation {
        id: scrollDrain
        running: false
        onTriggered: root._drainWheel()
    }

    // 1.4 px per angle unit = 168px/notch — the house tuning from the reader this one
    // replaced, restored on Hemanth's ruling (2026-07-25). We had TB2's 100px/notch: the
    // same easing curve travelling 40% less per notch, which reads as smooth-but-heavy.
    // The trackpad path is untouched — pixelDelta is already real pixels on every platform.
    function _intakeWheel(angleY, pixelY) {
        // THE WHEEL LOCK (Task 9). While the Loupe is up the wheel belongs to the lens — the
        // approved rule is that the Loupe "never changes ... reading position", and a notch that
        // magnified the glass AND scrolled the column underneath would break it in the most visible
        // way there is. The lens's own tracker already swallows the wheel over the comic; this is
        // the structural half, so the rule does not rest on which item Qt happened to deliver the
        // event to. It is the ONE wheel intake door, so there is nothing else to gate: keyboard
        // glides come through smoothScrollBy (and the keyboard is gated by `modalOpen` anyway), and
        // the shell's own restores come through haltScrollAt/seekToPage.
        if (wheelLocked) return
        var dy = pixelY
        if (dy === 0) dy = angleY * 1.4
        if (dy === 0) return
        // WHEEL-ONLY provenance, fired before the shared glide call below: manualNavigation() means
        // "a real mouse gesture happened", which a keyboard glide must never forge.
        _userInteracted = true
        manualNavigation()
        smoothScrollBy(-dy)                                 // wheel-down -> +contentY
    }

    // Glide by px through the SAME accumulator the wheel uses, so a keyboard press feels like one
    // big notch rather than a teleport.
    //
    // WHY THIS IS SHARED (E2). A raw `contentY = ...` write bypasses both the glide and the backlog.
    // Press Space in the middle of a wheel glide and the old code jumped you instantly AND THEN kept
    // sliding on the leftover wheel input still in the drain — jump-then-slide, the exact tell of two
    // scroll systems fighting. Reader 1 routes keys through smoothScrollBy and pins instant moves
    // through haltScrollAt; this restores that discipline. Instant, final repositions (a scrub seek,
    // Home/End) still go through haltScrollAt, which pins the position AND drops the in-flight
    // backlog so nothing carries across the jump.
    function smoothScrollBy(px) {
        if (px === 0) return
        // Starting from idle: re-anchor on the real position and mark this drain FRESH.
        if (!scrollDrain.running) { _smoothY = list.contentY; _drainFresh = true }
        _pendingWheelPx = Math.max(-_maxBacklogPx, Math.min(_maxBacklogPx, _pendingWheelPx + px))
        if (!scrollDrain.running) scrollDrain.running = true
    }

    // ================= touch drag + fling (phone / tablet) =================
    // The strip follows the finger 1:1, then Flickable's own fling carries it: that deceleration is
    // the one every touch list in Qt has, and the wheel drain (38% a frame) is far too abrupt to
    // pass for it. `interactive` stays false — an interactive Flickable takes the press itself, and
    // the click zones beneath the pages would go dead.
    readonly property bool flinging: list.flicking
    function touchDragBy(dy) {
        if (wheelLocked || dy === 0) return
        scrollDrain.running = false          // a finger outranks a glide still in flight
        _pendingWheelPx = 0
        list.cancelFlick()
        _userInteracted = true
        manualNavigation()
        var maxY = Math.max(0, list.contentHeight - list.height)
        list.contentY = Math.max(0, Math.min(maxY, list.contentY + dy))
    }
    // velocity: the finger's at release, px/s, + = moving down the screen (content toward the top).
    function touchFling(velocity) { if (!wheelLocked) list.flick(0, velocity) }
    function touchHold() { list.cancelFlick() }

    // Drain 38% of the remaining backlog per frame — but scaled by how much time ACTUALLY passed, so
    // the same glide feels identical at 60Hz, 120Hz or through a frame hitch. A fixed 38%-per-tick
    // silently becomes a different curve on every other refresh rate.
    function _drainWheel() {
        if (Math.abs(_pendingWheelPx) < 0.75) {
            _pendingWheelPx = 0
            scrollDrain.running = false
            return
        }
        // re-anchor if something else moved the view (a drag, a resume, a seek)
        if (Math.abs(list.contentY - _smoothY) > 1.5) _smoothY = list.contentY

        var frames = Math.min(3, Math.max(0.25, scrollDrain.frameTime * 60))
        // COLD-START (measured 2026-07-17, agents/wheel_latency_harness.qml): the first tick after
        // idle reports a ~3ms frameTime, so the 0.25 floor drained only 11% — about 19px, below the
        // threshold you can see. Every fresh scroll began with a dead beat. The first tick always
        // drains the full fraction. [[reference_frameanimation_cold_first_tick_underdrains]]
        if (_drainFresh) { frames = Math.max(1, frames); _drainFresh = false }

        var take = _pendingWheelPx * (1 - Math.pow(1 - _drainFraction, frames))
        if (Math.abs(_pendingWheelPx) <= 1) take = _pendingWheelPx    // final settle
        var maxY = Math.max(0, list.contentHeight - list.height)
        var y = _smoothY + take
        if (y <= 0 || y >= maxY) {          // ran into an edge: clamp and drop the backlog
            y = Math.max(0, Math.min(maxY, y))
            _pendingWheelPx = 0
        } else {
            _pendingWheelPx -= take
        }
        _smoothY = y
        // Assign the FLOAT, never Math.round(): rounding quantises every step to whole pixels, which
        // is exactly what "harsh" feels like at the slow end of a glide, where the true step is a
        // fraction of a pixel per frame and rounding turns it into stand-still-then-jump.
        _draining = true
        list.contentY = y
        _draining = false
        if (_pendingWheelPx === 0) scrollDrain.running = false
    }

    // ================= AUTO-SCROLL drive (Task 8) =================
    // A SECOND FrameAnimation, deliberately not the wheel drain. They are different machines: the
    // drain empties a backlog and stops, auto-scroll travels at a constant rate until something
    // stops it. Folding auto-scroll into the drain would mean continuously refilling _pendingWheelPx
    // to keep it alive, which would also make every wheel notch fight the motion inside one
    // accumulator. Two drives, one rule between them: manual input pauses auto-scroll BEFORE it
    // applies its own movement (see _intakeWheel), so they are never both writing contentY.
    //
    // `active` is in the running condition because both reading surfaces are mounted at once: a
    // HIDDEN strip must not keep scrolling a column nobody is looking at.
    property bool _autoScrollFresh: false
    FrameAnimation {
        id: autoScrollDrive
        running: root.autoScrollRunning && root.active
        onRunningChanged: if (running) root._autoScrollFresh = true
        onTriggered: root._autoScrollTick(autoScrollDrive.frameTime * 1000)
    }

    // ONE tick of motion, in milliseconds. Named and public so the gate can drive it deterministically
    // — an offscreen harness never ticks a FrameAnimation, and a test that slept for real frames
    // would be a flake.
    //
    // IT WRITES contentY AND NOTHING ELSE. No width, no gap, no layout call: that is the
    // never-resize rule made structural rather than guarded.
    function _autoScrollTick(ms) {
        if (list.count <= 0) return
        var dt = Number(ms)
        if (!isFinite(dt) || dt <= 0) return
        // COLD FIRST TICK. FrameAnimation reports a ~3ms frameTime on the tick right after it
        // starts (measured 2026-07-17, agents/wheel_latency_harness.qml) — the same trap the wheel
        // drain documents a few hundred lines above, fixed once already in c307ccb. Left alone the
        // first step is a fifth of a frame's travel, which reads as the page hesitating before it
        // moves. The first tick is worth a whole frame.
        // [[reference_frameanimation_cold_first_tick_underdrains]]
        if (_autoScrollFresh) { dt = Math.max(dt, 1000 / 60); _autoScrollFresh = false }
        // ...and the opposite guard: a stalled frame (a decode burst, a window drag) must not
        // teleport the page half a chapter down when the clock resumes.
        dt = Math.min(dt, 100)

        var maxY = Math.max(0, list.contentHeight - list.height)
        if (maxY <= 0) { root.autoScrollEnded(); return }   // nothing to travel: stop, don't spin

        var y = list.contentY + autoScrollPixelsPerSecond * dt / 1000
        var hitEnd = y >= maxY
        if (hitEnd) y = maxY

        // NOT _programmatic, and that is deliberate: auto-scroll is REAL READING. Suppressing the
        // tracking pair here would leave the HUD counter and the Continue record sitting on the
        // page you started from while the book moved underneath them.
        list.contentY = y
        _smoothY = y
        if (hitEnd) root.autoScrollEnded()                  // the end of the book stops the motion
    }

    // Land page `page0` (0-based) at the top of the viewport. The top comes from the BACKEND, not
    // from a delegate: the ListView only realizes delegates near the viewport, so a page you are
    // switching TO has no y to read yet — which is exactly why an immediate seek lands at 0.
    function seekToPage(page0) {
        if (!core || !core.stripPageTop) return false
        var span = list.contentHeight - list.height
        if (span <= 0) return false            // not laid out yet, or the whole book fits
        haltScrollAt(Math.max(0, Math.min(span, core.stripPageTop(page0))))
        return true
    }

    // ...and the same seek, but landing on a POINT INSIDE that page (Task 11). This is the exact
    // inverse of what _emitPresented reports: it measures `(viewportCentre - pageTop) / pageHeight`,
    // so putting the reader back means putting that same point back under the viewport centre.
    //
    // WHY IT IS A SECOND FUNCTION rather than an optional argument on seekToPage: the two have
    // genuinely different meanings at the boundary. seekToPage(n) means "start of page n" and lands
    // its TOP at the viewport top; a fraction of 0 means "the viewport centre was at the page's top
    // edge", which is half a screen higher. Folding them would make seekToPage(n) and
    // seekToPageFraction(n, 0) silently disagree, and the one place that matters is the resume of a
    // record written before pageFraction existed — where "no opinion" must mean the old behaviour,
    // not a half-screen drift.
    //
    // Falls back to the plain page seek when the backend cannot answer the height (a partial core,
    // an out-of-range page): landing on the page is far better than not landing at all.
    function seekToPageFraction(page0, frac) {
        if (!core || !core.stripPageTop) return false
        var span = list.contentHeight - list.height
        if (span <= 0) return false            // not laid out yet, or the whole book fits
        var h = (core.stripPageHeight) ? core.stripPageHeight(page0) : 0
        if (!(h > 0)) return seekToPage(page0)
        var f = Math.max(0, Math.min(1, Number(frac) || 0))
        var y = core.stripPageTop(page0) + f * h - list.height / 2
        haltScrollAt(Math.max(0, Math.min(span, y)))
        return true
    }

    // Stop any glide and pin the view at y — every instant reposition goes through here, so a seek
    // can never be fought by a drain that is still carrying old backlog.
    function haltScrollAt(y) {
        scrollDrain.running = false
        _pendingWheelPx = 0
        _smoothY = y
        _programmatic = true
        list.contentY = y
        _programmatic = false
        // The reader is now looking at wherever this put them, so report it — presented() only, never
        // the tracking pair (see _emitPresented). Deferred through Qt.callLater so it lands after the
        // caller's own bindings settle; callLater collapses repeats within one pass (measured), so a
        // seekToPage — which comes through here — reports once, not twice.
        Qt.callLater(root._emitPresented)
    }

    WheelHandler {
        enabled: !root.wheelLocked
        acceptedDevices: PointerDevice.Mouse | PointerDevice.TouchPad
        onWheel: function (event) { root._intakeWheel(event.angleDelta.y, event.pixelDelta.y) }
    }

    // ================= user-scroll reporting =================
    // NOTE: the surface no longer restores anything itself. Resume is a one-shot COMMAND from the
    // shell (seekToPage / haltScrollAt above), never a bound `resumeFraction` the surface re-applies:
    // the shell's fraction is written BY this surface's own onScrolled, so a binding the surface acts
    // on is a scroll -> fraction -> apply -> scroll loop, and the latch that used to break the loop
    // was per-object-lifetime — the reader is a persistent child, so the second book never resumed.
    // "successfully rendered" for the activity centre check — reads the REALIZED delegate
    // directly (list.itemAtIndex), mirroring _emitPresented's own "ask the backend/drawn
    // column, not a re-derivation" discipline; an unrealized row (outside the viewport)
    // answers false rather than guessing.
    function _activityPageRendered(idx0) {
        var it = list.itemAtIndex(idx0)
        return !!(it && it.pixelsShown)
    }
    // Called ONLY from _emitUserScroll below (the user-driven scroll report) — never from
    // haltScrollAt/onActiveChanged's direct _emitPresented() calls, which are exactly the
    // programmatic-resume/layout-compensation/mount-time paths §9 Lane C excludes ("Programmatic
    // resume/layout compensation -> no activity fact"). Dedupes on the LAST page the centre
    // genuinely entered, so sitting still or an edge peek that never reaches the centre never
    // re-fires — the "avoid obviously duplicate spam" surface-level politeness CPP-PORT-
    // CONTRACT.md §9 Lane C asks for; correctness against a genuine same-session bounce back
    // onto an already-read page is the projector's sessionId+kind+itemKey+pageKey dedupe (§10),
    // not this check, so a real bounce is allowed to reach the ledger again.
    function _noteActivityCentre(idx0) {
        if (idx0 === root._activityLastCentrePage) return
        if (!root._activityPageRendered(idx0)) return
        root._activityLastCentrePage = idx0
        root.activityPagesPresented([idx0])
    }
    function _emitUserScroll() {
        if (list.count <= 0) return
        var span = list.contentHeight - list.height
        var frac = span > 0 ? (list.contentY / span) : 0
        root.scrolled(Math.max(0, Math.min(1, frac)))
        var centreY = list.contentY + list.height / 2
        var idx = list.indexAt(list.width / 2, centreY)
        if (idx >= 0) {
            root.pageInView(idx + 1)               // 1-based (shell currentPage scale)
            root._noteActivityCentre(idx)
        }
        _emitPresented()
        var lo = list.indexAt(list.width / 2, list.contentY + 1)
        var hi = list.indexAt(list.width / 2, list.contentY + list.height - 1)
        if (lo >= 0 && hi >= 0) {
            var arr = []
            for (var i = lo; i <= hi; i++) arr.push(i)
            root.visiblePages(arr)
        }
    }
}
