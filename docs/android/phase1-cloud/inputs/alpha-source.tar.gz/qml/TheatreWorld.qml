// TheatreWorld - Colosseum's Theatre catalog shell.
// Owner: A4. Persistent top: Featured, Continue Watching, then Harbor-shaped pages
// under three tabs: Movies, Shows, Anime.

import QtQuick
import "Catalog.js" as Catalog
import "TheatreApi.js" as TheatreApi
import "Torrentio.js" as Torrentio
import "AddonClient.js" as AddonClient
import "EpisodeBrowser.js" as EpisodeBrowser
import "NextUp.js" as NextUp
import "LibraryApi.js" as LibraryApi
import "CatalogueRecents.js" as CatalogueRecents

WorldPage {
    id: theatre
    Theme { id:theme }
    dockContentLeft: discoverPage.visible ? discoverPage.contentLeft
                     : theatreCatalog.visible ? theatreCatalog.contentLeft : 0
    objectName: "theatreWorld"
    medium: "Theatre"
    tabBarSource: theatreTabBar          // docks under the TopBar when scrolled past (WorldPage)

    // Theatre carries the full tile object (Cinemeta id + type) up to Main for detail routing.
    signal theatreItemRequested(var item)
    signal theatreGenreRequested(string kind, string name)
    signal theatreGenreIndexRequested(string kind)
    // Bubbles a tap on a Your Collection tile up to Main's openCollectionEntry door.
    signal collectionOpenRequested(var entry)
    // Library tab (Stage 2) — the ⋮ menu's Resume / Mark-watched bubble up to Main's handlers.
    signal libraryResumeRequested(var entry)
    signal libraryMarkWatchedRequested(var entry, bool watched)
    signal libraryRemovalRequested(var entry)
    // Next Up direct play — the exact TheatreSeries.playRequested shape, wired in Main
    // to the same openMovieSession door (spec 2026-07-18, Jellyfin library inheritance).
    signal playRequested(string infoHash, int fileIdx, string title, string backdropUrl, string subType, string subId, var streamCandidates, var playbackContext)

    property var featuredRows: Catalog.theatreFeatured
    // Real "Continue Watching" from the Progress store (what you actually started).
    property int progressRevision: Progress.revision
    // §9: local (vault:) rows keep to the Vault Continue rail — strip them here before the cap.
    // Retained hidden worlds must not query Progress while their Loader is warming. The binding
    // rehydrates the same row when lifecycleActive becomes true; the activation handler also
    // refreshes it after the world has settled.
    property var continueRows: theatre.lifecycleActive
                                 ? CatalogueRecents.recent(Progress, "video", 12) : []
    property var movieRows: Catalog.theatreTopMovies
    property var seriesRows: Catalog.theatreTopSeries
    property var animeRows: []
    property string activeTab: "discover"

    // Deep-catalogue See-all: a non-null pin overlays TheatreSeeAllPage above the whole world.
    property var seeAllPin: null
    // the one global content preference (Main binds it in Task 9); null-safe until then.
    property var contentPreferences: null
    // Retained worlds pause their catalogue/Next Up warmers while hidden. The first activation
    // runs the existing setup exactly once, preserving the page instance and its state.
    property bool _contentInitialized: false

    onProgressRevisionChanged: {
        if (!theatre.lifecycleActive) return
        continueRows = CatalogueRecents.recent(Progress, "video", 12)
        recomputeNextUp()
    }

    // ---- Next Up (spec 2026-07-18): "you finished the last episode — here's the next".
    // A show cards ONLY when its latest episode entry is finished (the 0.90 line);
    // otherwise it lives in Continue. Meta is fetched ONCE per show per app session
    // (the same TheatreApi call the series page makes) and cached here.
    property var nextUpRows: []
    property var _nextUpMeta: ({})      // show root -> meta (videos carrier)
    property var _nextUpPending: ({})   // show root -> true while a fetch is in flight

    function recomputeNextUp() {
        var fin = NextUp.finishedShows(CatalogueRecents.recent(Progress, "video", 48)).slice(0, 8)
        var out = []
        for (var i = 0; i < fin.length; i++) {
            var rec = fin[i]
            var meta = theatre._nextUpMeta[rec.show]
            if (meta === undefined) {
                theatre.fetchNextUpMeta(rec.show)
                continue
            }
            if (!meta || !meta.videos || !meta.videos.length)
                continue                        // meta came back empty — no honest card
            var next = NextUp.nextEpisodeFromMeta(meta.videos, rec.entry.id)
            if (next)
                out.push(NextUp.theatreCard(rec, next, meta))
        }
        theatre.nextUpRows = out
    }

    function fetchNextUpMeta(show) {
        if (theatre._nextUpPending[show]) return
        theatre._nextUpPending[show] = true
        TheatreApi.loadMeta("series", show, function(meta) {
            theatre._nextUpMeta[show] = meta || null   // null caches the miss — never refetch-loop
            if (theatre.lifecycleActive) theatre.recomputeNextUp()
        })
    }

    // The circle on a Next Up card: resolve the fresh episode's sources and walk in the
    // series page's own door (playRequested → openMovieSession) with a full episode
    // queue, so prev/next and the drawer work from the first frame. No sources → the
    // series page (honest fallback, never a dead spinner).
    function playNextUp(item) {
        var showId = item.resume.showId
        var detail = { "id": showId, "type": "series", "title": item.title, "cover": item.cover }
        var onRows = function(rows) {
            if (!rows || !rows.length) { theatre.theatreItemRequested(detail); return }
            var meta = theatre._nextUpMeta[showId]
            var ctx = (meta && meta.videos)
                      ? EpisodeBrowser.queueContextFromMeta(meta.videos, item.id, item.title,
                                                            item.cover, meta.year || "")
                      : null
            var epTitle = item.title + " - S" + item.resume.season + "E" + item.resume.episode
            theatre.playRequested(rows[0].infoHash || "", rows[0].fileIdx || 0, epTitle,
                                  item.cover || "", "series", item.id, rows, ctx || ({}))
        }
        // Same source ladder as the player and the picker. This path used to call
        // Torrentio.js directly with no idea the store existed, so removing Torrentio
        // did nothing here and any well ranked above it was ignored. No source at all
        // falls through to onRows([]) — the series page, its own honest fallback.
        // (2026-07-25, A5 — Torrentio-honesty fix.)
        var installed = (typeof Extensions !== "undefined") ? Extensions.installed() : []
        var exts = AddonClient.streamExtensions(installed, "series", item.id)
        var lastResort = function() {
            if (AddonClient.torrentioEnabled(installed))
                Torrentio.loadStreams("series", item.id, onRows)
            else
                onRows([])
        }
        if (exts.length) {
            AddonClient.loadStreams(exts, "series", item.id, function() {}, function(rows) {
                if (rows && rows.length) onRows(rows)
                else lastResort()
            }, (typeof PlatformRuntime !== "undefined" ? PlatformRuntime : null))
        } else {
            lastResort()
        }
    }

    function idFromArt(item) {
        var fields = [item.cover || "", item.art || ""]
        for (var i = 0; i < fields.length; i++) {
            var m = String(fields[i]).match(/\/(tt\d+)\/img/)
            if (m && m[1])
                return m[1]
        }
        return ""
    }

    function itemWithIdentity(item, fallbackType) {
        var out = {}
        for (var k in item)
            out[k] = item[k]
        if (!out.id)
            out.id = idFromArt(item)
        if (!out.type)
            out.type = fallbackType
        return out
    }

    function activateContent() {
        if (theatre._contentInitialized) return
        theatre._contentInitialized = true
        recomputeNextUp()
        loadCatalog()
        // Refresh the Library's new-episode + airing stamps for saved series (spec §4.5).
        // Cheap: skips fresh-stamped (<6h) series and does zero network on an empty shelf.
        LibraryApi.refreshStamps(Collection.items("theatre"), TheatreApi.loadMeta,
            CatalogueRecents.recent(Progress, "video", 0),
            function(id) { return Progress.watchedMark(id) },
            function(id) { Progress.forget("video", id) },
            function(id, on) { Progress.setWatchedMark(id, on) },
            function(e) { Collection.add("theatre", e) },
            Date.now(), function() {})
    }
    Component.onCompleted: if (theatre.lifecycleActive) theatre.activateContent()
    onLifecycleActiveChanged: {
        if (!theatre.lifecycleActive) return
        theatre.continueRows = CatalogueRecents.recent(Progress, "video", 12)
        theatre.activateContent()
        theatre.recomputeNextUp()
    }
    function loadCatalog() { TheatreApi.loadTheatre(function(rows) {
        if (rows.movies.length > 0)
            theatre.movieRows = rows.movies
        if (rows.series.length > 0)
            theatre.seriesRows = rows.series
        if (rows.anime.length > 0)
            theatre.animeRows = rows.anime
        if (rows.featured.length > 0)
            theatre.featuredRows = rows.featured
    }) }

    FeaturedCarousel {
        kicker: "Featured in Theatre"
        primaryLabel: "Watch"
        secondaryLabel: "Details"
        slides: theatre.featuredRows
        // Watch + Details both open the detail page for now (Watch goes straight to play once the
        // player hook lands). Type comes from the slide's ghost marker ("S" = series, else movie).
        onPrimaryClicked: (index) => theatre.theatreItemRequested(
            theatre.itemWithIdentity(theatre.featuredRows[index], theatre.featuredRows[index].ghost === "S" ? "series" : "movie"))
        onSecondaryClicked: (index) => theatre.theatreItemRequested(
            theatre.itemWithIdentity(theatre.featuredRows[index], theatre.featuredRows[index].ghost === "S" ? "series" : "movie"))
    }

    // Next Up sits ABOVE Continue (Jellyfin's order — freshest intent first). Cards are
    // fresh episodes (no progress bar); the circle plays, elsewhere opens the series.
    ContinueRow {
        title: "Next Up"
        items: theatre.nextUpRows
        onResumeRequested: (item) => theatre.playNextUp(item)
        onDetailRequested: (item) => theatre.theatreItemRequested(
            { "id": item.resume.showId, "type": "series", "title": item.title, "cover": item.cover })
        onSeeAllRequested: theatre.continueSeeAllRequested()
    }

    ContinueRow {
        title: "Continue Watching"
        items: theatre.continueRows
        onResumeRequested: (item) => theatre.continueResumeRequested(item)
        onDetailRequested: (item) => theatre.continueDetailRequested(item)
        onSeeAllRequested: theatre.continueSeeAllRequested()
    }

    TheatreTabBar {
        id: theatreTabBar
        backdrop: theatre.backdrop
        track: theatre.viewportContentY
        currentTab: theatre.activeTab
        onTabRequested: (tab) => theatre.activeTab = tab
    }

    DiscoverPage {
        id: discoverPage
        objectName: "theatreDiscoverPage"
        visible: theatre.activeTab === "discover"
        width: parent.width
        pageFlick: theatre.pageFlickable
        backdrop: theatre.backdrop
        height: visible ? discoverPage.flowHeight : 0
        active: theatre.lifecycleActive && visible
        // Task 9: inherit the global Explicit Content preference (Main.qml binds it on this world).
        showExplicitContent: theatre.showExplicitContent
        onItemOpenRequested: (item) => theatre.theatreItemRequested(
            theatre.itemWithIdentity(item, item.type === "movie" ? "movie" : "series"))
    }

    TheatreCatalogPage {
        id: theatreCatalog
        objectName: "theatreCatalogPage"
        visible: theatre.activeTab === "movies" || theatre.activeTab === "shows" || theatre.activeTab === "anime"
        height: visible ? implicitHeight : 0
        active: theatre.lifecycleActive && visible
        pageKey: (theatre.activeTab === "movies" || theatre.activeTab === "shows" || theatre.activeTab === "anime")
                 ? theatre.activeTab : "movies"
        contentPreferences: theatre.contentPreferences
        pageFlick: theatre.pageFlickable
        backdrop: theatre.backdrop
        parkRowHandler: function(target) { theatre.parkRow(target) }
        malCatalog: (typeof MalCatalog !== "undefined") ? MalCatalog : null
        imdbCatalog: (typeof ImdbCatalog !== "undefined") ? ImdbCatalog : null
        // Theatre is the gallery pilot; the viewport (converted from board coords to this page's
        // local frame) drives lazy shelf residency. WorldPage stays the only vertical scroller.
        visualProfile: "gallery"
        viewportTop: Math.max(0, theatre.viewportContentY - y)
        viewportHeight: theatre.viewportHeight
        onItemRequested: (item) => theatre.theatreItemRequested(
            theatre.itemWithIdentity(item, item.type === "movie" ? "movie" : "series"))
        onGenreRequested: (kind, name) => theatre.theatreGenreRequested(kind, name)
        onGenreIndexRequested: (kind) => theatre.theatreGenreIndexRequested(kind)
        onSeeAllRequested: (pin) => theatre.seeAllPin = pin
    }

    // Library — the fifth tab (Stage 2). The saved shelf, life-marked, with the ⋮ menu.
    LibraryPage {
        id: libraryPage
        removeSelectionEntry: function(entry) {
            return typeof StremioActions !== "undefined" && StremioActions
                ? StremioActions.removeTheatreItem(String(entry.id), String(entry.type || "movie"), false) : false
        }
        visible: theatre.activeTab === "library"
        active: theatre.lifecycleActive && visible
        width: parent.width
        pageFlick: theatre.pageFlickable
        height: visible ? libraryPage.flowHeight : 0
        onResumeRequested: (e) => theatre.libraryResumeRequested(e)
        onDetailRequested: (e) => theatre.collectionOpenRequested(e)
        onDismissRequested: (e) => { if (typeof Progress !== "undefined") Progress.forget("video", String(e.id)) }
        onMarkWatchedRequested: (e, w) => theatre.libraryMarkWatchedRequested(e, w)
        onRemoveRequested: (e) => theatre.libraryRemovalRequested(e)
    }

    // ── See-all overlay: parented to the world root (NOT the scrolling board) so it floats
    //    over the whole tab. A non-null pin shows it; Back clears the pin and the world's own
    //    scroll position is preserved because the board never moved underneath. ──
    Item {
        id: seeAllOverlay
        parent: theatre
        // explicit geometry (not anchors) — the reparent to `theatre` races the default-property
        // parenting to the scrolling board, and anchors reject a non-parent/sibling target.
        x: 0; y: 0
        width: theatre.width
        height: theatre.height
        z: 300
        visible: theatre.seeAllPin !== null
        Rectangle { anchors.fill: parent; color: "#0b0d12" }   // opaque backing, matches the shell
        MouseArea { anchors.fill: parent }                     // swallow clicks to the world beneath

        TheatreSeeAllPage {
            anchors.fill: parent
            anchors.topMargin: 30
            anchors.leftMargin: theme.margin
            anchors.rightMargin: theme.margin
            anchors.bottomMargin: 12
            pin: theatre.seeAllPin
            malCatalog: (typeof MalCatalog !== "undefined") ? MalCatalog : null
            imdbCatalog: (typeof ImdbCatalog !== "undefined") ? ImdbCatalog : null
            showExplicit: theatre.contentPreferences ? theatre.contentPreferences.showExplicit : false
            onBackRequested: theatre.seeAllPin = null
            onItemRequested: (item) => theatre.theatreItemRequested(
                theatre.itemWithIdentity(item, item.type === "movie" ? "movie" : "series"))
        }
    }
}
