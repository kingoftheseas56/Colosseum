.pragma library

// Pure shell-level Escape arbitration. This file selects WHO owns one Escape press;
// the owning surface still decides WHAT its semantic back/escape operation does.
// No QObject or Loader mutation belongs here, which keeps the state matrix deterministic
// and lets tests prove precedence without booting the full application shell.
function on(value) { return value === true }

function actionFor(state) {
    var s = state || ({})

    // Covers that must never let an Escape leak into hidden application state.
    if (on(s.transitioning) || on(s.bootVisible) || on(s.accountHostVisible))
        return "consume"

    // A keyboard dismissal must not also close the page or its pending route.
    if (on(s.androidHost) && on(s.keyboardVisible)) return "dismissKeyboard"

    // Same-window modal/transient surfaces, highest visual/interaction ownership first.
    if (on(s.identityCeremonyOpen)) return "cancelIdentityCeremony"
    if (on(s.theatreRemovalOpen)) return "theatreRemoval"
    // Main Sync sits above taskbar pages, but an identity ceremony may cover it.
    if (on(s.stremioSyncOpen)) return "stremioSync"
    if (on(s.watchPartyJoinOpen)) return "watchPartyJoin"
    if (on(s.wallpaperActive)) return "wallpaper"
    if (on(s.accountFlyoutVisible)) return "accountFlyout"
    if (on(s.accountCenterVisible)) return "accountCenter"
    if (on(s.openRecentOpen)) return "openRecent"
    if (on(s.taskbarOpen)) return "taskbar"

    // A session surface owns Escape before pages that may still be instantiated beneath it.
    // activeSessionKind also heals the audited zombie state where a raw shell close hid the
    // surface without clearing Sessions.activeId.
    if (on(s.playerOpen) || s.activeSessionKind === "movie") return "player"
    if (on(s.bookReaderActive) || s.activeSessionKind === "book") return "bookReader"
    if (on(s.vaultComicActive) || on(s.comicReaderActive) || s.activeSessionKind === "comic")
        return "comicReader"

    if (on(s.librarySelectionActive)) return "librarySelection"

    // Taskbar full pages occupy the upper shell layers. Later document siblings win if a
    // broken caller ever leaves two active at once, so recovery remains deterministic.
    if (on(s.updateActive)) return "update"
    if (on(s.yourFeriaActive)) return "yourFeria"
    if (on(s.historyStatsActive)) return "historyStats"
    if (on(s.syncCenterActive)) return "syncCenter"
    if (on(s.extensionsActive)) return "extensions"
    if (on(s.feriaActive)) return "feria"
    if (on(s.vaultActive)) return "vault"
    if (on(s.downloadsActive)) return "downloads"
    // Android shell: the Profile list lies over the detail pages and under its own pages.
    if (on(s.profileActive)) return "profile"

    // Detail/browse layers follow their existing z-order and document order.
    if (on(s.bookActive)) return "book"
    if (on(s.theatreSeriesActive)) return "theatreSeries"
    if (on(s.westernActive)) return "western"
    if (on(s.seriesActive)) return "series"
    if (on(s.onePieceArcActive)) return "onePieceArc"
    if (on(s.onePieceAtlasTransientOpen)) return "onePieceAtlasTransient"
    if (on(s.universeActive)) return "universe"
    if (on(s.searchActive)) return "search"
    if (on(s.worldSearchActive)) return "worldSearch"
    if (on(s.comicSeriesActive)) return "comicSeries"
    if (on(s.locgPublisherActive)) return "locgPublisher"
    if (on(s.comicIndexActive)) return "comicIndex"
    if (on(s.comicBoardActive)) return "comicBoard"
    if (on(s.continueSeeAllActive)) return "continueSeeAll"
    if (on(s.theatreGenreActive)) return "theatreGenre"
    if (on(s.theatreGenreIndexActive)) return "theatreGenreIndex"
    if (on(s.biblioGenreActive)) return "biblioGenre"
    if (on(s.biblioGenreIndexActive)) return "biblioGenreIndex"
    if (on(s.genreActive)) return "genre"
    if (on(s.genreIndexActive)) return "genreIndex"

    // Android has no desktop Home. Preserve the current world when leaving the
    // foreground, after every keyboard, transient, session and page owner.
    if (on(s.androidHost)) return "backgroundApplication"
    if (on(s.worldOpen)) return "world"
    // Back never quits (world-feel Slice 6): on Home it returns to the top of Home and stops.
    // Quitting is Ctrl+Q or the Quit control, never a Back press.
    return "homeTop"
}


