// Colosseum native launcher. Normal launches require the live qml/ tree to match the
// fingerprint emitted by the native build; explicit dev QML overrides remain opt-in.

#include <QDir>
#include <QGuiApplication>
#include <QHash>
#include <QHostAddress>
#include <QIcon>
#include <QImageReader>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <QNetworkAccessManager>
#include <QNetworkDiskCache>
#include <QNetworkProxy>
#include <QNetworkReply>
#include <QNetworkRequest>
#include <QMetaObject>
#include <QPointer>
#include <QQmlApplicationEngine>
#include <QQmlNetworkAccessManagerFactory>
#if !defined(Q_OS_ANDROID)
#include <QtWebEngineQuick/QtWebEngineQuick>
#endif
#include <QQmlContext>
#include <QQuickItem>
#include <QQuickWindow>
#include <qqml.h>
#include <QStandardPaths>
#include <QString>
#include <QStringList>
#include <QUrl>
#include <QDebug>
#include <QDirIterator>
#include <QFile>
#include <QFileInfo>
#include <QFileSystemWatcher>
#include <QThread>
#include <QTimer>

#include <cstdio>
#include <cstring>
#include <memory>
#include <functional>

#include "ClipboardHelper.h"
#include "MangaEngine.h"
#include "ProgressStore.h"
#include "CollectionStore.h"
#include "SearchHistoryStore.h"
#include "SessionStore.h"
#include "AudioPairingStore.h"
#include "account/AccountRuntime.h"
#include "account/ActivityPlaybackTracker.h"
#include "account/RatingsReviewsController.h"
#include "account/RatingsReviewsDelivery.h"
#include "account/ProfilePreferencesStore.h"
#if !defined(Q_OS_ANDROID)
#include "update/UpdateCache.h"
#include "update/UpdateDownload.h"
#include "update/UpdateInstallBridge.h"
#include "update/UpdateReleaseClient.h"
#include "update/UpdateService.h"
#include "update/UpdateTrust.h"
#endif
#include "update/UpdateUserAgent.h"
#include "bootstrap/ApplicationShutdown.h"
#include "work/BackgroundActivityRegistry.h"
#include "work/BackgroundWorkCoordinator.h"
#include "work/ForegroundPriorityGovernor.h"
#include "platform/BackgroundDownloadBridge.h"
#include "platform/PlatformRuntime.h"
#include "third_party/miniz/miniz.h"  // gunzip for the Jikan Accept-Encoding workaround
#include "engine/MangaDownloader.h"
#include "devtools/LanistaServer.h"
#include "engine/BookDownloader.h"
#include "engine/AudiobookDownloader.h"
#include "engine/ComicDownloader.h"
#include "engine/CatalogVaultClient.h"
#include "engine/SourceContentStore.h"
#include "engine/ComicsCatalog.h"
#include "engine/MalCatalog.h"
#include "engine/TankobanCatalog.h"
#include "engine/ImdbCatalog.h"
#include "engine/BiblioCatalog.h"
#include "engine/ColosseumTitleIdentityRegistry.h"
#include "engine/RatingsReviewsProviderReadProjection.h"
#include "engine/LocalDownloads.h"
#include "engine/AppLog.h"
#include "bootstrap/AppDataMigration.h"
#include "bootstrap/InstanceLock.h"
#include "bootstrap/StartupLayout.h"
#include "bootstrap/QmlModuleGuards.h"
#include "engine/ExtensionsStore.h"
#include "engine/MangaTankobanService.h"
#if !defined(Q_OS_ANDROID)
#include "engine/LocalLaunch.h"
#include "engine/VaultPageStore.h"
#include "engine/VaultIndex.h"
#include "engine/VaultConfig.h"
#include "engine/VaultIdentity.h"
#include "engine/VaultScanner.h"
#include "engine/VaultLibrary.h"
#include "engine/VaultIdentifier.h"
#include "engine/VaultDownloadsRoot.h"
#include "engine/VaultEnricher.h"
#include "engine/VaultForensics.h"
#endif
#if !defined(Q_OS_ANDROID)
#include "player/MediaAdmissionProbe.h"
#endif
#include "net/LoopbackPinProxy.h"
#include "net/Ipv4PinStore.h"
#include "net/PinProxyFactory.h"
#include "net/CachingNam.h"
#include "net/CoverDelivery.h"
#include "net/PosterScoreboard.h"
#include "net/PosterTimingProbe.h"
#include "FrameTimingProbe.h"
#include "net/BiblioImageDiag.h"
#include <QNetworkProxyFactory>
#include <QSet>
#include <QtConcurrent>
#include <QFutureWatcher>
#include <algorithm>
#include <memory>
#include "anime/AnimeOrderService.h"
#include "reader2/Reader2Bridge.h"
#include "comicreader/ComicReaderCore.h"
#include "comicreader/ComicReaderProvider.h"
#include "engine/ComicCoverProvider.h"
#if !defined(Q_OS_ANDROID)
#include "engine/VaultBookCoverProvider.h"
#endif
#include "player/caststore.h"
#include "player/downloadstore.h"
#include "player/livestore.h"
#if defined(Q_OS_ANDROID)
#include "platform/android/AndroidBootstrap.h"
#else
#include "player/mpvitem.h"
#include "player/seekthumbnailer.h"
#include "player/windowmodestore.h"
#endif
#include "player/powerstore.h"
#include "player/roomstore.h"
#include "watchparty/WatchPartyPlayerSync.h"
#include "watchparty/WatchPartySource.h"
#include "watchparty/WatchPartyServiceEndpoint.h"
#include "watchparty/WatchPartyUiController.h"
#include "player/streamserver.h"
#include "torrent/TankorentSearchService.h"
#include "torrent/BookTorrentDownloader.h"
#include "torrent/BookTorrents.h"
#include "torrent/engine/TorrentEngine.h"
// NOT Player-2 stuff: the stall probe is the app's own QGuiApplication subclass, used
// unconditionally in main(). It sat inside the COLOSSEUM_PLAYER2 block below for weeks and
// compiled only because P2 was always linked — the first stock (P2-off) build broke on it.
#include "ScrollProbe.h"     // diagnostic wheel-input probe (env-gated; see header)
#if !defined(Q_OS_ANDROID)
#include "vinyl/VinylTorrentProvider.h"
#include "feria/PorticoComposition.h"
#include "feria/FeriaBrowserPolicy.h"
#include "feria/FeriaBrowserRuntime.h"
#include "feria/FeriaAccountStore.h"
#include "vinyl/VinylProvider.h"
#include "vinyl/VinylCatalogueSource.h"
#include "vinyl/VinylLocalSource.h"
#include "vinyl/VinylBackendSession.h"
#include "vinyl/VinylRecommendationService.h"
#include "vinyl/VinylAvailability.h"
#if defined(COLOSSEUM_ENABLE_VINYL_TEST_FIXTURES) && !defined(Q_OS_ANDROID)
#include "devtools/VinylTestProfileController.h"
#include "account/ActivityStore.h"
#endif
#endif
#include "GuiStallProbe.h"   // diagnostic GUI-thread stall probe (env-gated; see header)
// Player 2 LAST on purpose: its D3D11 headers drag in <windows.h>, and anything that pulls in the
// old WinSock.h before boost/asio (libtorrent, above) wants winsock2.h fails the build outright.
#ifdef COLOSSEUM_PLAYER2
#include "player2/Player2Backend.h"
#include "player2/video/Player2VideoItem.h"
#endif

// Package 1 has no production Ratings/Reviews writer.  This adapter exists
// only in the separately compiled, exact-tagged assembled-app fixture.
#ifdef COLOSSEUM_RATINGS_REVIEWS_TESTING
class RatingsReviewsTaggedFixtureAdapter final : public RatingsReviewsDeliveryAdapter
{
public:
    explicit RatingsReviewsTaggedFixtureAdapter(bool unknownFirstSend = false)
        : m_unknownFirstSend(unknownFirstSend) {}

    Result send(const RatingsReviewsDeliveryOperation &) override
    {
        ++m_sendCount;
        if (m_unknownFirstSend && m_sendCount == 1) {
            return {SendOutcome::UnknownAfterDispatch,
                    QStringLiteral("fixture_unknown"), {}, {}, std::nullopt};
        }
        return {SendOutcome::Success,
                QStringLiteral("fixture_ok"), {}, {}, std::nullopt};
    }

    ReconcileOutcome reconcile(const RatingsReviewsDeliveryOperation &) override
    {
        return ReconcileOutcome::MatchesIntendedState;
    }

private:
    bool m_unknownFirstSend = false;
    int m_sendCount = 0;
};
#endif

// Dev-only QML live-reloader: watches the qml/ tree and reloads the root window
// on save, so editing QML feels like Electron's `npm run dev`. Constructed ONLY
// when COLOSSEUM_DEV is set (dev.bat sets it); the normal launcher never makes one.
class QmlReloader : public QObject {
public:
    QmlReloader(QQmlApplicationEngine *engine, const QString &qmlPath, QObject *parent = nullptr)
        : QObject(parent), m_engine(engine) {
        m_qmlPath = QFileInfo(qmlPath).absoluteFilePath();
        m_watchDir = QFileInfo(m_qmlPath).absolutePath();

        m_debounce.setSingleShot(true);
        m_debounce.setInterval(150);  // coalesce an editor's save-burst into one reload
        QObject::connect(&m_debounce, &QTimer::timeout, this, [this] { reload(); });
        QObject::connect(&m_watcher, &QFileSystemWatcher::fileChanged, this,
                         [this](const QString &) { m_debounce.start(); });
        QObject::connect(&m_watcher, &QFileSystemWatcher::directoryChanged, this,
                         [this](const QString &) { rescan(); m_debounce.start(); });
        rescan();
        qInfo("[dev] live-reload watching %s", qUtf8Printable(m_watchDir));
    }

private:
    // (Re)watch every .qml/.js under the tree. Many editors save via temp-file +
    // rename, which silently drops that file's watch — so we re-add on every pass.
    void rescan() {
        QStringList found;
        QDirIterator it(m_watchDir, {QStringLiteral("*.qml"), QStringLiteral("*.js")},
                        QDir::Files, QDirIterator::Subdirectories);
        while (it.hasNext()) found << it.next();
        const QStringList watched = m_watcher.files();
        QStringList toAdd;
        for (const QString &p : found)
            if (!watched.contains(p)) toAdd << p;
        if (!toAdd.isEmpty()) m_watcher.addPaths(toAdd);
        if (!m_watcher.directories().contains(m_watchDir)) m_watcher.addPath(m_watchDir);
    }

    void reload() {
        rescan();  // re-arm any watches dropped by atomic saves
        const QList<QObject *> oldRoots = m_engine->rootObjects();
        m_engine->clearComponentCache();
        m_engine->load(QUrl::fromLocalFile(m_qmlPath));
        for (QObject *o : oldRoots) o->deleteLater();  // drop the previous window
        qInfo("[dev] reloaded");
    }

    QQmlApplicationEngine *m_engine;
    QString m_qmlPath;
    QString m_watchDir;
    QFileSystemWatcher m_watcher;
    QTimer m_debounce;
};

int main(int argc, char *argv[]) {
    if (argc == 2 && std::strcmp(argv[1], "--version") == 0) {
        std::printf("Colosseum %s\n", COLOSSEUM_VERSION);
        return 0;
    }
    // mpvqt renders through OpenGL, so the whole Quick scene must use the OpenGL RHI
    // backend (set process-wide, before the QGuiApplication). Proven 2026-06-27 that
    // Colosseum's frosted glass survives this — the player path's one prerequisite.
    // WebEngine (the foliate EPUB reader) also rides OpenGL: share contexts + init it
    // before the QGuiApplication, alongside the RHI pick. All three must precede app.
    // Player 2 draws through D3D11 texture sharing and REFUSES to initialise on any other RHI, while
    // mpvqt and WebEngine require OpenGL. Qt picks the RHI once per PROCESS, before QGuiApplication -
    // so the two video backends can never coexist in one running app, and the backend choice is a
    // BOOT choice, not a runtime one. Env var (not the ini) because this must be decided before any
    // Qt object exists. Default stays OpenGL: a normal launch is unchanged.
    // TASK 18 - THE DEFAULT FLIP (Hemanth's explicit go, 2026-07-26: "let's do it"). Player 2 is now
    // the default engine when it is compiled in, and mpv is the ESCAPE HATCH rather than the default.
    // He keeps a one-click way back: COLOSSEUM_PLAYER1=1 boots the old player, and there is a Desktop
    // launcher for it. This is deliberately still a BOOT choice both ways - the RHI is process-wide,
    // so it can never be a switch inside the running app.
    //
    // COLOSSEUM_PLAYER2 is still honoured as an explicit opt-IN so every existing launcher, probe and
    // gate keeps working unchanged; it simply is no longer required.
    // DEFAULT REVERTED to mpv, 2026-07-26 late evening - the Task 18 flip was PREMATURE and this is
    // the honest walk-back, on the day's own evidence: his first evenings on the flipped default hit
    // dead hotkeys (the rebuilt chrome never carried production's focus wiring), silent progress
    // tracking, a bare pause banner and seek-time frame drops. The ENGINE measured well all along;
    // the integration shell around it is what is not finished. So his daily driver goes back to the
    // player that is COMPLETE, and Player 2 stays fully built one launcher away (COLOSSEUM_PLAYER2=1,
    // the same opt-in it always honoured) while the shell is ported - not patched - to parity.
    // Re-flipping the default is Task 18 again, and it happens when HE cannot tell the two apart in
    // an evening of use - not when a ledger says so.
    QCoreApplication::setAttribute(Qt::AA_ShareOpenGLContexts);
#ifdef COLOSSEUM_PLAYER2
    const bool forcePlayer1 = qEnvironmentVariableIsSet("COLOSSEUM_PLAYER1")
                              || qEnvironmentVariableIsSet("COLOSSEUM_MPV");
    const bool bootPlayer2 = qEnvironmentVariableIsSet("COLOSSEUM_PLAYER2") && !forcePlayer1;
    if (bootPlayer2)
        QQuickWindow::setGraphicsApi(QSGRendererInterface::Direct3D11);
    else
        QQuickWindow::setGraphicsApi(QSGRendererInterface::OpenGL);
#else
    // Not compiled in: there is nothing to boot, and the old player is the only engine present.
    QQuickWindow::setGraphicsApi(QSGRendererInterface::OpenGL);
#endif
#if !defined(Q_OS_ANDROID)
    QtWebEngineQuick::initialize();
#endif

    // Qt Quick Controls style: the default on Windows is the NATIVE style, which refuses to
    // customize a control's contentItem/background — so HouseScrollBar's overrides were IGNORED
    // and a native white scrollbar rendered anyway (Hemanth's "ugly white bar", 2026-07-12).
    // ScrollBar is the ONLY Controls type this app instantiates (RoundButton is a local Item
    // component, not the Controls one), so forcing the fully-customizable Basic style has zero
    // blast radius beyond finally letting HouseScrollBar's gold sliver take. Set via env (pure
    // QtCore) so no QuickControls2 C++ module needs linking; must precede the QML engine.
    qputenv("QT_QUICK_CONTROLS_STYLE", "Basic");

    // Diagnostic only (2026-07-29 stutter investigation): ProbedGuiApplication IS a QGuiApplication
    // and behaves identically unless COLOSSEUM_GUI_STALL_PROBE is set, in which case it times every
    // GUI-thread event and ranks what blocks the thread. Frame pacing proved the stutter is a
    // GUI-thread stall, not the video engine; this names the work. See native/GuiStallProbe.h.
    ProbedGuiApplication app(argc, argv);
    app.setApplicationName(QStringLiteral("Colosseum"));
    app.setApplicationVersion(QStringLiteral(COLOSSEUM_VERSION));
    // App identity on the Windows taskbar / alt-tab / title: the amphitheatre glyph on a
    // dark tile (embedded via app_resources.qrc). The .exe file icon comes from app_icon.rc.
    app.setWindowIcon(QIcon(QStringLiteral(":/colosseum.ico")));
    // QSettings (every QML `Settings` block — reader prefs, player settings) keys on the
    // organization; without it QSettings::init fails (status 1) and NOTHING persists. This
    // was silently broken forever (Hemanth's log, 2026-07-09).
    // CAVEAT: on Windows, AppDataLocation *includes* the org — so setting it moves the data
    // dir (Roaming/Colosseum -> Roaming/Brotherhood/Colosseum), which would orphan the
    // existing downloads/books/videos/extensions. Capture the old path, set the org, then
    // MOVE the old tree to the new location ONCE (guarded), so nothing is lost.
    const QString oldAppData = QStandardPaths::writableLocation(QStandardPaths::AppDataLocation);
    app.setOrganizationName(QStringLiteral("Brotherhood"));
    app.setOrganizationDomain(QStringLiteral("colosseum.brotherhood"));
    const QString newAppData = QStandardPaths::writableLocation(QStandardPaths::AppDataLocation);
    const bool isolatedAppData = qEnvironmentVariableIsSet("COLOSSEUM_APPDATA_TAG");
    if (isolatedAppData) {
        app.setApplicationName(QStringLiteral("Colosseum-dltest-")
            + qEnvironmentVariable("COLOSSEUM_APPDATA_TAG"));
    }

    const QString instanceAppData =
        QStandardPaths::writableLocation(QStandardPaths::AppDataLocation);
#if defined(COLOSSEUM_ENABLE_VINYL_TEST_FIXTURES) && !defined(Q_OS_ANDROID)
    // Refuse a misconfigured synthetic launch before constructing personal stores
    // or installing the application log. The fixture must prepare its own root.
    if (qEnvironmentVariable("COLOSSEUM_VINYL_TEST_FIXTURES") == QLatin1String("1")
        && !VinylTestProfileController(instanceAppData, {}, {}).enabled()) {
        qCritical("Vinyl synthetic fixture launch containment check failed.");
        return 2;
    }
#endif
    // Install the rolling log after final identity selection so test launches write only
    // inside their disposable AppData sibling. Real launches reconcile the legacy root
    // afterwards, which makes any migration warning durable instead of stderr-only.
    AppLog::install();

    // Only one normal Colosseum process may use the shared AppDataLocation. This prevents
    // duplicate launches from racing the account refresh-token rotation and local sync stores.
    // Tagged test sessions have a different application name/AppDataLocation and therefore a
    // separate lock by design.
    ColosseumInstanceLock instanceLock(instanceAppData);
    if (!instanceLock.tryAcquire()) {
        if (instanceLock.wasBlockedByExistingInstance()) {
            qInfo("[boot] another Colosseum instance is already running; leaving it alone");
        } else {
            qWarning("[boot] could not establish the Colosseum instance lock");
        }
        return 0;
    }

    AppDataMigrationResult appDataMigration;
    if (!isolatedAppData)
        appDataMigration = reconcileAppData(oldAppData, newAppData);
    if (!appDataMigration.complete) {
        qWarning("[migrate] AppData reconciliation incomplete: %s (journal: %s)",
                 qUtf8Printable(appDataMigration.error),
                 qUtf8Printable(appDataMigration.logPath));
    } else if (appDataMigration.movedEntries > 0 || appDataMigration.conflicts > 0) {
        qInfo("[migrate] AppData reconciliation complete: moved=%d conflicts=%d journal=%s",
              appDataMigration.movedEntries, appDataMigration.conflicts,
              qUtf8Printable(appDataMigration.logPath));
    }

    QString startupManifestPathOverride;
#if defined(Q_OS_ANDROID)
    if (!Colosseum::Platform::bootstrapAndroidStartup(instanceAppData, &startupManifestPathOverride))
        return -1;
#else
    // Shared QML binds to PlayerItem; each host supplies its native playback engine.
    qmlRegisterType<MpvItem>("Colosseum.Player", 1, 0, "PlayerItem");
    qmlRegisterType<MpvItem>("Colosseum.Player", 1, 0, "MpvItem");
    qmlRegisterType<SeekThumbnailer>("Colosseum.Player", 1, 0, "SeekThumbnailer");
#endif
#ifdef COLOSSEUM_PLAYER2
    // The Player 2 backend, opt-in (build flag COLOSSEUM_PLAYER2_IN_APP). Registering the types costs
    // nothing at runtime — the engine is only constructed if QML instantiates Player2Page.
    qmlRegisterType<Colosseum::Player2::Player2VideoItem>("Colosseum.Player2", 1, 0, "Player2VideoItem");
    qmlRegisterType<Colosseum::Player2::Player2Backend>("Colosseum.Player2", 1, 0, "Player2Backend");
#endif

    // "Your Colosseum" playback activity sampler (CPP-PORT-CONTRACT.md §8), reached from QML as
    // `import Colosseum.Activity`. One transient instance per lane (Player 1, Player 2, audiobook);
    // each binds its own `sink: ProfileActivity` (the profile-scoped ActivityStore context property).
    qmlRegisterType<ActivityPlaybackTracker>("Colosseum.Activity", 1, 0, "ActivityPlaybackTracker");

    QNetworkProxyFactory::setUseSystemConfiguration(false);
    QNetworkProxy::setApplicationProxy(QNetworkProxy::NoProxy);

    // Backend stores and workers must finish while Qt and its event dispatcher
    // still exist. QML goes first so its destruction handlers can flush activity.
    QObject backendServices(&app);
    QQmlApplicationEngine engine;

    // One host/platform facade for lifecycle, Android Back, safe insets,
    // keyboard visibility, permissions/SAF requests and capability truth.
    // Product navigation remains in Main.qml; this object only forwards OS events.
    auto *platformRuntime = new Colosseum::Platform::Runtime(&app);
    engine.rootContext()->setContextProperty(
        QStringLiteral("PlatformRuntime"), platformRuntime);

    // Shared catalogue networking exists on every host. Desktop updater traffic
    // may reuse it, but Android does not construct updater/installer services.
    auto *catalogNam = new QNetworkAccessManager(&app);

#if !defined(Q_OS_ANDROID)
    // Auto-update is a post-first-paint desktop service. It reuses the plain
    // catalogue network manager but keeps its own cache and installer bridge.
    auto updateCacheOwner = std::make_unique<Colosseum::Update::UpdateCache>(
        Colosseum::Update::UpdateCache::productionRoot());
    auto *updateCache = updateCacheOwner.get();
    auto *updateDownloader = new Colosseum::Update::UpdateDownload(
        catalogNam, std::move(updateCacheOwner), &app);
    Colosseum::Update::ReleaseClientConfig updateConfig;
    updateConfig.latestReleaseUrl = QUrl(
        QStringLiteral("https://getcolosseum.world/updates/stable.json"));
    updateConfig.publicKey = QByteArray(Colosseum::Update::embeddedUpdatePublicKey().data(),
                                        Colosseum::Update::embeddedUpdatePublicKey().size());
    Colosseum::Update::UpdateReleaseClient updateClientStorage(catalogNam, updateConfig, &app);
    auto *updateClient = &updateClientStorage;
    Colosseum::Update::UpdateInstallBridge updateBridgeStorage(&app);
    auto *updateBridge = &updateBridgeStorage;

    struct ActiveUpdateCallbacks final {
        std::function<void(qint64, qint64, qint64)> progress;
        std::function<void(const QString&)> completed;
        std::function<void(const QString&, bool)> failed;
    };
    const auto updateCallbacks = std::make_shared<ActiveUpdateCallbacks>();
    QObject::connect(updateDownloader, &Colosseum::Update::UpdateDownload::progress,
                     &app, [updateCallbacks](qint64 received, qint64 total, qint64 speed) {
        if (updateCallbacks->progress)
            updateCallbacks->progress(received, total, speed);
    });
    QObject::connect(updateDownloader, &Colosseum::Update::UpdateDownload::completed,
                     &app, [updateCallbacks](const QString& path) {
        if (updateCallbacks->completed)
            updateCallbacks->completed(path);
    });
    QObject::connect(updateDownloader, &Colosseum::Update::UpdateDownload::failed,
                     &app, [updateCallbacks](const QString& code, bool resumable) {
        if (updateCallbacks->failed)
            updateCallbacks->failed(code, resumable);
    });

    Colosseum::Update::UpdateServiceHooks updateHooks;
    updateHooks.checkLatest = [updateClient](const QString& priorEtag,
                                              Colosseum::Update::UpdateReleaseClient::Callback done) {
        updateClient->checkLatest(priorEtag, std::move(done));
    };
    updateHooks.startDownload = [updateDownloader, updateCallbacks](
        const Colosseum::Update::DownloadRequest& request,
        Colosseum::Update::UpdateServiceHooks::DownloadProgress progress,
        Colosseum::Update::UpdateServiceHooks::DownloadCompleted completed,
        Colosseum::Update::UpdateServiceHooks::DownloadFailed failed) {
        updateCallbacks->progress = std::move(progress);
        updateCallbacks->completed = std::move(completed);
        updateCallbacks->failed = std::move(failed);
        updateDownloader->start(request);
    };
    updateHooks.cancelDownload = [updateDownloader] { updateDownloader->cancel(); };
    updateHooks.installLauncher = [updateBridge](const QString& installer,
                                                 const Colosseum::Update::Version& target,
                                                 QString* error) {
        const auto launch = updateBridge->prepare(installer, target, error);
        return launch.has_value() && updateBridge->launchDetached(*launch, error);
    };
    // Installer waits on /WAITPID=<our PID>; the shell must drain browsers
    // before ending the event loop, just as it does for a user-requested quit.
    updateHooks.requestShutdown = [&app, &engine] {
        Colosseum::Bootstrap::requestApplicationShutdown(app, engine);
    };
    updateHooks.fetchArtwork = [catalogNam](const QString&, const QUrl& url, qint64 cap,
                                           Colosseum::Update::UpdateServiceHooks::ArtworkCompleted done,
                                           Colosseum::Update::UpdateServiceHooks::ArtworkFailed failed) {
        if (!url.isValid() || url.scheme() != QLatin1String("https")) {
            failed(QStringLiteral("unsafe_artwork_url"));
            return;
        }
        QNetworkRequest request(url);
        request.setRawHeader("User-Agent", Colosseum::Update::updateUserAgent());
        request.setAttribute(QNetworkRequest::RedirectPolicyAttribute,
                             QNetworkRequest::NoLessSafeRedirectPolicy);
        QNetworkReply *reply = catalogNam->get(request);
        const auto bytes = std::make_shared<QByteArray>();
        const auto settled = std::make_shared<bool>(false);
        QObject::connect(reply, &QNetworkReply::readyRead, reply, [reply, bytes, settled, cap, failed] {
            if (*settled)
                return;
            bytes->append(reply->readAll());
            if (bytes->size() > cap) {
                *settled = true;
                reply->abort();
                failed(QStringLiteral("artwork_too_large"));
            }
        });
        QObject::connect(reply, &QNetworkReply::finished, reply,
                         [reply, bytes, settled, done, failed] {
            if (*settled) {
                reply->deleteLater();
                return;
            }
            bytes->append(reply->readAll());
            *settled = true;
            const int status = reply->attribute(QNetworkRequest::HttpStatusCodeAttribute).toInt();
            if (reply->error() != QNetworkReply::NoError || status < 200 || status >= 300)
                failed(QStringLiteral("artwork_download_failed"));
            else
                done(*bytes);
            reply->deleteLater();
        });
    };

    QString installedVersionText = QStringLiteral(COLOSSEUM_VERSION);
#ifdef COLOSSEUM_UPDATE_TESTING
    // Lanista's UpToDate fixture uses the same signed release chronicle as the
    // Available case, but boots the test binary at that release version so the
    // service can exercise its no-newer-release branch without a second signing key.
    if (qEnvironmentVariableIsSet("COLOSSEUM_UPDATE_TEST_INSTALLED_VERSION"))
        installedVersionText = qEnvironmentVariable("COLOSSEUM_UPDATE_TEST_INSTALLED_VERSION");
#endif
    const auto installedVersion = Colosseum::Update::Version::parseCanonical(installedVersionText);
    if (!installedVersion)
        return -1;
    // Bundled installed-chronicle seed: extract the signed manifest + signature +
    // artwork from the qrc to a cache subdir so the runtime highlightMap SHA256
    // check works on real files (qrc bytes cannot be memory-mapped/hashed by
    // QFile). Extracted once per launch; the loader re-verifies the signature
    // before use, so a stale or tampered extraction is rejected.
    {
        const QString chronicleCacheDir =
            QDir(updateCache->rootPath()).filePath(QStringLiteral("installed-chronicle"));
        const QString artworkCacheDir = QDir(chronicleCacheDir).filePath(QStringLiteral("artwork"));
        QDir().mkpath(artworkCacheDir);
        const auto extract = [&chronicleCacheDir, &artworkCacheDir](const QString& qrcPath,
                                                                    const QString& destName,
                                                                    const QString& destDir) {
            QFile src(QStringLiteral(":/installed-chronicle/") + qrcPath);
            if (!src.exists())
                return false;
            const QString dest = QDir(destDir).filePath(destName);
            // Skip if already extracted with identical bytes (idempotent across launches).
            if (QFile::exists(dest)) {
                QFile existing(dest);
                if (existing.open(QIODevice::ReadOnly) && src.open(QIODevice::ReadOnly)
                    && existing.readAll() == src.readAll())
                    return true;
            }
            if (!src.open(QIODevice::ReadOnly))
                return false;
            QFile out(dest);
            if (!out.open(QIODevice::WriteOnly | QIODevice::Truncate))
                return false;
            return out.write(src.readAll()) == src.size();
        };
        if (extract(QStringLiteral("installed-manifest.json"), QStringLiteral("installed-manifest.json"), chronicleCacheDir)
            && extract(QStringLiteral("installed-manifest.json.sig"), QStringLiteral("installed-manifest.json.sig"), chronicleCacheDir)) {
            // Extract each artwork asset. The manifest lists them; we extract by
            // scanning the qrc artwork prefix (the manifest is already on disk).
            updateHooks.installedChronicleManifestPath =
                QDir(chronicleCacheDir).filePath(QStringLiteral("installed-manifest.json"));
            updateHooks.installedChronicleSignaturePath =
                QDir(chronicleCacheDir).filePath(QStringLiteral("installed-manifest.json.sig"));
            updateHooks.installedChronicleArtworkRoot = artworkCacheDir;
            // Extract artwork assets named in the manifest.
            QFile manifestFile(updateHooks.installedChronicleManifestPath);
            if (manifestFile.open(QIODevice::ReadOnly)) {
                const auto doc = QJsonDocument::fromJson(manifestFile.readAll());
                const auto artwork = doc.object().value(QStringLiteral("artwork")).toArray();
                for (const auto& value : artwork)
                    extract(QStringLiteral("artwork/") + value.toObject().value(QStringLiteral("asset")).toString(),
                            value.toObject().value(QStringLiteral("asset")).toString(),
                            artworkCacheDir);
            }
        }
    }
    auto *updates = new Colosseum::Update::UpdateService(
        *installedVersion, updateCache->rootPath(), std::move(updateHooks), &backendServices);
#ifdef COLOSSEUM_UPDATE_TESTING
    if (qEnvironmentVariableIsSet("COLOSSEUM_UPDATE_TEST_PRESENTATION_STATE")) {
        const QString requestedState = qEnvironmentVariable("COLOSSEUM_UPDATE_TEST_PRESENTATION_STATE");
        Colosseum::Update::UpdateService::State state = Colosseum::Update::UpdateService::Idle;
        if (requestedState == QStringLiteral("Downloading"))
            state = Colosseum::Update::UpdateService::Downloading;
        else if (requestedState == QStringLiteral("Paused"))
            state = Colosseum::Update::UpdateService::Paused;
        else if (requestedState == QStringLiteral("Verifying"))
            state = Colosseum::Update::UpdateService::Verifying;
        else if (requestedState == QStringLiteral("Ready"))
            state = Colosseum::Update::UpdateService::Ready;
        else
            qWarning("[update] ignored unknown test presentation state: %s",
                     requestedState.toUtf8().constData());

        bool receivedOk = false;
        bool totalOk = false;
        const qint64 received = qEnvironmentVariable("COLOSSEUM_UPDATE_TEST_RECEIVED_BYTES")
                                    .toLongLong(&receivedOk);
        const qint64 total = qEnvironmentVariable("COLOSSEUM_UPDATE_TEST_TOTAL_BYTES")
                                 .toLongLong(&totalOk);
        if (state != Colosseum::Update::UpdateService::Idle && receivedOk && totalOk)
            updates->setTestingPresentationState(state, received, total);
        else if (state != Colosseum::Update::UpdateService::Idle)
            qWarning("[update] ignored invalid test presentation byte counts");
    }
#endif
    engine.rootContext()->setContextProperty(QStringLiteral("Updates"), updates);
    const bool installedUpdateEligible = updateBridge->installedBuildEligible();
#ifdef COLOSSEUM_UPDATE_TESTING
    constexpr bool updateTestingBuild = true;
#else
    constexpr bool updateTestingBuild = false;
#endif
    if (!installedUpdateEligible && !updateTestingBuild)
        qInfo("[update] automatic checks disabled (source/dev build or missing installed layout)");
#endif
    QString startupLayoutError;
    const auto startupLayout = resolveStartupLayout(
        QCoreApplication::arguments(), QCoreApplication::applicationDirPath(),
        &startupLayoutError, startupManifestPathOverride);
    if (!startupLayout) {
        qCritical("[boot] startup layout rejected: %s", qUtf8Printable(startupLayoutError));
        return -1;
    }
    if (!startupLayout->resourceRoot.isEmpty())
        QDir::setCurrent(startupLayout->resourceRoot);
    const QString qmlPath = startupLayout->qmlPath;
    const bool hasQmlOverride = startupLayout->qmlOverride;
    const QStringList pinnedHosts = {
        QStringLiteral("live.metahub.space"),
        QStringLiteral("images.metahub.space"),
        // Theatre search + genre browse hosts: both publish AAAA records and Qt tries IPv6
        // first — on this ISP's dead IPv6 route that's a ~21s stall per connection (the TB3
        // scar). Pin them to IPv4 like the poster hosts. (2026-07-05, Theatre search triage)
        QStringLiteral("v3-cinemeta.strem.io"),
        QStringLiteral("cinemeta-catalogs.strem.io"),
        // Manga art lane: AniList (API + banner CDN) and Kitsu (fallback API + media CDN)
        // all publish AAAA records — same dead-IPv6 stall. The API hosts are called from
        // MangaEngine's own NAM (pins passed via setIpv4Pins below); the CDNs are loaded
        // by QML Image through this factory. (2026-07-06, manga art ladder)
        QStringLiteral("graphql.anilist.co"),
        QStringLiteral("s4.anilist.co"),
        QStringLiteral("kitsu.io"),
        QStringLiteral("media.kitsu.app"),
        // Universe banners (2026-07-12 expansion): the Weekly Shonen Jump cover rides
        // Wikimedia, which publishes AAAA records — same dead-IPv6 stall as the rest.
        QStringLiteral("upload.wikimedia.org"),
        // Comics lane (2026-07-12, "no top-10 series has any issues"): BOTH comics API
        // hosts publish AAAA records (getcomics is Cloudflare-fronted) and were never
        // pinned — every attach/search/releases XHR ate the dead-IPv6 stall, so series
        // pages sat empty while curl (happy-eyeballs) worked and hid the root cause.
        // Probe: tests pattern _gc_net_probe — Qt-stack reachability, exit-code verdict.
        QStringLiteral("getcomics.org"),
        QStringLiteral("leagueofcomicgeeks.com"),
        // Book-torrent indexer hosts (2026-07-13): apibay/extto/torrents-csv publish AAAA
        // records → dead-IPv6 ~21s stall unless pinned to IPv4 (same scar as the comics lane).
        QStringLiteral("apibay.org"),
        QStringLiteral("extto.org"),
        QStringLiteral("torrents-csv.com"),
        // Jikan (2026-07-13, genre-pages triage): api.jikan.moe publishes AAAA and was
        // NEVER pinned — every manga genre / Jump registry / Theatre anime call rode the
        // dead-IPv6 stall on top of whatever Jikan itself was doing. Same scar, same fix.
        QStringLiteral("api.jikan.moe"),
        // Tankoban Mode (2026-07-15, eyes-on): cover thumbnails ride uploads.mangadex.org
        // (QML Image via this factory — still the source of Catalog.js's Monster tile);
        // Apple Books + Open Library per-volume synopsis lookups ride itunes.apple.com /
        // openlibrary.org. All publish a dead AAAA on this ISP → ~21s stall per request
        // (covers never painted; Apple synopses trickled a scattered few). Same scar, same
        // fix. NOTE: Open Library's IPv4 is ALSO ISP-firewalled — pinning only makes it fail
        // fast so the Apple fallback runs sooner; it never returns data here.
        // The MangaDex catalog API host was pinned here for the volume catalog; that client
        // is retired (2026-07-29, ComickCatalogClient) and nothing contacts the host now.
        QStringLiteral("uploads.mangadex.org"),
        QStringLiteral("itunes.apple.com"),
        QStringLiteral("openlibrary.org"),
        // Wallpaper CDN (WallpaperApi.js): unpinned, its requests rode the same dead-AAAA
        // ISP stall as the Jikan scar, so walls silently fell back to the packaged
        // captured-motion asset (humbled-current recap 2026-07-24). Same scar, same fix.
        QStringLiteral("wsrv.nl")
    };
    auto *pinStore = new Ipv4PinStore(QString(), Ipv4PinStore::Lookup(), &backendServices);
    const QHash<QString, QString> initialPins = pinStore->snapshot();
    for (auto it = initialPins.constBegin(); it != initialPins.constEnd(); ++it)
        qInfo("[net] cached IPv4 pin %s -> %s", qUtf8Printable(it.key()), qUtf8Printable(it.value()));

    // Instant posters (spec 2026-07-23): keep the hostname in metahub requests so
    // HTTP/2 negotiates (SNI / cert / :authority all correct → the whole poster wall
    // multiplexes over ONE connection), while a loopback CONNECT concierge pins the
    // CONNECTION to metahub's IPv4 — dodging the dead-IPv6 stall the URL-rewrite pin
    // exists for. GetComics now takes this same connection-pin path so its
    // persistent cache key remains the original URL. If binding fails, both
    // retain the existing URL-rewrite/HTTP1.1 fallback.
    const QSet<QString> connectionPinnedHosts = {
        QStringLiteral("live.metahub.space"), QStringLiteral("images.metahub.space"),
        // Keep the canonical GetComics URL as the QNetworkDiskCache key.
        QStringLiteral("getcomics.org")
    };
    auto *concierge = new LoopbackPinProxy(pinStore, &backendServices);
    const bool conciergeOk = concierge->start();
    if (conciergeOk)
        qInfo("[net] connection concierge on 127.0.0.1:%u (metahub + GetComics hostname-preserved)", concierge->port());
    else
        qWarning("[net] concierge could not bind -> metahub + GetComics fall back to URL-pin + HTTP/1.1");
    QNetworkProxyFactory::setApplicationProxyFactory(
        new PinProxyFactory(connectionPinnedHosts, pinStore,
                            conciergeOk ? concierge->port() : quint16(0), conciergeOk));

    // When the concierge is up, metahub and GetComics keep their hostnames for
    // TLS/h2 and canonical image-cache keys; the proxy pins their connections.
    // On concierge failure, both retain the existing URL-rewrite fallback.
    QStringList namPinnedHosts = pinnedHosts;
    if (conciergeOk)
        namPinnedHosts.erase(std::remove_if(namPinnedHosts.begin(), namPinnedHosts.end(),
            [&](const QString &h){ return connectionPinnedHosts.contains(h); }), namPinnedHosts.end());
    // Felt-speed Stage 0: the poster scoreboard. Counts every reply on the QML image
    // NAM; dumped at quit so a real run answers "did the posters actually arrive?"
    // with numbers instead of a shrug. The webp check is the dev-hack scar made loud:
    // the decoder must ship BESIDE the exe (deploy-runtime.bat), not live in the Qt install.
    auto *scoreboard = new PosterScoreboard(&backendServices);
    {
        const bool webpOk =
            QImageReader::supportedImageFormats().contains(QByteArrayLiteral("webp"));
        scoreboard->setWebpDecoderPresent(webpOk);
        if (webpOk)
            qInfo("[img] webp decoder present");
        else
            qWarning("[img] webp decoder MISSING -> every image/webp poster is UNDECODABLE "
                     "(run native/deploy-runtime.bat to bundle qwebp.dll)");
    }
    // Sweep zero-byte entries out of the image cache before any NAM can read them.
    //
    // A zero-byte cache file is served as a HIT: no request, no error, blank tile, forever.
    // That is what kept the KDE Plasma shelf and the comics covers empty for days while the
    // URLs, CDN, proxy, pin and delegates were all provably fine — found 2026-07-26 by
    // parking the cache directory and watching the shelf come back. The parked copy held
    // 168 sub-kilobyte entries out of 6029, many of them exactly 0 bytes.
    //
    // evictOnFailure() above stops us WRITING new ones. This heals what is already there,
    // including files truncated by a hard kill mid-write, which no reply handler can catch
    // because there is no reply. Cheap: a stat per file, once, before the UI exists.
    {
        const QString imgCacheDir =
            QStandardPaths::writableLocation(QStandardPaths::CacheLocation)
            + QStringLiteral("/colosseum-images");
        int swept = 0;
        QDirIterator it(imgCacheDir, QDir::Files, QDirIterator::Subdirectories);
        while (it.hasNext()) {
            it.next();
            if (it.fileInfo().size() > 0)
                continue;
            if (QFile::remove(it.filePath()))
                ++swept;
        }
        if (swept > 0)
            qInfo("[img] swept %d empty entries from the image cache (they render as blank "
                  "tiles and never re-fetch)", swept);
    }
    // Per-URL image diagnostics behind the Lanista biblio.imageDiag probe (decision
    // brief 2026-08-06 §4) — same lifetime contract as the scoreboard beside it.
    auto *imageDiag = new BiblioImageDiag(&backendServices);
    const bool posterTimingEnabled = qEnvironmentVariable("COLOSSEUM_POSTER_TIMING") == QLatin1String("1");
    const bool frameProbeEnabled = qEnvironmentVariable("COLOSSEUM_FRAME_PROBE") == QLatin1String("1");
    auto *posterTiming = new PosterTimingProbe(posterTimingEnabled, &backendServices);
    auto frameTiming = std::make_shared<FrameTimingProbe>(frameProbeEnabled);
    if (posterTimingEnabled) app.installEventFilter(posterTiming);
    // App-wide cover delivery state: per-host admission cap + durable Retry-After
    // ledger shared by every cache-enabled NAM the factory creates (the engine
    // creates NAMs on multiple threads). Loaded before the factory is installed;
    // flushed synchronously on shutdown. Metadata only — not an image cache.
    auto *coverState = new CoverDeliveryState(&backendServices);
    const QString coverLedgerPath =
        QStandardPaths::writableLocation(QStandardPaths::AppLocalDataLocation)
        + QStringLiteral("/net/image-retry.json");
    if (coverState->loadLedger(coverLedgerPath))
        qInfo("[cover] retry ledger loaded: %s", qUtf8Printable(coverLedgerPath));
    else
        qWarning("[cover] retry ledger unreadable/corrupt at %s; starting empty",
                 qUtf8Printable(coverLedgerPath));
    QObject::connect(&app, &QCoreApplication::aboutToQuit, coverState, [coverState] {
        coverState->saveLedgerNow();
    });
    engine.setNetworkAccessManagerFactory(
        new CachingNamFactory(namPinnedHosts, pinStore, scoreboard, imageDiag,
                              posterTimingEnabled ? posterTiming : nullptr, coverState));
    engine.rootContext()->setContextProperty(QStringLiteral("NetScoreboard"), scoreboard);
    engine.rootContext()->setContextProperty(QStringLiteral("BiblioImageDiag"), imageDiag);
    QObject::connect(&app, &QCoreApplication::aboutToQuit, scoreboard, [scoreboard] {
        const QString text = scoreboard->summaryText();
        if (!text.isEmpty())
            qInfo("[net] poster scoreboard (arrived/failed/undecodable/bytes by host):\n%s",
                  qUtf8Printable(text));
    });
    if (posterTimingEnabled || frameProbeEnabled) {
        const QString probeDir = QStandardPaths::writableLocation(QStandardPaths::AppDataLocation)
                                 + QStringLiteral("/probes");
        qInfo("[probe] poster=%d frame=%d output=%s", posterTimingEnabled, frameProbeEnabled,
              qUtf8Printable(probeDir));
        QObject::connect(&app, &QCoreApplication::aboutToQuit, &app,
                         [posterTiming, frameTiming, probeDir] {
            if (posterTiming->enabled())
                posterTiming->writeArtifact(probeDir + QStringLiteral("/poster-timing.json"));
            if (frameTiming->enabled())
                frameTiming->writeArtifact(probeDir + QStringLiteral("/frame-timing.json"));
        });
    }

    // Native manga engine (WeebCentral) exposed to QML as `Manga`.
    auto *manga = new MangaEngine(&backendServices);
    manga->setIpv4Pins(initialPins);   // cached pins are available before async refresh
    engine.rootContext()->setContextProperty(QStringLiteral("Manga"), manga);

    // Download-fed reading backbone exposed to QML as `Downloads`. Reading is never
    // a live stream: a chapter is downloaded to loose local files once, then the
    // reader reads those offline. Own plain NAM (no cache) — it persists to disk itself.
    auto *dlNam = new QNetworkAccessManager(&backendServices);
    auto *downloads = new MangaDownloader(dlNam, &backendServices, {}, {}, manga->tankoyomiService());
    downloads->setIpv4Pins(initialPins);   // cached pins are available before async refresh
    pinStore->setPinChangedCallback([manga, downloads, pinStore](const QString&, const QString&) {
        const QHash<QString, QString> pins = pinStore->snapshot();
        manga->setIpv4Pins(pins);
        downloads->setIpv4Pins(pins);
    });
    engine.rootContext()->setContextProperty(QStringLiteral("Downloads"), downloads);
    if (qEnvironmentVariableIsSet("COLOSSEUM_DL_SELFTEST"))
        downloads->selfTest(qEnvironmentVariable("COLOSSEUM_DL_SELFTEST"));
    if (qEnvironmentVariableIsSet("COLOSSEUM_INDEX_SELFTEST"))
        downloads->indexSelfTest();

    // Book download backbone (LibGen → local .epub) exposed to QML as `Books`.
    // Same download-fed law as manga: a book is fetched to disk once, then the
    // reader opens the local file (never a stream). Shares the plain uncached NAM.
    auto *books = new BookDownloader(dlNam, &backendServices);
    engine.rootContext()->setContextProperty(QStringLiteral("Books"), books);
    if (qEnvironmentVariableIsSet("COLOSSEUM_BOOK_DLTEST"))
        books->selfTest(qEnvironmentVariable("COLOSSEUM_BOOK_DLTEST"));

    // Western-comics download backbone (GetComics release → archive → local page
    // dir) exposed to QML as `Comics`. BookDownloader lineage: ONE signed-link
    // file per release post, extracted so MangaReader reads it like a chapter.
    // The FRESH reader's native seam (Task 16 swap): Biblio's reader layer is
    // qml/reader2/ReaderShell over the vendored Anx foliate paper. QML sees the full
    // bridge; the paper's QWebChannel gets ONLY its filesRead/paperEvent gate
    // (Reader2Bridge.paperGate — least privilege). LegacyLocal keeps the old
    // BookStores files (native/reader/BookStores.h) readable without migration;
    // account and local-only profiles route new private records to their own roots.
    //
    // BookBridge itself was DELETED 2026-08-07: the Task 16 swap replaced its door
    // (Main.qml loads reader2/ReaderShell), and the one caller it was being kept for
    // — the standalone audiobook strip — was retired 2026-07-18 (Main.qml:1412). It
    // had no live caller in qml/, tests/ or native/. BookStores stays: it is shared
    // storage, not part of the old reader.
    auto *reader2Bridge = new Reader2Bridge(&backendServices);
    engine.rootContext()->setContextProperty(QStringLiteral("Reader2Bridge"), reader2Bridge);
#ifdef Q_OS_ANDROID
    Colosseum::Platform::installAndroidEngineBindings(&engine, reader2Bridge, &app);
#endif

    // From-scratch native Comic Reader backend (Agent 1, plan 2026-07-23, Task 7)
    // exposed to QML as `ComicReaderCore`: the ONE orchestrator over the five pure
    // comicreader/ engine units (types+pairing, pinned LRU cache, generation-safe
    // decode coordinator, auto-coupling probe, strip geometry). Its read-only
    // image://comicreader/ provider serves decoded pages from the pinned cache and
    // returns null for a superseded generation. The engine takes ownership of the
    // provider (addImageProvider); the core (parented to app) owns the cache + the
    // live-generation the provider reads. Registered now so the seam is live and
    // boot-tested; the QML surfaces (Task 9+) are what consume it. Scheme is
    // `comicreader`, distinct from Reader2's Biblio book reader.
    auto *comicReaderCore = new comicreader::ComicReaderCore(&backendServices);
    engine.rootContext()->setContextProperty(QStringLiteral("ComicReaderCore"), comicReaderCore);
    engine.addImageProvider(QStringLiteral("comicreader"), comicReaderCore->createProvider());

    // image://comiccover/ (2026-08-06 CBZ-in-place arc, Task 3): a fully
    // stateless cover-thumbnail provider for archive-shaped comic rows, which
    // have no loose page file for the library grid to point at. Engine takes
    // ownership via addImageProvider, same as the comicreader provider above.
    engine.addImageProvider(QStringLiteral("comiccover"), new Colosseum::ComicCoverProvider());
#if !defined(Q_OS_ANDROID)
    // image://vaultbookcover/ (Vault Slice 17 foundation): stateless bounded EPUB cover decode.
    engine.addImageProvider(QStringLiteral("vaultbookcover"),
                            new Colosseum::VaultBookCoverProvider());

    // ── Vault local-media: the launch pillar (execution plan Slice 8) ──────────
    // LocalLaunch routes a handed-in file (taskbar Open Media…, OS drag-drop,
    // Ctrl+O) to the right reader/player and rejects the unopenable BEFORE any
    // session is created (no dead taskbar tiles). VaultPageStore adapts a local
    // CBZ to ComicReaderShell's injected-store contract so it reads with zero
    // reader edits. C++ decides the route; Main.qml paints the door.
    const QString vaultDir =
        QStandardPaths::writableLocation(QStandardPaths::AppDataLocation)
        + QStringLiteral("/vault");
    QDir().mkpath(vaultDir);
    auto *localLaunch = new LocalLaunch(vaultDir, &backendServices);
    engine.rootContext()->setContextProperty(QStringLiteral("LocalLaunch"), localLaunch);
    auto *vaultPageStore = new VaultPageStore(&backendServices);
    engine.rootContext()->setContextProperty(QStringLiteral("VaultPageStore"), vaultPageStore);

    // VaultLibrary — the Vault's single QML façade: the read-model the page + door + shelves
    // paint from, plus the scan/confirm commands. It wraps the rebuildable VaultIndex (SQLite at
    // <vaultDir>/index-v1.sqlite), the cancellable off-thread VaultScanner, and the VaultConfig
    // user-intent store (roots + kind overrides), so QML fires one gesture (addFolder/confirmRoot)
    // and C++ owns the scan/publish threading and multi-step sequence. VaultEnricher is
    // constructed below (UX-uplift S5): census facts still shelve first via the inline
    // static pass, then the instance fills video durations + local artwork.
    auto *vaultIndex = new VaultIndex(vaultDir + QStringLiteral("/index-v1.sqlite"), &backendServices);
    auto *vaultConfig = new VaultConfig(vaultDir, &backendServices);
    auto *vaultIdentity = new VaultIdentity(vaultDir, &backendServices);
    localLaunch->setIdentity(vaultIdentity);
    auto *vaultScanner = new VaultScanner(vaultIndex, vaultIdentity, &backendServices);
    // Slice 15: VaultLibrary OWNS the VaultWatcher (per-root QFileSystemWatcher + debounce);
    // it needs the identity to build arrival rows identical to the census's.
    // Browse-artwork execution plan, Slice 3 part 2: `vaultDir` is reused as-is — the SAME
    // VaultStoreIo-managed dir vaultConfig/vaultIdentity/vaultIndex already sit under — so
    // VaultLibrary's owned VaultThumbnailer/VaultPosterFetcher (thumbs/, posters/ subdirs) land
    // beside config.json/identity.json/index-v1.sqlite instead of scattering a second cache root.
    auto *vaultLibrary =
        new VaultLibrary(vaultIndex, vaultScanner, vaultConfig, vaultIdentity, vaultDir, &backendServices);
    engine.rootContext()->setContextProperty(QStringLiteral("VaultLibrary"), vaultLibrary);

    // ── VaultEnricher, the instance the app never constructed (UX-uplift S5) ──────
    // main.cpp used the class's static fact helpers only, so durationSec stayed -1 on
    // every video row and the findLocalArtwork() convention (poster./folder./cover.
    // beside the film) never ran — comics and EPUBs got covers from the census pass,
    // videos never did. The instance owns the durations.json cache (load once here,
    // flush every 20 files) and commits through upsertManyIfRevision on the index
    // owner thread (its own resurrection barrier, commitRowsOnIndexThread), so a slow
    // ffprobe pass can never overwrite newer index data. Lives on the GUI thread;
    // enrich() itself runs on a worker.
    auto *vaultEnricher = new VaultEnricher(vaultIndex, vaultDir, &backendServices);

    // The video duration + local-artwork pass. Chained AFTER the census-enrichment
    // lambda below completes (its finished handler / empty-todo return), so admission
    // verdicts are already durable and the enricher's probe-if-empty branch stays
    // cold. Row selection mirrors the census pass's video filter (present, not away,
    // not rejected); the work condition is the missing fact itself. Immersive gate
    // (VaultWatcher's debounceExpired pattern): never start while a player/reader is
    // open, cancel an in-flight pass between files, rerun the remainder on close.
    bool vaultVideoEnrichInFlight = false;
    bool vaultVideoEnrichRerun = false;
    std::shared_ptr<VaultKit::CancellationToken> vaultVideoEnrichCancel;
    auto runVaultVideoEnrichment = [vaultIndex, vaultEnricher, vaultLibrary,
                                    &vaultVideoEnrichInFlight, &vaultVideoEnrichRerun,
                                    &vaultVideoEnrichCancel]() {
        if (vaultVideoEnrichInFlight) {
            vaultVideoEnrichRerun = true; // one pass at a time; coalesce the later trigger
            return;
        }
        if (vaultLibrary->immersive()) {
            vaultVideoEnrichRerun = true; // deferred until the immersive surface closes
            return;
        }
        vaultVideoEnrichRerun = false;
        QList<VaultIndex::FileRow> todo;
#if !defined(Q_OS_ANDROID)
        for (const VaultIndex::FileRow& r : vaultIndex->rowsForKind(QStringLiteral("video"))) {
            if (!r.away && QDir(r.rootPath).exists() && QFileInfo::exists(r.path)
                && r.errorState != QLatin1String("rejected")
                && (r.durationSec <= 0.0 || r.coverRef.isEmpty()))
                todo.append(r);
        }
        if (todo.isEmpty())
            return;
        vaultVideoEnrichInFlight = true;
        vaultVideoEnrichCancel = std::make_shared<VaultKit::CancellationToken>();
        const VaultKit::CancellationToken* cancel = vaultVideoEnrichCancel.get();
        // ffprobe (kill-on-timeout, per file) and artwork header sniffs stay off the
        // GUI thread; enrich() hops its own single-batch write-back to the index owner.
        (void)QtConcurrent::run([vaultEnricher, todo, cancel]() {
            vaultEnricher->enrich(todo, cancel);
        });
#endif
    };
    // An immersive surface opening mid-pass cancels the pass between files (the probe
    // itself admits no cancellation; the enrich loop guard does) and reruns on close.
    QObject::connect(
        vaultEnricher, &VaultEnricher::progress, vaultLibrary,
        [&vaultVideoEnrichInFlight, &vaultVideoEnrichRerun, &vaultVideoEnrichCancel,
         vaultLibrary](int, int) {
            if (!vaultVideoEnrichInFlight || !vaultLibrary->immersive())
                return;
            vaultVideoEnrichRerun = true;
            if (vaultVideoEnrichCancel)
                vaultVideoEnrichCancel->cancel();
        });
    QObject::connect(
        vaultEnricher, &VaultEnricher::enrichmentFinished, vaultLibrary,
        [&vaultVideoEnrichInFlight, &vaultVideoEnrichRerun,
         &runVaultVideoEnrichment]() {
            vaultVideoEnrichInFlight = false;
            if (vaultVideoEnrichRerun)
                runVaultVideoEnrichment();
        });
    QObject::connect(
        vaultLibrary, &VaultLibrary::immersiveChanged, vaultLibrary,
        [vaultLibrary, &vaultVideoEnrichInFlight, &vaultVideoEnrichRerun,
         &runVaultVideoEnrichment]() {
            if (vaultLibrary->immersive() || vaultVideoEnrichInFlight || !vaultVideoEnrichRerun)
                return;
            runVaultVideoEnrichment();
        });

    // Vault cover enrichment (execution plan Slice 12): after a publish, read each comic's
    // CBZ cover ENTRY off the GUI thread (pure file I/O — VaultEnricher::readComicFacts, no
    // SQLite), then write the enriched rows back in ONE batch on the GUI thread so the shelf
    // tiles paint real covers via the already-registered image://comiccover provider. Video
    // durations + local artwork run in the instance-level VaultEnricher pass chained AFTER
    // this one (runVaultVideoEnrichment above) — never ffprobe on the GUI thread. An
    // index-revision guard drops stale enrichment after ANY superseding index mutation, so
    // scanner and watcher changes cannot be resurrected.
    auto runVaultCoverEnrichment = [vaultIndex, runVaultVideoEnrichment]() {
        // Capture the exact index snapshot this async work is derived from. Any successful
        // scanner publish, watcher reconciliation, away-state change, or other mutation advances
        // the revision and makes this worker's eventual write-back ineligible.
        const quint64 baseRevision = vaultIndex->revision();
        // Only comics still missing a cover — so a re-publish or a re-launch of an already
        // enriched library does no redundant CBZ reads (this returns nothing after the first pass).
        QList<VaultIndex::FileRow> todo;
        for (const VaultIndex::FileRow& r : vaultIndex->rowsForKind(QStringLiteral("comic"))) {
            if (!r.away && QDir(r.rootPath).exists() && QFileInfo::exists(r.path)
                && r.errorState.isEmpty() && r.coverRef.isEmpty())
                todo.append(r);
        }
#if !defined(Q_OS_ANDROID)
        for (const VaultIndex::FileRow& r : vaultIndex->rowsForKind(QStringLiteral("video"))) {
            if (!r.away && QDir(r.rootPath).exists() && QFileInfo::exists(r.path)
                && r.errorState != QLatin1String("rejected")
                && r.admissionVerdict.isEmpty())
                todo.append(r);
        }
#endif
        for (const VaultIndex::FileRow& r : vaultIndex->rowsForKind(QStringLiteral("book"))) {
            if (!r.away && QDir(r.rootPath).exists() && QFileInfo::exists(r.path)
                && QFileInfo(r.path).suffix().compare(QStringLiteral("epub"), Qt::CaseInsensitive) == 0
                && r.errorState.isEmpty() && r.metadataSource.isEmpty())
                todo.append(r);
        }
        if (todo.isEmpty()) {
            // A zero-work newer publication still advanced VaultIndex::revision(); the
            // video duration/artwork pass still owes its chained turn (S5).
            runVaultVideoEnrichment();
            return;
        }
        auto *watcher = new QFutureWatcher<QList<VaultIndex::FileRow>>(vaultIndex);
        QObject::connect(
            watcher, &QFutureWatcher<QList<VaultIndex::FileRow>>::finished, vaultIndex,
            [vaultIndex, watcher, baseRevision, runVaultVideoEnrichment]() {
                const QList<VaultIndex::FileRow> enriched = watcher->result();
                watcher->deleteLater();
                // Conditional write-back is the resurrection barrier: stale workers cannot
                // reinsert rows after a scanner publish OR a live watcher deletion/replacement.
                vaultIndex->upsertManyIfRevision(enriched, baseRevision);
                // S5: video durations + local artwork run only after this census commit
                // landed, so admission verdicts are durable before the enricher re-reads.
                runVaultVideoEnrichment();
            });
        watcher->setFuture(QtConcurrent::run([todo]() {
            QList<VaultIndex::FileRow> out;
            out.reserve(todo.size());
            for (VaultIndex::FileRow r : todo) {
                if (r.kind == QLatin1String("comic")) {
                    const VaultEnricher::ComicFacts cf = VaultEnricher::readComicFacts(r.path);
                    if (cf.ok) {
                        r.pages = cf.pages;
                        r.coverRef = cf.coverEntry;
                        r.errorState.clear();
                        r.errorDetail.clear();
                    } else {
                        r.errorState = QStringLiteral("corrupt");
                        r.errorDetail = cf.errorDetail;
                    }
                }
#if !defined(Q_OS_ANDROID)
                else if (r.kind == QLatin1String("video")) {
                    const MediaAdmissionProbe::Result admission =
                        MediaAdmissionProbe::probe(r.path);
                    switch (admission.verdict) {
                    case MediaAdmissionProbe::Verdict::Admitted:
                        r.admissionVerdict = QStringLiteral("Admitted");
                        break;
                    case MediaAdmissionProbe::Verdict::RejectedNoVideo:
                        r.admissionVerdict = QStringLiteral("RejectedNoVideo");
                        break;
                    case MediaAdmissionProbe::Verdict::RejectedError:
                        r.admissionVerdict = QStringLiteral("RejectedError");
                        break;
                    case MediaAdmissionProbe::Verdict::RejectedTimeout:
                        r.admissionVerdict = QStringLiteral("RejectedTimeout");
                        break;
                    }
                    r.admissionDetail = admission.detail;
                    if (admission.verdict == MediaAdmissionProbe::Verdict::Admitted) {
                        r.errorState.clear();
                        r.errorDetail.clear();
                    } else {
                        r.errorState = QStringLiteral("rejected");
                        r.errorDetail = admission.detail;
                    }
                }
#endif
                else if (r.kind == QLatin1String("book")) {
                    r.format = QFileInfo(r.path).suffix().toLower();
                    const VaultEnricher::BookFacts book = VaultEnricher::readBookFacts(r.path);
                    if (book.ok) {
                        if (!book.title.isEmpty())
                            r.displayTitle = book.title;
                        r.author = book.author;
                        r.synopsis = book.synopsis;
                        r.coverRef = book.coverEntry;
                        r.metadataSource = QStringLiteral("EPUB");
                        r.errorState.clear();
                        r.errorDetail.clear();
                    } else {
                        r.errorState = QStringLiteral("corrupt");
                        r.errorDetail = book.errorDetail;
                    }
                }
                out.append(r);
            }
            return out;
        }));
    };
    QObject::connect(vaultScanner, &VaultScanner::indexPublished, vaultLibrary,
                     [runVaultCoverEnrichment]() { runVaultCoverEnrichment(); });
    // Enrich an already-indexed library once at boot too, so covers appear on a relaunch
    // without re-adding the folder (a fresh index published this run enriches via the signal).
    runVaultCoverEnrichment();
#endif

    // Torrent stream engine (Stremio sidecar) exposed to QML as `Stream`. Lazy: the
    // runtime only spawns on the first Stream.play() call.
    auto *stream = new StreamServer(&backendServices);
    engine.rootContext()->setContextProperty(QStringLiteral("Stream"), stream);
#ifdef Q_OS_ANDROID
    // Opt-in Nuvio playback backend lifecycle: gate new torrent work on the
    // app state PlatformRuntime already owns (quiesce in the background,
    // reconstruct fresh engine state on the next explicit foreground demand).
    // The startup warmUp() call below stays a no-op on Android: the backend
    // is born only on an explicit play()/prefetch(), never at launch.
    // QML lifecycle handlers run before the coordinator installed below; a re-demand
    // they issue reads the live state rather than racing this slot.
    stream->setForegroundProbe([platformRuntime]() { return platformRuntime->foreground(); });
#endif
    // Warm the torrent engine shortly AFTER the window is up -- not during launch, and no longer
    // lazily on the first play. Lazy-on-play made every session pay the engine's cold start (DHT
    // bootstrap + tracker announce + handshake + unchoke) at the exact moment Play was pressed, which
    // is why one torrent play was instant and the next -- same file, same ~100 seeders -- took
    // minutes. The 3s delay keeps it off the cold-launch critical path; adopt-first means an
    // already-running official Stremio Service is adopted rather than clashed with. Cost accepted
    // knowingly: a comics- or books-only session spawns a runtime it never uses, but any video
    // session would have spawned it seconds later anyway. (2026-07-30, Theatre lane)
    QTimer::singleShot(3000, stream, [stream]() { stream->warmUp(); });

    // Audiobook download backbone exposed to QML as `Audiobooks`. BookDownloader
    // lineage, but multi-file and Stremio-fed: a book's paired audiobook torrent
    // (from AudioBookBay) downloads its audio files to <appdata>/audiobooks, keyed
    // by pairKey so the book page flips to "Listen". Needs the Stream engine above.
    auto *audiobooks = new AudiobookDownloader(dlNam, stream, &backendServices);
    engine.rootContext()->setContextProperty(QStringLiteral("Audiobooks"), audiobooks);

    // ── Tankorent engine (Phase 2 — books consume it) ───────────────────────
    // One engine per job (spec 2026-07-13): Stremio keeps watch-now; this
    // embedded libtorrent engine owns download-to-keep. BookTorrents is its
    // first consumer — it lazy-start()s the engine on the first book download,
    // so an idle app still touches no network (born-asleep, 4fbb1c2). Manga
    // volumes join in Phase 3. Session/resume state under Colosseum's OWN
    // appdata; download-and-stop seeding posture (pause 1 s after seeding).
    const QString torrentEngineDir =
        QStandardPaths::writableLocation(QStandardPaths::AppDataLocation)
        + QStringLiteral("/torrent-engine");
    QDir().mkpath(torrentEngineDir);
    auto *torrentEngine = new TorrentEngine(torrentEngineDir, &backendServices);
    torrentEngine->setGlobalSeedingRules(0.f, 1);

    // Book torrents shelf (Biblio): federated indexer search + engine-fed single-file pull.
    // searchNam = pinned + UA-stamped + UNCACHED CachingNam (live seeder counts, no stale
    // cache); torrentEngine carries the download bytes. pinnedHosts/ipv4ByHost include the
    // 3 indexers.
    auto *searchNam = new CachingNam(pinnedHosts, pinStore, &backendServices, /*useCache=*/false);

    // Comics keeps one public reader/download identity (`Comics`) while privately
    // composing torrent search + archive download with its proven extraction/index.
    auto *comics = new ComicDownloader(dlNam, searchNam, torrentEngine, &backendServices);
    engine.rootContext()->setContextProperty(QStringLiteral("Comics"), comics);
    if (qEnvironmentVariableIsSet("COLOSSEUM_COMIC_DLTEST"))
        comics->selfTest(qEnvironmentVariable("COLOSSEUM_COMIC_DLTEST"));

    // Data-vault adoption Slice 2 (2026-08-22): each of the four catalogue seams below
    // resolves its db through the SAME ladder MalCatalog's constructor always used —
    // relative dev path, then applicationDirPath()/../../ — before falling back to the
    // per-user AppData vault directory that CatalogVaultClient (Slice 1, 085c1b0) keeps
    // fresh from the public Colosseum-Data GitHub release. A name that resolves via the
    // dev ladder is "dev-overridden": CatalogVaultClient never fetches it (see
    // setManagedNames below), so a dev machine with all four data/*.db files present
    // behaves byte-identically to before this slice — the vault client does no network
    // work at all in that case.
    const QString catalogVaultDir =
        QStandardPaths::writableLocation(QStandardPaths::AppDataLocation)
        + QStringLiteral("/catalog-vault");
    struct CatalogPathResolution { QString path; bool devOverridden; };
    auto resolveCatalogPath = [&catalogVaultDir](const QString& relDevPath,
                                                  const QString& assetName) {
        QString path = relDevPath;
        bool exists = QFileInfo::exists(path);
        if (!exists) {
            const QString beside = QCoreApplication::applicationDirPath()
                                   + QStringLiteral("/../../") + relDevPath;
            if (QFileInfo::exists(beside)) { path = beside; exists = true; }
        }
        if (exists)
            return CatalogPathResolution{path, true};
        return CatalogPathResolution{catalogVaultDir + QLatin1Char('/') + assetName, false};
    };

    const CatalogPathResolution comicsRes =
        resolveCatalogPath(QStringLiteral("data/comics_catalog.db"), QStringLiteral("comics_catalog.db"));
    const CatalogPathResolution malRes =
        resolveCatalogPath(QStringLiteral("data/mal_catalog.db"), QStringLiteral("mal_catalog.db"));
    const CatalogPathResolution tankobanRes =
        resolveCatalogPath(QStringLiteral("data/tankoban_catalog.db"), QStringLiteral("tankoban_catalog.db"));
    const CatalogPathResolution imdbRes =
        resolveCatalogPath(QStringLiteral("data/imdb_catalog.db"), QStringLiteral("imdb_catalog.db"));

    QUrl contentEndpoint;
#ifdef COLOSSEUM_CONTENT_API_URL
    contentEndpoint = QUrl(QStringLiteral(COLOSSEUM_CONTENT_API_URL));
#endif
    // Opt-in loopback qualification of the actual app, never the daily profile.
    // No arbitrary remote origin, visible window, default IPC or account override.
    const QString testCatalogueOrigin = qEnvironmentVariable("COLOSSEUM_TEST_CATALOGUE_ORIGIN");
    if (!testCatalogueOrigin.isEmpty()) {
        const QUrl testOrigin(testCatalogueOrigin);
        const bool isolatedFixture = isolatedAppData
            && qEnvironmentVariable("COLOSSEUM_APPDATA_TAG").startsWith(QLatin1String("i05-static-"))
            && qEnvironmentVariable("COLOSSEUM_LANISTA_PIPE").startsWith(QLatin1String("i05-static-"))
            && qEnvironmentVariableIntValue("COLOSSEUM_LANISTA_DRIVE") == 1
            && qEnvironmentVariable("QT_QPA_PLATFORM") == QLatin1String("offscreen");
        if (!isolatedFixture || !testOrigin.isValid() || testOrigin.scheme() != QLatin1String("http")
            || testOrigin.host() != QLatin1String("127.0.0.1") || testOrigin.port() <= 0
            || !testOrigin.userInfo().isEmpty() || !testOrigin.path().isEmpty()
            || !testOrigin.query().isEmpty() || !testOrigin.fragment().isEmpty())
            qFatal("Invalid isolated static catalogue qualification origin");
        contentEndpoint = testOrigin;
        if (qEnvironmentVariableIntValue("COLOSSEUM_TEST_CATALOGUE_OFFLINE") == 1) {
            // The fixture controller stops its own listener before this run.
            const QNetworkProxy offlineProxy(QNetworkProxy::HttpProxy,
                testOrigin.host(), quint16(testOrigin.port()));
            QNetworkProxy::setApplicationProxy(offlineProxy);
            catalogNam->setProxy(offlineProxy);
            qInfo("I05_OFFLINE process HTTP proxy points at the stopped fixture listener");
        }
        QObject::connect(catalogNam, &QNetworkAccessManager::finished, &backendServices,
            [](QNetworkReply* reply) {
                qInfo().noquote() << "I05_NETWORK" << reply->url().host() << reply->url().path()
                    << reply->attribute(QNetworkRequest::HttpStatusCodeAttribute).toInt();
            });
    }
    const bool contentApiConfigured = contentEndpoint.isValid() && !contentEndpoint.isEmpty()
        && contentEndpoint.userInfo().isEmpty() && contentEndpoint.query().isEmpty()
        && contentEndpoint.fragment().isEmpty() && (contentEndpoint.scheme() == QLatin1String("https")
            || (contentEndpoint.scheme() == QLatin1String("http")
                && (contentEndpoint.host() == QLatin1String("127.0.0.1") || contentEndpoint.host() == QLatin1String("localhost"))));
    // A configured API owns catalogue delivery, including upgrades retaining old DBs.
    // Existing local files are preserved but cannot shadow server revisions.

    // Availability-first SQLite catalogue (spec 2026-07-17): read-only seam; the db
    // is pipeline-deployed to data/ (cwd = repo root) on dev machines, vault-fed elsewhere.
    auto *comicsCatalog = new ComicsCatalog(contentApiConfigured ? QString() : comicsRes.path, &backendServices);
    engine.rootContext()->setContextProperty(QStringLiteral("ComicsCatalog"), comicsCatalog);

    // Baked MyAnimeList catalog (genre-page revival 2026-07-18): same doctrine —
    // read-only seam, script-built db in data/, dormant when absent (live ladder runs).
    auto *malCatalog = new MalCatalog(contentApiConfigured ? QString() : malRes.path, &backendServices);
    engine.rootContext()->setContextProperty(QStringLiteral("MalCatalog"), malCatalog);

    // Baked Tankoban volume catalogue (catalogue-independence Slice 1, 2026-08-20): same
    // doctrine as MalCatalog — read-only seam, script-built db in data/, dormant when absent.
    auto *tankobanCatalog = new TankobanCatalog(tankobanRes.path, &backendServices);
#ifdef COLOSSEUM_CONTENT_API_URL
    tankobanCatalog->configureRemote(catalogNam, contentEndpoint,
                                    catalogVaultDir + QStringLiteral("/tankoban_remote_v1.json"));
#endif
    engine.rootContext()->setContextProperty(QStringLiteral("TankobanCatalog"), tankobanCatalog);
    auto* imdbCatalog = new ImdbCatalog(contentApiConfigured ? QString() : imdbRes.path, &backendServices);
    engine.rootContext()->setContextProperty(QStringLiteral("ImdbCatalog"), imdbCatalog);

    if (contentApiConfigured) {
        comicsCatalog->configureRemote(catalogNam, contentEndpoint, catalogVaultDir + QStringLiteral("/comics_api_v1.json"));
        malCatalog->configureRemote(catalogNam, contentEndpoint, catalogVaultDir + QStringLiteral("/mal_api_v1.json"));
        imdbCatalog->configureRemote(catalogNam, contentEndpoint, catalogVaultDir + QStringLiteral("/imdb_api_v1.json"));
    }
    auto* sourceContent = new SourceContentStore(&backendServices);
    sourceContent->configure(catalogNam, contentEndpoint, catalogVaultDir + QStringLiteral("/content_api_v1.json"),
                             QDir::current().filePath(QStringLiteral("assets/content-starter/bundle.json")));
    engine.rootContext()->setContextProperty(QStringLiteral("Content"), sourceContent);
    // configure() synchronizes the bundle through the shared freshness policy.
    // A second forced boot refresh would revalidate even a just-checked cache.
    auto* contentRefreshTimer = new QTimer(sourceContent);
    contentRefreshTimer->setInterval(15 * 60 * 1000);
    QObject::connect(contentRefreshTimer, &QTimer::timeout, sourceContent, [&app, sourceContent] {
        if (app.applicationState() == Qt::ApplicationActive) sourceContent->refresh();
    });
    contentRefreshTimer->start();


#if !defined(Q_OS_ANDROID)
    auto *vaultIdentifier = new VaultIdentifier(vaultIndex, comicsCatalog, malCatalog,
                                                 imdbCatalog, &backendServices);
    vaultLibrary->setIdentifier(vaultIdentifier);
#endif

    // CatalogVaultClient (Slice 1) only manages the names that did NOT resolve via a
    // dev-machine override above. On Hemanth's dev machine, all four data/*.db files are
    // present, so this list — and the client's network work — is empty.
    QStringList catalogManagedNames;
    if (!comicsRes.devOverridden) catalogManagedNames << QStringLiteral("comics_catalog.db");
    if (!malRes.devOverridden) catalogManagedNames << QStringLiteral("mal_catalog.db");
    if (!tankobanRes.devOverridden) catalogManagedNames << QStringLiteral("tankoban_catalog.db");
    if (!imdbRes.devOverridden) catalogManagedNames << QStringLiteral("imdb_catalog.db");

    // Data-vault Slice 4 (2026-08-22) fix: this used to pass `{}` for apiBaseUrl, which
    // is an EXPLICIT empty QString, not "omitted" — C++ default arguments only apply when
    // the parameter is left out entirely, so the header's real default
    // (https://api.github.com/repos/kingoftheseas56/Colosseum-Data, CatalogVaultClient.h)
    // was silently discarded and every fetchManifest() request hit a bare "/releases/latest"
    // URL. On a dev machine (all four data/*.db present) this never showed: checkAndFetch()
    // takes the zero-network devOverridden branch before ever building a request. Caught
    // live in Slice 4's first-launch runtime session (an empty AppData + no reachable
    // data/ never fetched at all — WAIT_TIMEOUT on catalogVaultState.fetching==true).
    auto *catalogVaultClient = new CatalogVaultClient(catalogNam, catalogVaultDir,
        QStringLiteral("https://api.github.com/repos/kingoftheseas56/Colosseum-Data"), &backendServices);
    // API builds never recover from outages by downloading a whole catalogue
    // through GitHub REST. Empty is an explicitly managed empty set.
#ifdef COLOSSEUM_CONTENT_API_URL
    catalogManagedNames.clear();
#endif
    catalogVaultClient->setManagedNames(catalogManagedNames);
    // This follows validated configuration, never request health: API outages must
    // keep using cached/local Tankoban data without reviving the GitHub bulk download.
    catalogVaultClient->setTankobanApiEnabled(tankobanCatalog->remoteEnabled());
    engine.rootContext()->setContextProperty(QStringLiteral("CatalogVault"), catalogVaultClient);

    // aboutToReplace fires synchronously right before a fresh download is renamed over an
    // existing target — the matching catalog closes its SQLite handle in that instant so
    // the Windows rename can succeed. databaseUpdated fires right after, so the catalog
    // reopens at the (now current) path and starts answering queries again. Both are
    // effectively no-ops for a dev-overridden catalog, since CatalogVaultClient never
    // fetches that name (excluded from setManagedNames above).
    QObject::connect(catalogVaultClient, &CatalogVaultClient::aboutToReplace, &app,
                     [comicsCatalog, malCatalog, tankobanCatalog, imdbCatalog](const QString& name) {
        if (name == QStringLiteral("comics_catalog.db")) comicsCatalog->closeForSwap();
        else if (name == QStringLiteral("mal_catalog.db")) malCatalog->closeForSwap();
        else if (name == QStringLiteral("tankoban_catalog.db")) tankobanCatalog->closeForSwap();
        else if (name == QStringLiteral("imdb_catalog.db")) imdbCatalog->closeForSwap();
    });
    QObject::connect(catalogVaultClient, &CatalogVaultClient::databaseUpdated, &app,
                     [comicsCatalog, malCatalog, tankobanCatalog, imdbCatalog](const QString& name, const QString& path) {
        if (name == QStringLiteral("comics_catalog.db")) comicsCatalog->reopen(path);
        else if (name == QStringLiteral("mal_catalog.db")) malCatalog->reopen(path);
        else if (name == QStringLiteral("tankoban_catalog.db")) tankobanCatalog->reopen(path);
        else if (name == QStringLiteral("imdb_catalog.db")) imdbCatalog->reopen(path);
    });

    // A failed pass (an offline first launch, a transfer that died while the app was in the
    // background) used to stay failed until the next app start, leaving Discover empty with no
    // trace in the log. The client schedules nothing itself (its contract), so the retry lives
    // here: 30 s, doubling, five tries per run.
    auto *catalogVaultRetry = new QTimer(catalogVaultClient);
    catalogVaultRetry->setSingleShot(true);
    QObject::connect(catalogVaultRetry, &QTimer::timeout,
                     catalogVaultClient, &CatalogVaultClient::checkAndFetch);
    const auto catalogVaultAttempts = std::make_shared<int>(0);
    QObject::connect(catalogVaultClient, &CatalogVaultClient::fetchFailed, &app,
                     [catalogVaultRetry, catalogVaultAttempts](const QString& name, const QString& error) {
        qWarning("[catalog-vault] fetch failed (%s): %s", qUtf8Printable(name), qUtf8Printable(error));
        if (*catalogVaultAttempts >= 5) return;
        catalogVaultRetry->start(30000 << (*catalogVaultAttempts)++);
    });
    QObject::connect(catalogVaultClient, &CatalogVaultClient::allFresh, &app,
                     [catalogVaultAttempts](const QString&) { *catalogVaultAttempts = 0; });

    // Kick once, off the cold-launch critical path — never blocks boot. A no-op (zero
    // network) when every catalog is dev-overridden, per the comment above.
    QTimer::singleShot(0, catalogVaultClient, [catalogVaultClient] { catalogVaultClient->checkAndFetch(); });

#if !defined(Q_OS_ANDROID)
    // Agent Visibility Phase 2, Slice F1-Bridge: the live, app-owned Vault forensic
    // projection (F1-Core). Composes vaultLibrary only (F0's named safe seam,
    // docs/visibility/vault-forensic-owner-thread.md §10) — no second SQLite
    // connection, no writer. Parented to &app like every other Vault object (F0 §1),
    // so it shares vaultLibrary's GUI-thread lifetime; wired into LanistaServer below.
    VaultForensics vaultForensicsStorage(vaultLibrary, &app);
    auto *vaultForensics = &vaultForensicsStorage;
#endif

    // BiblioCatalog Discover/Explore keyless daily refresh service (spec
    // 2026-08-01, plan 2026-08-03 Task 4): a writable per-user SQLite cache
    // (unlike the pipeline-deployed read-only catalogues above), refreshed at
    // most once a local day from Apple Books + Open Library. Construction
    // never blocks startup: a prior day's cached snapshot (if any) is already
    // browsable through BiblioCatalog.ready/discoverPage before the first
    // network reply lands, and refreshIfDue() is fire-and-forget. The refresh
    // coordinator is started after first paint below: its synchronous
    // SQLite/enqueue bookkeeping does not belong on the cold-launch path.
    const QString biblioCatalogPath =
        QStandardPaths::writableLocation(QStandardPaths::AppDataLocation)
        + QStringLiteral("/catalog/biblio-v1.sqlite");
    auto *biblioCatalog = new BiblioCatalog(biblioCatalogPath, nullptr, &backendServices);
    engine.rootContext()->setContextProperty(QStringLiteral("BiblioCatalog"), biblioCatalog);

    auto *bookTorrents = new BookTorrents(searchNam, torrentEngine, &backendServices);
    engine.rootContext()->setContextProperty(QStringLiteral("BookTorrents"), bookTorrents);

    // Tankoban "volume mode" façade exposed to QML as `TankobanVolumes` (Task 8).
    // ONE object composes the whole volume lifecycle: Nyaa search over the pinned
    // uncached searchNam, per-volume download through the shared TorrentEngine
    // (wrapped in a queued IMangaTorrentEngine adapter built inside), the
    // WeebCentral chapter-pack fallback + synopsis enrichment over the plain
    // dlNam, and ingestion into a durable local index under AppDataLocation.
    auto *tankobanVolumes = new MangaTankobanService(searchNam, dlNam, torrentEngine, QString(), &backendServices);
    engine.rootContext()->setContextProperty(QStringLiteral("TankobanVolumes"), tankobanVolumes);
    if (qEnvironmentVariableIsSet("COLOSSEUM_TANKOBAN_DLTEST")) {
        // Honest end-to-end self-test (Task 11). Spec:
        //   "<magnet-or-infohash>|<seriesId>|<seriesTitle>|<volumeNumber>".
        // Drives search-cache-bypassed download → ingest → index and exits 0 on
        // ready pages / 2 on any failure (240 s backstop). Mirrors the
        // COLOSSEUM_COMIC_DLTEST / COLOSSEUM_TORRENT_DLTEST self-test idiom above.
        // Never runs unless the env var is set (an idle app touches no network).
        tankobanVolumes->runDownloadSelfTest(
            qEnvironmentVariable("COLOSSEUM_TANKOBAN_DLTEST"));
    }

    if (qEnvironmentVariableIsSet("COLOSSEUM_COMIC_PACK_DLTEST")) {
        // Honest end-to-end self-test (Task 11) for the Tankorent Comic
        // shared-infohash pack-selection transport. Spec:
        //   "<scenario>|<magnet>|<fixture-id>[|<fixture-id2>]"
        // scenario in {single, issues, shared, restart}. Drives the REAL
        // production downloadTorrentEdition() path against a legal loopback
        // seeder (tests/comic_torrent_pack_seed_harness.cpp), prints
        // "COMIC_PACK_<SCENARIO>_DONE pages=<n> [groups=<n>]" and exits 0, or
        // "[comic-pack-dltest] FAIL <reason>" and exits 2. Mirrors the
        // COLOSSEUM_TANKOBAN_DLTEST self-test idiom above. Never runs unless
        // the env var is set.
        comics->runPackSelfTest(qEnvironmentVariable("COLOSSEUM_COMIC_PACK_DLTEST"));
    }

    if (qEnvironmentVariableIsSet("COLOSSEUM_ABB_DLTEST")) {
        const QString spec = qEnvironmentVariable("COLOSSEUM_ABB_DLTEST");   // "<pairKey>|<infoHash>"
        const int bar = spec.lastIndexOf(QChar('|'));
        if (bar > 0) audiobooks->selfTest(spec.left(bar), spec.mid(bar + 1));
    }

    // Dev smoke: which book-torrent indexers still work? Runs on the SAME pinned +
    // UA-stamped + UNCACHED NAM production uses, so a slow-but-alive indexer isn't
    // falsely declared dead by an unpinned IPv6 stall. Ends on searchFinished.
    if (qEnvironmentVariableIsSet("COLOSSEUM_TORRENT_SEARCHTEST")) {
        auto *smokeNam = new CachingNam(pinnedHosts, pinStore, &backendServices, /*useCache=*/false);
        auto *svc = new TankorentSearchService(smokeNam, &backendServices);
        svc->selfTest(qEnvironmentVariable("COLOSSEUM_TORRENT_SEARCHTEST"));
        QTimer::singleShot(45000, &app, &QCoreApplication::quit);   // hard backstop only
    }
    if (qEnvironmentVariableIsSet("COLOSSEUM_TORRENT_DLTEST")) {
        // Book lane: "<infoHash>|<title>". Comics end-to-end lane:
        // "<infoHash>|<series title>|<edition title>" -> archive -> extract -> localPages.
        const QStringList a = qEnvironmentVariable("COLOSSEUM_TORRENT_DLTEST").split(QChar('|'));
        if (a.size() == 3) {
            comics->selfTestTorrent(a[0], a[1], a[2]);
        } else if (a.size() == 2) {
            auto* dl = new BookTorrentDownloader(torrentEngine, &backendServices);
            dl->selfTest(a[0], a[1]);
        }
        QTimer::singleShot(240000, &app, []() {   // >= live gate's 240s DHT wait
            qWarning() << "[bt-dl] FAIL timeout — no DONE/FAIL after 240s";
            QCoreApplication::exit(2);            // honest failing verdict, never a silent exit-0 green
        });
    }

    // Cast session state exposed to QML as `Cast`. Network discovery/control is the
    // later backend; this slice gives the player real device/session state today.
    auto *cast = new CastStore(&backendServices);
    engine.rootContext()->setContextProperty(QStringLiteral("Cast"), cast);

    // Current-player video download state exposed to QML as `Download`.
    auto *download = new DownloadStore(&backendServices);
    engine.rootContext()->setContextProperty(QStringLiteral("Download"), download);
    if (qEnvironmentVariableIsSet("COLOSSEUM_VIDEOQ_SELFTEST"))
        download->selfTest(qEnvironmentVariable("COLOSSEUM_VIDEOQ_SELFTEST"));

    // Unified downloads read-model exposed to QML as `LocalDownloads` — the
    // Downloads page renders this; every mutation still routes to the owning
    // backend (Downloads / Books / Comics / Download).
    auto *localDownloads = new LocalDownloads(downloads, books, comics, download,
                                              tankobanVolumes, &backendServices);
    engine.rootContext()->setContextProperty(QStringLiteral("LocalDownloads"), localDownloads);

    // OS-facing download progress seam. Android owns the notification/service
    // implementation; Colosseum publishes only the unified active-job snapshot.
    auto *platformDownloads = new Colosseum::Platform::BackgroundDownloadBridge(
        localDownloads, &app);
    engine.rootContext()->setContextProperty(
        QStringLiteral("PlatformDownloads"), platformDownloads);

#ifdef Q_OS_ANDROID
    const auto syncVideoForeground = [platformRuntime, platformDownloads, stream, download]() {
        const bool foreground = platformRuntime->foreground();
        platformDownloads->setForeground(foreground);
        const bool backgroundAllowed = platformDownloads->backgroundHostReady();
        const bool videoDownloadAllowed = backgroundAllowed && platformDownloads->videoRunningCount() > 0;
        if (foreground) {
            stream->setForeground(true);
            stream->setBackgroundDownloadsActive(videoDownloadAllowed);
            download->setForeground(true);
            download->setBackgroundExecutionAllowed(backgroundAllowed);
        } else {
            // Grant the backend before resumed resolution can ask for a route.
            if (videoDownloadAllowed) stream->setBackgroundDownloadsActive(true);
            download->setBackgroundExecutionAllowed(backgroundAllowed);
            download->setForeground(false);
            // Withdraw OS permission only after HTTP partials have been parked.
            if (!videoDownloadAllowed) stream->setBackgroundDownloadsActive(false);
            stream->setForeground(false);
        }
        // Completion/cancel can precede the service's asynchronous startup.
        // Release the download route even when no OS lease was ever granted.
        if (platformDownloads->videoRunningCount() == 0) stream->stopFetchDemand();
    };
    QObject::connect(platformRuntime,
                     &Colosseum::Platform::Runtime::applicationStateChanged,
                     stream, syncVideoForeground);
    QObject::connect(platformDownloads,
                     &Colosseum::Platform::BackgroundDownloadBridge::hostStateChanged,
                     stream, syncVideoForeground, Qt::QueuedConnection);
    QObject::connect(platformDownloads,
                     &Colosseum::Platform::BackgroundDownloadBridge::changed,
                     stream, syncVideoForeground, Qt::QueuedConnection);
    syncVideoForeground();
#endif

#if !defined(Q_OS_ANDROID)
    // Slice 18 — the synthetic downloads root: derives VaultIndex::FileRows from
    // Colosseum's own download backbones (videos + CBZ comics + CBZ tankoban
    // volumes + epub/pdf books) so the Vault shelves them as ONE quiet, pre-
    // confirmed trusted root. The path is a logical identifier (the rows come
    // from the backbones, NOT a filesystem scan), pinned under AppData.
    auto *vaultDownloadsRoot = new VaultDownloadsRoot(download, books, comics,
                                                      tankobanVolumes, &backendServices);
    const QString vaultDownloadsRootPath =
        QStandardPaths::writableLocation(QStandardPaths::AppDataLocation)
        + QStringLiteral("/downloads");
    vaultLibrary->setDownloadsRoot(vaultDownloadsRoot, vaultDownloadsRootPath);
    // Heal stale derived Vault rows once per process after every download backbone is wired.
    QTimer::singleShot(0, vaultLibrary, [vaultLibrary]() { vaultLibrary->republishAtBoot(); });
#endif

    // Extension registry (Stremio-protocol addons) exposed to QML as `Extensions`.
    // Spec: Brotherhood docs/superpowers/specs/2026-07-05-colosseum-extensions-store-design.md.
    // Shares the plain uncached NAM — manifests are small JSON, never cache-served.
    auto *extensions = new ExtensionsStore(dlNam, &backendServices);
    engine.rootContext()->setContextProperty(QStringLiteral("Extensions"), extensions);

    // dev harness: COLOSSEUM_OPEN_EXTENSIONS=1 boots straight into the store, so
    // smoke runs exercise the page Loader (QML errors only surface on activation).
    engine.rootContext()->setContextProperty(
        QStringLiteral("DevOpenExtensions"),
        qEnvironmentVariableIsSet("COLOSSEUM_OPEN_EXTENSIONS"));
    // dev harness: COLOSSEUM_STREAMS_SELFTEST="movie|tt0816692" runs the multi-
    // extension stream ask headlessly at boot and logs row counts per extension.
    engine.rootContext()->setContextProperty(
        QStringLiteral("DevStreamsSelfTest"),
        qEnvironmentVariable("COLOSSEUM_STREAMS_SELFTEST"));
    // dev harness: COLOSSEUM_CATALOG_SELFTEST="movies" logs a tab's rows (house +
    // extension shelves) headlessly at boot.
    engine.rootContext()->setContextProperty(
        QStringLiteral("DevCatalogSelfTest"),
        qEnvironmentVariable("COLOSSEUM_CATALOG_SELFTEST"));
    // dev harness: COLOSSEUM_OPEN_WORLD="Theatre" boots straight into a world.
    engine.rootContext()->setContextProperty(
        QStringLiteral("DevOpenWorld"),
        qEnvironmentVariable("COLOSSEUM_OPEN_WORLD"));
    // dev harness: COLOSSEUM_OPEN_UNIVERSE="starwars" boots straight into a universe.
    engine.rootContext()->setContextProperty(
        QStringLiteral("DevOpenUniverse"),
        qEnvironmentVariable("COLOSSEUM_OPEN_UNIVERSE"));
    // bakeoff harness (long-strip reader bakeoff, spec 2026-07-15): point
    // COLOSSEUM_BAKEOFF_STRIP at an extracted fixture page directory and the shell
    // boots a page-only MangaReader over those exact bytes. Adapter only — the
    // production reader component and its scroll behavior are untouched.
    {
        const QString bakeoffDir = qEnvironmentVariable("COLOSSEUM_BAKEOFF_STRIP");
        QVariantList bakeoffPages;
        if (!bakeoffDir.isEmpty()) {
            QDir dir(bakeoffDir);
            const QStringList names = dir.entryList(
                QStringList() << QStringLiteral("*.jpg") << QStringLiteral("*.jpeg")
                              << QStringLiteral("*.png") << QStringLiteral("*.webp"),
                QDir::Files, QDir::Name);
            int idx = 0;
            for (const QString& name : names) {
                QVariantMap page;
                page[QStringLiteral("index")] = idx++;
                page[QStringLiteral("url")] =
                    QUrl::fromLocalFile(dir.absoluteFilePath(name)).toString();
                page[QStringLiteral("group")] = -1;
                bakeoffPages.append(page);
            }
            qInfo() << "[bakeoff] strip fixture pages:" << bakeoffPages.size()
                    << "from" << bakeoffDir;
        }
        engine.rootContext()->setContextProperty(
            QStringLiteral("DevBakeoffStripPages"), bakeoffPages);
    }
    // dev harness: COLOSSEUM_SUBS_SELFTEST="movie|tt0111161" logs subtitle rows
    // per source (multi-well proof) headlessly at boot.
    engine.rootContext()->setContextProperty(
        QStringLiteral("DevSubsSelfTest"),
        qEnvironmentVariable("COLOSSEUM_SUBS_SELFTEST"));

    // Live TV / DVR player state exposed to QML as `Live`.
    auto *live = new LiveStore(&backendServices);
    engine.rootContext()->setContextProperty(QStringLiteral("Live"), live);

    // Shared background-work spine: ONE coordinator (one worker) for every adopted
    // offline-analysis producer. The registry is the QML-facing activity/control surface
    // and is bound to the same scheduler so pause/resume cannot terminate in presentation.
    auto *backgroundWork = new work::BackgroundWorkCoordinator(1, &backendServices);
    auto *backgroundActivity = new work::BackgroundActivityRegistry(&backendServices);
    backgroundActivity->setCoordinator(backgroundWork);
    engine.rootContext()->setContextProperty(QStringLiteral("BackgroundActivity"),
                                             backgroundActivity);

    // Foreground-priority governor: direct user input gets a 350 ms latency-sensitive
    // lease; immersive player/reader ownership dominates as Suspended. One reasoned
    // pressure signal fans out to every adopted background seam.
    auto *foregroundPriority = new work::ForegroundPriorityGovernor(350, &backendServices);
    app.installEventFilter(foregroundPriority);
    engine.rootContext()->setContextProperty(QStringLiteral("ForegroundPriority"),
                                             foregroundPriority);
    QObject::connect(foregroundPriority, &work::ForegroundPriorityGovernor::pressureChanged,
                     &app, [backgroundWork, biblioCatalog,
#if !defined(Q_OS_ANDROID)
                            vaultLibrary,
#endif
                            catalogVaultClient](int pressure) {
        work::Pressure nativePressure = work::Pressure::Normal;
        if (pressure >= work::ForegroundPriorityGovernor::Suspended)
            nativePressure = work::Pressure::Suspended;
        else if (pressure >= work::ForegroundPriorityGovernor::LatencySensitive)
            nativePressure = work::Pressure::LatencySensitive;
        backgroundWork->setPressure(nativePressure);

        const bool foregroundBusy = pressure >= work::ForegroundPriorityGovernor::LatencySensitive;
        const bool immersive = pressure >= work::ForegroundPriorityGovernor::Suspended;
        biblioCatalog->setForegroundPriorityActive(foregroundBusy);
        biblioCatalog->setBackgroundWorkSuspended(immersive);
#if !defined(Q_OS_ANDROID)
        vaultLibrary->setImmersive(foregroundBusy);
#endif
        catalogVaultClient->setForegroundPressure(pressure);
    });

    // Watch-room / together backbone exposed to QML as `Room`. This first slice is
    // local and in-process, but it carries the participant/chat/sync model the
    // network transport will publish later.
    auto *room = new RoomStore(&backendServices);
    engine.rootContext()->setContextProperty(QStringLiteral("Room"), room);

    // Watch Party Slice 2: source eligibility is a separate, read-only decision seam.
    // The existing local RoomStore remains untouched; no room/network/account behavior
    // is adopted here. Player 1 asks this object only for a credential-free descriptor.
    auto *watchPartySource = new Colosseum::WatchParty::SourceInspector(&backendServices);
    engine.rootContext()->setContextProperty(QStringLiteral("WatchPartySource"),
                                             watchPartySource);

    // Watch Party Slice 3: narrow Player 1 timeline synchronization policy. It starts
    // inactive and owns neither room transport nor account/session state; later room
    // integration feeds it authoritative timeline state and consumes explicit commands.
    auto *watchPartySync = new Colosseum::WatchParty::PlayerSyncController(&backendServices);
    engine.rootContext()->setContextProperty(QStringLiteral("WatchPartySync"),
                                             watchPartySync);

    // Watch Party Slice 6: QML-facing room/UI coordinator. The production account bridge
    // is created after AccountRuntime and ownership is transferred into this controller;
    // until then only the accountless guest flow exists. The service endpoint is
    // deployment configuration, never room/shared state.
    auto *watchPartyUi = new Colosseum::WatchParty::UiController(watchPartySync, &backendServices);
    const QUrl watchPartyUrl = Colosseum::WatchParty::ServiceEndpoint::configuredUrl();
    if (!watchPartyUi->configureServiceUrl(watchPartyUrl))
        qWarning() << "[watch-party] ignored invalid service endpoint";
    engine.rootContext()->setContextProperty(QStringLiteral("WatchPartyUi"),
                                             watchPartyUi);

#if !defined(Q_OS_ANDROID)
    auto *windowMode = new WindowModeStore(&app);
    engine.rootContext()->setContextProperty(QStringLiteral("WindowMode"), windowMode);
#endif

    // Playback power-inhibit exposed to QML as `Power`, matching Harbor's play-only
    // OS/display sleep prevention.
    auto *power = new PowerStore(&backendServices);
    engine.rootContext()->setContextProperty(QStringLiteral("Power"), power);

    // Efficiency gate: auto-play this local file through the app's REAL player on startup. Both
    // backends are then measured inside the same application, playing the same file, through the
    // same session machinery - the only difference being which engine draws. That removes every
    // asymmetry a synthetic side-by-side introduces (the previous attempt compared a bare lab
    // harness against a probe window that decoded without ever painting).
    engine.rootContext()->setContextProperty(QStringLiteral("DevAbbaClip"),
                                             qEnvironmentVariable("COLOSSEUM_ABBA_CLIP"));

    // Whether THIS PROCESS actually booted on D3D11 - a boot fact, not a build flag or a saved
    // setting. False in a stock build (nothing linked in) and false whenever COLOSSEUM_PLAYER2 was
    // unset at launch, so QML can never route playback into a backend this process cannot render.
#ifdef COLOSSEUM_PLAYER2
    // Available only when the process ACTUALLY booted on D3D11. Reporting true on an OpenGL boot is
    // what made Player 2 take a playback it could never render (2026-07-25).
    engine.rootContext()->setContextProperty(QStringLiteral("Player2Available"), bootPlayer2);
#else
    engine.rootContext()->setContextProperty(QStringLiteral("Player2Available"), false);
#endif

    // Build edition identity (1.1.9 no-account edition): surfaces the compiled
    // edition to QML and diagnostics so edition-specific behavior and future
    // update targeting have one authoritative in-process source.
#ifdef COLOSSEUM_NO_ACCOUNT_EDITION
    engine.rootContext()->setContextProperty(QStringLiteral("ColosseumEdition"),
                                             QStringLiteral("no-account"));
#else
    engine.rootContext()->setContextProperty(QStringLiteral("ColosseumEdition"),
                                             QStringLiteral("standard"));
#endif

    // Account + personal-profile runtime (Bundle 8C adoption, 2026-08-16).
    // AccountRuntime owns the personal store runtime, which is now the SOLE
    // owner/binder of the Progress/Collection/SearchHistory/AudioPairing context
    // properties (plus ProfilePreferences/ProfileHistory/ProfileContext and the
    // AccountController/AccountRecoveryKey surfaces). Boot starts sealed behind
    // the onboarding gate; the user's choice (create account / continue local)
    // rebinds to the adopted account profile or the legacy stores exactly as
    // designed. Replaces the four raw store constructions this block used to
    // hold — the split-brain risk of two owners binding the same QML names is
    // closed by construction.
#if !defined(Q_OS_ANDROID)
    // Vinyl uses the existing canonical local identity and profile-owned stores.
    // Register checkpoint callbacks before AccountRuntime installs store shutdown writers.
    int vinylResolutionDelayMs = 0;
#if defined(COLOSSEUM_ENABLE_VINYL_TEST_FIXTURES) && !defined(Q_OS_ANDROID)
    vinylResolutionDelayMs = VinylTestProfileController(instanceAppData, {}, {}).resolutionDelayMs();
#endif
    auto *vinylLocalSource = new VinylLocalSource(vaultIdentity, &backendServices, vinylResolutionDelayMs);
    qmlRegisterType<VinylBackendSession>("Colosseum.Vinyl", 1, 0, "VinylBackendSession");
    qmlRegisterType<VinylRecommendationService>("Colosseum.Vinyl", 1, 0, "VinylRecommendationService");
    QObject::connect(&app, &QCoreApplication::aboutToQuit,
                     vinylLocalSource, &VinylLocalSource::shuttingDown);
    // Prefer the assembled app's helper/runtime; source-tree launches retain an
    // explicit resource-root fallback. Never resolve Python through PATH.
    const auto vinylBundledHelper = QDir(QCoreApplication::applicationDirPath()).absoluteFilePath("scripts/vinyl/provider.py");
    auto *vinylProvider = new VinylProvider(
        QFileInfo::exists(vinylBundledHelper) ? vinylBundledHelper :
            QDir(startupLayout->resourceRoot.isEmpty() ? QDir::currentPath() : startupLayout->resourceRoot)
                .absoluteFilePath("scripts/vinyl/provider.py"), &backendServices);
    QObject::connect(&app, &QCoreApplication::aboutToQuit,
                     vinylProvider, &VinylProvider::shuttingDown);
    auto *vinylCatalogueSource = new VinylCatalogueSource(vinylLocalSource, vinylProvider, nullptr, &backendServices);
#endif
    auto *accountRuntime = new AccountRuntime(&backendServices);
#ifdef COLOSSEUM_RATINGS_REVIEWS_TESTING
    std::unique_ptr<ProfilePreferencesStore> ratingsReviewsFixturePreferences;
    std::unique_ptr<RatingsReviewsTaggedFixtureAdapter> ratingsReviewsFixtureA;
    std::unique_ptr<RatingsReviewsTaggedFixtureAdapter> ratingsReviewsFixtureB;
    std::unique_ptr<RatingsReviewsTaggedFixtureAdapter> ratingsReviewsFixtureSpoilerBlocked;
    if (qEnvironmentVariable("COLOSSEUM_APPDATA_TAG")
        == QLatin1String("ratings-reviews-delivery-fixture")) {
        // This is the sole assembled-app writer seam in Package 1.  It is
        // isolated by both compile flag and exact AppData tag; daily launches
        // never register any Ratings/Reviews adapter.
        auto *delivery = accountRuntime->ratingsReviewsDelivery();
        const auto hook = RatingsReviewsConversionTestHook::syntheticDomains();
        ratingsReviewsFixturePreferences = std::make_unique<ProfilePreferencesStore>(
            QDir(instanceAppData).filePath(QStringLiteral("ratings-reviews-fixture-preferences.ini")),
            hook);
        const auto mapA = RatingsReviewsConversionMap::recommended(
            QStringLiteral("fixture-a"), QStringLiteral("fixture-halfpoint-v1"), 1, hook);
        const auto mapB = RatingsReviewsConversionMap::recommended(
            QStringLiteral("fixture-b"), QStringLiteral("fixture-halfpoint-v1"), 1, hook);
        if (!mapA || !mapB
            || !ratingsReviewsFixturePreferences->ratingsReviewsConversionMapsHealthy()
            || (!ratingsReviewsFixturePreferences->hasRatingsReviewsProviderOrder()
                && !ratingsReviewsFixturePreferences->setRatingsReviewsProviderOrder(
                    RatingsReviewsConversionMap::canonicalProviderIds()))
            || (!ratingsReviewsFixturePreferences->hasRatingsReviewsDefaultRatingDestinations()
                && !ratingsReviewsFixturePreferences->setRatingsReviewsDefaultRatingDestinations(
                    {QStringLiteral("fixture-a"), QStringLiteral("fixture-b")}))
            || (!ratingsReviewsFixturePreferences->hasRatingsReviewsDefaultReviewDestinations()
                && !ratingsReviewsFixturePreferences->setRatingsReviewsDefaultReviewDestinations(
                    {QStringLiteral("fixture-a")}))
            || (!ratingsReviewsFixturePreferences->ratingsReviewsConversionMap(QStringLiteral("fixture-a"))
                && !ratingsReviewsFixturePreferences->setRatingsReviewsConversionMap(*mapA))
            || (!ratingsReviewsFixturePreferences->ratingsReviewsConversionMap(QStringLiteral("fixture-b"))
                && !ratingsReviewsFixturePreferences->setRatingsReviewsConversionMap(*mapB))) {
            qWarning() << "Ratings/Reviews tagged fixture preferences could not be seeded";
        } else {
            delivery->setFixturePreferencesForTests(ratingsReviewsFixturePreferences.get());
            ratingsReviewsFixtureA = std::make_unique<RatingsReviewsTaggedFixtureAdapter>();
            ratingsReviewsFixtureB = std::make_unique<RatingsReviewsTaggedFixtureAdapter>(true);
            ratingsReviewsFixtureSpoilerBlocked = std::make_unique<RatingsReviewsTaggedFixtureAdapter>();
            RatingsReviewsDeliveryProviderCapability full;
            full.connected = true;
            full.connectionGeneration = 1;
            full.ratingCapable = true;
            full.reviewCapable = true;
            full.spoilerMetadata = true;
            delivery->setFixtureProviderForTests(
                QStringLiteral("fixture-a"), full, ratingsReviewsFixtureA.get());
            RatingsReviewsDeliveryProviderCapability unknown = full;
            unknown.reviewCapable = false;
            delivery->setFixtureProviderForTests(
                QStringLiteral("fixture-b"), unknown, ratingsReviewsFixtureB.get());
            RatingsReviewsDeliveryProviderCapability spoilerBlocked = full;
            spoilerBlocked.spoilerMetadata = false;
            delivery->setFixtureProviderForTests(
                QStringLiteral("fixture-spoiler-blocked"), spoilerBlocked,
                ratingsReviewsFixtureSpoilerBlocked.get());
            delivery->enableTaggedFixtureMappingForTests({
                QStringLiteral("theatre"), QStringLiteral("series"),
                QStringLiteral("fixture-provider-read-series")});
        }
    }
#endif
    accountRuntime->setDownloadSource(localDownloads);
    accountRuntime->setExtensionsStore(extensions);
    accountRuntime->prepareForQml(&engine);

    auto *ratingsReviewsIdentity = new ColosseumTitleIdentityRegistry(QString(), &backendServices);
    // Persist learned provider-id pivots (kitsu:/mal:… → tt…) under the tagged
    // AppData root; the tag re-rooting applied earlier keeps isolated test
    // sessions from touching the daily profile's learned unions.
    {
        const QString unionsDir = QStandardPaths::writableLocation(
            QStandardPaths::AppDataLocation) + QStringLiteral("/ratings-reviews");
        if (QDir().mkpath(unionsDir))
            ratingsReviewsIdentity->setAliasUnionsPath(
                unionsDir + QStringLiteral("/alias-unions-v1.json"));
    }
    auto *ratingsReviewsProviderRead = new RatingsReviewsProviderReadProjection(&backendServices);
    auto *ratingsReviewsController = new RatingsReviewsController(
        accountRuntime->profileStores(), ratingsReviewsIdentity,
        ratingsReviewsProviderRead, &backendServices, accountRuntime->ratingsReviewsDelivery());
    engine.rootContext()->setContextProperty(
        QStringLiteral("RatingsReviewsIdentity"), ratingsReviewsIdentity);
    engine.rootContext()->setContextProperty(
        QStringLiteral("RatingsReviewsController"), ratingsReviewsController);
    engine.rootContext()->setContextProperty(
        QStringLiteral("ratingsReviewsDeliveryState"),
        accountRuntime->ratingsReviewsDelivery());
#ifdef COLOSSEUM_RATINGS_REVIEWS_TESTING
    const QString ratingsReviewsFixture =
        qEnvironmentVariable("COLOSSEUM_APPDATA_TAG")
                == QLatin1String("ratings-reviews-delivery-fixture")
            ? qEnvironmentVariable("COLOSSEUM_RR_PROVIDER_FIXTURE") : QString();
    engine.rootContext()->setContextProperty(
        QStringLiteral("RatingsReviewsProviderFixture"), ratingsReviewsFixture);
#endif

    // Reader2 private JSON follows the same profile lifecycle as the account-owned
    // stores. The runtime emits storesAboutToChange before destroying the old owner;
    // Reader2Bridge uses that window to flush/scrub QML, clear paper authorization,
    // and seal the old route before storesChanged installs the next profile root.
    reader2Bridge->bindProfileStoreRuntime(accountRuntime->profileStores());

    // Arc 39 restores chapter mode. The 2026-08-20 one-time chapter purge is
    // intentionally retired: future boots must preserve <AppData>/manga and kind:"manga"
    // progress because those are live product data again. The migration implementation
    // remains in-tree as historical/tested code, but production no longer invokes it.

    // Watch Party account bridge (arc 03): signed-in identity + bearer stay native.
    // UiController owns the bridge it dereferences, so its teardown cannot outlive
    // a shorter-lived local unique_ptr. Identity changes still close authenticated sessions.
    watchPartyUi->setOwnedAccountBridge(accountRuntime->createWatchPartyAccountBridge());
    QObject::connect(accountRuntime->controller(), &AccountController::signedIn,
                     watchPartyUi, &Colosseum::WatchParty::UiController::handleAccountIdentityChanged);
    QObject::connect(accountRuntime->controller(), &AccountController::signedOut,
                     watchPartyUi, &Colosseum::WatchParty::UiController::handleAccountIdentityChanged);

    auto *audioPairing = accountRuntime->profileStores()->audioPairingStore();

    // (Deleted 2026-08-07 with BookBridge: two setters that handed the retired bridge the
    // audiobook library + pairing store. Nothing read them — the reader takes `AudioPairing`
    // straight as a context property, see qml/reader2/ReaderShell.qml:310-314.)

    // Read-along auto-attach (Task 12): when an audiobook finishes downloading from a
    // book's page, the downloader writes the pairing under the reader's bookId itself —
    // no pairing UI. Same store instance QML uses, so the reader's Audio tab reads it.
    audiobooks->setPairing(audioPairing);

    // (SearchHistory is owned + bound by the account runtime's profile stores above.)

    // System clipboard for QML — the sources sheet's copy-magnet button (spec 2026-07-08).
    auto *clipboard = new ClipboardHelper(&backendServices);
    engine.rootContext()->setContextProperty(QStringLiteral("Clipboard"), clipboard);

    // Open-sessions model exposed to QML as `Sessions` - the OS-shell's switcher state
    // (which surfaces are open, which is active, each one's saved-state blob).
    auto *sessions = new SessionStore(&backendServices);
    engine.rootContext()->setContextProperty(QStringLiteral("Sessions"), sessions);
    if (qEnvironmentVariableIsSet("COLOSSEUM_SESSION_SELFTEST"))
        sessions->selfTest();

    // Keyless anime ordering (spec 2026-07-15): downloads two community mapping
    // datasets at runtime, caches immutable generations, and hands Theatre/player
    // a cheap synchronous resolver as `AnimeOrder`. Shares the plain download NAM;
    // never blocks first paint (progressive enhancement).
    auto *animeOrder = new AnimeOrderService(dlNam, &backendServices);
    engine.rootContext()->setContextProperty(QStringLiteral("AnimeOrder"), animeOrder);
    const bool devWorldWarmer = qEnvironmentVariableIntValue("COLOSSEUM_WORLD_WARMER") == 1;
    engine.rootContext()->setContextProperty(QStringLiteral("DevWorldWarmer"), devWorldWarmer);
    // KeyboardSpatialNavigator's focus seams walk the whole item tree and re-run on every
    // child/focus/geometry change; only an automation session driving the app reads them.
    // COLOSSEUM_AUTOMATION_FOCUS_SEAMS=0 keeps them off in a driven session that measures
    // performance as users get it.
    engine.rootContext()->setContextProperty(QStringLiteral("AutomationFocusSeams"),
        qEnvironmentVariableIntValue("COLOSSEUM_LANISTA_DRIVE") == 1   // LanistaServer's drive gate
            && qEnvironmentVariable("COLOSSEUM_AUTOMATION_FOCUS_SEAMS") != QLatin1String("0"));
    // Diagnostic A/B: leave the normal catalog prefetch enabled unless explicitly disabled.
    engine.rootContext()->setContextProperty(
        QStringLiteral("BootSplashPrefetchEnabled"),
        qEnvironmentVariable("COLOSSEUM_DISABLE_BOOT_PREFETCH") != QLatin1String("1"));
    const bool scrollProbeEnabled = ScrollProbe::enabledFromEnv();
    ScrollProbe scrollProbe;
    if (scrollProbeEnabled)
        app.installEventFilter(&scrollProbe);
    engine.rootContext()->setContextProperty(QStringLiteral("ScrollProbeEnabled"), scrollProbeEnabled);
    GuiStallProbeBridge guiStallProbe(&app);
    engine.rootContext()->setContextProperty(QStringLiteral("GuiStallProbe"), &guiStallProbe);
    engine.rootContext()->setContextProperty(QStringLiteral("CatalogueTraceEnabled"),
        qEnvironmentVariableIntValue("COLOSSEUM_CATALOGUE_TRACE") == 1);

    // Startup qualification is opt-in and intentionally marks only coarse boundaries. Keeping
    // the context explicit makes GUI_STALL_PROBE output distinguish boot work from later playback
    // stalls without adding work to every event delivery.
    app.setStallContext(QStringLiteral("startup"), QStringLiteral("qml-load"));
#if !defined(Q_OS_ANDROID)
    FeriaBrowserPolicy::registerTypes();
    engine.rootContext()->setContextProperty(QStringLiteral("FeriaBrowserPolicy"), static_cast<QObject *>(nullptr));
    engine.rootContext()->setContextProperty(QStringLiteral("FeriaAccount"), static_cast<QObject *>(nullptr));
    std::unique_ptr<PorticoComposition> feriaDiscovery;
    FeriaBrowserPolicy *feriaBrowserPolicy = nullptr;
    FeriaAccountStore *feriaAccount = nullptr;
    auto ensureFeriaRuntime = [&app, &engine, &feriaDiscovery, &feriaBrowserPolicy, &feriaAccount, accountRuntime, sessions]() {
        if (feriaDiscovery)
            return;
        feriaDiscovery = std::make_unique<PorticoComposition>();
        feriaDiscovery->exposeTo(engine.rootContext());
        feriaBrowserPolicy = new FeriaBrowserPolicy(&engine);
        QObject::connect(&app, &QCoreApplication::aboutToQuit,
                         feriaBrowserPolicy->runtime(), &FeriaBrowserRuntime::shutdown);
        feriaAccount = new FeriaAccountStore(&engine);
        auto bindFeriaProfile = [feriaAccount, feriaBrowserPolicy, accountRuntime, sessions] {
            const auto &profile = accountRuntime->profileStores()->activeProfile();
            QString root = profile.profileRoot();
            if (profile.kind() == ProfilePaths::Kind::LegacyLocal)
                root = QStandardPaths::writableLocation(QStandardPaths::AppLocalDataLocation);
            sessions->setBrowserProfile(root);
            feriaAccount->setStoragePath(root.isEmpty() ? QString() : root + QStringLiteral("/feria/account.json"));
            feriaBrowserPolicy->setStorageRoot(root.isEmpty() ? QString() : root + QStringLiteral("/feria/browser"));
        };
        bindFeriaProfile();
        QObject::connect(accountRuntime->profileStores(), &ProfileStoreRuntime::storesAboutToChange,
                         feriaAccount, [feriaAccount, feriaBrowserPolicy, sessions] {
                             sessions->setBrowserProfile({});
                             feriaAccount->setStoragePath({});
                             feriaBrowserPolicy->setStorageRoot({});
                         });
        QObject::connect(accountRuntime->profileStores(), &ProfileStoreRuntime::storesChanged,
                         feriaAccount, bindFeriaProfile);
        engine.rootContext()->setContextProperty(QStringLiteral("FeriaBrowserPolicy"), feriaBrowserPolicy);
        engine.rootContext()->setContextProperty(QStringLiteral("FeriaAccount"), feriaAccount);
    };
#endif
#if !defined(Q_OS_ANDROID)
    engine.rootContext()->setContextProperty(QStringLiteral("VinylLocalSource"), vinylLocalSource);
    engine.rootContext()->setContextProperty(QStringLiteral("VinylCatalogueSource"), vinylCatalogueSource);
    vinylCatalogueSource->setArtworkNetworkManager(engine.networkAccessManager());
    vinylCatalogueSource->setTorrentProvider(new VinylTorrentProvider(engine.networkAccessManager(),stream,&backendServices));
    const auto bindVinylScope = [&engine, accountRuntime] {
        engine.rootContext()->setContextProperty(QStringLiteral("VinylProfileScope"),
            accountRuntime->profileStores()->activeProfile().profileId());
    };
    bindVinylScope();
    QObject::connect(accountRuntime->profileStores(), &ProfileStoreRuntime::storesChanged,
                     &engine, bindVinylScope);
    engine.rootContext()->setContextProperty(QStringLiteral("VinylProvider"), vinylProvider);
    engine.rootContext()->setContextProperty(QStringLiteral("VinylLiveEnabled"),
        Colosseum::vinylLiveEnabled());
    QObject::connect(accountRuntime->profileStores(), &ProfileStoreRuntime::profileDeactivationRequested,
                     vinylLocalSource, &VinylLocalSource::checkpointRequested);
    QObject::connect(accountRuntime->profileStores(), &ProfileStoreRuntime::storesAboutToChange,
                     vinylLocalSource, &VinylLocalSource::profileLeaving);
    QObject::connect(accountRuntime->profileStores(), &ProfileStoreRuntime::storesChanged,
                     vinylLocalSource, &VinylLocalSource::profileEntered);
    QObject::connect(accountRuntime->profileStores(), &ProfileStoreRuntime::profileDeactivationRequested,
                     vinylProvider, &VinylProvider::checkpointRequested);
    QObject::connect(accountRuntime->profileStores(), &ProfileStoreRuntime::storesAboutToChange,
                     vinylProvider, &VinylProvider::profileLeaving);
    QObject::connect(accountRuntime->profileStores(), &ProfileStoreRuntime::storesChanged,
                     vinylProvider, &VinylProvider::profileEntered);
#else
    engine.rootContext()->setContextProperty(QStringLiteral("VinylLiveEnabled"), false);
#endif
    engine.load(QUrl::fromLocalFile(qmlPath));
    if (engine.rootObjects().isEmpty())
        return -1;
#if defined(Q_OS_ANDROID)
    qInfo("[boot] Main.qml loaded");
#else
    if (auto *feriaLayerItem = engine.rootObjects().constFirst()->findChild<QQuickItem *>(QStringLiteral("feriaLayer"))) {
        QObject::connect(feriaLayerItem, &QQuickItem::enabledChanged, &engine,
                         [feriaLayerItem, &ensureFeriaRuntime] {
            if (feriaLayerItem->isEnabled())
                ensureFeriaRuntime();
        });
        if (feriaLayerItem->isEnabled())
            ensureFeriaRuntime();
    }
#endif

    // Main has initialized the built-in types. Later player imports must reuse
    // that registration instead of resolving another QtQuick plugin instance.
    if (Colosseum::Bootstrap::sealQtQuickModule())
        qInfo("[boot] QtQuick 6 sealed for lazy player imports");
    else
        qWarning("[boot] QtQuick 6 module could not be sealed");

    if (!hasQmlOverride) {
        QTimer::singleShot(0, pinStore, [pinStore, pinnedHosts] {
            pinStore->refresh(pinnedHosts);
        });
    }

    const QStringList launchArguments = QCoreApplication::arguments();
    QObject* rootObject = engine.rootObjects().constFirst();
#ifdef COLOSSEUM_RATINGS_REVIEWS_TESTING
    if (qEnvironmentVariable("COLOSSEUM_APPDATA_TAG")
        == QLatin1String("ratings-reviews-delivery-fixture")) {
        const QVariant fixtureTitle = QVariantMap{
            {QStringLiteral("id"), QStringLiteral("fixture-provider-read-series")},
            {QStringLiteral("type"), QStringLiteral("series")},
            {QStringLiteral("title"), QStringLiteral("Arc 49 Delivery Fixture")}};
        const bool routed = QMetaObject::invokeMethod(
            rootObject, "openTheatreSeries", Qt::DirectConnection,
            Q_ARG(QVariant, fixtureTitle));
        if (!routed) {
            qCritical("Arc 49 delivery fixture could not open its exact Theatre title route");
            return -1;
        }
    }
#endif
    QObject::connect(platformRuntime, &Colosseum::Platform::Runtime::backRequested,
                     rootObject, [rootObject] {
        if (!QMetaObject::invokeMethod(rootObject, "handleEscape", Qt::QueuedConnection))
            qWarning("[platform] root QML does not expose handleEscape()");
    });
#if !defined(Q_OS_ANDROID)
    const auto acknowledgeFirstFrame = [&app, &guiStallProbe, updateBridge,
                                        launchArguments, biblioCatalog](const QString &context) {
        app.setStallContext(QStringLiteral("startup"), context);
        app.markFirstFrame();
        guiStallProbe.notifyFirstFrame();
        updateBridge->acknowledgeHealthyBoot(launchArguments);
        QTimer::singleShot(0, biblioCatalog, [biblioCatalog] { biblioCatalog->refreshIfDue(); });
    };
#else
    const auto acknowledgeFirstFrame = [&app, &guiStallProbe,
                                        biblioCatalog](const QString &context) {
        app.setStallContext(QStringLiteral("startup"), context);
        app.markFirstFrame();
        guiStallProbe.notifyFirstFrame();
        QTimer::singleShot(0, biblioCatalog, [biblioCatalog] { biblioCatalog->refreshIfDue(); });
    };
#endif

    if (auto* rootWindow = qobject_cast<QQuickWindow*>(rootObject)) {
#ifdef Q_OS_ANDROID
        Colosseum::Platform::attachAndroidRootWindow(rootWindow);
#endif
        platformRuntime->attachWindow(rootWindow);
        if (posterTimingEnabled) posterTiming->attach(rootWindow);
        if (frameProbeEnabled)
            QObject::connect(rootWindow, &QQuickWindow::frameSwapped, &app,
                             [frameTiming] { frameTiming->recordSwap(); }, Qt::DirectConnection);
        QObject::connect(rootWindow, &QQuickWindow::frameSwapped, &app,
                         [acknowledgeFirstFrame] {
            acknowledgeFirstFrame(QStringLiteral("first-frame"));
        }, Qt::SingleShotConnection);
    } else {
        QTimer::singleShot(0, &app, [acknowledgeFirstFrame] {
            acknowledgeFirstFrame(QStringLiteral("first-frame-fallback"));
        });
    }

    // BootSplash owns the last startup boundary. Its visibleChanged signal fires after the
    // reveal fade, so this is the first point at which the shell is actually interactive.
    if (auto *bootSplash = rootObject->findChild<QQuickItem*>(QStringLiteral("bootSplash"))) {
        if (!bootSplash->isVisible()) {
            app.markShellInteractive();
            app.setStallContext({}, {});
        } else {
            QObject::connect(bootSplash, &QQuickItem::visibleChanged, &app, [bootSplash, &app] {
                if (!bootSplash->isVisible()) {
                    app.markShellInteractive();
                    app.setStallContext({}, {});
                }
            });
        }
    } else {
        QTimer::singleShot(0, &app, [&app] {
            app.markShellInteractive();
            app.setStallContext({}, {});
        });
    }

#if !defined(Q_OS_ANDROID)
    if (installedUpdateEligible && !updateTestingBuild)
        QTimer::singleShot(0, updates, &Colosseum::Update::UpdateService::startAutomaticChecks);
#endif

    // Lanista dev-control bridge — ALWAYS ON for reads/grabs (Hemanth, spec
    // 2026-08-01 §3). Local named pipe only, never a network port. Driving and
    // mutation commands gate on env INSIDE the server, per command.
    LanistaServer lanistaServerStorage(&engine, &app);
    auto *lanistaServer = &lanistaServerStorage;
#if !defined(Q_OS_ANDROID)
    // F1-Bridge: hand the bridge the live forensic projection constructed above.
    lanistaServer->setVaultForensics(vaultForensics);
#if defined(COLOSSEUM_ENABLE_VINYL_TEST_FIXTURES) && !defined(Q_OS_ANDROID)
    // Synthetic-only fixture: no account authentication or arbitrary profile
    // identifier is exposed. Existing profile activation observers still run;
    // use only fresh credential-free, extension-free synthetic profiles.
    // The controller additionally
    // requires the explicit launch gate and a marked, isolated temporary root.
    const QPointer<ProfileStoreRuntime> vinylFixtureStores(accountRuntime->profileStores());
    const QString vinylFixtureA = QStringLiteral("11111111-1111-4111-8111-111111111175");
    const QString vinylFixtureB = QStringLiteral("11111111-1111-4111-8111-111111111176");
    struct VinylFixtureWriteObservation {
        quint64 generation = 0;
        bool accepted = false, pendingBeforeSwitch = false, completed = false;
        bool succeeded = false, ownerRetired = false, armed = false;
        bool identityMatched = false, writeError = false;
        double priorPosition = -1, finalPosition = -1;
    };
    const auto vinylWriteObservation = std::make_shared<VinylFixtureWriteObservation>();
    const auto armVinylPendingWrite = [vinylFixtureStores, vinylWriteObservation](bool shutdown) {
        if (!vinylFixtureStores || vinylWriteObservation->armed) return false;
        const QPointer<ProgressStore> outgoing(vinylFixtureStores->progressStore());
        if (!outgoing || outgoing->get("music-session", "vinyl").isEmpty()) return false;
        const quint64 generation = vinylWriteObservation->generation + 1;
        *vinylWriteObservation = VinylFixtureWriteObservation{};
        vinylWriteObservation->generation = generation;
        vinylWriteObservation->armed = true;
        const auto report = [vinylWriteObservation](const char *phase) {
            const auto &o = *vinylWriteObservation;
            qInfo().noquote() << "VinylPendingWrite" << QJsonDocument(QJsonObject{
                {"phase", QString::fromLatin1(phase)}, {"accepted", o.accepted},
                {"pendingBefore", o.pendingBeforeSwitch}, {"completed", o.completed},
                {"succeeded", o.succeeded}, {"ownerRetired", o.ownerRetired},
                {"identityMatched", o.identityMatched}, {"writeError", o.writeError},
                {"priorPosition", o.priorPosition}, {"finalPosition", o.finalPosition}
            }).toJson(QJsonDocument::Compact);
        };
        QObject::connect(outgoing, &QObject::destroyed, qApp,
            [vinylWriteObservation, generation, report] {
                if (vinylWriteObservation->generation != generation) return;
                vinylWriteObservation->ownerRetired = true;
                report("retired");
            });
        const auto boundary = [outgoing, vinylWriteObservation, generation, report] {
            if (!outgoing || vinylWriteObservation->generation != generation) return;
            vinylWriteObservation->armed = false;
            auto session = outgoing->get("music-session", "vinyl");
            auto resume = session.value("resume").toMap();
            const auto queue = resume.value("queue").toList();
            const auto editions = resume.value("editionTable").toList();
            const int index = resume.value("queueIndex", -1).toInt();
            const int edition = index >= 0 && index < queue.size()
                ? queue.at(index).toMap().value("editionKey", -1).toInt() : -1;
            const QString id = edition >= 0 && edition < editions.size()
                ? editions.at(edition).toMap().value("id").toString() : QString();
            auto music = outgoing->get("music", id);
            const auto musicResume = music.value("resume").toMap();
            const double prior = resume.value("position", -1).toDouble();
            const double duration = resume.value("duration").toDouble();
            if (id.isEmpty() || music.isEmpty() || prior < 0 || duration <= 7.5
                || resume.value("trackId").toString().isEmpty()
                || musicResume.value("trackId") != resume.value("trackId")
                || musicResume.value("position") != resume.value("position")) {
                vinylWriteObservation->writeError = true;
                report("invalid-existing-checkpoint");
                return;
            }
            outgoing->flush(); // The older checkpoint precedes the distinct final write.
            vinylWriteObservation->identityMatched = true;
            vinylWriteObservation->priorPosition = prior;
            const double finalPosition = prior == 6.25 ? 7.5 : 6.25;
            vinylWriteObservation->finalPosition = finalPosition;
            resume.insert("position", finalPosition);
            session.insert("resume", resume);
            music.insert("resume", resume);
            music.insert("progress", finalPosition / duration);
            outgoing->recordSilent(music);
            outgoing->recordSilent(session);
            vinylWriteObservation->accepted = outgoing->requestDurableReceipt(
                [vinylWriteObservation, generation, report](bool committed, const QString &error) {
                    if (vinylWriteObservation->generation != generation) return;
                    vinylWriteObservation->completed = true;
                    vinylWriteObservation->succeeded = committed;
                    vinylWriteObservation->writeError = !error.isEmpty();
                    report("completed");
                });
            vinylWriteObservation->pendingBeforeSwitch = vinylWriteObservation->accepted
                && !vinylWriteObservation->completed;
            report("pending");
        };
        if (shutdown) {
            QObject::connect(qApp, &QCoreApplication::aboutToQuit, outgoing,
                             boundary, Qt::SingleShotConnection);
        } else {
            QObject::connect(vinylFixtureStores, &ProfileStoreRuntime::storesAboutToChange,
                             outgoing, boundary, Qt::SingleShotConnection);
        }
        report("armed");
        return true;
    };
    auto vinylFixture = std::make_shared<VinylTestProfileController>(
        instanceAppData,
        [vinylFixtureStores, vinylFixtureA, vinylFixtureB, armVinylPendingWrite, instanceAppData](
            const QString &alias, bool withPendingWrite) {
            if (!vinylFixtureStores) return false;
            const QString targetId = alias == QLatin1String("A") ? vinylFixtureA : vinylFixtureB;
            if (withPendingWrite && vinylFixtureStores->activeProfile().profileId() == targetId)
                return false; // A pending-switch witness may not be a same-profile no-op.
            if (alias == QLatin1String("A") || alias == QLatin1String("B")) {
                const auto targetPaths = ProfilePaths::account(targetId, instanceAppData);
                if (!targetPaths || !QDir().mkpath(targetPaths->profileRoot())) return false;
            }
            if (withPendingWrite && !armVinylPendingWrite(false)) return false;
            QString error; // Never return store paths or detailed errors over this fixture.
            if (alias == QLatin1String("local"))
                return vinylFixtureStores->activateLocalOnlyProfile(&error);
            if (alias == QLatin1String("A") || alias == QLatin1String("B"))
            {
                // Exercise the existing departure boundary explicitly: account A
                // cannot activate B directly. This fixture performs A -> local -> B.
                const auto &current = vinylFixtureStores->activeProfile();
                if (current.kind() == ProfilePaths::Kind::Account
                    && current.profileId() != targetId
                    && !vinylFixtureStores->activateLocalOnlyProfile(&error)) return false;
                return vinylFixtureStores->activateAccountProfile(targetId, &error);
            }
            return false;
        },
        [vinylFixtureStores, vinylFixtureA, vinylFixtureB, vinylWriteObservation] {
            VinylTestProfileController::Status status;
            if (!vinylFixtureStores) return status;
            status.pendingWriteAccepted = vinylWriteObservation->accepted;
            status.pendingBeforeSwitch = vinylWriteObservation->pendingBeforeSwitch;
            status.pendingWriteCompleted = vinylWriteObservation->completed;
            status.pendingWriteSucceeded = vinylWriteObservation->succeeded;
            status.pendingOwnerRetired = vinylWriteObservation->ownerRetired;
            status.pendingWriteArmed = vinylWriteObservation->armed;
            status.pendingIdentityMatched = vinylWriteObservation->identityMatched;
            status.pendingWriteError = vinylWriteObservation->writeError;
            status.pendingPriorPosition = vinylWriteObservation->priorPosition;
            status.pendingFinalPosition = vinylWriteObservation->finalPosition;
            const auto &profile = vinylFixtureStores->activeProfile();
            if (profile.kind() == ProfilePaths::Kind::LocalOnly
                || profile.kind() == ProfilePaths::Kind::LegacyLocal)
                status.alias = QStringLiteral("local");
            else if (profile.kind() == ProfilePaths::Kind::Account) {
                if (profile.profileId() == vinylFixtureA) status.alias = QStringLiteral("A");
                if (profile.profileId() == vinylFixtureB) status.alias = QStringLiteral("B");
            }
            status.collectionHealthy = vinylFixtureStores->collectionStore()
                && vinylFixtureStores->collectionStore()->healthy();
            status.progressHealthy = vinylFixtureStores->progressStore()
                && vinylFixtureStores->progressStore()->healthy();
            status.activityHealthy = vinylFixtureStores->activityStore()
                && vinylFixtureStores->activityStore()->healthy();
            return status;
        }, [armVinylPendingWrite] { return armVinylPendingWrite(true); });
    lanistaServer->setVinylTestProfileHandler([vinylFixture](const QJsonObject &request) {
        return vinylFixture->execute(request);
    });
#endif
#endif // !Q_OS_ANDROID: Vault diagnostics and synthetic Vinyl profile seam

    // Live-reload only in dev (dev.bat sets COLOSSEUM_DEV). Production is untouched.
    if (qEnvironmentVariableIsSet("COLOSSEUM_DEV")) {
        new QmlReloader(&engine, qmlPath, &backendServices);
        manga->selfTest(QStringLiteral("Berserk"));  // log WeebCentral chapter count at startup
        // DEBUG: log volume resolution. There is no WeebCentral id at startup, so this
        // exercises the LIVE Comick scrape + completeness gate only — the volume-DB read
        // is keyed by the WC id and is proved by opening a real series page.
        manga->volumes(QString(), QStringLiteral("One Piece"));
    }

    return app.exec();
}
