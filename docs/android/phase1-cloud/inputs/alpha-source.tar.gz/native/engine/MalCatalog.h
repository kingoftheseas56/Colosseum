#pragma once
// MalCatalog — read-only seam onto the baked MyAnimeList catalog
// (data/mal_catalog.db, built by scripts/anime_brain/build_mal_db.py from the
// weekly Kaggle dump; genre-page revival, Hemanth 2026-07-18). QML paints, C++
// decides: db, schema, and query shape live here. Rows come back JIKAN-SHAPED
// (nested images.jpg, [{name}] credit/genre lists, Jikan status strings) so the
// genre pages' existing card mappers consume them without a rendering change.
// Missing db => ready()==false and every accessor returns empty — the pages
// fall through to their live Jikan/AniList/Kitsu ladder untouched.
#include <QObject>
#include "CatalogRemote.h"
#include <QHash>
#include <QSqlDatabase>
#include <QVariantList>
#include <QVariantMap>

class MalCatalog final : public QObject {
    Q_OBJECT
    Q_PROPERTY(int revision READ revision NOTIFY revisionChanged)
    Q_PROPERTY(bool remoteEnabled READ remoteEnabled NOTIFY revisionChanged)
    // No Q_PROPERTY(ready) here on purpose (data-vault Slice 4, 2026-08-22 fix): a
    // Q_PROPERTY and a Q_INVOKABLE sharing the name "ready" collide in QML's property
    // lookup — `.ready()` resolves to the property's bool VALUE first, then throws
    // "not a function" trying to call it. Nothing in qml/ ever read a bare `.ready`
    // property (grep-verified) — every call site uses `.ready()` — so the property
    // declaration was pure dead weight that broke its own callers. readyChanged stays
    // a plain signal; Connections-based listeners (see qml/Main.qml's catalogVaultState)
    // still work off it exactly as before.
public:
    explicit MalCatalog(const QString& dbPath, QObject* parent = nullptr);
    ~MalCatalog() override;

    Q_INVOKABLE bool ready() const { return m_ok; }
    // Service availability is distinct from complete local SQLite readiness.
    Q_INVOKABLE bool available() const { return m_ok || m_remote->available(); }
    bool remoteEnabled() const { return m_remote->enabled(); }
    int revision() const { return m_remote->revision(); }
    Q_INVOKABLE bool remotePending() const { return m_remote->pending(); }
    Q_INVOKABLE QString remoteQueryKey(const QString& method, const QVariantList& args) const { return m_remote->queryKey(method, args); }
    Q_INVOKABLE QVariantMap landing(const QString& tab) const { return m_ok ? QVariantMap{} : m_remote->read(QStringLiteral("landing"), {tab}, QVariantMap{}).toMap(); }
    Q_INVOKABLE QVariantMap landingState(const QString& tab) const { auto state=m_remote->queryState(QStringLiteral("landing"), {tab}, QVariantMap{}); state.insert(QStringLiteral("source"),m_ok?QStringLiteral("local"):QStringLiteral("remote")); return state; }
    Q_INVOKABLE bool remoteWaiting() const { return m_remote->waiting(); }
    void configureRemote(QNetworkAccessManager* nam, const QUrl& endpoint, const QString& cachePath = {}) {
        m_remote->configure(nam, endpoint, cachePath);
    }

    // Data-vault Slice 2 (2026-08-22): reopen at a fresh path (e.g. after
    // CatalogVaultClient lands a new download over this db) — closes any
    // existing connection first. Returns the new ready() state.
    Q_INVOKABLE bool reopen(const QString& dbPath);
    // Close the connection ahead of a vault swap so Windows can rename over
    // the file (CatalogVaultClient::aboutToReplace's contract). ready()
    // becomes false until the next reopen().
    Q_INVOKABLE void closeForSwap();
    // medium: "anime" | "manga"; order: "members" | "score". Jikan-shaped maps.
    Q_INVOKABLE QVariantList genreEntries(const QString& medium, const QString& genre,
                                          const QString& order, int limit = 24) const;
    Q_INVOKABLE QVariantMap genreEntriesState(const QString& medium, const QString& genre,
                                              const QString& order, int limit = 24) const;
    Q_INVOKABLE bool retryGenreEntries(const QString& medium, const QString& genre,
                                       const QString& order, int limit = 24);
    // the TRUE catalog total for a genre (baked before the browsable slice)
    Q_INVOKABLE int genreCount(const QString& medium, const QString& genre) const;
    // [{name, count}] for index tiles, count DESC
    Q_INVOKABLE QVariantList genreCounts(const QString& medium) const;

    // Deep Theatre catalogue (spec 2026-08-01): paged, allowlisted, fully-bound anime
    // queries. `query` accepts only: order ("members"|"score"|"year"), status, type, tag,
    // yearFrom, yearTo, voteFloor, membersMin, membersMax — ANY other key, or an unknown
    // order value, returns an empty list. Limit is clamped to [1,100]; every value is
    // bound. Rows come back JIKAN-SHAPED, identical to genreEntries, so mapJikan consumes
    // them unchanged.
    Q_INVOKABLE QVariantList animeCatalog(const QVariantMap& query,
                                          int offset = 0, int limit = 24) const;
    // Exact-query state for animeCatalog. SQLite readiness is reported as
    // source=local,status=success; no remote request is required in that mode.
    Q_INVOKABLE QVariantMap animeCatalogState(const QVariantMap& query,
                                              int offset = 0, int limit = 24) const;
    // Explicit retry only for the same failed remote query key. Never fetch in local mode.
    Q_INVOKABLE bool retryAnimeCatalog(const QVariantMap& query,
                                       int offset = 0, int limit = 24);

    // Offline exact-title identity lookup. Returns every normalized-exact
    // candidate so the caller can reject ambiguous matches conservatively.
    // medium is "anime", "manga", or empty for both tables; year==0 is unset.
    Q_INVOKABLE QVariantList matchByTitle(const QString& title, int year = 0,
                                          const QString& medium = {}) const;
    // Offline single-row lookup by MAL id (catalogue-independence Slice 2, 2026-08-20) —
    // the series masthead's identity-first path. One bound SELECT on the manga table,
    // mapped to the SAME Jikan-shaped row genreEntries() emits for manga (title,
    // title_english, score, members, status, volumes/chapters, year+published,
    // images.jpg.large_image_url, synopsis, authors, genres). Empty map when not ready
    // or malId not found — never a partial row.
    Q_INVOKABLE QVariantMap mangaById(int malId) const;
    // Cheap manual Identify search over the baked normalized-title columns. Results are
    // prefix-ranked and remain fully offline; an empty/unknown medium returns no rows.
    Q_INVOKABLE QVariantList search(const QString& text, int limit = 20,
                                    const QString& medium = {}) const;
    Q_INVOKABLE QVariantMap searchState(const QString& text, int limit = 20,
                                       const QString& medium = {}) const;

    // Tankoban Discover (spec 2026-08-01): paged, allowlisted, fully-bound MANGA
    // discovery over the same baked artifact. `axis` is "genre" | "demographic";
    // anything else returns an empty facet list. Each facet is {value, count};
    // includeExplicit=false prunes facets that only exist on explicit titles.
    Q_INVOKABLE QVariantList discoverFilters(const QString& axis, bool includeExplicit) const;
    // UI-safe read of facets warmed on a worker. Empty until filterCacheReady fires.
    Q_INVOKABLE QVariantList cachedDiscoverFilters(const QString& axis, bool includeExplicit) const;
    // catalogId ∈ {popular, top-rated, new-releases, trending}; filterAxis ∈
    // {genre, demographic, ""}. filterKey is BOUND (never concatenated). offset is
    // clamped >= 0, limit to [1,100]. Returns
    //   {items, nextOffset, exhausted, freshness:"bundled", fallbackCatalog}
    // where fallbackCatalog is "popular" for trending (no comparable snapshots yet)
    // and "" otherwise. An unknown catalogId or axis returns the same map with no
    // items. Every row carries availability:false for the adapter to enrich later.
    Q_INVOKABLE QVariantMap discoverPage(const QString& catalogId,
                                         const QString& filterAxis,
                                         const QString& filterKey,
                                         bool includeExplicit,
                                         int offset, int limit) const;
    // Same page, any number of filters ANDed: filters = [{axis, key}, ...] (one per axis;
    // Discover sidebar: one filter per group). discoverPage() is this with one pair.
    Q_INVOKABLE QVariantMap discoverPageFiltered(const QString& catalogId,
                                                 const QVariantList& filters,
                                                 bool includeExplicit,
                                                 int offset, int limit) const;
    // Exact-query state for this page route. SQLite readiness is reported as
    // source=local,status=success; no remote request is required in that mode.
    Q_INVOKABLE QVariantMap discoverPageFilteredState(const QString& catalogId,
                                                      const QVariantList& filters,
                                                      bool includeExplicit,
                                                      int offset, int limit) const;
    // Explicit retry only for the same failed remote page key. Never fetch in local mode.
    Q_INVOKABLE bool retryDiscoverPageFiltered(const QString& catalogId,
                                                const QVariantList& filters,
                                                bool includeExplicit,
                                                int offset, int limit);

signals:
    void readyChanged();
    void revisionChanged();
    void requestFailed(QString method, QString reason);
    // All native MAL query keys; subscribers compare against the exact page state key.
    void remoteQueryChanged(QString key);
    void filterCacheReady();

private:
    bool openAt(const QString& dbPath);
    void warmDiscoverFilters();
    QVariantList discoverFiltersUncached(const QString& axis, bool includeExplicit) const;

    CatalogRemote* m_remote;
    QSqlDatabase m_db;
    bool m_ok = false;
    QString m_conn;    // discoverFilters() answers per axis/explicit flag, computed once per opened database:
    // each is a GROUP BY over the whole catalogue (~0.45 s) and Discover asks repeatedly.
    mutable QHash<QString, QVariantList> m_filterCache;
    int m_filterGeneration = 0;
};
