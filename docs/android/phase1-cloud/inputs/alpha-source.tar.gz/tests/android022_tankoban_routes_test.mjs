// Exercise the production routing/label functions with only shell effects replaced.
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { runInNewContext } from 'node:vm';
import { test } from 'node:test';

const main = readFileSync(new URL('../qml/Main.qml', import.meta.url), 'utf8');
const series = readFileSync(new URL('../qml/MangaSeries.qml', import.meta.url), 'utf8');
const world = readFileSync(new URL('../qml/TankobanWorld.qml', import.meta.url), 'utf8');

test('featured carousel index routes its actual catalogue slide to Read', () => {
    const handler = /onPrimaryClicked:\s*\((\w+)\)\s*=>\s*([^\n]+)/.exec(world);
    assert.ok(handler, 'world connects its carousel primary signal');
    const slides = [{ title: 'One Piece', ghost: 'M' }, { title: 'Saga', ghost: 'C' }];
    let requested;
    const invoke = new Function('Catalog', 'tanko', handler[1], handler[2]);
    invoke({ featured: slides }, { featuredReadRequested: slide => { requested = slide; } }, 0);
    assert.equal(requested, slides[0]);
});

function loadFunction(source, name, context) {
    const start = source.indexOf('    function ' + name + '(');
    assert.ok(start >= 0, 'production ' + name + ' exists');
    const end = source.indexOf('\n    }', start);
    assert.ok(end > start, 'production function has a body');
    runInNewContext(source.slice(start, end + 6), context);
    return context[name];
}

for (const lane of ['seriesLayer', 'westernLayer', 'comicSeriesLayer']) {
    test('reader Back retains its originating ' + lane, () => {
        const closed = [];
        const layers = Object.fromEntries(['seriesLayer', 'westernLayer', 'comicSeriesLayer']
            .map(name => [name, { active: name === lane, item: {
                openChapterId: name === lane ? 'chapter-3' : '', openChapterLabel: 'Chapter 3',
            }}]));
        const context = {
            ...layers,
            Sessions: { activeId: '', get: () => ({}) },
            win: { closeComicReader: () => closed.push('whole page') },
        };
        loadFunction(main, 'backComicReader', context)();
        assert.equal(layers[lane].active, true);
        assert.equal(layers[lane].item.openChapterId, '');
        assert.equal(layers[lane].item.openChapterLabel, '');
        assert.deepEqual(closed, []);
    });
}

test('reader Back retires the active comic record without tearing down its series', () => {
    const closed = [];
    const layer = { active: true, item: { openChapterId: 'chapter-3', openChapterLabel: 'Chapter 3' } };
    const context = {
        seriesLayer: layer, westernLayer: { active: false }, comicSeriesLayer: { active: false },
        Sessions: { activeId: 'comic-1', get: () => ({ id: 'comic-1', contentKind: 'comic' }),
            close: id => closed.push(id) },
        win: { closeComicReader: () => closed.push('whole page') },
    };
    loadFunction(main, 'backComicReader', context)();
    assert.equal(layer.active, true);
    assert.equal(layer.item.openChapterId, '');
    assert.deepEqual(closed, ['comic-1']);
});

test('standalone comic Back keeps its existing close authority', () => {
    let closed = 0;
    const context = {
        seriesLayer: { active: false }, westernLayer: { active: false }, comicSeriesLayer: { active: false },
        win: { closeComicReader: () => ++closed },
    };
    loadFunction(main, 'backComicReader', context)();
    assert.equal(closed, 1);
});

test('cold Continue uses its saved chapter label and a late catalogue label supersedes it', () => {
    const page = { seriesId: 'mal:13', chaptersModel: [], openChapterId: 'chapter-3', openChapterLabel: '',
        progressRef: { revision: 1, get: (kind, id) => {
            assert.equal(kind, 'manga');
            assert.equal(id, 'mal:13');
            return { sub: 'Chapter 3', resume: { chapterId: 'chapter-3' } };
        }},
    };
    const label = loadFunction(series, '_chapterLabelById', { page });
    assert.equal(label('chapter-3'), 'Chapter 3');
    page.openChapterLabel = 'Chapter 2';
    assert.equal(label('chapter-3'), 'Chapter 3', 'a reused page must prefer the matching Continue record');
    page.chaptersModel = [{ id: 'chapter-3', name: 'Chapter 3: New title' }];
    assert.equal(label('chapter-3'), 'Chapter 3: New title');
    assert.equal(label('chapter-4'), 'Chapter', 'saved label belongs only to the saved chapter');
});

test('featured Read dispatches its manga action after cold load or immediately on a warm page', () => {
    for (const warm of [false, true]) {
        const effects = [];
        const seriesLayer = { active: false, item: null, featuredReadPending: false };
        const context = { seriesLayer,
            win: {
                openSeries: title => {
                    effects.push(title);
                    seriesLayer.active = true;
                    if (warm) seriesLayer.item = { readPrimary: () => effects.push('read') };
                },
                openWestern: data => effects.push(data.title),
            },
        };
        loadFunction(main, 'readTankobanFeatured', context)({ title: 'One Piece', ghost: 'M' });
        assert.deepEqual(effects, warm ? ['One Piece', 'read'] : ['One Piece']);
        assert.equal(seriesLayer.featuredReadPending, !warm);
    }
});


function exerciseFeaturedComics(extensions) {
    const effects = [];
    const context = {
        seriesLayer: { active: false, item: null, featuredReadPending: false },
        win: {
            openExtensionsPage: page => effects.push(['extensions', page]),
            openWestern: data => effects.push(['western', data.title]),
            openSeries: title => effects.push(['series', title]),
        },
    };
    if (extensions !== undefined) context.Extensions = extensions;
    loadFunction(main, 'readTankobanFeatured', context)({ title: 'Invincible', ghost: 'C' });
    return effects;
}

test('featured comics route a missing GetComics integration to Tankoban extensions', () => {
    for (const extensions of [undefined, { installed: () => [] }]) {
        assert.deepEqual(exerciseFeaturedComics(extensions), [['extensions', 'tankoban']]);
    }
});

test('featured comics route a disabled GetComics integration to Tankoban extensions', () => {
    const extensions = { installed: () => [
        { id: 'colosseum.well.getcomics.issues', enabled: false },
        { id: 'another.extension', enabled: true },
    ] };
    assert.deepEqual(exerciseFeaturedComics(extensions), [['extensions', 'tankoban']]);
});

test('featured comics open the western shelf only when GetComics is enabled', () => {
    const extensions = { installed: () => [
        { id: 'colosseum.well.getcomics.issues', enabled: true },
    ] };
    assert.deepEqual(exerciseFeaturedComics(extensions), [['western', 'Invincible']]);
});
