"""Check the qmldir-only newline transform against actual CMake execution."""
import hashlib
import importlib.util
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location('runtime_packaging', ROOT / 'tests/test_android_runtime_packaging.py')
PACKAGING = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(PACKAGING)


class RuntimePackagingEolTests(unittest.TestCase):
    def fixture(self, newline):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        root = Path(temp.name)
        source = root / 'source/qml'
        overlay = root / 'overlay/qml'
        (source / 'reader2').mkdir(parents=True)
        (overlay / 'reader2').mkdir(parents=True)
        qmldir = newline.join((b'module Reader2', b'Paper Paper.qml', b'Chapter 1.0 Chapter.qml', b''))
        main = b'import QtQuick\r\nItem {}\r\n'
        (source / 'reader2/qmldir').write_bytes(qmldir)
        (source / 'Main.qml').write_bytes(main)
        (overlay / 'reader2/qmldir').write_bytes(qmldir)
        # Execute the production transform stanza, not a Python approximation.
        cmake_source = (ROOT / 'native/cmake/android.cmake').read_text(encoding='utf-8')
        stanza = cmake_source.split('set(_android_reader_qmldir ', 1)[1].split('\nendif()', 1)[0]
        script = root / 'stage.cmake'
        script.write_text('set(COLOSSEUM_ANDROID_QML_ROOT "' + overlay.as_posix() + '")\n'
                          'set(_android_reader_qmldir ' + stanza + '\nendif()\n'
                          'configure_file("' + (source / 'Main.qml').as_posix() + '" "' +
                          (overlay / 'Main.qml').as_posix() + '" COPYONLY)\n', encoding='utf-8')
        cmake = shutil.which('cmake')
        self.assertIsNotNone(cmake, 'CMake is required for this regression check')
        run = subprocess.run([cmake, '-P', str(script)], capture_output=True, text=True)
        self.assertEqual(run.returncode, 0, run.stdout + run.stderr)
        return source.parent, overlay, main

    def check_qmldir(self, newline):
        repo, overlay, _ = self.fixture(newline)
        actual = (overlay / 'reader2/qmldir').read_bytes()
        self.assertEqual(actual, b'module Reader2\nChapter 1.0 Chapter.qml\n')
        self.assertEqual(PACKAGING.expected_overlay(repo)['qml/reader2/qmldir'], hashlib.sha256(actual).hexdigest())

    def test_lf_qmldir_matches_cmake_unix_transform(self):
        self.check_qmldir(b'\n')

    def test_crlf_qmldir_matches_cmake_unix_transform(self):
        self.check_qmldir(b'\r\n')

    def test_ordinary_crlf_qml_is_byte_identical_and_stale_drift_still_fails(self):
        repo, overlay, main = self.fixture(b'\r\n')
        expected = PACKAGING.expected_overlay(repo)
        self.assertEqual((overlay / 'Main.qml').read_bytes(), main)
        self.assertEqual(expected['qml/Main.qml'], hashlib.sha256(main).hexdigest())
        stale = dict(expected)
        stale['qml/Main.qml'] = hashlib.sha256(main.replace(b'\r\n', b'\n')).hexdigest()
        self.assertEqual(PACKAGING.overlay_drift(expected, stale), ['changed qml/Main.qml'])


if __name__ == '__main__':
    unittest.main(verbosity=2)
