import QtQuick
import QtQuick.Window
import QtTest
import "../../qml" as App

TestCase {
    id: testCase
    name: "Android022TemplateGeometry"
    when: windowShown
    property int detailsCount: 0
    readonly property var featuredSlides: [
        {title:"Invincible",blurb:"Mark Grayson inherits powers from his father, then learns the truth.",c1:"#352311",c2:"#14100c"},
        {title:"Saga",blurb:"A family travels across a galaxy.",c1:"#352311",c2:"#14100c"},
        {title:"Berserk",blurb:"A swordsman's journey.",c1:"#352311",c2:"#14100c"},
        {title:"One Piece",blurb:"A pirate's journey.",c1:"#352311",c2:"#14100c"}
    ]
    Window { id: host; width:354; height:792; visible:true; property bool androidHost:true }
    Component {
        id: carouselComponent
        App.FeaturedCarousel {
            width:host.width
            height:implicitHeight
            slides:testCase.featuredSlides
            onSecondaryClicked: testCase.detailsCount += 1
        }
    }
    Component {
        id: sourcesComponent
        App.MangaTankobanSourcesPage {
            open:true
            context:({seriesTitle:"One Piece",volumeNumber:"1",
                      synopsis:"Gol D. Roger is set to be executed. Before his death he confirms the existence of the great treasure, One Piece, hidden somewhere in the vast ocean known as the Grand Line. Anyone worthy can claim it."})
        }
    }
    function find(node,predicate) {
        if(predicate(node)) return node
        for(const child of node.children || []) {
            const found=find(child,predicate)
            if(found) return found
        }
        return null
    }
    function box(item,ancestor) {
        const p=item.mapToItem(ancestor,0,0)
        return {left:p.x,top:p.y,right:p.x+item.width,bottom:p.y+item.height}
    }
    function overlap(a,b) {
        return a.left<b.right && b.left<a.right && a.top<b.bottom && b.top<a.bottom
    }
    function init() { host.width=354; host.height=792; detailsCount=0 }
    function test_portrait_dots_do_not_cover_details() {
        const carousel=createTemporaryObject(carouselComponent,host.contentItem)
        verify(carousel!==null)
        wait(60)
        const details=findChild(carousel,"featuredSecondaryAction_0")
        const dot=find(carousel,item=>item["accessibleName"]==="Featured story 1")
        verify(details!==null && dot!==null)
        const detailsBox=box(details,carousel), dotBox=box(dot,carousel)
        verify(!overlap(detailsBox,dotBox),"Details overlaps the first dot hit target: "
               +JSON.stringify(detailsBox)+" vs "+JSON.stringify(dotBox))
        verify(detailsBox.top>=0 && detailsBox.bottom<=carousel.height)
        verify(dotBox.top>=0 && dotBox.bottom<=carousel.height)
        const p=details.mapToItem(host.contentItem,details.width/2,details.height/2)
        mouseClick(host.contentItem,p.x,p.y)
        compare(detailsCount,1,"Details stays pointer reachable")
    }
    function test_source_header_clears_back_data() {
        return [{tag:"phone-landscape",width:792,height:354},
                {tag:"phone-portrait",width:354,height:792}]
    }
    function test_source_header_clears_back(data) {
        host.width=data.width;host.height=data.height
        const page=createTemporaryObject(sourcesComponent,host.contentItem)
        verify(page!==null)
        wait(60)
        const back=findChild(page,"tankobanSourcesBack")
        const eyebrow=find(page,item=>item["text"]==="SOURCES · TANKOBAN VOLUME")
        const synopsis=findChild(page,"tankobanSourcesSynopsis")
        verify(back!==null && eyebrow!==null && synopsis!==null)
        const backBox=box(back,page), headerBox=box(eyebrow.parent,page)
        verify(headerBox.top>=0 && !overlap(backBox,headerBox),"Source header begins at "+headerBox.top
               +" and intersects Back ending at "+backBox.bottom)
        const synopsisBox=box(synopsis,page)
        verify(synopsisBox.top>=0 && synopsisBox.bottom<page.height,
               "Volume synopsis remains inside the viewport")
        verify(backBox.left>=0 && backBox.top>=0 && backBox.bottom<=page.height)
        const enable=findChild(page,"tankobanSourcesEnableRoute")
        verify(enable!==null && enable.visible)
        const enableBox=box(enable,page)
        verify(enableBox.top>=synopsisBox.bottom && enableBox.bottom<=page.height,
               "Open Extensions stays reachable below the hero: "+JSON.stringify(enableBox))
    }
    function test_short_landscape_carousel_remains_compact() {
        host.width=792;host.height=354
        const carousel=createTemporaryObject(carouselComponent,host.contentItem)
        verify(carousel!==null)
        tryCompare(carousel,"implicitHeight",186,2000)
    }
}
