from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
NATIVE = ROOT / "native"


def test_platform_services_are_wired_into_build_graph():
    cmake = (NATIVE / "CMakeLists.txt").read_text(encoding="utf-8-sig")
    required_sources = [
        "account/AccountCredentialStoreFactory.cpp",
        "account/AndroidAccountCredentialStore.cpp",
        "account/AndroidJniSecureStorageBackend.cpp",
        "platform/PlatformKind.cpp",
        "platform/PlatformRuntime.cpp",
        "platform/AndroidWindowModeAdapter.cpp",
        "platform/BackgroundDownloadBridge.cpp",
    ]
    for source in required_sources:
        assert source in cmake, f"missing app build wiring: {source}"
    assert "add_executable(platform_services_harness" in cmake
    assert 'include("${CMAKE_CURRENT_SOURCE_DIR}/cmake/android.cmake")' in cmake
    android_cmake = (NATIVE / "cmake" / "android.cmake").read_text(encoding="utf-8-sig")
    assert "QT_ANDROID_PACKAGE_SOURCE_DIR" in android_cmake
    java = NATIVE / "platform" / "android" / "src" / "org" / "colosseum" / "platform" / "SecureCredentialStore.java"
    assert java.is_file(), "Android secure-store Java source is outside package-source src/"


def test_platform_services_harness_is_registered_with_ctest():
    tests_cmake = (ROOT / "tests" / "CMakeLists.txt").read_text(encoding="utf-8-sig")
    assert "colosseum_register_harness(platform_services_harness" in tests_cmake


def test_platform_kind_selector_avoids_legacy_linux_macro_name():
    header = (NATIVE / "platform" / "PlatformKind.h").read_text(encoding="utf-8-sig")
    signature = next(
        line for line in header.splitlines()
        if "constexpr Kind selectKind(" in line
    )
    assert "bool linux" not in signature, (
        "selectKind uses the GNU/Linux predefined macro name `linux` as a parameter"
    )


def test_platform_runtime_exposes_android_tv_contract():
    header = (NATIVE / "platform" / "PlatformRuntime.h").read_text(encoding="utf-8-sig")
    source = (NATIVE / "platform" / "PlatformRuntime.cpp").read_text(encoding="utf-8-sig")
    assert "Q_PROPERTY(bool androidTelevision READ androidTelevision CONSTANT)" in header
    assert "bool androidTelevision() const;" in header
    assert "bool Runtime::androidTelevision() const" in source
    assert "QNativeInterface::QAndroidApplication::context()" in source
    assert "getCurrentModeType" in source
    assert "android.software.leanback" in source


if __name__ == "__main__":
    test_platform_services_are_wired_into_build_graph()
    test_platform_services_harness_is_registered_with_ctest()
    test_platform_kind_selector_avoids_legacy_linux_macro_name()
    test_platform_runtime_exposes_android_tv_contract()
    print("ANDROID_PLATFORM_SERVICES_CONTRACT_OK")
