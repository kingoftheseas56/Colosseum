// Colosseum — HOME (v1, on the proven spine)
// Fullscreen-exclusive frameless OS surface: persistent wallpaper + frosted-glass chrome.
//   Top bar -> universal Continue -> per-medium widgets.
// Glass = proven material (see Glass.qml).
// Run:  C:/Qt/6.11.1/mingw_64/bin/qml.exe qml/Main.qml      (Esc / Ctrl+Q to quit)

import QtQuick
import QtQuick.Window
import QtQuick.Layouts
import QtQuick.Controls
import QtCore
import QtQuick.Dialogs
import "account"
import "collections" as CollectionsUi
import "CollectionsReferences.js" as CollectionsReferences
import "Catalog.js" as Catalog
import "TheatreApi.js" as TheatreApi
import "ContinueVideoPresentation.js" as VideoPresentation
import "UniverseExtApi.js" as UniverseApi
import "UniverseContentApi.js" as UniverseContent
import "Universes.js" as UniverseCanon
import "ExtensionsCatalog.js" as ExtCatalog
import "LocgApi.js" as Locg
import "ComicsApi.js" as GcApi
import "ComicsDb.js" as ComicsDb
import "CatalogDelivery.js" as CatalogDelivery
import "ComicResolve.js" as Resolve
import "AddonClient.js" as AddonClient
import "Subtitles.js" as Subtitles
import "Torrentio.js" as Torrentio
import "EpisodeBrowser.js" as EpisodeBrowser
import "BiblioApi.js" as BiblioApi
import "CollectionBackfill.js" as CollectionBackfill
import "WarmingQueue.js" as Warming
import "ShellBackPolicy.js" as ShellBackPolicy
import "WallpaperApi.js" as Wallpapers

Window {
    id: win
    // Hidden until the native WindowModeStore chooses the startup presentation
    // (fullscreen by default; developer-windowed if that was the last stable mode).
    visible: false
    flags: Qt.Window | Qt.FramelessWindowHint
    color: "#05060a"
    title: "Colosseum"

    property bool applicationQuitPending: false
    property bool applicationQuitReady: false
    property string applicationQuitError: ""

    function completeApplicationQuit() {
        if (!applicationQuitPending || applicationQuitReady) return
        applicationQuitReady = true
        console.info("[quit] Feria drained")
        Qt.callLater(function() { Qt.quit() })
    }
    function failApplicationQuit(reason) {
        if (!applicationQuitPending) return
        applicationQuitPending = false
        applicationQuitError = reason
        console.warn("[quit] Waiting for Feria: " + reason)
    }
    function requestApplicationQuit() {
        if (win.guardNamedCollectionsNavigation(function() { win.requestApplicationQuit() })) return

        if (applicationQuitPending) return
        applicationQuitPending = true
        applicationQuitError = ""
        // Android never loads the browser deck. Do not instantiate it just to quit.
        if (!feriaAvailable || !feriaSessionDeck.item) {
            completeApplicationQuit()
            return
        }
        // Keep the event loop alive until Feria retires its views, then profiles.
        console.info("[quit] Closing Feria sessions")
        feriaSessionDeck.item.startQuiescence(true)
    }
    onClosing: function(event) {
        if (applicationQuitReady) return
        event.accepted = false
        win.requestApplicationQuit()
    }

    Rectangle {
        anchors { left: parent.left; right: parent.right; bottom: parent.bottom }
        height: quitErrorText.implicitHeight + 24
        z: 1000
        color: "#321e25"
        visible: win.applicationQuitError.length > 0
        Text {
            id: quitErrorText
            anchors.centerIn: parent
            width: parent.width - 32
            wrapMode: Text.WordWrap
            color: "#fff2ee"
            text: "A browser is still closing. Close the dependent page, then try quitting again."
        }
    }

    property string currentSurface: "Home"
    readonly property bool feriaComingSoon: typeof FeriaLiveEnabled === "undefined" || !FeriaLiveEnabled
    property bool feriaRuntimeReady: false
    readonly property alias televisionMode: phoneShell.televisionMode
    property var vinylWorld: null
    readonly property bool vinylVideoFullscreen: !!win.vinylWorld && worldStack.current === "Vinyl"
        && win.vinylWorld.videoFullscreen === true
    property var vinylVideoReturnWindowed: null
    onVinylVideoFullscreenChanged: {
        if (vinylVideoFullscreen && vinylVideoReturnWindowed === null && typeof WindowMode !== "undefined")
            vinylVideoReturnWindowed = WindowMode.shellWindowed
        win.syncVinylVideoWindowMode()
    }
    function syncVinylVideoWindowMode() {
        if (typeof WindowMode === "undefined" || fullscreenTransition.transitioning) return
        var wanted = vinylVideoFullscreen ? false : vinylVideoReturnWindowed
        if (wanted === null) return
        if (WindowMode.shellWindowed !== wanted) {
            win.toggleFullscreenShell()
            return
        }
        if (!vinylVideoFullscreen) vinylVideoReturnWindowed = null
    }
    property var pendingVinylResume: null
    property bool audioHandoffBusy: false
    property string audioOwner: ""
    property bool vinylProfileActive: true
    property int vinylShellGeneration: 0
    // Arbitration lives at the shell; engines retain their own queues and resume state.
    function claimAudio(owner) {
        if (win.audioHandoffBusy) return
        win.audioHandoffBusy = true
        try {
            win.audioOwner = owner
            if (owner !== "vinyl" && win.vinylWorld)
                win.vinylWorld.session.suspendPlayback("audio-handoff")
            if (owner !== "audiobook") audioSession.suspendForAudioHandoff()
            if (owner !== "theatre") {
                win.pendingPlayerOpen = null
                if (playerLayer.item) {
                    if (playerLayer.item.suspendForAudioHandoff)
                        playerLayer.item.suspendForAudioHandoff()
                    else if (playerLayer.item.suspendForMinimize)
                        playerLayer.item.suspendForMinimize()
                }
            }
        } finally { win.audioHandoffBusy = false }
    }
    function requestTheatreAudio() {
        win.claimAudio("theatre")
        if (playerLayer.item && playerLayer.item.requestAudioPlayback)
            playerLayer.item.requestAudioPlayback()
    }
    function registerVinylSession() {
        if (!win.vinylEnabled || !win.vinylProfileActive) return
        Sessions.openOrSwitch({ appType: "vinyl", contentKind: "music", title: "Vinyl",
                                target: { id: "vinyl-session" } })
    }
    function leaveVinylProfile() {
        win.vinylProfileActive = false
        win.vinylShellGeneration++
        win.pendingVinylResume = null
        win.pendingPlayerOpen = null
        win.audioOwner = ""
        if (win.vinylWorld) win.vinylWorld.session.suspendPlayback("profile-leaving")
        audioSession.stop()
        if (playerLayer.item) {
            if (playerLayer.item.suspendForAudioHandoff) playerLayer.item.suspendForAudioHandoff()
            playerLayer.item.stop()
        }
        win.warmPlayerSessionId = ""
        win.playerOpen = false
        var records = Sessions.list()
        for (var i = 0; i < records.length; i++)
            if (["music", "movie", "book"].indexOf(records[i].contentKind) >= 0)
                win.closeSession(records[i].id)
    }
    readonly property bool vinylEnabled: typeof VinylLiveEnabled !== "undefined" && VinylLiveEnabled
    function openVinylResume(entry, play) {
        if (!vinylEnabled || !vinylProfileActive) return
        pendingVinylResume = { entry: entry, play: play, generation: vinylShellGeneration }
        openWorld("Vinyl")
        applyVinylResume()
    }
    function applyVinylResume() {
        if (!vinylWorld || !pendingVinylResume) return
        var pending = pendingVinylResume
        if (!vinylProfileActive || pending.generation !== vinylShellGeneration) {pendingVinylResume=null;return}
        if (!vinylWorld.canEnterVinyl) {vinylWorld.enforceTasteGate();return}
        pendingVinylResume = null
        vinylWorld.session.snapshot()
        vinylWorld.session.restore(pending.entry)
        vinylWorld.page = pending.play ? "song" : "album"
        if (pending.play) vinylWorld.session.paused = false
    }
    Connections {
        target: win.vinylWorld
        ignoreUnknownSignals: true
        function onCanEnterVinylChanged() {
            if(win.vinylWorld && win.vinylWorld.canEnterVinyl)Qt.callLater(win.applyVinylResume)
        }
    }
    property var feriaReturnSnapshot: null
    // Feria is desktop-only (its deck rides QtWebEngine, which Android does not ship).
    // Every Feria surface below is a string-source Loader gated on this flag, so nothing
    // under qml/feria/ is parsed on Android.
    readonly property bool feriaAvailable: Qt.platform.os !== "android"
    readonly property bool worldWarmerEnabled: (typeof DevWorldWarmer !== "undefined") && DevWorldWarmer
    property var pendingIdentityRoute: null
    // The Biblio detail layer is owned by this shell. Keep one route-local
    // return snapshot so closing it restores the live page item and bounded
    // offsets without introducing a global focus history service.
    property var bookReturnSnapshot: null
    property int bookRouteGeneration: 0
    property var pendingBookReturn: null
    // Keep the same 25% identifiable-portion threshold as spatial landing.
    readonly property real bookReturnIdentifiablePortionRatio: 0.25
    // Explicit layer references keep route coverage tests and helpers on the actual Loader
    // owners; the component ids themselves are not Window properties.
    readonly property var bookLayerRef: bookLayer
    readonly property var bookReaderLayerRef: bookReaderLayer
    readonly property var playerLayerRef: playerLayer
    readonly property var searchLayerRef: searchLayer
    readonly property var vaultLayerRef: vaultLayer
    property bool reducedMotion: false     // single shell motion preference seam for Update surfaces
    readonly property string defaultWallpaperSource: typeof Content !== "undefined"
        ? (Content.generation, Wallpapers.imageSource(null, Content)) : ""
    property string wallpaperSource: win.defaultWallpaperSource
    onDefaultWallpaperSourceChanged: Qt.callLater(win.refreshWallpaper)
    property alias androidHost: phoneShell.androidHost
    AdaptiveLayout { id: presentationPolicy; viewportWidth: win.width }
    readonly property alias desktopPresentation: presentationPolicy.desktopPresentation
    readonly property real headerOuterMargin: win.androidHost && win.desktopPresentation ? 16 : theme.margin
    readonly property real outerPageMargin: win.androidHost && win.desktopPresentation
        ? presentationPolicy.outerPageMargin : theme.margin

    // Non-visual, non-secret bridge projection for the tagged Stremio connection fixture.
    // Lanista deliberately reads QQuickItem properties only; never expose credentials,
    // provider account ids, callback URLs, or configured addon state here.
    Item {
        objectName: "stremioSyncState"
        visible: false
        width: 0
        height: 0
        property var status: stremioSyncState.status
        property var pendingCount: stremioSyncState.pendingCount
        property var lastSuccessAt: stremioSyncState.lastSuccessAt
        property var activeProfileId: stremioSyncState.activeProfileId
        property var mergeComplete: stremioSyncState.mergeComplete
        property var completedRun: stremioSyncState.completedRun
        property var accountDisplayName: stremioSyncState.accountDisplayName
        property var lastResultSummary: stremioSyncState.lastResultSummary
        property var linkedAccount: stremioSyncState.linkedAccount
    }

    // Lanista's existing qml-get reads named QQuickItems. Keep the RR state
    // projection read-only and content-free; the native owner exposes fixture
    // scalars only in its exact compile/tag-gated test build.
    Item {
        objectName: "ratingsReviewsDeliveryState"
        visible: false
        width: 0
        height: 0
        property var sourceState: ratingsReviewsDeliveryState
        property var activeProfileId: sourceState ? sourceState.activeProfileId : ""
        property int pendingCount: sourceState ? sourceState.pendingCount : 0
        property int unknownCount: sourceState ? sourceState.unknownCount : 0
        property var providerRows: sourceState ? sourceState.providerRows : []
        property string fixturePhase: sourceState && sourceState.fixturePhase !== undefined
                                      ? sourceState.fixturePhase : ""
        property int fixtureARatingSendCount: sourceState
                                             ? Number(sourceState.fixtureARatingSendCount || 0) : 0
        property int fixtureAReviewSendCount: sourceState
                                             ? Number(sourceState.fixtureAReviewSendCount || 0) : 0
        property int fixtureBSendCount: sourceState
                                       ? Number(sourceState.fixtureBSendCount || 0) : 0
        property int fixtureBReconcileCount: sourceState
                                            ? Number(sourceState.fixtureBReconcileCount || 0) : 0
        property int fixtureSpoilerBlockedSendCount: sourceState
                                                     ? Number(sourceState.fixtureSpoilerBlockedSendCount || 0) : 0
    }

    function theatreWorldItem() {
        for (let i = 0; i < worldRepeater.count; ++i) {
            const loader = worldRepeater.itemAt(i)
            if (loader && loader.mode === "Theatre" && loader.item)
                return loader.item
        }
        return null
    }
    function openStremioSyncPanel() {
        stremioPanel.shown = true
    }
    function closeStremioSyncPanel() {
        stremioPanel.shown = false
        if (syncCenterLayer.active && syncCenterLayer.item) {
            Qt.callLater(function() { syncCenterLayer.item.focusMainSyncButton() })
            return
        }
        const theatreWorld = win.theatreWorldItem()
        if (theatreWorld)
            Qt.callLater(function() { theatreWorld.focusStremioButton() })
    }
    function requestTheatreRemoval(entry) {
        theatreRemoval.entry = entry
        theatreRemoval.shown = true
    }

    // The existing Theatre metadata reader is the only QML participant in
    // Stremio episode-state reconciliation. It receives a one-shot opaque
    // request and returns an identity-only ordered episode map; the native
    // owner retains profile/account fences, timeouts, compressed watched data,
    // and all validation. This has no visual or user-control surface.
    Connections {
        target: (typeof stremioSyncState !== "undefined") ? stremioSyncState : null
        function onEpisodeMetadataRequested(requestId, seriesId) {
            TheatreApi.loadMeta("series", seriesId, function(meta) {
                var projection = TheatreApi.stremioEpisodeMetadataProjection(meta, seriesId)
                stremioSyncState.submitEpisodeMetadata(
                    requestId, projection.metadataRootId, projection.episodes)
            })
        }
        Component.onCompleted: {
            if (target)
                target.setEpisodeMetadataBridgeReady(true)
        }
    }

    Connections {
        target: typeof Content !== "undefined" ? Content : null
        function onGenerationChanged() { UniverseContent.reload(Content.generation) }
    }

    // Arc 41 semantic keyboard authority. Commands hold meaning and metadata; the shell's
    // Shortcut objects below only deliver the physical chord into this registry-backed action.
    KeyboardRegistry {
        id: keyboardRegistry
        objectName: "keyboardRegistry"
    }
    KeyboardCommand {
        id: openMediaCommand
        enabled: win.localMediaAvailable
        semanticId: "global.openMedia"
        label: "Open media"
        category: "Shortcuts"
        scope: "application"
        sequences: ["Ctrl+O"]
        icon: "file.svg"
        onTriggered: if (win.localMediaAvailable) openMediaDialog.open()
    }
    KeyboardCommand {
        id: openVaultCommand
        semanticId: "global.openVault"
        label: "Open Vault"
        category: "Shortcuts"
        scope: "application"
        sequences: ["Ctrl+Shift+V"]
        icon: "vault.svg"
        onTriggered: win.openVaultPage()
    }
    KeyboardCommand {
        id: openDownloadsCommand
        semanticId: "global.openDownloads"
        label: "Open Downloads"
        category: "Shortcuts"
        scope: "application"
        sequences: ["Ctrl+Shift+D"]
        icon: "download.svg"
        onTriggered: win.openDownloadsPage()
    }
    KeyboardCommand {
        id: openExtensionsCommand
        semanticId: "global.openExtensions"
        label: "Open Extensions"
        category: "Shortcuts"
        scope: "application"
        sequences: ["Ctrl+Shift+E"]
        icon: "extensions.svg"
        onTriggered: win.openExtensionsPage()
    }
    KeyboardCommand {
        id: fullscreenCommand
        semanticId: "global.fullscreen"
        label: "Fullscreen"
        category: "Shortcuts"
        scope: "application"
        sequences: ["F11"]
        icon: "fullscreen.svg"
        onTriggered: {
            if (win.vinylVideoFullscreen) win.vinylWorld.exitVideoFullscreen()
            else win.toggleFullscreenShell()
        }
    }
    KeyboardCommand {
        id: quitCommand
        semanticId: "global.quit"
        label: "Quit Colosseum"
        category: "Shortcuts"
        scope: "application"
        sequences: ["Ctrl+Q"]
        icon: "power.svg"
        onTriggered: win.requestApplicationQuit()
    }
    KeyboardCommand {
        id: escapeCommand
        semanticId: "global.escape"
        label: "Back / close"
        category: "Features"
        scope: "application"
        sequences: ["Escape"]
        icon: "back.svg"
        onTriggered: win.handleEscape()
    }
    function setGuiStallContext(operation, surface) {
        if (typeof GuiStallProbe !== "undefined" && GuiStallProbe)
            GuiStallProbe.setContext(operation, surface)
    }

    // Collection backfill and Biblio cover enrichment are intentionally post-frame work. Both
    // functions are idempotent, but their initial local-model scans can be large enough to hold
    // the GUI inside Component.onCompleted. Start only after native startup has observed the first
    // frame, then give the shell a short settling window so the first interaction is responsive.
    Timer {
        id: postFrameStartupWork
        interval: 350
        repeat: false
        onTriggered: {
            win.runCollectionBackfill()
            win.enrichBiblioCovers()
        }
    }
    property bool startupIdleWorkArmed: false
    property bool auxiliaryFontsReady: false
    Timer {
        id: startupIdleGate
        interval: 2500
        repeat: false
        onTriggered: {
            if (win.androidHost && worldStack.current !== "" && !win.immersiveSurfaceOpen) {
                // Android always stands in a world: do the post-frame work, skip the Home board.
                auxiliaryFontsReady = true
                postFrameStartupWork.start()
                return
            }
            if (worldStack.current !== "" || win.immersiveSurfaceOpen) {
                startupIdleWorkArmed = false
                win.armStartupIdleWork()
                return
            }
            auxiliaryFontsReady = true
            postFrameStartupWork.start()
            win.armHomeIntroWidgets()
            win.armHomeContinueRail()
        }
    }
    // Hosted catalogues only: queue Tankoban Discover's first page and filter lists while the
    // boot splash is up, so the first Manga/Comics Discover open reads the query cache instead
    // of waiting on two sequential static-shard round trips. Same native calls and arguments
    // as TankobanDiscoverApi's default view ("popular", no filters, first 24). A local SQLite
    // catalogue reports source "local" and is skipped, so nothing runs SQL on the GUI thread.
    function warmTankobanDiscover() {
        var x = !!contentPreferences.showExplicit
        function remote(catalog) {
            return catalog && catalog.remoteEnabled && typeof catalog.discoverPageFilteredState === "function"
                && catalog.discoverPageFilteredState("popular", [], x, 0, 24).source === "remote"
        }
        var mal = typeof MalCatalog !== "undefined" ? MalCatalog : null
        if (remote(mal)) {
            mal.cachedDiscoverFilters("genre", x)
            mal.cachedDiscoverFilters("demographic", x)
            mal.discoverPageFiltered("popular", [], x, 0, 24)
        }
        var comics = typeof ComicsCatalog !== "undefined" ? ComicsCatalog : null
        if (remote(comics)) {
            for (var axis of ["genre", "publisher", "format", "availability"])
                comics.discoverFilters(axis, x)
            comics.discoverPageFiltered("popular", [], x, 0, 24)
        }
    }
    function armStartupIdleWork() {
        if (startupIdleWorkArmed || boot.visible) return
        startupIdleWorkArmed = true
        startupIdleGate.start()
    }
    // The Home intro board is below the first viewport and each widget owns its own
    // catalogue requests/poster delegates. Keep their object trees out of Main.qml's
    // pre-first-frame critical path, then instantiate them asynchronously once the
    // shell has had a chance to present and accept input.
    property bool homeIntroWidgetsLoaded: false
    property int homeIntroWidgetCursor: 0
    property var homeIntroPendingLoader: null
    Timer {
        id: homeIntroWidgetsTimer
        interval: 850
        repeat: false
        onTriggered: win.loadHomeIntroWidgets()
    }
    function armHomeIntroWidgets() {
        if (homeIntroWidgetsLoaded || homeIntroPendingLoader) return
        if (boot.visible || worldStack.current !== "" || win.immersiveSurfaceOpen) return
        homeIntroWidgetsTimer.start()
    }

    // Continue is the only Home rail that queries the Progress store while its delegates are
    // created. Keep a fixed reservation so loading it later cannot reflow the Home board, but move
    // the query and ContinueTile object tree behind the post-splash idle boundary.
    property bool homeContinueRailRequested: false
    property bool homeContinueRailLoaded: false
    readonly property int homeContinueRailPlaceholderHeight: 192
    Timer {
        id: homeContinueRailTimer
        interval: 500
        repeat: false
        onTriggered: win.loadHomeContinueRail()
    }
    function armHomeContinueRail() {
        if (homeContinueRailLoaded || homeContinueRailRequested) return
        if (boot.visible || worldStack.current !== "" || win.immersiveSurfaceOpen) return
        homeContinueRailRequested = true
        homeContinueRailTimer.start()
    }
    function loadHomeContinueRail() {
        if (homeContinueRailLoaded) return
        if (worldStack.current !== "" || win.immersiveSurfaceOpen) {
            homeContinueRailRequested = false
            return
        }
        homeContinueRailLoader.sourceComponent = homeContinueRailComponent
        homeContinueRailLoader.active = true
    }
    function loadHomeIntroWidgets() {
        if (homeIntroWidgetsLoaded || homeIntroPendingLoader) return
        if (worldStack.current !== "" || win.immersiveSurfaceOpen) return
        var loaders = [homeBookshelfLoader, homeTheatreStripLoader,
                       homeReadingDeskLoader, homeVaultWidgetLoader]
        var sources = ["Bookshelf.qml", "TheatreStrip.qml",
                       "ReadingDesk.qml", "VaultHomeWidget.qml"]
        if (win.androidHost && !win.desktopPresentation) {
            loaders.pop()
            sources.pop()
        }
        if (homeIntroWidgetCursor >= loaders.length) {
            homeIntroWidgetsLoaded = true
            return
        }
        var loader = loaders[homeIntroWidgetCursor]
        homeIntroWidgetCursor++
        homeIntroPendingLoader = loader
        loader.setSource(sources[homeIntroWidgetCursor - 1], { "backdrop": wall })
        loader.active = true
    }
    function homeIntroWidgetSettled(loader) {
        if (homeIntroPendingLoader !== loader) return
        homeIntroPendingLoader = null
        if (homeIntroWidgetCursor >= (win.androidHost && !win.desktopPresentation ? 3 : 4)) {
            homeIntroWidgetsLoaded = true
            return
        }
        homeIntroWidgetsTimer.restart()
    }
    Connections {
        target: (typeof GuiStallProbe !== "undefined") ? GuiStallProbe : null
        function onFirstFrameReady() {
            win.armStartupIdleWork()
        }
    }
    // Native living wallpapers (2026-07-18, ratified from the arena mock): a pick whose
    // image_url is "native:<id>" loads a QML scene instead of an Image. The registry is
    // the one honest map — an unknown id falls back to the default still.
    readonly property bool wallpaperIsNative: wallpaperSource.indexOf("native:") === 0
    // Mirrors WallpaperApi.nativeSceneFor — keep the two in sync when adding a scene.
    function nativeWallpaperFile(source) {
        if (source === "native:noirflow") return "wallpapers/NoirFlow.qml"
        if (source === "native:aurora-flow") return "wallpapers/AuroraFlow.qml"
        if (source === "native:mesh-twilight") return "wallpapers/MeshTwilight.qml"
        if (source === "native:mesh-ember") return "wallpapers/MeshEmber.qml"
        if (source === "native:mesh-mint") return "wallpapers/MeshMint.qml"
        if (source === "native:lowpoly") return "wallpapers/LowPoly.qml"
        return ""
    }

    // The rebuilt title pages (world feel design, 2026-09-24): TheatreSeriesView.qml and
    // TankobanSeriesView.qml are built to replace TheatreSeries.qml and MangaSeries.qml.
    // Until Hemanth signs them off, a local views.ini (git-ignored, beside wallpapers.ini)
    // selects them: [views] rebuiltTitlePages=true.
    Settings {
        id: viewSettings
        location: Qt.resolvedUrl("../views.ini")
        category: "views"
        property bool rebuiltTitlePages: false
    }

    Settings {
        id: wallpaperSettings
        location: Qt.resolvedUrl("../wallpapers.ini")
        category: "wallpapers"
        property string homePick: ""
        property string tankobanPick: ""
        property string biblioPick: ""
        property string theatrePick: ""
    }

    // The ONE global preference store the whole shell reads (Task 2). Production leaves
    // settingsLocation unset, so it uses the application QSettings store. Threading
    // showExplicit into Theatre/Tankoban/Biblio is Task 9 — here it is only set + surfaced.
    ContentPreferences { id: contentPreferences }

    // Keep direct extension installs aligned with unrestricted catalogue browsing.
    Binding {
        target: typeof Extensions !== "undefined" ? Extensions : null
        property: "showExplicit"
        value: contentPreferences.showExplicit
    }

    function wallpaperKey(world) {
        if (world === "Tankoban") return "tankobanPick"
        if (world === "Biblio") return "biblioPick"
        if (world === "Theatre") return "theatrePick"
        return "homePick"
    }
    function parsePick(raw) {
        if (!raw) return null
        if (typeof raw === "object") return raw
        try {
            var parsed = JSON.parse(raw)
            if (typeof parsed === "string") return { image_url: parsed }
            return parsed
        } catch (e) {
            return { image_url: raw }
        }
    }
    function pickFor(world) {
        return parsePick(wallpaperSettings[wallpaperKey(world)])
    }
    property string activeBrowserSessionId: ""
    property bool browserReturnToFeria: false
    property bool parkingBrowserForWorld: false
    function wallpaperWorldForSession(rec) {
        var appType = rec && rec.appType ? ("" + rec.appType).toLowerCase() : ""
        var contentKind = rec && rec.contentKind ? ("" + rec.contentKind).toLowerCase() : ""
        if (contentKind === "music") return "Vinyl"
        if (contentKind === "browser") return "Feria"
        if (appType === "theatre" || contentKind === "movie") return "Theatre"
        if (appType === "tankoban" || contentKind === "comic") return "Tankoban"
        if (appType === "biblio" || contentKind === "book" || contentKind === "audiobook") return "Biblio"
        return currentSurface || "Home"
    }
    function refreshWallpaper() {
        var pick = pickFor(currentSurface)
        wallpaperSource = Wallpapers.imageSource(pick, typeof Content !== "undefined" ? Content : null)
    }
    function setWallpaperPick(world, pick) {
        wallpaperSettings[wallpaperKey(world)] = typeof pick === "string" ? pick : JSON.stringify(pick || {})
        if (currentSurface === world) refreshWallpaper()
    }
    function setWallpaperEverywhere(pick) {
        var raw = typeof pick === "string" ? pick : JSON.stringify(pick || {})
        wallpaperSettings.homePick = raw
        wallpaperSettings.tankobanPick = raw
        wallpaperSettings.biblioPick = raw
        wallpaperSettings.theatrePick = raw
        refreshWallpaper()
    }

    // One-time migration: everything already downloaded becomes a Collection entry
    // (grouped to the series). Guarded by a hidden "_meta" marker so it runs once —
    // manual removals then stick. New downloads collect live via the detail pages.
    function runCollectionBackfill() {
        if (typeof Collection === "undefined" || typeof LocalDownloads === "undefined") return
        if (Collection.has("_meta", "backfill_v3")) return
        var ths = LocalDownloads.series("theatre") || []
        for (var i = 0; i < ths.length; i++) {
            var te = CollectionBackfill.entryForTheatreSeries(ths[i], LocalDownloads.items("theatre", ths[i].key))
            if (te && !Collection.has("theatre", String(te.id))) Collection.add("theatre", te)
        }
        var tks = LocalDownloads.series("tankoban") || []
        for (var j = 0; j < tks.length; j++) {
            var ke = CollectionBackfill.entryForTankobanSeries(tks[j])
            if (ke && !Collection.has("tankoban", String(ke.id))) Collection.add("tankoban", ke)
        }
        // One-time cleanup: an earlier backfill (pre title-dedup) could add the same
        // book twice — an authorless "title|" entry AND a proper authored "title|author"
        // entry (ebook + audiobook of the same title). Drop the authorless one when an
        // authored entry with the same title exists (the authored id matches a live save).
        var cleanupBiblio = Collection.items("biblio") || []
        var authoredTitles = {}
        for (var cc = 0; cc < cleanupBiblio.length; cc++) {
            var ce = cleanupBiblio[cc]
            var caut = (ce.payload && ce.payload.book && ce.payload.book.author) ? ce.payload.book.author : ""
            if (caut) authoredTitles[CollectionBackfill.titleKey(ce.title)] = true
        }
        for (var cd = 0; cd < cleanupBiblio.length; cd++) {
            var de = cleanupBiblio[cd]
            var daut = (de.payload && de.payload.book && de.payload.book.author) ? de.payload.book.author : ""
            if (!daut && authoredTitles[CollectionBackfill.titleKey(de.title)])
                Collection.remove("biblio", String(de.id))
        }
        // Biblio: dedup by BOTH exact id and normalized title, so a book already
        // saved as "title|author" isn't re-added as an authorless "title|" tile.
        var biblioTitles = {}
        var existingBiblio = Collection.items("biblio") || []
        for (var b0 = 0; b0 < existingBiblio.length; b0++)
            biblioTitles[CollectionBackfill.titleKey(existingBiblio[b0].title)] = true
        function addBook(entry) {
            if (!entry || !entry.id) return
            var tk = CollectionBackfill.titleKey(entry.title)
            if (Collection.has("biblio", String(entry.id)) || biblioTitles[tk]) return
            Collection.add("biblio", entry)
            biblioTitles[tk] = true
        }
        if (typeof Books !== "undefined") {
            var bks = Books.downloadedBooks() || []
            for (var k = 0; k < bks.length; k++)
                addBook(CollectionBackfill.entryForBook(bks[k], BiblioApi.pairKey(bks[k].title || "", bks[k].author || "")))
        }
        if (typeof Audiobooks !== "undefined") {
            var abs = Audiobooks.downloadedAudiobooks() || []
            for (var m = 0; m < abs.length; m++)
                addBook(CollectionBackfill.entryForBook(abs[m], abs[m].id))
        }
        Collection.add("_meta", { "id": "backfill_v3", "type": "flag", "title": "", "cover": "" })
    }

    // Fill covers for backfilled books that have no local cover anywhere. Books with a
    // Progress cover are filled reactively by the Biblio Collection row; this handles the
    // rest by fetching the cover from Apple Books by title and baking it into the entry.
    // Runs each startup but only touches cover-less entries, so it converges.
    function enrichBiblioCovers() {
        if (typeof Collection === "undefined" || typeof BiblioApi === "undefined") return
        var entries = Collection.items("biblio") || []
        if (!entries.length) return
        var progCovered = {}
        if (typeof Progress !== "undefined") {
            var prog = Progress.recent("book", 200) || []
            for (var i = 0; i < prog.length; i++)
                if (prog[i].cover) progCovered[CollectionBackfill.titleKey(prog[i].title)] = true
        }
        for (var j = 0; j < entries.length; j++) {
            var e = entries[j]
            if (e.cover && e.cover !== "") continue                              // already has a cover
            if (progCovered[CollectionBackfill.titleKey(e.title)]) continue      // Progress fills it (render-time)
            if (!e.title) continue
            ;(function(entry) {
                BiblioApi.lookupBook(entry.title, function(book) {
                    if (!book || !book.cover) return
                    var e2 = {}
                    for (var k in entry) e2[k] = entry[k]
                    e2.cover = book.cover
                    e2.art = book.cover
                    Collection.add("biblio", e2)   // upsert same id, now with a cover
                })
            })(e)
        }
    }

    Component.onCompleted: {
        keyboardRegistry.registerCommand(openMediaCommand)
        keyboardRegistry.registerCommand(openVaultCommand)
        keyboardRegistry.registerCommand(openDownloadsCommand)
        keyboardRegistry.registerCommand(openExtensionsCommand)
        keyboardRegistry.registerCommand(fullscreenCommand)
        keyboardRegistry.registerCommand(quitCommand)
        keyboardRegistry.registerCommand(escapeCommand)

        // C++ owns the payload read (Qt blocks file:// XHR by default, and house doctrine keeps
        // transport off the GUI thread's JS). Installed once, here, because a .pragma library
        // holds one shared instance per QML engine. FIRST in this handler on purpose: the dev
        // harnesses below can `return` early, and a universe with no reader renders empty.
        if (typeof Content !== "undefined") {
            UniverseContent.setAssetResolver(function (path) { return Content.assetUrl(path) })
            UniverseContent.setReader(function (key) { return Content.document(key) })
            UniverseContent.reload(Content.generation)
            UniverseApi.setReader(function (file) { return JSON.stringify(Content.document("universe-" + file)) })
        } else if (typeof Extensions !== "undefined") {
            UniverseApi.setReader(function (file) { return Extensions.universePayload(file) })
        }
        Qt.callLater(win.warmTankobanDiscover)
        // Efficiency gate: play a given local file through the real player as soon as the shell is
        // up, so both backends can be measured under identical conditions.
        if (typeof DevAbbaClip !== "undefined" && String(DevAbbaClip).length > 0) {
            var abbaPath = String(DevAbbaClip)
            abbaTimer.path = abbaPath
            abbaTimer.start()
        }
        // Which video backend this launch will use. Announced at startup so a run can be diagnosed
        // without playing anything (Task 17).
        console.log("[player] startup backend = " + (win.usePlayer2 ? "PLAYER 2" : "mpv (player 1)")
                    + "  (booted=" + Player2Available + ")")
        // Native state owns the startup presentation and shows the window; the fallback
        // keeps a bare QML run (harnesses) fullscreen as before.
        if (phoneShell.initializeWindow(typeof WindowMode !== "undefined" ? WindowMode : null))
            ;
        else if (typeof WindowMode !== "undefined")
            WindowMode.initializeShell(win)
        else
            win.showFullScreen()
        refreshWallpaper()
        // The full comics catalog is intentionally absent here. TankobanWorld owns its generated
        // import and ingest so root startup never parses the multi-megabyte payload.
        // LOCG catalogue: real clock + polite request spacer + the resolve machine's deps
        Locg.nowFn = function() { return Date.now() }
        Locg.delayFn = function(ms, cb) { locgSpacer.fire(ms, cb) }
        Resolve.store = {
            get: function(k) { return comicMapStore.value(k, "") },
            set: function(k, v) { comicMapStore.setValue(k, v) }
        }
        // GetComics is the content lane (spec 2026-07-10).
        // Adapter shape: GC tag hits → {id: "<slug>|<tagId>", title}; the composite id
        // is what persists — the series page splits it (slug feeds gc: routing, tagId
        // feeds releases()). GC has no blocked signal: empty = plain no-match,
        // session-only, retry free next launch.
        Resolve.searchFn = function(q, cb) {
            GcApi.searchSeries(q, function(hits) {
                cb((hits || []).map(function(h) {
                    return { id: h.tag + "|" + h.tagId, title: h.title };
                }), { ok: true, blocked: false });
            });
        }
        // Slug-first lane (2026-07-12): WP's tag search floods popular titles out of its
        // own results (Batman 1417 buries Absolute Batman 27) — the exact slug never does.
        Resolve.slugFn = function(slug, cb) {
            GcApi.tagBySlug(slug, function(h) {
                cb(h ? { id: h.tag + "|" + h.tagId, title: h.title } : null);
            });
        }
        // Theatre reads the extension registry through a pushed copy — a .pragma
        // library can't reach context properties (extensions spec Phase 3)
        if (typeof Extensions !== "undefined") {
            TheatreApi.setExtensions(Extensions.installed())
            Subtitles.setExtensions(Extensions.installed())
        }
        // Task 9: push the global Explicit Content preference into TheatreApi so the boot-time
        // marquee rows (loadTheatre/loadHome, airing-anime top-10) honour it. Sexually-explicit
        // ONLY — Berserk/GoT/Ecchi/Mature/TV-MA stay visible; only EXPLICIT_TAGS gate.
        TheatreApi.setShowExplicit(contentPreferences.showExplicit)
        // dev harness (COLOSSEUM_OPEN_EXTENSIONS=1): boot straight into the store,
        // so smoke runs exercise the Loader (QML errors only surface on activation)
        if (typeof DevOpenExtensions !== "undefined" && DevOpenExtensions)
            win.openExtensionsPage()
        // dev harness (COLOSSEUM_OPEN_WORLD="Theatre"): boot straight into a world
        if (typeof DevOpenWorld !== "undefined" && String(DevOpenWorld).length)
            win.openWorld(String(DevOpenWorld))
        // dev harness (COLOSSEUM_OPEN_UNIVERSE="starwars"): boot straight into a universe
        if (typeof DevOpenUniverse !== "undefined" && String(DevOpenUniverse).length) {
            var devUniverse = String(DevOpenUniverse).toLowerCase()
            if (devUniverse === "starwars" || devUniverse === "star-wars")
                win.openUniverse("com.colosseum.universe.starwars", "Star Wars")
            else if (devUniverse === "cosmere")
                win.openUniverse("com.colosseum.universe.cosmere", "Cosmere")
            else   // COLOSSEUM_OPEN_UNIVERSE="Harry Potter": an archived universe, by curated name
                win.openUniverseByName(String(DevOpenUniverse))
        }
        // bakeoff harness (COLOSSEUM_BAKEOFF_STRIP=<dir>): page-only production
        // MangaReader over the canonical fixture (long-strip bakeoff spec §10)
        if (typeof DevBakeoffStripPages !== "undefined" && DevBakeoffStripPages.length)
            bakeoffStripLayer.active = true
        // dev harness (COLOSSEUM_SUBS_SELFTEST="movie|tt0111161"): headless proof
        // of the multi-well subtitle pipeline — logs subtitle rows per source
        if (typeof DevSubsSelfTest !== "undefined" && String(DevSubsSelfTest).length) {
            var sp = String(DevSubsSelfTest).split("|")
            if (sp[0] === "MERGETEST") {
                var m = Subtitles.selfTestMerge()
                var mBySrc = ({})
                for (var mi = 0; mi < m.length; mi++)
                    mBySrc[m[mi].source] = (mBySrc[m[mi].source] || 0) + 1
                console.log("[subs-selftest] MERGE:", m.length, "rows (expect 5: 1 shared url deduped)")
                for (var ms in mBySrc) console.log("[subs-selftest]   via", ms + ":", mBySrc[ms])
                for (var mj = 0; mj < m.length; mj++)
                    console.log("[subs-selftest]   row", m[mj].langName, m[mj].source, m[mj].url)
                return
            }
            Subtitles.fetch(sp[0], sp[1], function(list) {
                var bySource = ({})
                for (var i = 0; i < list.length; i++)
                    bySource[list[i].source] = (bySource[list[i].source] || 0) + 1
                console.log("[subs-selftest]", list.length, "subtitles for", sp[0], sp[1])
                for (var src in bySource)
                    console.log("[subs-selftest]   via", src + ":", bySource[src])
            })
        }
        // dev harness (COLOSSEUM_CATALOG_SELFTEST="movies"): headless proof of the
        // extension-shelf pipeline — logs every row the tab would render
        if (typeof DevCatalogSelfTest !== "undefined" && String(DevCatalogSelfTest).length) {
            TheatreApi.loadCatalogPage(String(DevCatalogSelfTest), function(result) {
                console.log("[catalog-selftest] tab", result.pageKey, "->", result.rows.length, "rows")
                for (var i = 0; i < result.rows.length; i++)
                    console.log("[catalog-selftest] row", i, JSON.stringify(result.rows[i].title),
                                result.rows[i].sub || "(house)", result.rows[i].items.length, "items,",
                                "first:", result.rows[i].items.length ? result.rows[i].items[0].id : "-")
            })
        }
        // dev harness (COLOSSEUM_STREAMS_SELFTEST="movie|tt123"): headless proof of
        // the multi-extension stream pipeline — logs per-extension answers and rows
        if (typeof DevStreamsSelfTest !== "undefined" && String(DevStreamsSelfTest).length) {
            var st = String(DevStreamsSelfTest).split("|")
            var exts = AddonClient.streamExtensions(Extensions.installed(), st[0], st[1])
            console.log("[streams-selftest] asking", exts.length, "extensions for", st[0], st[1])
            AddonClient.loadStreams(exts, st[0], st[1],
                function(rows) { console.log("[streams-selftest] partial:", rows.length, "rows") },
                function(rows, names) {
                    console.log("[streams-selftest] DONE:", rows.length, "rows via", names.join(","))
                    for (var i = 0; i < Math.min(rows.length, 6); i++)
                        console.log("[streams-selftest] #" + i, rows[i].addonName,
                                    rows[i].quality, rows[i].streamKind,
                                    String(rows[i].infoHash).substring(0, 24))
                })
        }
        // The production native entry point starts this timer from its first-frame signal. A
        // bare QML harness has no bridge, so retain a deterministic fallback for those fixtures.
        if (typeof GuiStallProbe === "undefined" || !GuiStallProbe) {
            win.armStartupIdleWork()
        }
    }

    // locg:<id> → "<gc-tag-slug>|<gc-tagId>", persisted forever (survives restarts)
    // V3: content lane settled on GetComics (2026-07-10) — the category bump orphans stale
    // prior-source mappings so they can never poison a GC attach (V2's own bump orphaned
    // the year-gate poison the same way)
    Settings { id: comicMapStore; category: "comicResolveV3" }
    // polite spacer for LOCG's request queue (Locg.delayFn)
    Timer {
        id: locgSpacer
        property var _cb: null
        function fire(ms, cb) { _cb = cb; interval = Math.max(1, ms); restart() }
        onTriggered: { var c = _cb; _cb = null; if (c) c() }
    }

    // Named collections own their profile store and drafts. Navigation asks the
    // panel to resolve a draft before the shell changes the surface beneath it.
    property var namedCollectionsNavigation: null
    property bool namedCollectionsRouteBypass: false
    property var namedCollectionsReturn: null
    property var namedCollectionsOpening: null
    property var namedCollectionsVaultPending: null
    property int namedCollectionsProfileGeneration: 0
    function guardNamedCollectionsNavigation(continuation) {
        if (namedCollectionsRouteBypass) return false
        namedCollectionsReturn = null
        if (win.vinylWorld) win.vinylWorld.namedCollectionReturn = null
        if (!collectionsPanel.showing && !collectionsPanel.pickerActive && !collectionsPanel.deleteActive)
            return false
        namedCollectionsNavigation = continuation
        collectionsPanel.requestClose()
        return true
    }
    function openNamedCollectionsPicker(reference, opener) {
        if (typeof CollectionsIdentity === "undefined") return false
        var resolved = CollectionsIdentity.collectionReference(reference)
        if (!resolved.ok) { collectionsPanel.showMessage(resolved.error); return false }
        return collectionsPanel.openPicker(resolved.reference, opener)
    }
    function openNamedCollectionsPage() {
        if (collectionsPanel.showing) { collectionsPanel.showOverview(); return }
        namedCollectionsReturn = null
        win.parkFeria(true)
        downloadsLayer.active = false
        vaultLayer.active = false
        extensionsLayer.active = false
        updateLayer.active = false
        historyStatsLayer.active = false
        syncCenterLayer.active = false
        yourFeriaLayer.open = false
        taskbar.open = false
        collectionsPanel.showOverview()
    }
    function closeNamedCollectionsPage() { collectionsPanel.requestClose() }
    function restoreNamedCollectionsReturn() {
        if (!namedCollectionsReturn) return false
        var target = namedCollectionsReturn
        namedCollectionsReturn = null
        collectionsPanel.collectionId = target.collectionId
        collectionsPanel.showing = true
        collectionsPanel.forceActiveFocus(Qt.BacktabFocusReason)
        return true
    }
    function cancelNamedCollectionsOpen() {
        namedCollectionsOpening = null
        namedCollectionsVaultPending = null
        if (win.vinylWorld) win.vinylWorld.cancelNamedCollectionOpen()
    }
    function finishNamedCollectionVaultOpen() {
        var pending = namedCollectionsVaultPending
        if (!pending || !vaultLayer.item) return
        var detail = CollectionsReferences.vaultDetail(VaultLibrary,
            {sourceId:pending.sourceId, payload:{vaultKey:pending.key}}, Qt.platform.os === "windows")
        namedCollectionsVaultPending = null
        if (!detail) {
            vaultLayer.active = false
            win.restoreNamedCollectionsReturn()
            collectionsPanel.showMessage("This exact Vault film is unavailable. Reconnect its source and try again.")
            return
        }
        vaultLayer.item.openDetailSheet({key:detail.key, state:detail.identityState, kind:"video", nodeType:"film"})
    }
    function clearNamedCollectionsUnderlyingPages() {
        // Clear detail covers only. This does not close, resume, or create a
        // playback/reader session and never writes Library or Progress.
        seriesLayer.active = false
        westernLayer.active = false
        comicSeriesLayer.active = false
        theatreSeriesLayer.active = false
        bookLayer.active = false
        bookReturnSnapshot = null
        searchLayer.active = false
        worldSearchLayer.active = false
        universeLayer.active = false
        onePieceArcLayer.active = false
        locgPublisherLayer.active = false
        comicIndexLayer.active = false
        comicBoardLayer.active = false
        continueSeeAllLayer.active = false
        genreLayer.active = false
        genreIndexLayer.active = false
        biblioGenreLayer.active = false
        biblioGenreIndexLayer.active = false
        theatreGenreLayer.active = false
        theatreGenreIndexLayer.active = false
        phoneShell.closeProfilePage()
    }
    function acceptNamedCollectionsRoute(continuation) {
        var target = {collectionId:collectionsPanel.collectionId}
        namedCollectionsOpening = null
        namedCollectionsNavigation = function() {
            namedCollectionsRouteBypass = true
            try {
                clearNamedCollectionsUnderlyingPages()
                namedCollectionsReturn = target
                continuation()
            } finally { namedCollectionsRouteBypass = false }
        }
        collectionsPanel.requestClose()
    }
    function openNamedCollectionReference(saved) {
        if (collectionsPanel.pendingChanges) {
            collectionsPanel.showMessage("Save or cancel your collection changes before opening a title.")
            return
        }
        cancelNamedCollectionsOpen()
        if (typeof CollectionsIdentity === "undefined") {
            collectionsPanel.showMessage("Title identity is unavailable. The saved item has been kept.")
            return
        }
        var resolution = CollectionsIdentity.collectionReference(saved)
        if (!resolution.ok) { collectionsPanel.showMessage(resolution.error); return }
        var ref = resolution.reference
        var p = ref.payload || {}
        collectionsPanel.showMessage("")
        if (ref.route.indexOf("vinyl-") === 0) {
            if (!win.vinylEnabled || !win.vinylProfileActive) {
                collectionsPanel.showMessage("Vinyl is unavailable for this profile. The saved item has been kept.")
                return
            }
            cancelNamedCollectionsOpen()
            namedCollectionsOpening = ref
            if (win.vinylWorld) win.vinylWorld.openNamedCollectionReference(ref)
            else {
                var found = false
                for (var i = 0; i < openModes.count; ++i)
                    if (openModes.get(i).mode === "Vinyl") found = true
                if (!found) openModes.append({mode:"Vinyl"})
            }
            return
        }
        if (ref.route === "vault-film-detail") {
            if (win.androidHost || typeof VaultLibrary === "undefined") {
                collectionsPanel.showMessage("Vault is unavailable on this device. The saved item has been kept.")
                return
            }
            var detail = CollectionsReferences.vaultDetail(VaultLibrary, ref, Qt.platform.os === "windows")
            if (!detail) {
                collectionsPanel.showMessage("This exact Vault film is unavailable. Reconnect its source and try again.")
                return
            }
            acceptNamedCollectionsRoute(function() {
                win.openVaultPage()
                namedCollectionsVaultPending = {key:detail.key, sourceId:ref.sourceId}
                win.finishNamedCollectionVaultOpen()
            })
            return
        }
        if (ref.route === "comic-pack-detail") {
            var pack = typeof Comics !== "undefined" ? Comics.packVolumes(ref.sourceId) : null
            if (!pack || (!(pack.mains || []).length && !(pack.extras || []).length)) {
                collectionsPanel.showMessage("This exact comic pack is unavailable. The saved item has been kept.")
                return
            }
        }
        if (ref.route === "comic-gcd-detail" && !(p.posts || []).length) {
            var gcd = Number(ref.sourceId.substring(4))
            var series = typeof ComicsCatalog !== "undefined" && CatalogDelivery.available(ComicsCatalog)
                ? ComicsCatalog.series(gcd) : null
            if (!series || Number(series.gcdId) !== gcd) {
                collectionsPanel.showMessage("This exact comic catalogue reference is unavailable. The saved item can be retried later.")
                return
            }
        }
        var theatreOpenItem = null
        if (ref.route === "theatre-detail") {
            var theatreSourceId = String(ref.sourceId || "")
            var canonicalSourceId = String(p.canonicalSourceId || "")
            var directImdb = /^tt[0-9]+$/.test(theatreSourceId)
            if (!theatreSourceId) {
                collectionsPanel.showMessage("This saved Theatre item has no source identity. The saved item has been kept.")
                return
            }
            if (directImdb && canonicalSourceId && canonicalSourceId !== theatreSourceId) {
                collectionsPanel.showMessage("This saved Theatre item has conflicting canonical identities. The saved item has been kept.")
                return
            }
            if (!canonicalSourceId) {
                if (!directImdb) {
                    collectionsPanel.showMessage("This saved Theatre item has no canonical identity. The saved item has been kept.")
                    return
                }
                canonicalSourceId = theatreSourceId
            }
            theatreOpenItem = {id:canonicalSourceId, canonicalSourceId:canonicalSourceId,
                sourceId:theatreSourceId, type:ref.kind, title:ref.title, cover:ref.cover, art:p.art || ""}
        }
        acceptNamedCollectionsRoute(function() {
            if (ref.route === "theatre-detail") {
                win.openWorld("Theatre")
                win.openTheatreSeries(theatreOpenItem)
            } else if (ref.route === "book-detail") {
                win.openWorld("Biblio")
                win.openBook(p.book)
            } else {
                win.openWorld("Tankoban")
                if (ref.route === "manga-detail") {
                    win.openSeries(ref.title, p.malId, {malId:p.malId, seriesId:ref.sourceId,
                        sourceSearchTitle:p.sourceSearchTitle || "", sourceSearchAliases:p.sourceSearchAliases || [],
                        sourceRequiredMarkers:p.sourceRequiredMarkers || []}, "")
                } else if (ref.route === "manga-weebcentral-detail") {
                    clearSeriesEditionProfile()
                    seriesLayer.legacyWeebCentral = true
                    seriesLayer.exactCollectionReference = ref
                    seriesLayer.resumeSeriesId = ""
                    seriesLayer.resumeChapterId = ""
                    seriesLayer.resumeVolumeId = ""
                    seriesLayer.requestedVolumeNumber = ""
                    seriesLayer.title = ref.title
                    seriesLayer.active = true
                } else if (ref.route === "comic-locg-detail") {
                    win._openComicSeriesReady({id:ref.sourceId, title:ref.title, cover:ref.cover, locgMeta:p.locgMeta || {}})
                } else if (ref.route === "comic-gcd-detail") {
                    var data = {gcdId:Number(ref.sourceId.substring(4)), title:ref.title, cover:ref.cover, year:ref.year, posts:p.posts || []}
                    if (data.posts.length) win._openPinnedGcdSeries(data)
                    else win._openGcdSeriesReady(data, true)
                } else if (ref.route === "comic-posts-detail") {
                    win.openUniverseComic({title:ref.title, cover:ref.cover, posts:p.posts})
                } else if (ref.route === "comic-pack-detail") {
                    win.openPackSeries({seriesId:ref.sourceId, seriesTitle:ref.title})
                } else if (ref.route === "comic-tag-detail") {
                    westernLayer.baked = null
                    westernLayer.title = ref.title
                    westernLayer.tagId = Number(p.tagId || 0)
                    westernLayer.tagSlug = p.tag
                    westernLayer.resumeChapterId = ""
                    westernLayer.active = true
                }
            }
        })
    }
    CollectionsUi.CollectionsPanel {
        id: collectionsPanel
        anchors.fill: parent
        z: 58.6
        onMinimizeRequested: win.minimizeShell()
        onFullscreenRequested: win.toggleFullscreenShell()
        onQuitRequested: win.requestApplicationQuit()
        nativeStore: typeof NamedCollections !== "undefined" ? NamedCollections : null
        wallpaperItem: wall
        bottomInset: taskbar.visible ? taskbar.closedSize + taskbar.bottomGap + 16 : 24
        onOpenReferenceRequested: reference => win.openNamedCollectionReference(reference)
        onCollectionIdChanged: win.cancelNamedCollectionsOpen()
        onPickerActiveChanged: if (pickerActive) win.cancelNamedCollectionsOpen()
        onDeleteActiveChanged: if (deleteActive) win.cancelNamedCollectionsOpen()
        onNavigationCanceled: win.namedCollectionsNavigation = null
        onClosed: {
            win.cancelNamedCollectionsOpen()
            var continuation = win.namedCollectionsNavigation
            win.namedCollectionsNavigation = null
            var profileGeneration = win.namedCollectionsProfileGeneration
            if (continuation) Qt.callLater(function() {
                if (profileGeneration === win.namedCollectionsProfileGeneration) continuation()
            })
            else taskbar.focusCollectionsAction()
        }
    }
    Connections {
        target: typeof NamedCollectionsProfileScope !== "undefined" ? NamedCollectionsProfileScope : null
        function onStoresAboutToChange() {
            win.namedCollectionsProfileGeneration++
            win.cancelNamedCollectionsOpen()
            win.namedCollectionsNavigation = null
            win.namedCollectionsReturn = null
            collectionsPanel.profileChanged()
        }
    }
    Connections {
        target: win.vinylWorld
        function onNamedCollectionOpened(success, message) {
            if (!win.namedCollectionsOpening) return
            if (!success) {
                win.namedCollectionsOpening = null
                collectionsPanel.showMessage(message || "This music item is unavailable. The saved item has been kept.")
                return
            }
            win.acceptNamedCollectionsRoute(function() { win.openWorld("Vinyl") })
        }
        function onNamedCollectionBackRequested() { win.restoreNamedCollectionsReturn() }
    }

    // Escape has one shell entry point. ShellBackPolicy owns precedence; each selected
    // surface still owns the meaning of Back/Escape so session, progress and overlay
    // semantics cannot be bypassed by a parallel root-level close path.
    function shellEscapeState() {
        var rec = (typeof Sessions !== "undefined" && Sessions && Sessions.activeId)
                ? Sessions.get(Sessions.activeId) : ({})
        return {
            transitioning: fullscreenTransition.transitioning,
            bootVisible: boot.visible,
            accountHostVisible: accountHost.visible,
            identityCeremonyOpen: identityCeremonyDialog.opened,
            watchPartyJoinOpen: watchPartyJoinSheet.opened,
            wallpaperActive: wallpaperLayer.active,
            dlnaPopupVisible: dlnaSharePopup.visible,
            accountFlyoutVisible: accountFlyout.visible,
            accountCenterVisible: accountCenter.visible,
            openRecentOpen: openRecentPanel.open,
            taskbarOpen: taskbar.open,
            collectionsModalOpen: collectionsPanel.pickerActive || collectionsPanel.deleteActive,
            collectionsActive: collectionsPanel.showing,
            stremioSyncOpen: stremioPanel.shown,
            activeSessionKind: rec && rec.contentKind ? String(rec.contentKind) : "",
            playerOpen: win.playerOpen,
            bookReaderActive: bookReaderLayer.active,
            vaultComicActive: vaultComicLayer.active,
            comicReaderActive: win.embeddedComicReaderOpen(),
            updateActive: updateLayer.active,
            historyStatsActive: historyStatsLayer.active,
            yourFeriaActive: yourFeriaLayer.active,
            syncCenterActive: syncCenterLayer.active,
            extensionsActive: extensionsLayer.active,
            feriaActive: feriaLayer.open,
            vaultActive: vaultLayer.active,
            downloadsActive: downloadsLayer.active,
            profileActive: phoneShell.profileActive,
            bookActive: bookLayer.active,
            theatreSeriesActive: theatreSeriesLayer.active,
            westernActive: westernLayer.active,
            seriesActive: seriesLayer.active,
            onePieceArcActive: onePieceArcLayer.active,
            onePieceAtlasTransientOpen: universeLayer.active
                    && universeLayer.extensionId === "com.colosseum.universe.onepiece"
                    && universeLayer.item
                    && universeLayer.item.atlasTransientOpen === true,
            universeActive: universeLayer.active,
            searchActive: searchLayer.active,
            worldSearchActive: worldSearchLayer.active || (worldStack.current === "Vinyl" && win.vinylWorld && win.vinylWorld.searchOpen),
            comicSeriesActive: comicSeriesLayer.active,
            locgPublisherActive: locgPublisherLayer.active,
            comicIndexActive: comicIndexLayer.active,
            comicBoardActive: comicBoardLayer.active,
            continueSeeAllActive: continueSeeAllLayer.active,
            theatreGenreActive: theatreGenreLayer.active,
            theatreGenreIndexActive: theatreGenreIndexLayer.active,
            biblioGenreActive: biblioGenreLayer.active,
            biblioGenreIndexActive: biblioGenreIndexLayer.active,
            genreActive: genreLayer.active,
            genreIndexActive: genreIndexLayer.active,
            worldOpen: worldStack.current !== ""
        }
    }
    function embeddedComicReaderOpen() {
        return !!((seriesLayer.active && seriesLayer.item && String(seriesLayer.item.openChapterId || "").length)
               || (westernLayer.active && westernLayer.item && String(westernLayer.item.openChapterId || "").length)
               || (comicSeriesLayer.active && comicSeriesLayer.item && String(comicSeriesLayer.item.openChapterId || "").length))
    }
    function requestPlayerEscape() {
        var rec = Sessions.get(Sessions.activeId)
        if (playerLayer.active && playerLayer.item && playerLayer.item.requestEscape) {
            playerLayer.item.requestEscape()
            return
        }
        if (rec && rec.contentKind === "movie") { win.minimizePlayer(); return }
        if (win.playerOpen) win.closePlayer()
    }
    function requestBookReaderEscape() {
        var rec = Sessions.get(Sessions.activeId)
        if (bookReaderLayer.active && bookReaderLayer.item && bookReaderLayer.item.requestEscape) {
            bookReaderLayer.item.requestEscape()
            return
        }
        if (rec && rec.contentKind === "book") { win.closeBookReaderSession(); return }
        if (bookReaderLayer.active) win.closeBookReader()
    }
    function requestUniverseEscape() {
        if (universeLayer.active && universeLayer.item && universeLayer.item.requestEscape
                && universeLayer.item.requestEscape()) {
            return
        }
        win.closeUniverse()
    }
    function requestComicReaderEscape() {
        if (vaultComicLayer.active && vaultComicLayer.item && vaultComicLayer.item.requestEscape) {
            vaultComicLayer.item.requestEscape(); return
        }
        if (comicSeriesLayer.active && comicSeriesLayer.item
                && String(comicSeriesLayer.item.openChapterId || "").length
                && comicSeriesLayer.item.requestReaderEscape) {
            comicSeriesLayer.item.requestReaderEscape(); return
        }
        if (westernLayer.active && westernLayer.item
                && String(westernLayer.item.openChapterId || "").length
                && westernLayer.item.requestReaderEscape) {
            westernLayer.item.requestReaderEscape(); return
        }
        if (seriesLayer.active && seriesLayer.item
                && String(seriesLayer.item.openChapterId || "").length
                && seriesLayer.item.requestReaderEscape) {
            seriesLayer.item.requestReaderEscape(); return
        }
        var rec = Sessions.get(Sessions.activeId)
        if (rec && rec.contentKind === "comic") win.closeSession(rec.id)
    }
    function requestOnePieceAtlasEscape() {
        if (universeLayer.active
                && universeLayer.extensionId === "com.colosseum.universe.onepiece"
                && universeLayer.item
                && universeLayer.item.requestEscape)
            universeLayer.item.requestEscape()
    }
    function cancelPendingIdentityCeremony() {
        if (win.pendingIdentityRoute && win.pendingIdentityRoute.vinylImport && win.vinylWorld)
            win.vinylWorld.session.cancelImportIdentity(true)
        win.pendingIdentityRoute = null
        identityCeremonyDialog.close()
    }
    readonly property var shellInputMethod: Qt.inputMethod
    function handleEscape() {
        var keyboard = win.shellInputMethod
        if (win.androidHost && keyboard.visible) {
            keyboard.hide()
            return
        }
        win.cancelCatalogueRoute();
        var action = ShellBackPolicy.actionFor(win.shellEscapeState())
        switch (action) {
        case "consume": return
        case "cancelIdentityCeremony": identityCeremonyDialog.cancelRequested(); return
        case "watchPartyJoin": watchPartyJoinSheet.close(); return
        case "wallpaper": win.closeWallpaperSearch(); return
        case "dlnaPopup": dlnaSharePopup.close(); return
        case "accountFlyout": accountFlyout.close(); return
        case "accountCenter": accountCenter.close(); return
        case "openRecent": openRecentPanel.open = false; return
        case "collections": collectionsPanel.requestEscape(); return
        case "taskbar": taskbar.open = false; return
        case "stremioSync": win.closeStremioSyncPanel(); return
        case "player": win.requestPlayerEscape(); return
        case "bookReader": win.requestBookReaderEscape(); return
        case "comicReader": win.requestComicReaderEscape(); return
        case "update": win.closeUpdatePage(); return
        case "historyStats": win.closeHistoryStatsPage(); return
        case "yourFeria": win.closeYourFeriaPage(); return
        case "syncCenter":
            if (syncCenterLayer.item && syncCenterLayer.item.requestEscape)
                syncCenterLayer.item.requestEscape()
            else
                win.closeSyncCenterPage()
            return
        case "extensions":
            if (extensionsLayer.item && extensionsLayer.item.requestEscape
                    && extensionsLayer.item.requestEscape()) return
            win.closeExtensionsPage(); return
        case "feria":
            if (feriaLayer.item) feriaLayer.item.back()
            else win.closeFeriaPage()
            return
        case "vault": if (vaultLayer.item && vaultLayer.item.handleBack) vaultLayer.item.handleBack(); else win.closeVaultPage(); return
        case "downloads": win.closeDownloadsPage(); return
        case "profile": phoneShell.closeProfilePage(); return
        case "book": win.closeBook(); return
        case "theatreSeries": win.closeTheatreSeries(); return
        case "western": win.closeWestern(); return
        case "series": win.closeSeries(); return
        case "onePieceArc": win.closeOnePieceArc(); return
        case "onePieceAtlasTransient": win.requestOnePieceAtlasEscape(); return
        case "universe": win.requestUniverseEscape(); return
        case "search": win.closeSearch(); return
        case "worldSearch": win.closeWorldSearch(); return
        case "comicSeries": win.closeComicSeries(); return
        case "locgPublisher": win.closeLocgPublisher(); return
        case "comicIndex": win.closeComicArchive(); return
        case "comicBoard": win.closeComicArchiveBoard(); return
        case "continueSeeAll": win.closeContinueSeeAll(); return
        case "theatreGenre": win.closeTheatreGenre(); return
        case "theatreGenreIndex": win.closeTheatreGenreIndex(); return
        case "biblioGenre": win.closeBiblioGenre(); return
        case "biblioGenreIndex": win.closeBiblioGenreIndex(); return
        case "genre": win.closeGenre(); return
        case "genreIndex": win.closeGenreIndex(); return
        case "world":
            if (worldStack.current === "Vinyl" && win.vinylWorld
                    && win.vinylWorld.goBack && win.vinylWorld.goBack()) return
            win.closeWorld()
            return
        default: win.goHomeTop(); return   // "homeTop": Back never quits (Ctrl+Q does)
        }
    }
    Shortcut {
        sequences: escapeCommand.sequences
        enabled: !win.vinylVideoFullscreen
            && !(feriaLayer.open && feriaLayer.item && feriaLayer.item.hostFullScreenActive)
        onActivated: escapeCommand.invoke("shortcut")
    }
    // Backspace is Back too (world-feel Slice 6). Text fields keep it (they claim it before any
    // shortcut), and the Vault keeps its own Backspace (folder up), so it is off while Vault is open.
    Shortcut {
        sequence: "Backspace"
        enabled: !vaultLayer.active
        onActivated: escapeCommand.invoke("backspace")
    }

    // The mouse's Back button is Back too (world-feel Slice 6). A full-window item that only
    // accepts the Back button: every other button, hover and wheel pass straight through it.
    Item {
        anchors.fill: parent
        z: 100000
        TapHandler {
            // acceptedButtons filters mouse buttons only; touch would otherwise trigger Back.
            acceptedDevices: PointerDevice.Mouse | PointerDevice.TouchPad
            acceptedButtons: Qt.BackButton
            onTapped: escapeCommand.invoke("mouseBack")
        }
    }

    // Home is the bottom of the Back ladder: scroll Home to its top and focus its first control.
    function goHomeTop() {
        if (win.guardNamedCollectionsNavigation(function() { win.goHomeTop() })) return

        homeGlide.toTop()
        win.focusHomePrimary()
    }
    Shortcut { sequences: quitCommand.sequences; onActivated: quitCommand.invoke("shortcut") }

    // Home has an intentional console-style focus origin: the current Universe hero's
    // primary action. A fresh shell therefore begins in visible content rather than in Qt's
    // incidental Tab order. If no Universe hero exists, fall back to the first enabled mode.
    function focusHomePrimary() {
        if (!page.visible || worldStack.current !== "" || win.immersiveSurfaceOpen)
            return false
        if (homePageSpatialNav.focusNamed("homeHeroExplore", Qt.TabFocusReason))
            return true
        return homeTopSpatialNav.focusNamed("modePillFocus_Tankoban", Qt.TabFocusReason)
    }

    // ── Keyboard ignition (Arc 41 repair) ──────────────────────────────────────────
    // Qt Quick starts a Tab traversal only from an item that BOTH holds focus and has
    // activeFocusOnTab. On a cold launch nothing in the shell claims focus, so the
    // window's contentItem holds it — and contentItem.activeFocusOnTab is false. Every
    // focus-dependent key (Tab, Backtab, the arrows) therefore died on arrival, while the
    // ApplicationShortcut chords kept working because Qt's shortcut map never consults
    // focus. That asymmetry was the whole bug: Arc 41's chain, controllers and focus rings
    // were all correct, with no origin to start from.
    //
    // This item is the missing origin. It holds focus at rest and paints nothing, so a
    // mouse user is never greeted by a focus ring; the first navigation key hands focus to
    // the first real control, and from there Arc 41's own machinery carries it.
    Item {
        id: keyboardIgnition
        objectName: "keyboardIgnition"
        width: 0
        height: 0
        focus: true
        // Deliberately NOT activeFocusOnTab: the origin must never become a stop in the
        // chain, or Tab would eventually cycle back into an invisible item.

        readonly property var navigationKeys: [
            Qt.Key_Tab, Qt.Key_Backtab, Qt.Key_Up, Qt.Key_Down,
            Qt.Key_Left, Qt.Key_Right, Qt.Key_Home, Qt.Key_End
        ]

        // Directional ignition follows the page's explicit focus origin. Tab/Backtab keeps
        // the conventional focus chain as a secondary accessibility route.
        function ignite(key, modifiers) {
            var directional = key === Qt.Key_Up || key === Qt.Key_Down
                || key === Qt.Key_Left || key === Qt.Key_Right
            if (directional && win.focusHomePrimary())
                return true
            if (!win.contentItem)
                return false
            var backward = key === Qt.Key_Backtab
                || (key === Qt.Key_Tab && (modifiers & Qt.ShiftModifier) !== 0)
            var first = win.contentItem.nextItemInFocusChain(!backward)
            if (!first || first === keyboardIgnition || first === win.contentItem)
                return false
            first.forceActiveFocus(backward ? Qt.BacktabFocusReason : Qt.TabFocusReason)
            return true
        }

        Keys.onPressed: (event) => {
            if (keyboardIgnition.navigationKeys.indexOf(event.key) < 0)
                return
            if (keyboardIgnition.ignite(event.key, event.modifiers))
                event.accepted = true
        }
    }

    // Keyboard focus is dead when no live control owns it. Three ways that happens here:
    // nothing has claimed it yet (a cold launch), it fell back to the window's contentItem,
    // or — the one that actually strands the running shell — it is still held by an item
    // that has since been hidden or disabled. Onboarding leaves focus on a hidden control
    // when it dismisses, and the layer closers (closeVaultPage, closeExtensionsPage and
    // friends) deactivate a Loader the same way. A hidden owner is worse than no owner:
    // Qt keeps delivering keys to it, and it traverses nothing, so every navigation key
    // disappears into an item the user cannot see.
    // This has to be a BINDING, not a function called from onActiveFocusItemChanged. The
    // stranding case never changes activeFocusItem at all — the same item keeps focus and
    // simply goes invisible — so no focus signal is emitted and a change handler would
    // never re-run. Reading visible/enabled here makes them binding dependencies, so the
    // shell notices the moment its focus owner stops being real.
    readonly property bool keyboardFocusDead: {
        var item = win.activeFocusItem
        if (!item || item === win.contentItem)
            return true
        return item.visible !== true || item.enabled !== true
    }

    // Returning focus to the ignition item keeps the next keypress live without showing a
    // ring in the meantime. callLater lets a surface that seeds its own focus win the race
    // rather than fighting it for the same frame.
    onKeyboardFocusDeadChanged: {
        if (!win.keyboardFocusDead)
            return
        Qt.callLater(function() {
            if (win.keyboardFocusDead)
                keyboardIgnition.forceActiveFocus()
        })
    }

    // The secret developer door: F11 flips the whole shell between fullscreen (Colosseum's
    // public identity) and the frameless developer window. Application-scoped so it works on
    // home, world pages, readers, overlays, and active playback alike. The native store is the
    // single authority — it exits PiP first if needed, then toggles the base mode.
    Shortcut {
        sequences: fullscreenCommand.sequences
        context: Qt.ApplicationShortcut
        onActivated: fullscreenCommand.invoke("shortcut")
    }

    // Minimize the OS surface to the taskbar — "get it off my screen" WITHOUT quitting (the shell
    // keeps running, art stays warm). Windows restores it to whatever base mode it held before
    // minimizing (fullscreen or the developer window), so no forced snap-back is needed.
    function minimizeShell() { win.showMinimized() }
    // Topbar fullscreen toggle — the same shell flip as the F11 developer door
    // (WindowModeStore stays the single native authority for the mode).
    function toggleFullscreenShell() {
        if (typeof WindowMode !== "undefined" && !fullscreenTransition.transitioning)
            fullscreenTransition.begin()
    }

    // ---- navigation: open a medium's world page over the persistent wallpaper ----
    // Each visited mode keeps ONE live Loader (created on first entry, never destroyed); navigating
    // Home or between modes just toggles visibility. So returning to a mode shows the already-loaded
    // world with its covers INTACT instead of re-downloading them. Real mode pages route to their
    // own QML; unbuilt modes fall back to DemoWorld.qml.
    // This ordered registry is also the Android shell's world-tab source. Registering a future
    // world here therefore adds its tab without a second navigation list.
    readonly property var worldDefinitions: [
        { name: "Theatre",  source: "TheatreWorld.qml",  icon: "../assets/icons/projector-theatre.svg" },
        { name: "Tankoban", source: "TankobanWorld.qml", icon: "../assets/icons/comic-book.svg" },
        { name: "Biblio",   source: "BiblioWorld.qml",   icon: "../assets/icons/book-library.svg" },
        { name: "Universes", source: "UniversesWorld.qml", icon: "../assets/icons/universes-atom.svg" }
    ]
    function worldSourceFor(medium) {
        if (medium === "Vinyl" && vinylEnabled) return "vinyl/VinylLiveWorld.qml"
        for (var i = 0; i < win.worldDefinitions.length; ++i)
            if (win.worldDefinitions[i].name === medium)
                return win.worldDefinitions[i].source
        return "DemoWorld.qml"
    }
    function ensureFeriaRuntime() {
        if (win.feriaComingSoon !== false || !win.feriaAvailable) return false
        if (!win.feriaRuntimeReady)
            win.feriaRuntimeReady = true
        return true
    }
    function parkFeria(preserveSnapshot) {
        var preserve = preserveSnapshot !== false
        if (!preserve) {
            feriaReturnSnapshot = null
        } else if (feriaLayer.open && feriaLayer.item && feriaLayer.item.navigationSnapshot) {
            feriaReturnSnapshot = feriaLayer.item.navigationSnapshot()
        }
        if (win.activeBrowserSessionId.length > 0) {
            win.parkingBrowserForWorld = true
            Sessions.switchTo("")
            win.parkingBrowserForWorld = false
        }
        if (feriaLayer.open) feriaLayer.open = false
    }
    function restoreFeriaIfReady() {
        if (win.activeBrowserSessionId.length > 0) return false
        if (!feriaLayer.open || !feriaReturnSnapshot || !feriaLayer.item
                || !feriaLayer.item.restoreNavigationSnapshot)
            return false
        var snapshot = feriaReturnSnapshot
        if (!feriaLayer.item.restoreNavigationSnapshot(snapshot))
            return false
        feriaReturnSnapshot = null
        return true
    }
    function openWorld(medium) {
        if (win.guardNamedCollectionsNavigation(function() { win.openWorld(medium) })) return
 win.cancelCatalogueRoute();
        // These worlds are not available in this release, including through indirect callers.
        var requestedWorld = String(medium || "").trim().toLowerCase()
        if ((requestedWorld === "feria" && win.feriaComingSoon !== false) || (requestedWorld === "vinyl" && !win.vinylEnabled)) return
        if (medium === "Feria") { win.openFeriaPage(); return }
        if (win.parkFeria) win.parkFeria(true)
        var found = false
        for (var i = 0; i < openModes.count; i++)
            if (openModes.get(i).mode === medium) { found = true; break }
        if (!found) openModes.append({ mode: medium })   // first visit → create its keep-alive Loader
        worldStack.current = medium
        currentSurface = medium
        phoneShell.recordWorldOpened(medium)
        setGuiStallContext("navigate", String(medium))
        refreshWallpaper()
    }
    // Vault identity door: reuse the already-owned world entry points. The Vault never edits a
    // world page or invents a second reader route; it only hands over a certain identity.
    function openVaultIdentity(identity) {
        if (!identity || !identity.world || !identity.identityId) return
        win.closeVaultPage()
        var source = String(identity.source || "")
        var sid = String(identity.identityId || "")
        if (identity.world === "Tankoban") {
            win.openWorld("Tankoban")
            if (source === "COMICS")
                win.openGcdSeries({ gcdId: Number(sid.replace(/^comics:/, "")), title: identity.title || "" })
            else
                win.openSeries(identity.title || "")
        } else if (identity.world === "Theatre") {
            win.openWorld("Theatre")
            win.openTheatreSeries({ id: sid.replace(/^imdb:/, ""), type: "movie",
                                    title: identity.title || "", cover: identity.coverUrl || "" })
        } else if (identity.world === "Biblio") {
            win.openWorld("Biblio")
            win.openBook({ id: sid, title: identity.title || "", synopsis: identity.synopsis || "" })
        }
    }
    function closeWorld() {
        if (win.guardNamedCollectionsNavigation(function() { win.closeWorld() })) return

        if (win.androidHost && !win.desktopPresentation) return
        win.cancelCatalogueRoute();
        win.parkFeria(true)
        worldStack.current = ""                           // hide all worlds; none destroyed
        currentSurface = "Home"
        setGuiStallContext("navigate", "Home")
        refreshWallpaper()
        win.armHomeIntroWidgets()
        win.armHomeContinueRail()
    }

    function openGenre(name) {
        genreLayer.genreName = name
        if (genreLayer.active && genreLayer.item) genreLayer.item.genreName = name
        else genreLayer.active = true
    }
    function closeGenre() { genreLayer.active = false }

    // ---- genre INDEX (the "Explore" directory of all genres) — a layer below the genre page so a
    //      picked genre opens its GenrePage over the index. Reached from a genre widget's "Explore"
    //      or the genre page's "Explore" pill. ----
    function openGenreIndex() { genreIndexLayer.active = true }
    function closeGenreIndex() { genreIndexLayer.active = false }

    // ---- Continue see-all: the whole resume backlog, scoped per door (spec: haven
    //      docs/superpowers/specs/2026-07-11-colosseum-continue-see-all-design.md) ----
    function openContinueSeeAll(scope) {
        continueSeeAllLayer.scope = scope
        if (continueSeeAllLayer.active && continueSeeAllLayer.item) continueSeeAllLayer.item.scope = scope
        else continueSeeAllLayer.active = true
    }
    function closeContinueSeeAll() { continueSeeAllLayer.active = false }

    // Menu "Resume / Play": resume the series' current episode through the EXACT Continue path
    // when there's watch history; otherwise (fresh save / "Play") open the detail page to start.
    function resumeLibraryEntry(entry) {
        if (!entry) return
        var pid = String(entry.id || "")
        var list = (typeof Progress !== "undefined") ? Progress.recent("video", 0) : []
        for (var i = 0; i < list.length; i++) {
            var id = String(list[i].id || "")
            if (id === pid || id.indexOf(pid + ":") === 0) { win.resumeContinue(list[i]); return }
        }
        win.openCollectionEntry(entry)
    }
    // Menu "Mark watched / unwatched" (spec §4.3). Marking watched = "I'm done": clear Continue
    // AND Next Up (both derive from Progress) FIRST, then set the mark — forget() clears the mark
    // by design, so the ORDER matters. Unmark just reverses the flag; progress history stays.
    function markLibraryWatched(entry, watched) {
        if (!entry || typeof Progress === "undefined") return
        var id = String(entry.id || "")
        if (watched) { Progress.forget("video", id); Progress.setWatchedMark(id, true) }
        else { Progress.setWatchedMark(id, false) }
    }

    function openBiblioGenre(name) {
        biblioGenreLayer.genreName = name
        if (biblioGenreLayer.active && biblioGenreLayer.item) biblioGenreLayer.item.genreName = name
        else biblioGenreLayer.active = true
    }
    function closeBiblioGenre() { biblioGenreLayer.active = false }

    // ---- Biblio genre INDEX (the books "Explore" directory) — sits below BiblioGenrePage so a
    //      picked genre opens its page over the index (same layering law as the manga pair). ----
    function openBiblioGenreIndex() { biblioGenreIndexLayer.active = true }
    function closeBiblioGenreIndex() { biblioGenreIndexLayer.active = false }

    // ---- Theatre genre page + index: Theatre-owned twins of the manga pair above. The index
    //      layer sits BELOW the page layer so a picked genre opens its page over the index. ----
    function openTheatreGenre(kind, name) {
        theatreGenreLayer.mediaKind = kind
        theatreGenreLayer.genreName = name
        if (theatreGenreLayer.active && theatreGenreLayer.item) {
            theatreGenreLayer.item.mediaKind = kind
            theatreGenreLayer.item.genreName = name
        } else theatreGenreLayer.active = true
    }
    function closeTheatreGenre() { theatreGenreLayer.active = false }
    function openTheatreGenreIndex(kind) {
        theatreGenreIndexLayer.mediaKind = kind
        if (theatreGenreIndexLayer.active && theatreGenreIndexLayer.item)
            theatreGenreIndexLayer.item.mediaKind = kind
        theatreGenreIndexLayer.active = true
    }
    function closeTheatreGenreIndex() { theatreGenreIndexLayer.active = false }

    // ---- series detail: a layer over the current world page (opened from a Top-10 title tile) ----
    function clearSeriesEditionProfile() {
        seriesLayer.malId = ""
        seriesLayer.seriesIdOverride = ""
        seriesLayer.sourceSearchTitle = ""
        seriesLayer.sourceSearchAliases = []
        seriesLayer.sourceRequiredMarkers = []
        if (seriesLayer.active && seriesLayer.item) {
            seriesLayer.item.malId = ""
            seriesLayer.item.seriesIdOverride = ""
            seriesLayer.item.sourceSearchTitle = ""
            seriesLayer.item.sourceSearchAliases = []
            seriesLayer.item.sourceRequiredMarkers = []
        }
    }
    function applySeriesEditionProfile(profile, fallbackMalId) {
        clearSeriesEditionProfile()
        var p = profile || ({})
        seriesLayer.malId = String(p.malId || fallbackMalId || "")
        seriesLayer.seriesIdOverride = String(p.seriesId || "")
        seriesLayer.sourceSearchTitle = String(p.sourceSearchTitle || "")
        seriesLayer.sourceSearchAliases = p.sourceSearchAliases || []
        seriesLayer.sourceRequiredMarkers = p.sourceRequiredMarkers || []
        if (seriesLayer.active && seriesLayer.item) {
            seriesLayer.item.malId = seriesLayer.malId
            seriesLayer.item.seriesIdOverride = seriesLayer.seriesIdOverride
            seriesLayer.item.sourceSearchTitle = seriesLayer.sourceSearchTitle
            seriesLayer.item.sourceSearchAliases = seriesLayer.sourceSearchAliases
            seriesLayer.item.sourceRequiredMarkers = seriesLayer.sourceRequiredMarkers
        }
    }
    // Only canonical MAL series keys may cross into the remote catalogue seam.
    // Reject suffixes, other namespaces and out-of-range IDs rather than guessing.
    function canonicalMalId(seriesId) {
        var sid = String(seriesId || "")
        var match = /^mal:([1-9][0-9]*)$/.exec(sid)
        if (!match || match[0] !== sid) return ""
        var id = Number(match[1])
        return Number.isInteger(id) && id <= 2147483647 ? match[1] : ""
    }
    function restoreSeriesEditionProfile(seriesId) {
        var sid = String(seriesId || "")
        if (sid !== "mal:13:color") {
            var malId = canonicalMalId(sid)
            if (malId.length) applySeriesEditionProfile(null, malId)
            else clearSeriesEditionProfile()
            return
        }
        applySeriesEditionProfile({
            malId: "13", seriesId: sid, sourceSearchTitle: "One Piece Colored",
            sourceSearchAliases: ["One Piece Digital Colored Comics"],
            sourceRequiredMarkers: ["colored", "full color", "full colour"]
        }, "13")
    }
    function openSeries(title, malId, profile, requestedVolumeNumber) {
        seriesLayer.exactCollectionReference = null
 if (win.cancelCatalogueRoute) win.cancelCatalogueRoute();
        if (seriesLayer.legacyWeebCentral) { seriesLayer.active = false; seriesLayer.legacyWeebCentral = false }
        seriesLayer.resumeSeriesId = ""
        seriesLayer.resumeChapterId = ""
        seriesLayer.resumeVolumeId = ""
        seriesLayer.requestedVolumeNumber = String(requestedVolumeNumber || "")
        applySeriesEditionProfile(profile, malId)
        seriesLayer.title = title
        if (seriesLayer.active && seriesLayer.item) {
            seriesLayer.item.openEntryKind = "manga"   // a reused item may still be in a volume read
            seriesLayer.item.openChapterId = ""        // leave the reader, show the chapter list
            if (seriesLayer.item.requestedVolumeNumber !== undefined)
                seriesLayer.item.requestedVolumeNumber = seriesLayer.requestedVolumeNumber
            seriesLayer.item.seriesTitle = title
        } else seriesLayer.active = true
    }
    // Direct provider compatibility for the returning WeebCentral colored edition.
    function openWeebCentralSeries(title, requestedVolumeNumber) {
        seriesLayer.exactCollectionReference = null

        if (seriesLayer.active) seriesLayer.active = false
        clearSeriesEditionProfile()
        seriesLayer.legacyWeebCentral = true
        seriesLayer.resumeSeriesId = ""
        seriesLayer.resumeChapterId = ""
        seriesLayer.resumeVolumeId = ""
        seriesLayer.requestedVolumeNumber = String(requestedVolumeNumber || "")
        seriesLayer.title = title || ""
        seriesLayer.active = true
    }

    // open a manga series AND jump straight into the reader at a saved chapter (Continue resume).
    function openSeriesAt(title, seriesId, chapterId) {
        seriesLayer.exactCollectionReference = null
 win.cancelCatalogueRoute();
        if (seriesLayer.legacyWeebCentral) { seriesLayer.active = false; seriesLayer.legacyWeebCentral = false }
        seriesLayer.resumeSeriesId = seriesId || ""
        seriesLayer.resumeChapterId = chapterId || ""
        seriesLayer.resumeVolumeId = ""
        seriesLayer.requestedVolumeNumber = ""
        restoreSeriesEditionProfile(seriesId)
        seriesLayer.title = title
        if (seriesLayer.active && seriesLayer.item) {
            seriesLayer.item.seriesTitle = title
            if (seriesId) seriesLayer.item.seriesId = seriesId
            seriesLayer.item.openEntryKind = "manga"   // a reused item may still be in a volume read
            seriesLayer.item.openChapterId = chapterId || ""
        } else seriesLayer.active = true
    }
    function closeSeries() { seriesLayer.active = false; win.restoreNamedCollectionsReturn() }

    // ---- western-comics detail: the GetComics shelf (ComicSeries), parallel to the
    //      manga seriesLayer. Series id app-wide = "gc:<tag-slug>" — the prefix is how
    //      every shared kind:"comic" route below tells the two lanes apart. ----
    property int _catalogueRouteGeneration: 0
    property var _catalogueRouteCancel: null
    function cancelCatalogueRoute() {
        _catalogueRouteGeneration++;
        if (typeof _catalogueRouteCancel === "function") _catalogueRouteCancel();
        _catalogueRouteCancel = null;
    }
    function catalogueRouteSnapshot() {
        return String(currentSurface) + "|" + JSON.stringify(win.shellEscapeState());
    }
    function openWestern(d) {
        win.cancelCatalogueRoute();
        var generation = _catalogueRouteGeneration;
        var snapshot = win.catalogueRouteSnapshot();
        var catalog = typeof ComicsCatalog !== "undefined" ? ComicsCatalog : null;
        _catalogueRouteCancel = CatalogDelivery.wait(catalog, function() {
            var title = (d && d.title) || "";
            var hit = win.comicsDbHit(title);
            if (CatalogDelivery.available(catalog)) catalog.exactMatches(title);
            return hit;
        }, function() {
            if (generation !== _catalogueRouteGeneration || snapshot !== win.catalogueRouteSnapshot()) return;
            _catalogueRouteCancel = null;
            win._openWesternReady(d, false);
        });
    }
    function _openWesternReady(d, skipGcd) {
        westernLayer.baked = null
        if (westernLayer.active && westernLayer.item) westernLayer.item.bakedReleases = null
        // DB-first (Hemanth 2026-07-15): the catalog series view is THE series
        // view now. Resolve the title against our DB (ingesting it on demand);
        // the GetComics shelf remains only for series the catalog doesn't carry.
        var hit = win.comicsDbHit((d && d.title) || "")
        if (hit) {
            win.openComicSeries({ id: hit.locgId, title: hit.title,
                                  cover: hit.cover || (d && d.cover) || "" })
            return
        }
        // catalogue redirect (spec 2026-07-17): exactly ONE run bears this title ->
        // its run-scoped page. Multiple same-name runs -> the live shelf keeps the
        // whole-franchise view; never guess a run.
        if (!skipGcd && typeof ComicsCatalog !== "undefined" && CatalogDelivery.available(ComicsCatalog)) {
            var ex = ComicsCatalog.exactMatches((d && d.title) || "")
            if (ex.length === 1) {
                win.openGcdSeries({ gcdId: ex[0].gcdId, title: (d && d.title) || "",
                                    cover: (d && d.cover) || "" })
                return
            }
        }
        westernLayer.resumeChapterId = ""
        westernLayer.title = (d && d.title) || ""
        westernLayer.tagId = (d && d.tagId) || 0
        westernLayer.tagSlug = (d && d.tag) || ""
        if (westernLayer.active && westernLayer.item) {
            westernLayer.item.openChapterId = ""       // leave the reader, show the shelf
            westernLayer.item.seriesTitle = westernLayer.title
            westernLayer.item.tagId = westernLayer.tagId
            westernLayer.item.tagSlug = westernLayer.tagSlug
        } else westernLayer.active = true
        // title-only open (Top-10 / genre tile): no tag change fires, ask the page to resolve
        if (!westernLayer.tagSlug.length && westernLayer.item) westernLayer.item.resolve()
    }
    // open a western series AND jump straight into the reader (Continue / session resume)
    function openWesternAt(title, tagSlug, chapterId) { win.cancelCatalogueRoute();
        westernLayer.baked = null
        if (westernLayer.active && westernLayer.item) westernLayer.item.bakedReleases = null
        westernLayer.title = title || ""
        westernLayer.tagId = 0
        westernLayer.tagSlug = tagSlug || ""
        westernLayer.resumeChapterId = chapterId || ""
        if (westernLayer.active && westernLayer.item) {
            westernLayer.item.seriesTitle = title || ""
            westernLayer.item.tagSlug = tagSlug || ""
            westernLayer.item.openChapterId = chapterId || ""
        } else westernLayer.active = true
    }
    function closeWestern() { win.cancelCatalogueRoute(); westernLayer.active = false; win.restoreNamedCollectionsReturn() }

    // ---- catalogue run page: the western shelf in baked mode (spec 2026-07-17).
    //      d: { gcdId, title?, cover?, resumeChapterId? } ----
    function _openPinnedGcdSeries(d) {
        var gcdId = Number((d && d.gcdId) || 0)
        var posts = (d && d.posts) || []
        if (!gcdId || !posts.length) return false
        var rel = []
        for (var i = 0; i < posts.length; i++)
            rel.push({ id: String(posts[i]), url: "https://getcomics.org/?p=" + posts[i],
                       name: (d && d.title) || "", cover: "", year: Number((d && d.year) || 0),
                       sizeMB: 0, synopsis: "", date: "", collection: true })
        westernLayer.baked = { gcdId: gcdId, releases: rel, cover: (d && d.cover) || "" }
        westernLayer.title = (d && d.title) || ""
        westernLayer.tagSlug = ""; westernLayer.tagId = 0
        westernLayer.resumeChapterId = (d && d.resumeChapterId) || ""
        if (westernLayer.active && westernLayer.item) {
            var it = westernLayer.item
            it.bakedReleases = null
            it.seriesTitle = westernLayer.title
            it.poster = westernLayer.baked.cover || ""
            it.packSeriesId = ""                 // release a previous post/pack identity
            it.gcdId = gcdId
            it.bakedReleases = rel
            it.tagId = 0; it.tagSlug = ""
            it.openChapterId = westernLayer.resumeChapterId || ""
        } else westernLayer.active = true
        return true
    }

    function openGcdSeries(d) {
        win.cancelCatalogueRoute();
        var generation = _catalogueRouteGeneration;
        var snapshot = win.catalogueRouteSnapshot();
        var catalog = typeof ComicsCatalog !== "undefined" ? ComicsCatalog : null;
        _catalogueRouteCancel = CatalogDelivery.wait(catalog, function() {
            if (!CatalogDelivery.available(catalog)) return null;
            var id = Number((d && d.gcdId) || 0);
            return { series: catalog.series(id), downloads: catalog.downloadsFor(id) };
        }, function() {
            if (generation !== _catalogueRouteGeneration || snapshot !== win.catalogueRouteSnapshot()) return;
            _catalogueRouteCancel = null;
            win._openGcdSeriesReady(d);
        });
    }
    function _openGcdSeriesReady(d, strictNamedCollection) {
        if (typeof ComicsCatalog === "undefined" || !CatalogDelivery.available(ComicsCatalog)) {
            if (_openPinnedGcdSeries(d)) return
            if (strictNamedCollection) {
                win.restoreNamedCollectionsReturn()
                collectionsPanel.showMessage("This exact comic catalogue reference is unavailable. The saved item has been kept.")
                return
            }
            if (d && d.title) win._openWesternReady({ title: d.title }, true)
            return
        }
        var gcdId = Number((d && d.gcdId) || 0)
        var s = ComicsCatalog.series(gcdId)
        if (!s || s.gcdId === undefined) {
            if (_openPinnedGcdSeries(d)) return
            if (strictNamedCollection) {
                win.restoreNamedCollectionsReturn()
                collectionsPanel.showMessage("This exact comic catalogue reference is unavailable. The saved item has been kept.")
                return
            }
            if (d && d.title) win._openWesternReady({ title: d.title }, true)
            return
        }
        var rows = ComicsCatalog.downloadsFor(gcdId)
        var rel = []
        for (var i = 0; i < rows.length; i++) {
            var r = rows[i]
            rel.push({ id: String(r.postId), url: r.link, name: r.title, cover: "",
                       year: r.yearStart || 0, sizeMB: 0, synopsis: "",
                       date: r.date || "", collection: r.kind !== "single" })
        }
        westernLayer.baked = { gcdId: gcdId, releases: rel,
                               cover: s.cover || (d && d.cover) || "" }
        westernLayer.title = s.title + (s.year ? " (" + s.year + ")" : "")
        westernLayer.tagSlug = ""; westernLayer.tagId = 0
        westernLayer.resumeChapterId = (d && d.resumeChapterId) || ""
        if (westernLayer.active && westernLayer.item) {
            var it = westernLayer.item
            it.bakedReleases = null                 // reset first so re-injection repaints
            it.seriesTitle = westernLayer.title
            it.poster = westernLayer.baked.cover || ""
            // Resolve the baked IDENTITY (gcdId + bakedReleases -> seriesId "gcd:<id>")
            // BEFORE opening the reader. Opening the reader first (as this did) mounts
            // ComicReaderShell while seriesId is still the transient "gc:<empty-slug>",
            // so its resume reads the wrong (empty) progress key and lands on page 1 —
            // then the identity flips to "gcd:<id>" and every save goes to the OTHER key,
            // and the shell's first presentation writes page 1 over the real record.
            // Confirmed via runtime trace 2026-08-06 (save under gcd:119237, restore under
            // gc:). Set identity first; open the reader last, when seriesId is stable.
            it.packSeriesId = ""                 // release a previous post/pack identity
            it.gcdId = westernLayer.baked.gcdId
            it.bakedReleases = westernLayer.baked.releases   // seriesId now "gcd:<id>" (non-null baked)
            it.tagId = 0; it.tagSlug = ""                    // resolve() guard true (baked non-null), no stray live lookup
            it.openChapterId = westernLayer.resumeChapterId || ""   // open the reader LAST — identity fully stable
        } else westernLayer.active = true
    }

    // ---- a demuxed multi-volume pack shelf (Slice 5, 2026-08-07). The downloads index
    //      already holds the demuxed volumes (Slice 2's demultiplexPack wrote them with
    //      packRole "main"/"extra" + packOrder); packVolumes() (Slice 4) hands them back as
    //      {mains:[...], extras:[...]} in natural reading order. We inject those rows into the
    //      western series surface as a BAKED release list, with a packSeriesId that pins the
    //      reader's progress identity — mirroring openGcdSeries' baked injection (Main.qml:591)
    //      but sourced from the downloads store instead of the catalogue.
    //
    //      IDENTITY-ORDERING LAW (df003eb, non-negotiable): packSeriesId + bakedReleases are
    //      set BEFORE openChapterId — ComicReaderShell must mount with a STABLE seriesId so its
    //      resume reads the right progress key. Same sequence as openGcdSeries.
    //      d: { seriesId, seriesTitle, resumeChapterId? } ----
    function _packRow(r) {
        // Map a packVolumes() row to the release shape ComicSeries.qml renders. The pack
        // fields (packRole/packOrder/packId/pages) ride along so the section builder can split
        // mains from extras and the reader chain can build a mains-only crossing list.
        return { id: String(r.id || ""), name: String(r.label || ""),
                 url: "", cover: String(r.art || ""), year: 0, sizeMB: 0, synopsis: "",
                 date: "", collection: false,
                 packRole: String(r.packRole || ""), packOrder: Number(r.packOrder || 0),
                 packId: String(r.id || ""), pages: Number(r.pages || 0) }
    }
    function openPackSeries(d) { win.cancelCatalogueRoute();
        var seriesId = String((d && d.seriesId) || "")
        if (!seriesId.length) { console.warn("pack: openPackSeries — no seriesId"); return }
        var pv = (typeof Comics !== "undefined") ? Comics.packVolumes(seriesId) : { mains: [], extras: [] }
        var rel = []
        var mains = pv.mains || []
        var extras = pv.extras || []
        for (var i = 0; i < mains.length; i++) rel.push(_packRow(mains[i]))
        for (var j = 0; j < extras.length; j++) rel.push(_packRow(extras[j]))
        if (!rel.length) { console.warn("pack: openPackSeries — no volumes for", seriesId); return }
        westernLayer.baked = { packSeriesId: seriesId, releases: rel, cover: "" }
        westernLayer.title = (d && d.seriesTitle) || ""
        westernLayer.tagSlug = ""; westernLayer.tagId = 0
        westernLayer.resumeChapterId = (d && d.resumeChapterId) || ""
        if (westernLayer.active && westernLayer.item) {
            var it = westernLayer.item
            it.bakedReleases = null                 // reset first so re-injection repaints
            it.seriesTitle = westernLayer.title
            it.packSeriesId = westernLayer.baked.packSeriesId   // identity FIRST (df003eb)
            it.bakedReleases = westernLayer.baked.releases      // seriesId now stable
            it.tagId = 0; it.tagSlug = ""                       // resolve() guard: baked, no live lookup
            it.openChapterId = westernLayer.resumeChapterId || ""   // open reader LAST — identity stable
        } else westernLayer.active = true
    }

    // ---- a universe's comic row: each entry pins explicit GetComics post IDs and,
    //      when known, an exact GCD series ID. Mirrors openGcdSeries' baked injection
    //      (Main.qml:578) — an explicit release list, tagSlug/tagId deliberately empty.
    //      `?p=<id>` is GetComics' permalink; ComicSeries.qml:531 feeds it to downloadIssue.
    //      d: { title, posts:[Number], year?, gcdId? } ----
    function openUniverseComic(d) {
        var posts = (d && d.posts) || []
        if (!posts.length) { console.warn("universes: openUniverseComic — no posts for", (d && d.title) || "(untitled)"); return }
        var gcdId = Number((d && d.gcdId) || 0)
        if (!Number.isInteger(gcdId) || gcdId <= 0) gcdId = 0
        // GCD is authoritative only for an unambiguous series. An era collection may
        // contain multiple GCD runs, so use its pinned first GetComics post as a stable
        // independent identity; never let several collections share "gcd:0".
        var fallbackId = gcdId ? "" : "gc:posts:" + String(posts[0])
        var year = parseInt(String((d && d.year) || "").slice(0, 4), 10) || 0
        var rel = []
        for (var i = 0; i < posts.length; i++)
            rel.push({ id: String(posts[i]),
                       url: "https://getcomics.org/?p=" + posts[i],
                       name: d.title || "", cover: "",
                       year: year, sizeMB: 0, synopsis: "",
                       date: "", collection: true })
        westernLayer.baked = { gcdId: gcdId, packSeriesId: fallbackId,
                               releases: rel, cover: (d && d.cover) || "" }
        westernLayer.title = (d.title || "") + (d.year ? " (" + d.year + ")" : "")
        westernLayer.tagSlug = ""; westernLayer.tagId = 0
        westernLayer.resumeChapterId = ""
        if (westernLayer.active && westernLayer.item) {
            var it = westernLayer.item
            it.bakedReleases = null                 // reset first so re-injection repaints
            it.openChapterId = ""
            it.seriesTitle = westernLayer.title
            it.poster = westernLayer.baked.cover
            it.packSeriesId = fallbackId           // identity FIRST; also clears stale pack IDs
            it.gcdId = gcdId
            it.bakedReleases = rel                  // stable gcd:/gc:posts: identity before mount
            it.tagId = 0; it.tagSlug = ""           // no name/tag lookup
        } else westernLayer.active = true
    }

    // A pinned cross-run GetComics collection is not a live tag search. Resolve its
    // durable first-post key back to the bundled Universe's exact curated post list.
    function reopenPinnedUniverseComic(id, title, cover) {
        var match = /^gc:posts:([1-9][0-9]*)$/.exec(String(id || ""))
        if (!match) return false
        var stems = ["com.colosseum.universe.onepiece",
                     "com.colosseum.universe.dcau",
                     "com.colosseum.universe.starwars"]
        var matched = false
        var outstanding = stems.length
        for (var i = 0; i < stems.length; ++i) {
            UniverseApi.load(stems[i], function(payload) {
                if (!matched && payload) {
                    var sections = payload.sections || []
                    for (var si = 0; si < sections.length && !matched; ++si) {
                        if (sections[si].kind !== "comic") continue
                        var entries = sections[si].entries || []
                        for (var ei = 0; ei < entries.length; ++ei) {
                            var entry = entries[ei]
                            if (String((entry.posts || [])[0] || "") !== match[1]) continue
                            matched = true
                            win.openUniverseComic({
                                title: entry.title || title, year: entry.year || "",
                                cover: entry.cover || cover, posts: entry.posts,
                                gcdId: entry.gcdId || 0, gcdIds: entry.gcdIds || []
                            })
                            break
                        }
                    }
                }
                outstanding--
                if (!outstanding && !matched)
                    console.warn("Saved universe comic is no longer bundled:", id)
            })
        }
        return true
    }

    // ---- comic series: a LOCG catalogue series' issue list (GetComics content attached).
    //      Opened from search (data.locg), the world Top-Comics row, or a publisher grid. ----
    // catalog lookup with on-demand ingest: Main never imports the multi-MB
    // gen.js itself; the first route that needs the catalog activates the tiny
    // ComicsDbLoader (synchronous Loader -> ingest completes before we return).
    function comicsDbHit(title) {
        if (!title || !String(title).length) return null
        if (!ComicsDb.ready()) comicsDbLoader.active = true
        return ComicsDb.ready() ? ComicsDb.seriesByTitle(title) : null
    }

    function openComicSeries(d) {
        win.cancelCatalogueRoute();
        var generation = _catalogueRouteGeneration;
        var snapshot = win.catalogueRouteSnapshot();
        var catalog = typeof ComicsCatalog !== "undefined" ? ComicsCatalog : null;
        _catalogueRouteCancel = CatalogDelivery.wait(catalog, function() {
            if (!CatalogDelivery.available(catalog)) return null;
            return catalog.curatedSeries(String((d && d.id) || "").replace(/^locg:/, ""));
        }, function() {
            if (generation !== _catalogueRouteGeneration || snapshot !== win.catalogueRouteSnapshot()) return;
            _catalogueRouteCancel = null;
            win._openComicSeriesReady(d);
        });
    }
    function _openComicSeriesReady(d) {
        comicSeriesLayer.locgSid = (d && d.id) || ""
        comicSeriesLayer.locgMeta = (d && d.locgMeta) || ({})
        comicSeriesLayer.title = (d && d.title) || ""
        comicSeriesLayer.cover = (d && d.cover) || ""
        if (comicSeriesLayer.active && comicSeriesLayer.item) {
            comicSeriesLayer.item.openChapterId = ""       // leave the reader, show the list
            comicSeriesLayer.item.seriesTitle = comicSeriesLayer.title
            comicSeriesLayer.item.cover = comicSeriesLayer.cover
            comicSeriesLayer.item.locgMeta = comicSeriesLayer.locgMeta
            comicSeriesLayer.item.locgId = comicSeriesLayer.locgSid   // set LAST — triggers attach()
        } else comicSeriesLayer.active = true
    }
    function closeComicSeries() { win.cancelCatalogueRoute(); comicSeriesLayer.active = false; win.restoreNamedCollectionsReturn() }

    // ---- LOCG publisher grid: one publisher shelf (Marvel/DC/Image...) as a paginated
    //      series grid; tile → LOCG series list via openComicSeries. ----
    function openLocgPublisher(box) {
        locgPublisherLayer.box = box || ({})
        if (locgPublisherLayer.active && locgPublisherLayer.item) locgPublisherLayer.item.box = locgPublisherLayer.box
        else locgPublisherLayer.active = true
    }
    function closeLocgPublisher() { locgPublisherLayer.active = false }

    // ---- GetComics Archives board: the publisher/franchise taxonomy, full page ----
    function openComicArchiveBoard() { comicBoardLayer.active = true }
    function closeComicArchiveBoard() { comicBoardLayer.active = false }

    // ---- western-comics archive index: the SERIES ARCHIVES under an explore box
    //      (a publisher/franchise tag holds raw release posts — this is the middle
    //      layer that shows the /tag/ archives inside it, Hemanth's 2026-07-04 call) ----
    function openComicArchive(box) {
        comicIndexLayer.boxTitle = (box && box.name) || (box && box.title) || ""
        comicIndexLayer.tagSlug = (box && box.tag) || ""
        comicIndexLayer.boxCount = (box && box.count) || 0
        comicIndexLayer.tagId = (box && box.tagId) || 0
        if (comicIndexLayer.active && comicIndexLayer.item) {
            comicIndexLayer.item.boxTitle = comicIndexLayer.boxTitle
            comicIndexLayer.item.tagSlug = comicIndexLayer.tagSlug
            comicIndexLayer.item.boxCount = comicIndexLayer.boxCount
            comicIndexLayer.item.tagId = comicIndexLayer.tagId   // change fires resolve()
        } else comicIndexLayer.active = true
    }
    function closeComicArchive() { comicIndexLayer.active = false }


    // ---- Theatre detail: its own layer (Cinemeta meta + Torrentio sources), parallel to series ----
    function openTheatreSeries(item) { win.cancelCatalogueRoute();
        theatreSeriesLayer.pendingItem = item
        if (theatreSeriesLayer.active && theatreSeriesLayer.item) theatreSeriesLayer.item.itemData = item
        else theatreSeriesLayer.active = true
    }
    function closeTheatreSeries() { theatreSeriesLayer.active = false; win.restoreNamedCollectionsReturn() }

    // ---- video player: a fullscreen layer over everything; kept alive once opened so mpv
    //      isn't torn down/recreated each play (avoids the use-after-free teardown trap). ----
    property bool playerOpen: false
    // The movie session the player minimized while still loaded. Reopening it from the
    // taskbar finds the stream warm — we resume in place instead of re-streaming.
    property string warmPlayerSessionId: ""
    // First PlayerPage construction is large enough to block weak machines for visible chunks.
    // Keep the Loader cold until first use, incubate it across event-loop turns, then replay the
    // one latest open request after onLoaded. Once created, the existing keep-alive policy wins.
    property var pendingPlayerOpen: null
    property bool playerLayerRetryPending: false

    function ensurePlayerLayerLoading() {
        if (playerLayerRetryPending)
            return
        if (playerLayer.status === Loader.Error) {
            retryPlayerLayerLoading()
            return
        }
        if (!playerLayer.active)
            playerLayer.active = true
    }
    function retryPlayerLayerLoading() {
        if (playerLayerRetryPending || !win.playerOpen || !win.pendingPlayerOpen)
            return
        playerLayerRetryPending = true
        var sameSource = playerLayer.source
        playerLayer.active = false
        playerLayer.source = ""
        Qt.callLater(function() {
            playerLayer.source = sameSource
            playerLayerRetryPending = false
            playerLayer.active = win.playerOpen && !!win.pendingPlayerOpen
        })
    }
    function queuePlayerSessionOpen(sessionId) {
        win.pendingPlayerOpen = { "kind": "session", "sessionId": String(sessionId || "") }
        win.ensurePlayerLayerLoading()
    }
    function queueDirectPlayerOpen(infoHash, fileIdx, title, backdrop, subType, subId, candidates, context) {
        win.pendingPlayerOpen = { "kind": "direct", "infoHash": infoHash, "fileIdx": fileIdx,
                                  "title": title, "backdrop": backdrop, "subType": subType,
                                  "subId": subId, "candidates": candidates || [], "context": context || ({}) }
        win.ensurePlayerLayerLoading()
    }

    function queueWatchPartyPlayerOpen() {
        win.pendingPlayerOpen = { "kind": "watchParty" }
        win.ensurePlayerLayerLoading()
    }
    function clearPendingPlayerSession(sessionId) {
        var p = win.pendingPlayerOpen
        if (p && p.kind === "session" && p.sessionId === String(sessionId || "")) {
            win.pendingPlayerOpen = null
            return true
        }
        return false
    }
    function flushPendingPlayerOpen() {
        if (!playerLayer.item || !win.pendingPlayerOpen)
            return
        var p = win.pendingPlayerOpen
        win.pendingPlayerOpen = null
        if (p.kind === "session") {
            if (!win.playerOpen || Sessions.activeId !== p.sessionId)
                return
            var rec = Sessions.get(p.sessionId)
            if (rec && rec.id)
                win.activateMovieSession(rec)
            return
        }
        if (p.kind === "direct") {
            if (win.playerOpen) {
                win.requestTheatreAudio()
                playerLayer.item.playTorrent(p.infoHash, p.fileIdx, p.title, p.backdrop, p.subType, p.subId,
                                             p.candidates || [], p.context || ({}))
            }
            return
        }
        if (p.kind === "watchParty" && win.playerOpen)
            win.openWatchPartyRoomSource()
    }

    // Gives the shell a moment to finish coming up before the player is opened on top of it.
    Timer {
        id: abbaTimer
        property string path: ""
        interval: 2500
        repeat: false
        onTriggered: {
            console.log("[abba] auto-playing " + abbaTimer.path)
            win.openLocalVideoSession({ "id": "abba:clip", "title": "ABBA measurement clip",
                                        "path": abbaTimer.path })
        }
    }

    // The backend is a BOOT fact: COLOSSEUM_PLAYER2 selects the D3D11 RHI in C++, and
    // Player2Available reports what this process actually booted on. There is no runtime
    // fallback in a Player 2 boot - mpv cannot render on D3D11 - so failures surface on the
    // player page's error screen instead of swapping engines.
    readonly property bool usePlayer2: Player2Available === true

    // Every immersive manga/comic/reader/player surface suppresses the OS-shell taskbar.
    // A Tankoban series detail is itself an immersive Reading Room now: the fixed rail and
    // volume pane own the whole window before a reader is opened, so the taskbar must not
    // remain visible underneath that surface.
    readonly property bool immersiveSurfaceOpen: win.playerOpen
        || bookReaderLayer.active
        || vaultComicLayer.active
        || seriesLayer.active
        || (seriesLayer.active && seriesLayer.item && seriesLayer.item.openChapterId.length > 0)
        || (westernLayer.active && westernLayer.item && westernLayer.item.openChapterId.length > 0)
        || (comicSeriesLayer.active && comicSeriesLayer.item && comicSeriesLayer.item.openChapterId.length > 0)

    // Full-window pages opened from browsing own the canvas while they are active. Downloads is
    // deliberately excluded because it is the Profile destination and keeps shell navigation.
    readonly property bool fullWindowPageOpen:
        collectionsPanel.showing
        || theatreSeriesLayer.active
        || bookLayer.active
        || seriesLayer.active
        || westernLayer.active
        || comicSeriesLayer.active
        || locgPublisherLayer.active
        || comicIndexLayer.active
        || comicBoardLayer.active
        || genreLayer.active
        || genreIndexLayer.active
        || biblioGenreLayer.active
        || biblioGenreIndexLayer.active
        || theatreGenreLayer.active
        || theatreGenreIndexLayer.active
        || searchLayer.active
        || worldSearchLayer.active
        || universeLayer.active
        || onePieceArcLayer.active
        || vaultLayer.active
        || continueSeeAllLayer.active

    readonly property alias wideWorldNavigationLeftInset: phoneShell.wideWorldNavigationLeftInset

    // ---- season-download resolver: a promoted queue job carries only the episode's
    //      stream id; we pick the rank-best Torrentio stream and feed back the local
    //      engine URL. Deferred while the player streams (one engine, playback wins). ----
    property var pendingResolves: []
    property var pendingFeeds: ({})   // "hash:idx" -> job id, answered by onFetchReady
    property int downloadResolveEpoch: 0
    Connections {
        target: typeof PlatformDownloads !== "undefined" ? PlatformDownloads : null
        function onOpenDownloadsRequested() { win.openDownloadsPage() }
    }
    // torrent-choice pin (spec 2026-07-11): a hand-picked job carries infoHash/fileIdx
    // in its request; jobs() exposes them. Pinned -> prefetch exactly that torrent, no
    // source search, and Retry retries the SAME pick (the choice is durable — never
    // silently swapped). fileIdx -1 = hash-only pin (season-pack checkout 2026-07-19):
    // the torrent is chosen, the episode's file inside it resolves via the source
    // search below. Unpinned (auto fallback, old queued jobs) -> rank-best below.
    function pinnedPickFor(id) {
        var js = Download.jobs()
        for (var i = 0; i < js.length; i++) {
            if (js[i].id !== id) continue
            var h = String(js[i].infoHash || "")
            if (h.length) return { "infoHash": h, "fileIdx": Number(js[i].fileIdx || 0) }
            return null
        }
        return null
    }
    function resolveDownloadJob(id, streamId, mediaType) {
        var resolveEpoch = win.downloadResolveEpoch
        var pin = pinnedPickFor(id)
        if (pin && pin.fileIdx >= 0) {
            var pkey = pin.infoHash.toLowerCase() + ":" + pin.fileIdx
            win.pendingFeeds[pkey] = id
            Stream.prefetch(pin.infoHash, pin.fileIdx)
            return
        }
        var onRows = function(rows) {
            if (resolveEpoch !== win.downloadResolveEpoch) return
            if (!rows || !rows.length) {
                Download.failJob(id, "No stream found for this episode.")
                return
            }
            var best = rows[0]
            // hash-only pin (fileIdx -1, the season-pack checkout 2026-07-19): the
            // torrent was hand-picked, the file inside it wasn't known at queue time.
            // Prefer THIS episode's row from the picked torrent; the pack not
            // carrying this episode -> the rank-best fallback above stands.
            if (pin) {
                for (var p = 0; p < rows.length; p++) {
                    if (String(rows[p].infoHash || "").toLowerCase() === pin.infoHash.toLowerCase()) {
                        best = rows[p]
                        break
                    }
                }
            }
            // prefetch (NOT play): the url arrives via onFetchReady once the engine
            // is genuinely up. The old synchronous streamUrl() read raced a cold
            // engine and fed "" — the job then sat "resolving" forever (the
            // nothing-downloads wedge, diagnosed 2026-07-05). play() is also the
            // player's signal — prefetch keeps downloads out of mpv's ears.
            var directUrl = best.url ? String(best.url) : ""
            if (!directUrl.length && String(best.infoHash || "").indexOf("url:") === 0)
                directUrl = String(best.infoHash).substring(4)
            if ((best.streamKind === "Direct" || directUrl.length) && directUrl.length) {
                Download.feedSource(id, directUrl,
                                    (best.headers && typeof best.headers === "object" && !Array.isArray(best.headers))
                                    ? best.headers : ({}))
                return
            }
            var key = (best.infoHash || "").toLowerCase() + ":" + (best.fileIdx || 0)
            win.pendingFeeds[key] = id
            Stream.prefetch(best.infoHash, best.fileIdx || 0)
        }
        // Same source ladder as the player and the picker: every installed stream
        // extension in ask-order first, Torrentio only if it is still installed AND
        // enabled. This path used to call Torrentio.js directly and never look at the
        // store at all, so removing Torrentio did nothing here and a well ranked above
        // it was ignored outright. (2026-07-25, A5 — Torrentio-honesty fix.)
        var installed = (typeof Extensions !== "undefined") ? Extensions.installed() : []
        var exts = AddonClient.streamExtensions(installed, mediaType, streamId)
        var lastResort = function() {
            if (resolveEpoch !== win.downloadResolveEpoch) return
            if (AddonClient.torrentioEnabled(installed))
                Torrentio.loadStreams(mediaType, streamId, onRows)
            else
                Download.failJob(id, "No source installed for this. Add one in Extensions.")
        }
        if (exts.length) {
            AddonClient.loadStreams(exts, mediaType, streamId, function() {}, function(rows) {
                if (rows && rows.length) onRows(rows)
                else lastResort()
            })
        } else {
            lastResort()
        }
    }
    Connections {
        target: typeof Stream !== "undefined" ? Stream : null
        function onFetchReady(url, infoHash, fileIdx) {
            var key = infoHash.toLowerCase() + ":" + fileIdx
            var id = win.pendingFeeds[key]
            if (id === undefined)
                return
            delete win.pendingFeeds[key]
            Download.feedTorrentUrl(id, url, infoHash, fileIdx)
        }
        function onStreamError(message) {
            // Engine went away mid-warmup: fail the waiting jobs honestly (Retry
            // re-resolves) instead of leaving them wedged in "resolving".
            var any = false
            for (var key in win.pendingFeeds) {
                Download.failJob(win.pendingFeeds[key], message)
                any = true
            }
            if (any)
                win.pendingFeeds = ({})
        }
    }
    Connections {
        target: typeof Download !== "undefined" ? Download : null
        function onResolutionReset() {
            win.downloadResolveEpoch++
            win.pendingFeeds = ({})
            win.pendingResolves = []
        }
        function onNeedResolve(id, streamId, mediaType) {
            if (win.playerOpen) { win.pendingResolves.push({ id: id, sid: streamId, mt: mediaType }); return }
            win.resolveDownloadJob(id, streamId, mediaType)
        }
    }
    Connections {
        target: typeof Sessions !== "undefined" ? Sessions : null
        function onTargetReplaced(id) {
            // one-tab-per-show: the tile now points at NEW content — a warm-kept old
            // stream must not resume as if it were the new pick, and if the record is
            // somehow active (taskbar path) the live surface follows the new target.
            if (win.warmPlayerSessionId === id)
                win.warmPlayerSessionId = ""
            if (Sessions.activeId === id)
                win.activateSession(Sessions.get(id))
        }
    }
    Connections {
        target: win
        function onPlayerOpenChanged() {
            if (win.playerOpen) win.claimAudio("theatre")
            if (win.playerOpen || !win.pendingResolves.length)
                return
            var p = win.pendingResolves.shift()
            win.resolveDownloadJob(p.id, p.sid, p.mt)
        }
    }

    // ---- Feria: streaming world, entered from the shared selector ----
    function openFeriaPage() {
        if (win.guardNamedCollectionsNavigation(function() { win.openFeriaPage() })) return

        if (!win.ensureFeriaRuntime()) return
        win.bookRouteGeneration += 1
        downloadsLayer.active = false
        vaultLayer.active = false
        extensionsLayer.active = false
        updateLayer.active = false
        historyStatsLayer.active = false
        syncCenterLayer.active = false
        feriaLayer.open = true
        worldStack.current = ""
        currentSurface = "Feria"
        refreshWallpaper()
        taskbar.open = false
        Qt.callLater(win.restoreFeriaIfReady)
    }
    function closeFeriaPage() {
        win.parkFeria(false)
        win.closeWorld()
    }

    // ---- Tracker Sync Center: tracker connections, separate from Stremio Main Sync ----
    function openSyncCenterPage() {
        if (win.guardNamedCollectionsNavigation(function() { win.openSyncCenterPage() })) return

        win.parkFeria(true)
        win.bookRouteGeneration += 1
        downloadsLayer.active = false
        vaultLayer.active = false
        extensionsLayer.active = false
        updateLayer.active = false
        historyStatsLayer.active = false
        syncCenterLayer.active = true
        taskbar.open = false
        if (syncCenterLayer.item && syncCenterLayer.item.takeKeyboardFocus)
            Qt.callLater(syncCenterLayer.item.takeKeyboardFocus)
    }
    function closeSyncCenterPage() {
        syncCenterLayer.active = false
        win.focusTrackersDoor()
    }
    function toggleSyncCenterPage() {
        !syncCenterLayer.active ? win.openSyncCenterPage() : win.closeSyncCenterPage()
    }
    // The trackers door lives in the TopBar of home and of every world; hand focus back to
    // whichever of those is in front.
    function focusTrackersDoor() {
        for (let i = 0; i < worldRepeater.count; ++i) {
            const loader = worldRepeater.itemAt(i)
            if (loader && loader.mode === worldStack.current && loader.item
                    && loader.item.focusTrackersButton) {
                const world = loader.item
                Qt.callLater(function() { world.focusTrackersButton() })
                return
            }
        }
        Qt.callLater(function() { topbar.focusTrackersButton() })
    }

    // ---- Arc 35: local-first History, Highlights, and Stats ----
    function openHistoryStatsPage() {
        if (win.guardNamedCollectionsNavigation(function() { win.openHistoryStatsPage() })) return

        win.parkFeria(true)
        win.bookRouteGeneration += 1
        downloadsLayer.active = false
        vaultLayer.active = false
        extensionsLayer.active = false
        updateLayer.active = false
        syncCenterLayer.active = false
        historyStatsLayer.active = true
        taskbar.open = false
        if (historyStatsLayer.item && historyStatsLayer.item.takeKeyboardFocus)
            Qt.callLater(historyStatsLayer.item.takeKeyboardFocus)
    }
    function openYourFeriaPage(section) {
        if (win.guardNamedCollectionsNavigation(function() { win.openYourFeriaPage(section) })) return

        if (!win.ensureFeriaRuntime()) return
        if (!feriaLayer.open) win.openFeriaPage()
        if (!feriaLayer.item) return
        accountCenter.close()
        feriaLayer.item.accountTab = ["history", "highlights", "stats"].indexOf(section) >= 0 ? section : "history"
        yourFeriaLayer.open = true
        taskbar.open = false
        if (yourFeriaLayer.item) Qt.callLater(yourFeriaLayer.item.takeKeyboardFocus)
    }
    function closeYourFeriaPage() {
        yourFeriaLayer.open = false
        taskbar.focusHistoryStatsAction()
    }
    function closeHistoryStatsPage() {
        historyStatsLayer.active = false
        taskbar.focusHistoryStatsAction()
    }

    // ---- Downloads page: the taskbar's own full page over everything non-immersive ----
    // Downloads and Extensions are taskbar full-pages; opening either one
    // closes the other two so only one taskbar surface is ever the front page (Task 2).
    function openDownloadsPage() {
        if (win.guardNamedCollectionsNavigation(function() { win.openDownloadsPage() })) return

        win.parkFeria(true)
        win.bookRouteGeneration += 1
        setGuiStallContext("open", "Downloads")
        extensionsLayer.active = false
        updateLayer.active = false
        historyStatsLayer.active = false
        syncCenterLayer.active = false
        vaultLayer.active = false
        downloadsLayer.active = true
        taskbar.open = false
    }
    function closeDownloadsPage() {
        downloadsLayer.active = false
        setGuiStallContext("navigate", currentSurface || "Home")
    }

    // ---- Vault page: the taskbar folder door's full-page, mutually exclusive with the other taskbar
    // full-pages (Slice 10). It overlays the current surface (z:56); closing just deactivates the
    // Loader and reveals whatever the user stood on. ----
    function openVaultPage() {
        if (win.guardNamedCollectionsNavigation(function() { win.openVaultPage() })) return

        if (win.androidHost) return
        win.parkFeria(true)
        win.bookRouteGeneration += 1
        downloadsLayer.active = false
        extensionsLayer.active = false
        updateLayer.active = false
        historyStatsLayer.active = false
        syncCenterLayer.active = false
        vaultLayer.active = true
        taskbar.open = false
    }
    function closeVaultPage() { vaultLayer.active = false; win.restoreNamedCollectionsReturn() }

    // Esc inside the Vault, mirroring VaultPage's own top-left Back law: sheet, then folder
    // detail, then one browse level up (or out of the Hidden shelf), and only leave once
    // there is nowhere left to ascend.
    // The sheet must be handled HERE, not by its own Keys.onPressed: the window-context
    // Escape Shortcut above is matched before the key reaches the focus item, and nothing in
    // the Vault accepts Keys.onShortcutOverride, so an inner handler can never win Escape
    // back. Backspace is not a Shortcut, so inner ascend handlers still see it.
    function vaultBack() {
        var page = vaultLayer.item
        if (!page) { win.closeVaultPage(); return }
        if (page.detailSheetVisible) { page.closeDetailSheet(); return }
        // Vault ux uplift S14: Escape leaves the search pseudo-level first — it is the most
        // transient view state (the field itself can never see the key: the window-context
        // Shortcut is matched before the focus item, the S2 lesson).
        if (page.searchViewActive) { page.leaveSearchView(); return }
        if (page.hiddenViewActive || (page.crumbStack && page.crumbStack.length > 1)) {
            page.ascendBrowse()
            return
        }
        win.closeVaultPage()
    }

    Loader {
        id: yourFeriaLayer
        objectName: "yourFeriaLayer"
        anchors.fill: parent
        z: 58.5
        property bool open: false
        active: !win.feriaComingSoon && open && feriaLayer.open && feriaLayer.item !== null
        visible: active
        onActiveChanged: if (!active) open = false
        source: "feria/YourFeriaPage.qml"
        onLoaded: {
            item.controller = feriaLayer.item
            item.backRequested.connect(win.closeYourFeriaPage)
            item.settingsRequested.connect(function() { feriaLayer.item.openApps() })
            item.takeKeyboardFocus()
        }
    }

    // ---- Extensions page: the store, entered from the taskbar beside Downloads ----
    // The installed roster, live. The universes rail derives from it rather than from a
    // baked list, so installing or removing a universe changes Home with no other edit.
    property var installedExtensions:
        (typeof Extensions !== "undefined") ? Extensions.installed() : []

    // The carousel and the Hall both derive from the ROSTER, so installing or removing a
    // universe is the only way either surface changes. Replaces the five baked universes.
    readonly property var installedUniverses: {
        var out = []
        for (var i = 0; i < win.installedExtensions.length; i++) {
            var e = win.installedExtensions[i]
            if (!ExtCatalog.isUniverse(e)) continue
            if (e.enabled !== true) continue
            var m = e.manifest || ({})
            out.push({ extensionId: e.id, name: m.name || e.id,
                       banner: m.background || "", logo: m.logo || "" })
        }
        return out
    }

    // A universe is opened BY EXTENSION ID: the extension supplies identity, and the payload
    // is looked up from the curation point by that id. That join is what makes an installed
    // universe a real page instead of a row in a list. (Universes design §5.3 — a universe
    // supplies identity and ordering, never sources.) The name rides along only as a label,
    // for the header band before the payload lands.
    // One renderer for every universe. The per-category dispatcher is gone: it existed to
    // pick between bespoke per-IP pages, and those are being deleted (next task).
    function openUniverse(extensionId, name, plain) {
        if (!extensionId) return
        win.closeOnePieceArc()
        universeLayer.templatePage = ""
        universeLayer.plain = plain === true
        universeLayer.extensionId = extensionId
        universeLayer.universeName = name || ""
        if (universeLayer.item) {
            universeLayer.item.extensionId = extensionId
            universeLayer.item.universeName = name || ""
        }
        universeLayer.active = true
    }
    // An archived universe has no extension; it opens by name on its category's template.
    function openArchivedUniverse(name, page) {
        if (!name || !universeLayer.templateSources[page]) return
        win.closeOnePieceArc()
        universeLayer.plain = false
        universeLayer.extensionId = "archive." + page
        universeLayer.universeName = name
        universeLayer.templatePage = page
        if (universeLayer.item && universeLayer.status === Loader.Ready && universeLayer.item.universeName !== undefined)
            universeLayer.item.universeName = name
        universeLayer.active = true
    }
    // A banner in the Universes world opens the universe's STANDARD page. An entry with a
    // page (a curated sagaGrid, or an archived universe's template) opens through
    // openArchivedUniverse; only an entry with no page falls back to the extension route —
    // an installed One Piece carries both, and its story-grid page wins over the payload
    // route (a payload-less Cosmere still lands on its Tribute).
    function openRosterUniverse(entry) {
        if (!entry) return
        if (entry.page)
            win.openArchivedUniverse(entry.name, entry.page)
        else
            win.openUniverse(entry.extensionId, entry.name, UniverseApi.fileFor(entry.extensionId).length > 0)
    }
    // The Universes world's carousel: the hand-made art page.
    function openTribute(entry) { if (entry && entry.extensionId) win.openUniverse(entry.extensionId, entry.name) }
    // A "More universes" card names a sibling; its template comes from the curated list.
    function openUniverseByName(name) {
        var cfg = UniverseCanon.configFor(name)
        // same rule as the Universes world's roster: an anime universe (curated manga)
        // opens its shelves page; a curated sagaGrid opens the story grid
        if (cfg && cfg.category)
            win.openArchivedUniverse(cfg.name, (cfg.shelves || cfg.manga) ? "shelves" : (cfg.sagaGrid ? "saga" : cfg.category))
    }
    function closeUniverse() {
        win.closeOnePieceArc()
        universeLayer.active = false
    }
    function openOnePieceArc(arc) {
        if (!arc) return
        onePieceArcLayer.arcData = arc
        onePieceArcLayer.active = true
    }
    function closeOnePieceArc() {
        onePieceArcLayer.active = false
        onePieceArcLayer.arcData = null
        if (universeLayer.active && universeLayer.item && universeLayer.item.takeKeyboardFocus)
            Qt.callLater(universeLayer.item.takeKeyboardFocus)
    }
    function routeUniverseSeries(e) {
        var requested = (e && e.requestedVolumeNumber) ? String(e.requestedVolumeNumber) : ""
        if (e && e.provider === "weebcentral") win.openWeebCentralSeries(e.title || "", requested)
        else if (e && e.provider === "tankoban") win.openSeries(e.title || "", e.malId || "", {
            malId: e.malId || "", seriesId: e.seriesId || "",
            sourceSearchTitle: e.sourceSearchTitle || "",
            sourceSearchAliases: e.sourceSearchAliases || [],
            sourceRequiredMarkers: e.sourceRequiredMarkers || []
        }, requested)
        else if (e && e.provider === "anilist" && Number(e.malId) > 0)
            win.openSeries(e.title || "", String(e.malId), null, requested)
        else win.openSeries((e && e.title) || e || "", "", null, requested)
    }
    function openOnePaceArc(arc) { win.openExtensionsPage("theatre") }

    // world (optional, R1 2026-08-21): lands the page straight on that world's Sources
    // tab instead of the default "theatre" — the manga picker's empty-state route
    // passes "tankoban" so enabling Nyaa is one click, not a hunt through tabs.
    property string pendingExtensionConfiguration: ""
    function openExtensionsPage(world, configurationId) {
        if (win.guardNamedCollectionsNavigation(function() { win.openExtensionsPage(world, configurationId) })) return

        pendingExtensionConfiguration = String(configurationId || "")
        win.parkFeria(true)
        win.bookRouteGeneration += 1
        downloadsLayer.active = false
        updateLayer.active = false
        historyStatsLayer.active = false
        syncCenterLayer.active = false
        vaultLayer.active = false
        extensionsLayer.active = true
        if (world && extensionsLayer.item) extensionsLayer.item.world = world
        win.openPendingExtensionConfiguration()
        taskbar.open = false
        if (extensionsLayer.item && extensionsLayer.item.takeKeyboardFocus)
            Qt.callLater(extensionsLayer.item.takeKeyboardFocus)
    }
    function openPendingExtensionConfiguration() {
        if (!pendingExtensionConfiguration.length || !extensionsLayer.item) return
        extensionsLayer.item.openConfiguration(pendingExtensionConfiguration)
        pendingExtensionConfiguration = ""
    }
    function closeExtensionsPage() {
        pendingExtensionConfiguration = ""
        extensionsLayer.active = false
    }

    // ---- Update page: the verified release chronicle, mutually exclusive with the other
    // taskbar full-pages. Opening it marks only the current release as seen; availability stays.
    function openUpdatePage() {
        if (win.guardNamedCollectionsNavigation(function() { win.openUpdatePage() })) return

        win.parkFeria(true)
        win.bookRouteGeneration += 1
        downloadsLayer.active = false
        extensionsLayer.active = false
        vaultLayer.active = false
        historyStatsLayer.active = false
        syncCenterLayer.active = false
        updateLayer.active = true
        // Full-bleed: the chronicle owns the whole page. The taskbar closes like
        // every other full-page destination (Downloads/Vault/Extensions)
        // and still reveals on hover for session switching. The Update entry point
        // is the home topbar glyph now — no launcher in the taskbar dock.
        taskbar.open = false
        if (typeof Updates !== "undefined" && Updates.markSeen)
            Updates.markSeen()
    }
    function closeUpdatePage() { updateLayer.active = false }
    function routeDownloadItem(item) {
        win.closeDownloadsPage()
        if (item.world === "theatre") {
            // Downloaded videos take the SAME check-in as streams (spec 2026-07-06 parity):
            // a real session (taskbar tile, honest minimize) with identity (Continue store,
            // online subtitles). Resume where a previous watch left off, if the store knows one.
            var prog = Progress.get("video", item.id || "")
            var pos = (prog && prog.resume && Number(prog.resume.position || 0) > 0)
                      ? Number(prog.resume.position) : 0
            win.openLocalVideoSession({ "path": item.path, "id": item.id || "",
                                        "title": item.title || "", "art": item.art || "",
                                        "kind": item.kind || "", "position": pos })
        } else if (item.world === "biblio") {
            win.openBookSession(item.path, { "id": item.id || item.path, "title": item.title || "", "author": item.author || "" })
        } else if (item.kind === "comic") {
            // A demuxed pack child carries packRole (Slice 1 field, forwarded by
            // tankobanItems from downloadedIssueRow). Route it to the downloads-backed
            // pack shelf — NOT the live gc:/gcd: tag lanes, which can't see the demuxed
            // volumes. Ordinary single issues (empty packRole) stay on the existing paths.
            if (item.packRole && String(item.packRole).length > 0) {
                win.openPackSeries({ seriesId: item.seriesId,
                                     seriesTitle: item.seriesTitle,
                                     resumeChapterId: item.id })
            } else if (String(item.seriesId || "").indexOf("gc:") === 0)
                win.openWesternAt(item.seriesTitle, String(item.seriesId).slice(3), item.id)
            else if (String(item.seriesId || "").indexOf("gcd:") === 0)
                win.openGcdSeries({ gcdId: Number(String(item.seriesId).slice(4)),
                                    title: item.seriesTitle, resumeChapterId: item.id })
            else
                console.log("[route] ignoring unknown comic id:", item.seriesId)
        } else {
            win.openSeriesAt(item.seriesTitle, item.seriesId, item.id)
        }
    }
    // Play-while-arriving (2026-07-20): a LIVE theatre job can be watched now — the
    // player streams the same resolved url the download is pulling. Progress shares
    // the video id, so the landed copy resumes where the live watch left off.
    function routeArrivingPlay(job) {
        if (!job || !String(job.url || "").length) return
        win.closeDownloadsPage()
        var prog = Progress.get("video", job.id || "")
        var pos = (prog && prog.resume && Number(prog.resume.position || 0) > 0)
                  ? Number(prog.resume.position) : 0
        // disk-first (2026-07-31): with enough of the file on disk to probe and play
        // (8MB floor), the session opens on the .part instead of re-streaming bytes we
        // already have. Below the floor the stream url behaves exactly as before.
        var part = (Number(job.received || 0) > 8 * 1024 * 1024) ? String(job.partPath || "") : ""
        Sessions.openOrSwitch({
            "appType": "theatre", "contentKind": "movie", "title": job.title || "Video",
            "target": { "showKey": EpisodeBrowser.seriesRootId(job.id || ""),
                        "streamUrl": job.url, "partPath": part, "id": job.id || "",
                        "title": job.title || "", "headers": job.headers || ({}),
                        "art": job.art || "", "kind": job.kind || "", "position": pos }
        })
    }
    // Landed-restore guard: an Arriving session restored after the download finished
    // (app restart) must not chase a dead url when the file is already on disk.
    function downloadedVideoPath(id) {
        if (!id || typeof Download === "undefined") return ""
        var vids = Download.downloadedVideos() || []
        for (var i = 0; i < vids.length; i++)
            if (vids[i].id === id) return String(vids[i].path || "")
        return ""
    }
    function routeDownloadWorld(worldKey) {
        win.closeDownloadsPage()
        var medium = worldKey === "tankoban" ? "Tankoban"
                   : (worldKey === "biblio" || worldKey === "audiobook") ? "Biblio" : "Theatre"
        win.openWorld(medium)
    }
    function routeDownloadedAudiobook(item) {
        if (!item || !String(item.bookPath || "").length) return
        win.closeDownloadsPage()
        win.openBookSession(item.bookPath, {
            "id": item.bookId || item.bookPath,
            "title": item.title || "Book",
            "author": item.author || "",
            "pairKey": item.id || "",
            "openAudio": true
        })
    }

    function openPlayer(infoHash, fileIdx, title, backdrop, subType, subId, streamCandidates, playbackContext) {
        setGuiStallContext("open", "Player")
        win.playerOpen = true
        if (!playerLayer.item) {
            win.queueDirectPlayerOpen(infoHash, fileIdx, title, backdrop, subType, subId,
                                      streamCandidates || [], playbackContext || ({}))
            return
        }
        win.requestTheatreAudio()
        playerLayer.item.playTorrent(infoHash, fileIdx, title, backdrop, subType, subId,
                                     streamCandidates || [], playbackContext || ({}))
    }

    function openWatchPartyRoomSource() {
        if (typeof WatchPartyUi === "undefined" || !WatchPartyUi.inRoom)
            return false
        var source = WatchPartyUi.roomSource || ({})
        if (String(source.kind || "") !== "torrent")
            return false
        var hash = String(source.infoHash || "").toLowerCase()
        var fileIdx = Number(source.fileIdx || 0)
        if (hash.length !== 40 || !isFinite(fileIdx) || fileIdx < 0 || Math.floor(fileIdx) !== fileIdx)
            return false
        if (playerLayer.active && playerLayer.item
                && playerLayer.item.watchPartySourceEligible
                && playerLayer.item.watchPartySourceMatchesRoom) {
            playerLayer.item.syncWatchPartyPlayerObservation()
            return true
        }
        win.playerOpen = true
        if (!playerLayer.item) {
            win.queueWatchPartyPlayerOpen()
            return true
        }
        var candidate = { "infoHash": hash, "fileIdx": fileIdx }
        win.requestTheatreAudio()
        playerLayer.item.playTorrent(hash, fileIdx, "Watch Party", "", "", "",
                                    [candidate], { "watchPartyJoin": true })
        return true
    }
    function closePlayer() {
        win.pendingPlayerOpen = null
        if (playerLayer.item) playerLayer.item.stop()
        win.playerOpen = false
        setGuiStallContext("navigate", currentSurface || "Home")
    }

    // ---- book detail: Biblio's own dust-jacket page, a layer over the world ----
    function _stableKeyboardIdentity(item) {
        if (!item)
            return ""
        if (item.stableId !== undefined && item.stableId !== null)
            return String(item.stableId)
        return item.objectName ? String(item.objectName) : ""
    }

    function _keyboardCollectionOwner(item) {
        for (var node = item; node; node = node.parent) {
            if (node.keyboardReturnOwner === true && node.currentIndex !== undefined)
                return node
            if (node === win)
                break
        }
        return null
    }

    function _keyboardCollectionIdentity(owner, index) {
        if (!owner || index < 0)
            return ""
        if (owner.keyboardIdentityForIndex)
            return String(owner.keyboardIdentityForIndex(index) || "")
        var items = owner.keyboardItems !== undefined ? owner.keyboardItems : owner.model
        var value = items && items[index]
        if (value && value.entry && value.entry.id !== undefined)
            return String(value.entry.id)
        if (value && value.id !== undefined)
            return String(value.id)
        return ""
    }

    function _keyboardCollectionIndex(owner, identity) {
        if (!owner || !identity)
            return -1
        if (owner.keyboardIndexForIdentity)
            return Number(owner.keyboardIndexForIdentity(identity))
        var items = owner.keyboardItems !== undefined ? owner.keyboardItems : owner.model
        var count = items && items.length !== undefined ? items.length : Number(owner.count || 0)
        for (var i = 0; i < count; ++i) {
            if (win._keyboardCollectionIdentity(owner, i) === String(identity))
                return i
        }
        return -1
    }

    function _keyboardCollectionCount(owner) {
        if (!owner)
            return 0
        var items = owner.keyboardItems !== undefined ? owner.keyboardItems : owner.model
        if (items && items.length !== undefined)
            return Number(items.length)
        return Number(owner.count || 0)
    }

    function _keyboardCollectionModelRevision(owner) {
        if (!owner)
            return undefined
        if (owner.keyboardModelRevision !== undefined)
            return Number(owner.keyboardModelRevision)
        if (owner.modelRevision !== undefined)
            return Number(owner.modelRevision)
        return undefined
    }

    function _keyboardCollectionTarget(owner, index) {
        if (!owner)
            return null
        if (owner.keyboardItemAtIndex)
            return owner.keyboardItemAtIndex(index)
        if (owner.itemAtIndex)
            return owner.itemAtIndex(index)
        if (owner.currentItem && owner.currentIndex === index)
            return owner.currentItem
        if (owner.keyboardItems !== undefined || owner.model !== undefined
                || owner.count !== undefined)
            return null
        return owner
    }

    function _realizeKeyboardCollectionTarget(owner, index) {
        var target = win._keyboardCollectionTarget(owner, index)
        if (target)
            return target
        if (owner && owner.keyboardRevealIndex)
            owner.keyboardRevealIndex(index)
        else if (owner && owner.positionViewAtIndex)
            owner.positionViewAtIndex(index, GridView.Contain)
        return win._keyboardCollectionTarget(owner, index)
    }

    function _scheduleBookReturnLanding(snapshot, generation, owner, index, revision) {
        var pending = { snapshot: snapshot, generation: generation, owner: owner,
                        index: index, revision: revision }
        win.pendingBookReturn = pending
        Qt.callLater(function() {
            if (win.pendingBookReturn !== pending)
                return
            win.pendingBookReturn = null
            if (generation !== win.bookRouteGeneration || !owner
                    || !win._bookReturnTargetUsable(owner)
                    || (revision !== undefined
                        && win._keyboardCollectionModelRevision(owner) !== revision))
                return
            var resolvedIndex = win._keyboardCollectionIndex(owner, snapshot.identity)
            var count = win._keyboardCollectionCount(owner)
            if (resolvedIndex < 0 && count > 0)
                resolvedIndex = Math.max(0, Math.min(count - 1, Number(snapshot.index)))
            if (resolvedIndex < 0 || count <= 0)
                return
            var target = win._keyboardCollectionTarget(owner, resolvedIndex)
            if (!target || !win._bookReturnTargetUsable(target)
                    || !win._bookReturnTargetVisible(target)
                    || (snapshot.identity
                        && win._keyboardCollectionIdentity(owner, resolvedIndex)
                            !== String(snapshot.identity)))
                return
            owner.currentIndex = resolvedIndex
            if (target.forceActiveFocus)
                target.forceActiveFocus(Qt.PopupFocusReason)
        })
    }

    function _layerCoversReturn(layer) {
        if (!layer || layer.active !== true || layer.visible === false
                || Number(layer.opacity) <= 0.01)
            return false
        var item = layer.item
        return !item || (item.visible !== false && Number(item.opacity) > 0.01)
    }

    function _bookReturnCovered() {
        return win._layerCoversReturn(win.bookLayerRef)
            || win._layerCoversReturn(win.bookReaderLayerRef)
            || win._layerCoversReturn(win.playerLayerRef)
            || win._layerCoversReturn(win.searchLayerRef)
            || win._layerCoversReturn(win.vaultLayerRef)
    }

    function _bookReturnTargetVisible(item) {
        if (!item || item.visible === false || item.enabled === false)
            return false
        for (var node = item; node; node = node.parent) {
            if (node.visible === false || node.enabled === false)
                return false
            if (node.opacity !== undefined && Number(node.opacity) <= 0.01)
                return false
            if (node.clip === true) {
                var p0 = item.mapToItem(node, 0, 0)
                var p1 = item.mapToItem(node, Number(item.width), Number(item.height))
                var left = Math.min(p0.x, p1.x)
                var right = Math.max(p0.x, p1.x)
                var top = Math.min(p0.y, p1.y)
                var bottom = Math.max(p0.y, p1.y)
                var targetWidth = right - left
                var targetHeight = bottom - top
                var oversizedWidth = targetWidth > Number(node.width) + 0.000001
                var oversizedHeight = targetHeight > Number(node.height) + 0.000001
                if (oversizedWidth) {
                    var overlapWidth = Math.min(right, Number(node.width))
                        - Math.max(left, 0)
                    if (overlapWidth < Number(node.width) * win.bookReturnIdentifiablePortionRatio)
                        return false
                } else if (left < -0.000001
                           || right > Number(node.width) + 0.000001) {
                    return false
                }
                if (oversizedHeight) {
                    var overlapHeight = Math.min(bottom, Number(node.height))
                        - Math.max(top, 0)
                    if (overlapHeight < Number(node.height) * win.bookReturnIdentifiablePortionRatio)
                        return false
                } else if (top < -0.000001
                           || bottom > Number(node.height) + 0.000001) {
                    return false
                }
            }
            if (node === win)
                break
        }
        return true
    }

    function _bookReturnTargetUsable(item) {
        if (!item || item.visible === false || item.enabled === false)
            return false
        for (var node = item; node; node = node.parent) {
            if (node.visible === false || node.enabled === false
                    || (node.opacity !== undefined && Number(node.opacity) <= 0.01))
                return false
            if (node === win)
                break
        }
        return true
    }

    function _captureBookReturn() {
        var item = win.activeFocusItem
        var owner = win._keyboardCollectionOwner(item)
        var index = owner ? Number(owner.currentIndex) : -1
        var identity = owner ? win._keyboardCollectionIdentity(owner, index)
                             : win._stableKeyboardIdentity(item)
        if (!item || !identity)
            return null
        var scrolls = []
        for (var node = item; node; node = node.parent) {
            if (node.contentX !== undefined && node.contentY !== undefined) {
                scrolls.push({ flick: node, x: Number(node.contentX), y: Number(node.contentY) })
            }
            if (node === win)
                break
        }
        return {
            item: item,
            identity: identity,
            owner: owner,
            index: index,
            scrolls: scrolls
        }
    }

    function _restoreBookReturn(snapshot, generation, deferred) {
        if (!snapshot || (generation !== undefined && generation !== win.bookRouteGeneration)
                || win._bookReturnCovered())
            return false
        var target = null
        var resolvedOwnerIndex = -1
        var resolvedOwnerRevision = undefined
        var targetRealizationRequested = false
        if (snapshot.owner && win._bookReturnTargetUsable(snapshot.owner)) {
            resolvedOwnerRevision = win._keyboardCollectionModelRevision(snapshot.owner)
            var index = win._keyboardCollectionIndex(snapshot.owner, snapshot.identity)
            var count = win._keyboardCollectionCount(snapshot.owner)
            if (index < 0 && count > 0)
                index = Math.max(0, Math.min(count - 1, snapshot.index))
            if (index >= 0 && count > 0) {
                resolvedOwnerIndex = index
                snapshot.owner.currentIndex = index
                target = win._realizeKeyboardCollectionTarget(snapshot.owner, index)
                targetRealizationRequested = true
            }
        } else if (snapshot.item
                   && win._stableKeyboardIdentity(snapshot.item) === snapshot.identity) {
            target = snapshot.item
        }
        if (!win._bookReturnTargetUsable(target)
                && (!snapshot.owner || resolvedOwnerIndex < 0))
            return false
        for (var i = 0; i < snapshot.scrolls.length; ++i) {
            var saved = snapshot.scrolls[i]
            var flick = saved.flick
            if (!flick || flick.visible === false || flick.enabled === false)
                continue
            if (flick.contentX !== undefined) {
                var minX = flick.originX - flick.leftMargin
                var maxX = Math.max(minX, flick.originX + flick.contentWidth
                        - flick.width + flick.rightMargin)
                flick.contentX = Math.max(minX, Math.min(maxX, saved.x))
            }
            if (flick.contentY !== undefined) {
                var minY = flick.originY - flick.topMargin
                var maxY = Math.max(minY, flick.originY + flick.contentHeight
                        - flick.height + flick.bottomMargin)
                flick.contentY = Math.max(minY, Math.min(maxY, saved.y))
            }
        }
        if (snapshot.owner && resolvedOwnerIndex >= 0) {
            // Restore a valid historical owner offset first. A minimal owner reveal is only
            // needed when the resolved identity is clipped after reorder/removal/shrink.
            target = win._keyboardCollectionTarget(snapshot.owner, resolvedOwnerIndex)
            if (!target && !targetRealizationRequested)
                target = win._realizeKeyboardCollectionTarget(snapshot.owner, resolvedOwnerIndex)
            if (!win._bookReturnTargetVisible(target)) {
                if (target || !targetRealizationRequested) {
                    if (snapshot.owner.keyboardRevealIndex)
                        snapshot.owner.keyboardRevealIndex(resolvedOwnerIndex)
                    else if (snapshot.owner.positionViewAtIndex)
                        snapshot.owner.positionViewAtIndex(resolvedOwnerIndex, GridView.Contain)
                }
                target = win._keyboardCollectionTarget(snapshot.owner, resolvedOwnerIndex)
                if (!target && !targetRealizationRequested)
                    target = win._realizeKeyboardCollectionTarget(snapshot.owner, resolvedOwnerIndex)
            }
        }
        if (!win._bookReturnTargetVisible(target)) {
            if (!deferred && snapshot.owner && resolvedOwnerIndex >= 0) {
                snapshot.owner.forceActiveFocus(Qt.PopupFocusReason)
                win._scheduleBookReturnLanding(snapshot, generation, snapshot.owner,
                                               resolvedOwnerIndex, resolvedOwnerRevision)
                return true
            }
            return false
        }
        if (target.forceActiveFocus)
            target.forceActiveFocus(Qt.PopupFocusReason)
        return target.activeFocus === true || (snapshot.owner && snapshot.owner.activeFocus === true)
    }

    function openBook(b) { win.cancelCatalogueRoute();
        win.pendingBookReturn = null
        if (!bookLayer.active)
            win.bookReturnSnapshot = win._captureBookReturn()
        win.bookRouteGeneration += 1
        bookLayer.book = b
        bookLayer.active = true
    }
    function closeBook() {
        var generation = ++win.bookRouteGeneration
        win.pendingBookReturn = null
        bookLayer.active = false
        if (win.restoreNamedCollectionsReturn()) { win.bookReturnSnapshot = null; return }
        var snapshot = win.bookReturnSnapshot
        win.bookReturnSnapshot = null
        if (snapshot)
            Qt.callLater(function() {
                if (generation === win.bookRouteGeneration)
                    win._restoreBookReturn(snapshot, generation)
            })
    }

    // ---- the reader: the FRESH reader (reader2 — native QML chrome over the vendored Anx
    //      foliate paper) over everything (download-fed, never a stream). bookMeta stays on
    //      the layer for the session/Continue records; the shell itself needs only the path
    //      (it derives identity + resumes through Reader2Bridge/BookStores). ----
    function openBookReader(path, book) {
        if (!path) return
        setGuiStallContext("open", "Reader")
        bookReaderLayer.bookPath = path
        bookReaderLayer.bookMeta = book || ({})
        if (bookReaderLayer.active && bookReaderLayer.item) {
            bookReaderLayer.item.bookMeta = bookReaderLayer.bookMeta   // fresh catalog identity per book
            bookReaderLayer.item.openBook(path)
        } else bookReaderLayer.active = true
    }
    function closeBookReader() {
        bookReaderLayer.active = false
        setGuiStallContext("navigate", currentSurface || "Home")
    }

    // ---- search: a layer over the world. Biblio has its own rich surface; Tankoban + Theatre use the
    //      generic SearchSurface fed by their own source (AniList / Cinemeta). ----
    function openSearch() {
        if (win.guardNamedCollectionsNavigation(function() { win.openSearch() })) return
 win.cancelCatalogueRoute();
        win.bookRouteGeneration += 1
        setGuiStallContext("open", "Search")
        var w = worldStack.current
        if (w === "Vinyl" && win.vinylWorld) { win.vinylWorld.enterDiscoverSearch(true, false); return }
        if (w === "Biblio") { searchLayer.active = true; return }
        if (w === "Tankoban") {
            worldSearchLayer.searchMode = "Tankoban"
            worldSearchLayer.placeholder = "Search manga…"
            worldSearchLayer.active = true
        } else if (w === "Theatre") {
            worldSearchLayer.searchMode = "Theatre"
            worldSearchLayer.placeholder = "Search movies & series…"
            worldSearchLayer.active = true
        }
    }
    function closeSearch() {
        searchLayer.active = false
        setGuiStallContext("navigate", currentSurface || "Home")
    }
    function closeWorldSearch() {
        if (win.vinylWorld && win.vinylWorld.searchOpen) win.vinylWorld.closeSearch()
        worldSearchLayer.active = false
        setGuiStallContext("navigate", currentSurface || "Home")
    }
    function routeWorldSearchItem(data) {
        if (data && data.notice) return   // a cooldown/status notice row isn't clickable content
        win.closeWorldSearch()
        if (worldSearchLayer.searchMode === "Tankoban") {
            if (data && data.locg) win.openComicSeries(data)        // LOCG catalogue series → resolve+attach
            else if (data && data.gcd) win.openGcdSeries(data)      // catalogue run page
            else if (data && data.western) win.openWestern(data)   // GetComics shelf, not WeebCentral
            else win.openSeries(data.title)
        } else if (worldSearchLayer.searchMode === "Theatre") win.openTheatreSeries(data)
    }

    function openWallpaperSearch(world) {
        wallpaperLayer.targetWorld = world || currentSurface || "Home"
        wallpaperLayer.active = true
    }
    function closeWallpaperSearch() { wallpaperLayer.active = false }

    // ---- Continue: the center control resumes; the rest of the thumbnail
    //      opens the series/detail page, consistently across media. ----
    function resumeContinue(entry) {
        if (!entry) return
        if (entry.kind === "music") { win.openVinylResume(entry, true); return }
        var r = entry.resume || ({})
        // Continue never guesses a replacement chapter or drops saved progress.
        // A vanished download leads to the series/download surface, not an empty reader.
        var isLocalArchive = /^(vault:|vault-file:)/.test(String(entry.id || ""))
        if (entry.kind === "tankoban" || (entry.kind === "manga" && !isLocalArchive)) {
            var savedId = String(r.chapterId || "").trim()
            if (!savedId.length) { win.detailContinue(entry); return }
            if (entry.kind === "manga" && typeof Downloads !== "undefined" && Downloads.statusOf) {
                var chapterState = Downloads.statusOf(savedId) || ({})
                if (String(chapterState.state || "") !== "done") { win.detailContinue(entry); return }
            }
            if (entry.kind === "tankoban" && typeof TankobanVolumes !== "undefined" && TankobanVolumes.statusOf) {
                var volumeState = TankobanVolumes.statusOf(savedId) || ({})
                if (String(volumeState.state || "") !== "ready") { win.detailContinue(entry); return }
            }
        }
        var presentation = VideoPresentation.forEntry(entry,
            typeof ImdbCatalog !== "undefined" ? ImdbCatalog : null)
        var title = entry.title || entry.caption || presentation.title || ""
        var cover = entry.cover || presentation.cover || ""
        if (entry.kind === "video") {
            // A pre-teardown hosted-player (VidKing) watch: the hosted surface is gone
            // (House HTTP slice 4), so route to the Theatre detail — the user picks a real
            // source there instead of resuming into a player that no longer exists.
            if (r.hostedPlayerId) {
                win.openTheatreSeries({ "id": (r.imdbId || String(entry.id || "").split(":")[0]),
                                        "type": r.subType === "series" ? "series" : "movie",
                                        "title": title, "cover": cover })
                return
            }
            // downloaded file first: resume the LOCAL copy at position, never a stream fetch
            if (r.localPath && String(r.localPath).length)
                win.openLocalVideoSession({ "path": r.localPath, "id": entry.id || "",
                                            "title": title, "art": cover,
                                            "kind": r.subType === "series" ? "episode" : "movie",
                                            "position": r.position || 0 })
            else if (r.infoHash) win.openMovieSession(r.infoHash, r.fileIdx || 0, title, cover, r.subType || "", r.subId || "", [], {}, r.position || 0)
            else if (presentation.type) win.openTheatreSeries({ id: String(entry.id).split(":")[0],
                                                                type: presentation.type, title: title, cover: cover })
        } else if (entry.kind === "tankoban") {
            // a saved VOLUME read: same manga series, Tankoban Mode ON, the saved
            // volume id rides in resume.chapterId (curChapterId of the volume reader).
            win.openComicSession(title, entry.id || "", r.chapterId || "", "tankoban")
        } else if (entry.kind === "manga" || entry.kind === "comic") {
            // Loose Vault comics save the archive as chapterId; they have no series page.
            if (/^(vault:|vault-file:)/.test(String(entry.id || "")))
                win.openVaultComic(r.path || r.chapterId || "", entry.id, title)
            else win.openComicSession(title, entry.id || "", r.chapterId || "")
        } else if (entry.kind === "book") {
            if (r.path) win.openBookSession(r.path, r.book ? r.book : entry)
            else win.openBook(r.book ? r.book : entry)
        }
    }
    //  detail (click anywhere else on the card): the series / movie / book page.
    // The no-hang floor for detailContinue's movie/series race: if neither typed meta ask
    // has answered (deep-tail title, offline, or a stalled transport leg), open as a movie
    // — a sparse detail page beats a click that does nothing.
    Timer {
        id: continueKindFloor
        interval: 4000
        repeat: false
        property var settle: null
        onTriggered: if (settle) settle()
    }

    function detailContinue(entry) {
        if (!entry) return
        // Loose files have no catalogue detail owner. Keep their exact local reader
        // route, just as raw local video falls back to resume below. Do not infer
        // local ownership from a downloaded path on a catalogue-associated title.
        if (/^(vault:|vault-file:)/.test(String(entry.id || ""))
                && (entry.kind === "comic" || entry.kind === "manga"
                    || (entry.kind === "book" && entry.resume && entry.resume.path))) {
            win.resumeContinue(entry)
            return
        }
        if (entry.kind === "music") { win.openVinylResume(entry, false); return }
        var presentation = VideoPresentation.forEntry(entry,
            typeof ImdbCatalog !== "undefined" ? ImdbCatalog : null)
        var title = entry.title || entry.caption || presentation.title || ""
        var cover = entry.cover || presentation.cover || ""
        if (entry.kind === "video") {
            var id = (entry.id || "").split(":")[0]                      // base tt id (strip episode suffix)
            if (id.indexOf("tt") !== 0) {
                // Non-Cinemeta id: anime comes from Jikan (id "mal:<malId>") and resolves through
                // the Kitsu addon. Its episode id is PREFIX:NUM(:season:episode); the series id is
                // PREFIX:NUM. Open the SAME series view shows/movies use (TheatreSeries), not the
                // universe landing page.
                var p = String(entry.id || "").split(":")
                if (p.length >= 2 && /^(mal|kitsu|anilist|anidb)$/.test(p[0])) {
                    win.openTheatreSeries({ id: p[0] + ":" + p[1],
                                            type: entry.type === "movie" ? "movie" : "series",
                                            title: title, cover: cover })
                    return
                }
                win.resumeContinue(entry); return   // raw torrent, no detail page
            }
            if (presentation.type) {
                win.openTheatreSeries({ id: id, type: presentation.type, title: title, cover: cover })
                return
            }
            // Resolve movie vs series live from Cinemeta, then open the Theatre detail —
            // no stored type needed, so existing entries work too.
            // Cinemeta answers a wrong-type meta ask with a 307 into the unpinned live host —
            // a leg the pinned transport cannot follow (it stalls, and QML XHR ignores
            // .timeout) — so a lone series-probe hung forever on every movie tile
            // (diagnosed 2026-08-08). Race both typed asks instead: the matching type's
            // direct 200 settles in well under a second, and the 4s floor below opens the
            // tile as a movie rather than letting the click die silently.
            var settled = false
            var settle = function(type, meta) {
                if (settled) return
                settled = true
                continueKindFloor.stop()
                win.openTheatreSeries({ id: id, type: type, title: title, cover: cover })
            }
            TheatreApi.loadMeta("movie", id, function(meta) { if (meta) settle("movie", meta) })
            TheatreApi.loadMeta("series", id, function(meta) { if (meta) settle("series", meta) })
            continueKindFloor.settle = function() { settle("movie", null) }
            continueKindFloor.restart()
        } else if (entry.kind === "tankoban") {
            // detail = the manga series page; Tankoban Mode restores itself from the
            // service's per-series flag once the id resolves.
            win.openSeries(title, canonicalMalId(entry.id))
        } else if (entry.kind === "manga" || entry.kind === "comic") {
            if (win.reopenPinnedUniverseComic(entry.id, title, entry.cover || "")) return
            if (String(entry.id || "").indexOf("gc:") === 0)
                win.openWestern({ title: title, tag: String(entry.id).slice(3) })
            else if (String(entry.id || "").indexOf("gcd:") === 0)
                win.openGcdSeries({ gcdId: Number(String(entry.id).slice(4)), title: title,
                                    cover: entry.cover || "" })
            else if (entry.kind === "comic")
                // retired-source or unknown comic id — honest no-op (preset-pages source cut 2026-07-12);
                // comics open only via the gc: lane, so a stale id never opens the manga page
                console.log("[route] ignoring unknown comic id:", entry.id)
            else win.openSeries(title, canonicalMalId(entry.id))                                   // manga → the chapter-list series page
        } else if (entry.kind === "book") {
            win.openBook(entry.resume && entry.resume.book ? entry.resume.book : entry)
        }
    }

    // A Collection tile always opens the DETAIL surface (saved is a bookmark, not a
    // promise it's downloaded/started). Routes by world + saved snapshot; the gc:/gcd:/
    // locg: prefixes pick the comics lane; manga keeps its canonical MAL identity.
    function openCollectionEntry(e) {
        if (!e || !e.world) return
        var id = String(e.id || "")
        if (e.world === "theatre") {
            win.openTheatreSeries({ "id": id, "type": e.type || "series", "title": e.title || "",
                                    "cover": e.cover || "", "art": (e.payload && e.payload.art) || "" })
        } else if (e.world === "biblio") {
            win.openBook((e.payload && e.payload.book) || e)
        } else if (e.world === "tankoban") {
            if (win.reopenPinnedUniverseComic(id, e.title || "", e.cover || "")) return
            if (e.type === "manga") { win.openSeries(e.title || id, canonicalMalId(id)); return }
            if (id.indexOf("locg:") === 0) {
                win.openComicSeries({ "id": id, "title": e.title || "", "cover": e.cover || "",
                                      "locgMeta": (e.payload && e.payload.locgMeta) || null })
            } else if (id.indexOf("gcd:") === 0) {
                win.openGcdSeries({ "gcdId": parseInt(id.substring(4)), "title": e.title || "", "cover": e.cover || "" })
            } else {
                win.openWestern({ "title": e.title || "", "tag": (e.payload && e.payload.tag) || "",
                                  "tagId": (e.payload && e.payload.tagId) || 0, "cover": e.cover || "" })
            }
        }
    }

    // ===== OS-shell session engine (Approach 2: only the active surface is instantiated) =====
    // The UI opens content by registering a SESSION; Sessions.activeChanged then drives the
    // capture -> teardown -> build -> restore switch. contentKind picks the surface.

    // UI entry points (replace direct open* calls from cards / world pages):
    function openMovieSession(infoHash, fileIdx, title, backdrop, subType, subId, streamCandidates, playbackContext, position) {
        setGuiStallContext("open", "Player")
        // Library membership (spec §4.4): the moment playback starts, it joins the shelf.
        // The show root is EpisodeBrowser.seriesRootId (tt123:1:2 → tt123 ; kitsu:9:3:4 → kitsu:9);
        // a movie's subId IS its id. Downloads keep auto-adding; one shelf, no saved-vs-watched split.
        var joinId = (subType === "series" && subId) ? EpisodeBrowser.seriesRootId(subId) : subId
        if (joinId && typeof Collection !== "undefined" && !Collection.has("theatre", String(joinId)))
            Collection.add("theatre", { "id": String(joinId),
                "type": (subType === "series") ? "series" : "movie",
                "title": title || "", "cover": backdrop || "", "payload": ({}) })
        Sessions.openOrSwitch({
            "appType": "theatre", "contentKind": "movie", "title": title || "Movie",
            "target": { "showKey": EpisodeBrowser.seriesRootId(subId || ""),
                        "infoHash": infoHash, "fileIdx": fileIdx || 0, "title": title || "",
                        "backdrop": backdrop || "", "subType": subType || "", "subId": subId || "",
                        "streamCandidates": streamCandidates || [], "playbackContext": playbackContext || ({}),
                        "position": position || 0 }
        })
    }
    // A downloaded video's session: dedup key = target.id (the stream id, e.g. "tt123:1:2"),
    // so re-opening the same episode reuses its tile. `position` rides along for first-open
    // resume; a fresher captured position (minimize) wins via restoreState.
    function openLocalVideoSession(v) {
        setGuiStallContext("open", "Player")
        Sessions.openOrSwitch({
            "appType": "theatre", "contentKind": "movie", "title": v.title || "Video",
            "target": { "showKey": EpisodeBrowser.seriesRootId(v.id || ""),
                        "localPath": v.path, "id": v.id || "", "title": v.title || "",
                        "art": v.art || "", "kind": v.kind || "", "position": v.position || 0 }
        })
    }
    // entryKind "tankoban" marks a VOLUME read (the same manga series, Tankoban Mode
    // ON); anything else is a chapter read. It rides the target so restore/resume
    // rebuilds the right surface.
    function openComicSession(title, seriesId, chapterId, entryKind) {
        Sessions.openOrSwitch({
            "appType": "tankoban", "contentKind": "comic", "title": title || "Comic",
            "target": { "title": title || "", "seriesId": seriesId || "", "chapterId": chapterId || "",
                        "entryKind": entryKind || "" }
        })
    }
    function openBookSession(path, book) {
        if (!path) return
        setGuiStallContext("open", "Reader")
        var b = book || ({})
        Sessions.openOrSwitch({
            "appType": "biblio", "contentKind": "book", "title": b.title || "Book",
            "target": { "path": path, "book": b, "id": path }
        })
    }

    // ── Vault launch pillar (execution plan Slice 8): hand the app a local file ──
    // The picker / an OS drag-drop / Ctrl+O all funnel here. LocalLaunch (C++) routes the
    // FIRST file and decides if it can open at all; QML paints the door — the right reader/
    // player as a normal taskbar session, or a categorized "can't open" with NO tile.
    function dispatchLocalRoute(r) {
        if (!r) return
        if (r.prompt && typeof LocalLaunch !== "undefined") {
            win.pendingIdentityRoute = r
            identityCeremonyDialog.ceremony = r
            identityCeremonyDialog.open()
            return
        }
        localLaunchState.lastRouteKind = r.family || "unknown"
        localLaunchState.lastRejectCategory = r.accepted ? "" : (r.reject || "unsupported")
        if (!r.accepted) { win.showLocalRejection(r); return }
        localLaunchState.openCount = localLaunchState.openCount + 1
        if (r.family === "comic")      win.openVaultComic(r.path, r.vaultId, r.title)
        else if (r.family === "book")  win.openBookSession(r.path, { "id": r.vaultId, "title": r.title })
        else if (r.family === "video") win.openLocalVideoSession(win.videoTargetFor(r.path, r.vaultId, r.title))
    }
    readonly property bool localMediaAvailable: typeof LocalLaunch !== "undefined" && LocalLaunch !== null
    function openLocalMedia(paths) {
        if (!paths || !paths.length) return
        if (!win.localMediaAvailable) return
        LocalLaunch.openAsync(paths)
    }
    function openNextToOpen(index) {
        if (typeof LocalLaunch === "undefined") return
        LocalLaunch.openNextToOpenAsync(index)
    }
    function removeNextToOpen(index) {
        if (typeof LocalLaunch !== "undefined") LocalLaunch.removeNextToOpen(index)
    }
    function decidePendingIdentity(choice) {
        var pending = win.pendingIdentityRoute
        if (pending && pending.vinylImport) {
            win.pendingIdentityRoute = null
            identityCeremonyDialog.close()
            if (win.vinylWorld) win.vinylWorld.session.decideImportIdentity(pending.relationship || "", choice)
            return
        }
        if (!pending || typeof LocalLaunch === "undefined") return
        if (!LocalLaunch.decideIdentityCeremony(pending.relationship || "", choice)) return
        win.pendingIdentityRoute = null
        identityCeremonyDialog.close()
        LocalLaunch.routeInfoAsync(pending.path || "")
    }
    // Build the player target for a local video, resuming at the saved spot. A finished movie
    // (>=90%) is dropped from Progress, so its lookup is empty → position 0 → restart from the
    // top; an unfinished one carries its resume position (Slice 9 reopen semantics).
    function videoTargetFor(path, vaultId, title) {
        var pos = 0
        if (typeof Progress !== "undefined") {
            var pg = Progress.get("video", vaultId || "")
            if (pg && pg.resume && pg.resume.position !== undefined)
                pos = Number(pg.resume.position) || 0
        }
        return { "path": path, "id": vaultId, "title": title, "kind": "video", "position": pos }
    }
    // One-click reopen from the recent list. A dead file offers nothing. If the file is already
    // open, focus its tile (no duplicate, no re-count); otherwise route it fresh — comics/books
    // resume via their reader, video resumes-or-restarts via videoTargetFor above.
    function reopenRecent(entry) {
        if (!entry || !entry.available) return
        var existing = win.findVaultSession(entry.vaultId)
        if (existing.length) { Sessions.switchTo(existing); return }
        win.openLocalMedia([entry.path])
    }
    function findVaultSession(vaultId) {
        if (!vaultId) return ""
        var list = Sessions.list()
        for (var i = 0; i < list.length; i++) {
            var t = list[i].target || ({})
            if (String(t.id || "") === vaultId) return list[i].id
        }
        return ""
    }
    // A loose local comic has no series page — open it in the standalone Vault reader host
    // (vaultComicLayer) as a taskbar comic session keyed to its content id.
    function openVaultComic(path, vaultId, title) {
        if (win.androidHost || !path) return
        Sessions.openOrSwitch({
            "appType": "tankoban", "contentKind": "comic", "title": title || "Comic",
            "target": { "vaultPath": path, "id": vaultId || ("vault-file:" + path), "title": title || "" }
        })
    }
    function showLocalRejection(r) {
        var msg = "Can't open this file."
        var c = r ? r.reject : ""
        if (c === "corrupt") msg = "This comic looks damaged — there's nothing to read."
        else if (c === "no-decoder") msg = "This video can't be played."
        else if (c === "not-found") msg = "That file no longer exists."
        else msg = "That file type isn't supported."
        localLaunchToast.flash(msg, false)
    }
    function showFolderDropExplain() {
        // The folder → Vault shelf gesture is Slice 10; until then, explain + offer the picker.
        localLaunchToast.flash("Folders open in the Vault (coming soon). For now, pick media files:", true)
    }
    // (openAudiobookSession retired 2026-07-18 — the standalone audiobook player is gone;
    // the READER is the one audiobook surface. AudiobookSession, the engine, lives on below.)

    // ---- window-verbs for the reader/player chrome (Windows-taskbar vocabulary, 2026-07-04) ----
    // minimize = capture the exact spot, drop the surface, KEEP the session in the taskbar,
    // land on the world behind. close = the session is gone. Back keeps its old meaning.
    function closeSession(id) {
        if (!id) return
        var rec = Sessions.get(id)
        // Browser close must await the exact page's unload veto/terminal result.
        // The changed/active signals tear down its presentation after acceptance.
        if (rec && rec.contentKind === "browser") {
            feriaSessionDeck.closeTab(id)
            return
        }
        // the store removes the record BEFORE the switch glue can look it up, so the live
        // surface must come down here when closing the active one (else it lingers on screen).
        if (id === Sessions.activeId) win.teardownSession(rec)
        // a real close ends the stream for good — minimize keeps the movie warm, close does not.
        if (rec && rec.contentKind === "movie" && win.warmPlayerSessionId === id) {
            if (playerLayer.item) playerLayer.item.stop()
            win.warmPlayerSessionId = ""
        }
        Sessions.close(id)
    }
    function minimizePlayer() {
        var rec = Sessions.get(Sessions.activeId)
        if (rec && rec.contentKind === "movie") Sessions.switchTo("")
        else win.closePlayer()                       // not session-run (legacy path): just drop it
    }
    function closePlayerSession() {
        var rec = Sessions.get(Sessions.activeId)
        if (rec && rec.contentKind === "movie") win.closeSession(rec.id)
        else win.closePlayer()
    }
    function minimizeComicReader() {
        var rec = Sessions.get(Sessions.activeId)
        if (!(rec && rec.contentKind === "comic")) {
            // reading began from a browse (no session yet) — register it from the live reader.
            // Check every comic lane (LOCG-catalogue / western / manga) — the reader chrome is shared.
            var x = comicSeriesLayer.active ? comicSeriesLayer.item : null
            var w = westernLayer.active ? westernLayer.item : null
            if (x && x.openChapterId) {
                win.openComicSession(x.seriesTitle, "gc:" + x.gcTag, x.openChapterId)   // LOCG page reads GetComics content
            } else if (w && w.openChapterId) {
                win.openComicSession(w.seriesTitle, w.seriesId, w.openChapterId)   // seriesId = "gc:<slug>" (live) or "gcd:<id>" (baked catalogue run)
            } else {
                var s = seriesLayer.item
                if (!s || !s.openChapterId) { win.closeSeries(); return }
                win.openComicSession(s.seriesTitle, s.seriesId, s.openChapterId, s.openEntryKind)
            }
        }
        Sessions.switchTo("")
    }
    function closeComicReader() {
        var rec = Sessions.get(Sessions.activeId)
        if (rec && rec.contentKind === "comic") win.closeSession(rec.id)
        else if (comicSeriesLayer.active && comicSeriesLayer.item && comicSeriesLayer.item.openChapterId.length) win.closeComicSeries()
        else if (westernLayer.active && westernLayer.item && westernLayer.item.openChapterId.length) win.closeWestern()
        else win.closeSeries()
    }
    function backFromMangaReader() {
        var page = seriesLayer.item
        if (!page || !page.openChapterId) { win.closeComicReader(); return }
        var title = page.seriesTitle
        var legacy = seriesLayer.legacyWeebCentral
        var profile = {
            malId: seriesLayer.malId,
            seriesId: seriesLayer.seriesIdOverride,
            sourceSearchTitle: seriesLayer.sourceSearchTitle,
            sourceSearchAliases: seriesLayer.sourceSearchAliases,
            sourceRequiredMarkers: seriesLayer.sourceRequiredMarkers
        }
        win.closeComicReader()
        if (legacy) win.openWeebCentralSeries(title)
        else win.openSeries(title, profile.malId, profile)
    }
    // Vault comic (standalone reader host) session verbs — mirror the comic reader verbs,
    // but the live surface is vaultComicLayer, not a series page.
    function minimizeVaultComic() { Sessions.switchTo("") }
    function closeVaultComic() {
        var rec = Sessions.get(Sessions.activeId)
        if (rec && rec.contentKind === "comic") win.closeSession(rec.id)
        else vaultComicLayer.active = false
    }
    // Book minimize is BACK (2026-07-18, Hemanth — the swap had dropped the affordance):
    // the fresh reader's chrome carries a minimize icon → minimized() lands here. Every
    // live open path registers a session first (openBookSession), so this is normally just
    // a park; the register-if-missing arm mirrors minimizeComicReader's defensive shape.
    function minimizeBookReader() {
        var rec = Sessions.get(Sessions.activeId)
        if (!(rec && rec.contentKind === "book")) {
            if (!bookReaderLayer.active || !bookReaderLayer.bookPath.length) { win.closeBookReader(); return }
            win.openBookSession(bookReaderLayer.bookPath, bookReaderLayer.bookMeta)
        }
        Sessions.switchTo("")
    }
    function closeBookReaderSession() {
        var rec = Sessions.get(Sessions.activeId)
        if (rec && rec.contentKind === "book") win.closeSession(rec.id)
        else win.closeBookReader()
    }
    // (minimizeAudiobook / closeAudiobookSession retired with the standalone player, 2026-07-18.)

    // dispatcher: build the active surface from a record (+ restore its saved state).
    // Player-specific half of session activation. This only runs with a READY Loader item.
    // First-open callers queue the session id and onLoaded re-enters here on a later event turn.
    function activateMovieSession(rec) {
        if (!rec || !rec.id || !playerLayer.item)
            return
        win.claimAudio("theatre")
        var t = rec.target || ({})
        var st = rec.savedState || ({})
        if (win.warmPlayerSessionId === rec.id) {
            playerLayer.item.resumeFromMinimize()
        } else {
            win.requestTheatreAudio()
            if (t.localPath && String(t.localPath).length)
                playerLayer.item.playLocalFile(t)
            else if (t.streamUrl && String(t.streamUrl).length) {
                var landed = win.downloadedVideoPath(t.id || "")
                if (landed.length) {
                    t.localPath = landed
                    playerLayer.item.playLocalFile(t)
                } else if (t.partPath && String(t.partPath).length) {
                    t.localPath = t.partPath
                    t.arrivingUrl = t.streamUrl
                    playerLayer.item.playLocalFile(t)
                } else {
                    playerLayer.item.playRemoteUrl(t)
                }
            } else {
                playerLayer.item.playTorrent(t.infoHash, t.fileIdx || 0, t.title, t.backdrop,
                                             t.subType, t.subId, t.streamCandidates || [],
                                             t.playbackContext || ({}))
            }
            var resumeSt = (st && Number(st.position) > 0) ? st
                         : { "position": Number(t.position) || 0 }
            if (playerLayer.item.restoreState)
                playerLayer.item.restoreState(resumeSt)
        }
        win.warmPlayerSessionId = rec.id
    }

    function activateSession(rec) {
        if (!rec || !rec.id) return
        if (rec.contentKind === "music") {
            if (!win.vinylEnabled || !win.vinylProfileActive) return
            win.openWorld("Vinyl")
            // The kept-alive Vinyl owner alone restores queue/position; taskbar is presentation.
            return
        }
        if (rec.contentKind === "browser") {
            if (!win.ensureFeriaRuntime()) return
            if (!win.activeBrowserSessionId.length) win.browserReturnToFeria = feriaLayer.open
            win.activeBrowserSessionId = rec.id
            feriaLayer.open = true
            win.currentSurface = "Feria"
            win.refreshWallpaper()
            if (feriaLayer.item) feriaLayer.item.activateBrowserRecord(rec)
            return
        }
        win.activeBrowserSessionId = ""
        var t = rec.target || ({})
        var st = rec.savedState || ({})
        currentSurface = wallpaperWorldForSession(rec)
        refreshWallpaper()
        if (rec.contentKind === "movie") {
            win.playerOpen = true
            if (!playerLayer.item) {
                win.queuePlayerSessionOpen(rec.id)
                return
            }
            win.activateMovieSession(rec)
        } else if (rec.contentKind === "comic") {
            if (t.vaultPath && String(t.vaultPath).length) {
                // a loose local comic (Vault): no series page — mount the standalone reader
                // host with the injected VaultPageStore (execution plan Slice 8).
                vaultComicLayer.archivePath = t.vaultPath
                vaultComicLayer.vaultId = t.id || ""
                vaultComicLayer.title = t.title || rec.title || "Comic"
                if (vaultComicLayer.active && vaultComicLayer.item) {
                    vaultComicLayer.item.vaultId = t.id || ""
                    vaultComicLayer.item.title = vaultComicLayer.title
                    vaultComicLayer.item.archivePath = t.vaultPath
                } else vaultComicLayer.active = true
                return
            }
            if (String(t.seriesId || "").indexOf("gc:") === 0) {
                // GetComics content (western shelf OR LOCG-catalogue page) restores via the
                // GetComics shelf — same tag, same reader, resumed at the chapter.
                win.openWesternAt(t.title, String(t.seriesId).slice(3), (st.chapterId || t.chapterId || ""))
                if (westernLayer.item && westernLayer.item.restoreState) westernLayer.item.restoreState(st)
                return
            }
            if (String(t.seriesId || "").indexOf("gcd:") === 0) {
                // catalogue run page (baked mode, spec 2026-07-17) restores via the same
                // western shelf, baked branch — same run, same reader, resumed at the chapter.
                win.openGcdSeries({ gcdId: Number(String(t.seriesId).slice(4)), title: t.title,
                                    resumeChapterId: (st.chapterId || t.chapterId || "") })
                if (westernLayer.item && westernLayer.item.restoreState) westernLayer.item.restoreState(st)
                return
            }
            var savedComicId = (st.chapterId || t.chapterId || "")
            if (t.entryKind === "tankoban") {
                // a VOLUME session: restore the series with Tankoban Mode ON, then open the
                // saved volume through the shared reader (never the chapter path).
                seriesLayer.resumeSeriesId = t.seriesId || ""
                seriesLayer.resumeChapterId = ""
                seriesLayer.resumeVolumeId = savedComicId
                restoreSeriesEditionProfile(t.seriesId)
                seriesLayer.title = t.title
                if (seriesLayer.active && seriesLayer.item) {
                    seriesLayer.item.seriesTitle = t.title
                    if (t.seriesId) seriesLayer.item.seriesId = t.seriesId
                    seriesLayer.item.resumeTankobanVolume(savedComicId)
                } else seriesLayer.active = true
                return
            }
            seriesLayer.resumeSeriesId = t.seriesId || ""
            seriesLayer.resumeChapterId = savedComicId
            seriesLayer.resumeVolumeId = ""
            restoreSeriesEditionProfile(t.seriesId)
            seriesLayer.title = t.title
            if (seriesLayer.active && seriesLayer.item) {
                seriesLayer.item.seriesTitle = t.title
                if (t.seriesId) seriesLayer.item.seriesId = t.seriesId
                seriesLayer.item.openEntryKind = "manga"   // a reused item may still be in a volume read
                seriesLayer.item.openChapterId = savedComicId
            } else seriesLayer.active = true
            if (seriesLayer.item && seriesLayer.item.restoreState) seriesLayer.item.restoreState(st)  // Task 4
        } else if (rec.contentKind === "book") {
            bookReaderLayer.bookPath = t.path
            bookReaderLayer.bookMeta = t.book || ({})
            // Fresh-reader contract (the old item.open(path, book) survived the swap here and
            // THREW when the layer was already live — Continue resume into an open reader died).
            if (bookReaderLayer.active && bookReaderLayer.item) {
                bookReaderLayer.item.bookMeta = bookReaderLayer.bookMeta
                bookReaderLayer.item.openBook(t.path)
                if (bookReaderLayer.bookMeta.openAudio) {
                    var audioPanelGeneration = win.vinylShellGeneration
                    var audioPanelSessionId = rec.id
                    Qt.callLater(function() {
                        if (win.vinylProfileActive && win.vinylShellGeneration === audioPanelGeneration
                                && Sessions.activeId === audioPanelSessionId && bookReaderLayer.item)
                            bookReaderLayer.item.openAudioPanel()
                    })
                }
            } else bookReaderLayer.active = true
            // book precision: the reader restores its own saved position on reopen (resume seam).
        }
        // ('audiobook' sessions retired with the standalone player, 2026-07-18 — a stale
        // taskbar record of that kind now activates to nothing and closes normally.)
    }
    // capture the live outgoing surface's state (called BEFORE teardown).
    function captureSession(rec) {
        if (!rec || !rec.id) return ({})
        if (rec.contentKind === "music") return { page: win.vinylWorld ? win.vinylWorld.page : "library" }
        if (rec.contentKind === "movie" && playerLayer.item && playerLayer.item.captureState) return playerLayer.item.captureState()
        if (rec.contentKind === "comic") {
            // one comic surface hosts the reader at a time — capture from whichever is live
            var lay = comicSeriesLayer.active ? comicSeriesLayer
                    : (westernLayer.active ? westernLayer : seriesLayer)
            return (lay.item && lay.item.captureState) ? lay.item.captureState() : ({})
        }
        if (rec.contentKind === "book"  && bookReaderLayer.item && bookReaderLayer.item.captureState) return bookReaderLayer.item.captureState()
        return ({})
    }
    // tear the outgoing surface down. Player: stop media but KEEP the mpv host (use-after-free guard).
    function teardownSession(rec) {
        if (!rec || !rec.id) return
        if (rec.contentKind === "music") {
            if (win.vinylWorld) win.vinylWorld.session.suspendPlayback("session-parked")
            return
        }
        if (rec.contentKind === "browser") {
            // activeId's property signal already selects the incoming entry.
            // Tear down presentation on the outgoing record, never its sibling.
            var outgoing = feriaSessionDeck.entries[rec.id]
            if (outgoing && outgoing.fullSizeHost) feriaSessionDeck.restoreSession(rec.id)
            if (outgoing && outgoing.browser && outgoing.browser.fullScreenActive)
                outgoing.browser.runJavaScript(
                    "if(document.fullscreenElement) document.exitFullscreen()")
            feriaLayer.open = false
            return
        }
        if (rec.contentKind === "movie") {
            // If first-open incubation has not dispatched playback yet, cancel that queued open;
            // there is no warm stream to resume. Once playback exists, preserve the old keep-alive.
            var wasPending = win.clearPendingPlayerSession(rec.id)
            if (playerLayer.item && !wasPending) {
                playerLayer.item.suspendForMinimize()
                win.warmPlayerSessionId = rec.id
            } else {
                win.warmPlayerSessionId = ""
            }
            win.playerOpen = false
        } else if (rec.contentKind === "comic") {
            // one comic surface hosts the reader at a time — drop whichever is live
            if (vaultComicLayer.active) vaultComicLayer.active = false
            else if (comicSeriesLayer.active) comicSeriesLayer.active = false
            else if (westernLayer.active) westernLayer.active = false
            else seriesLayer.active = false
        } else if (rec.contentKind === "book")  {
            bookReaderLayer.active = false
        }
    }

    // ---- design tokens (the skin: glass is the constant; gold is sparing) ----
    Theme { id: theme }

    // ---- bundled editorial serif (the theme's target display face: theme.display = "Fraunces") ----
    FontLoader { source: "../assets/fonts/Fraunces-Regular.ttf" }
    FontLoader { source: "../assets/fonts/Fraunces-Italic.ttf" }

    // ---- player HUD face: Switzer (Harbor-parity), bundled weights (theme.hud) ----
    FontLoader { source: win.auxiliaryFontsReady ? "../assets/fonts/Switzer-Regular.otf" : "" }
    FontLoader { source: win.auxiliaryFontsReady ? "../assets/fonts/Switzer-Medium.otf" : "" }
    FontLoader { source: win.auxiliaryFontsReady ? "../assets/fonts/Switzer-Semibold.otf" : "" }
    FontLoader { source: win.auxiliaryFontsReady ? "../assets/fonts/Switzer-Bold.otf" : "" }

    // ---- HUD fallback face: Inter statics (theme.hud flip target). STATICS ON PURPOSE:
    // a variable TTF registers under its typographic name ("Inter Variable"), so asking
    // for "Inter" silently falls back to Tahoma on Windows (probe-proven 2026-07-08).
    // The statics register as plain "Inter" and weight-match across files. ----
    FontLoader { source: win.auxiliaryFontsReady ? "../assets/fonts/Inter-Regular.otf" : "" }
    FontLoader { source: win.auxiliaryFontsReady ? "../assets/fonts/Inter-Medium.otf" : "" }
    FontLoader { source: win.auxiliaryFontsReady ? "../assets/fonts/Inter-SemiBold.otf" : "" }
    FontLoader { source: win.auxiliaryFontsReady ? "../assets/fonts/Inter-Bold.otf" : "" }

    // ---- reading serif: Literata statics for the FRESH reader's chrome (Appearance panel
    // card + serif UI). STATICS for the same reason as Inter above — the variable TTF would
    // register as "Literata Variable" and silently Tahoma-fall. The BOOK text gets Literata
    // separately via @font-face injected into the paper page (paper_glue.js FONT_FACE_CSS). ----
    FontLoader { source: win.auxiliaryFontsReady ? "../assets/fonts/Literata-Regular.ttf" : "" }
    FontLoader { source: win.auxiliaryFontsReady ? "../assets/fonts/Literata-Italic.ttf" : "" }

    // =====================================================================
    // BACKDROP — the persistent wallpaper everything composites over.
    // =====================================================================
    Item {
        id: wall
        anchors.fill: parent
        // Not painted while the player is up. The player layer is opaque (PlayerPage draws a
        // full-bleed black Rectangle at z:-1) and does not fade, so nothing below it is ever
        // seen — yet Qt kept rendering all of it every frame, on a GPU the film needs. Costs
        // nothing visually; the object and its caches stay alive, so returning from the player
        // re-shows instantly with no re-fetch. (2026-07-29 render-load diet.)
        visible: !win.immersiveSurfaceOpen
            && !win.vinylVideoFullscreen
        // Real OS wallpaper — a placeholder PICK (Windows 11 "Captured Motion"; its translucent
        // glass-ribbon motif echoes our material, and it's dark enough for the glass to read).
        // Swap from the parked personalization gallery later. Glass composites over WHATEVER sits in
        // `wall`, so the Image "just works" — and it pops against the chrome instead of reading as an app.
        Image {
            anchors.fill: parent
            source: win.wallpaperIsNative ? "" : win.wallpaperSource
            visible: !win.wallpaperIsNative
            fillMode: Image.PreserveAspectCrop
            cache: true
        }
        // Native living wallpaper (the arena et al.): a QML scene in the Image's place.
        // Motion doctrine: it FREEZES whenever a reader/player owns the screen or the
        // window is minimized — ambient motion only while the shell is being looked at.
        Loader {
            anchors.fill: parent
            active: win.wallpaperIsNative && win.nativeWallpaperFile(win.wallpaperSource).length > 0
            source: active ? win.nativeWallpaperFile(win.wallpaperSource) : ""
            onLoaded: item.running = Qt.binding(function() {
                return !win.immersiveSurfaceOpen && win.visibility !== Window.Minimized
            })
        }
        // Global vignette so chrome + text read against the wallpaper, bright or dark.
        // The middle stop carries the world tab strips and catalogue headings; at 0.10 they
        // washed out on light wallpapers (parchment maps), so it holds 0.28 (2026-09-28).
        // Adaptive (2026-09-29, Hemanth's call over a curated roster or a per-text restyle):
        // wallpaper search is open-ended, so the vignette reads each pick's brightness and
        // deepens on bright ones — from luma 0.50 up to full at 0.85, every stop capped at 0.55
        // so a bright image still looks like itself. Dark picks keep the baseline untouched.
        WallpaperLuma {
            id: wallLuma
            objectName: "wallLuma"
            visible: false
            source: win.wallpaperIsNative ? "" : Qt.resolvedUrl(win.wallpaperSource)
        }
        Rectangle {
            id: wallVignette
            objectName: "wallVignette"
            property real extra: 0.27 * Math.max(0, Math.min(1, (wallLuma.luma - 0.50) / 0.35))
            Behavior on extra { NumberAnimation { duration: 400; easing.type: Easing.OutCubic } }
            anchors.fill: parent
            gradient: Gradient {
                GradientStop { position: 0.0; color: Qt.rgba(0,0,0, Math.min(0.55, 0.34 + wallVignette.extra)) }
                GradientStop { position: 0.5; color: Qt.rgba(0,0,0, Math.min(0.55, 0.28 + wallVignette.extra)) }
                GradientStop { position: 1.0; color: Qt.rgba(0,0,0, Math.min(0.55, 0.46 + wallVignette.extra)) }
            }
        }
    }

    // (RowHeader — the old hover-reveal row header — is gone: its one user was the home
    //  Continue row, which now wears the SAME WidgetHeader as the world rows, so the
    //  "See all ›" affordance reads identically on every Continue surface.)

    // (The unified Continue card now lives in ContinueTile.qml — one component worn two ways,
    //  shared with the world pages' ContinueRow. Spec: haven docs/superpowers/specs/
    //  2026-07-05-colosseum-continue-tiles-design.md.)

    // (PortraitTile · Pill · SysIcon · the top bar now live in shared sibling files:
    //  PortraitTile.qml and TopBar.qml — reused by the world-page template.)

    // =====================================================================
    // FOREGROUND
    // =====================================================================

    // ---- 1. TOP BAR (fixed, glass over wallpaper) — shared shell chrome.
    //      activeMedium "" → HOME: no pill selected (the no-selection rule). Tapping a pill
    //      enters that world. ----
    TopBar {
        onAccountClicked: (anchorRight, anchorBottom) => accountFlyout.toggleAt(anchorRight, anchorBottom)
        id: topbar
        z: 20
        visible: !win.immersiveSurfaceOpen && !feriaLayer.open && worldStack.current === ""
        backdrop: wall
        activeMedium: ""
        androidHost: win.androidHost
        x: win.headerOuterMargin; y: 18
        width: win.width - win.headerOuterMargin * 2
        onMediumSelected: (medium) => win.openWorld(medium)
        onWallpaperClicked: win.openWallpaperSearch("Home")
        onDlnaClicked: (anchorRight, anchorBottom) => dlnaSharePopup.toggleAt(anchorRight, anchorBottom)
        onFullscreenClicked: win.toggleFullscreenShell()
        onMinimizeClicked: win.minimizeShell()
        onPowerClicked: win.requestApplicationQuit()
        // Update glyph (home only, takes the retired search slot). Toggle mirrors
        // the taskbar launcher: open when closed, close when already front.
        updateAvailable: typeof Updates !== "undefined" ? Updates.updateAvailable : false
        updateUnseen: typeof Updates !== "undefined" ? Updates.unseenUpdate : false
        reducedMotion: win.reducedMotion
        onUpdateClicked: !updateLayer.active ? win.openUpdatePage() : win.closeUpdatePage()
        trackersEnabled: true
        trackersActive: syncCenterLayer.active
        onTrackersClicked: win.toggleSyncCenterPage()
        onBoundaryArrowRequested: (key, fromItem) => {
            if (key === Qt.Key_Down && page.visible)
                homePageSpatialNav.moveFrom(fromItem, key)
        }
    }

    KeyboardSpatialNavigator {
        id: homeTopSpatialNav
        root: topbar
    }

    // Chrome-free desktop interaction for developer-windowed mode. Reuses the existing TopBar
    // as the drag surface (no titlebar added) and self-disables in fullscreen. See WindowBehavior.qml.
    WindowBehavior {
        visible: !win.androidHost
        shell: win
        dragSurface: topbar
        controller: win.androidHost ? null : WindowMode
    }

    // Kept as a Component so Progress.recent() and the ContinueTile delegates are not evaluated
    // while Main.qml's Home object tree is being constructed. The Loader below owns the same
    // bindings and signals as the former inline rail once the shell is idle.
    Component {
        id: homeContinueRailComponent
        Column {
            id: contCol
            width: parent ? parent.width : 0
            spacing: 14
            // watched episodes sink below unfinished entries (both halves keep recency order)
            property var contItems: (Progress.revision, (function() {
                // 'audiobook' records persist ONLY as resume positions for the reader's
                // read-along (Hemanth 2026-07-18: audio progress rides the BOOK — the
                // book's own tile represents both). Never surface them as tiles.
                var a = Progress.recent("", 12).filter(function(e) { return e.kind !== "audiobook" })
                return a.filter(function(e) { return e.watched !== true })
                        .concat(a.filter(function(e) { return e.watched === true }))
            })())
            property bool hasResumeItems: contItems.length > 0
            property int currentIndex: contItems.length > 0 ? 0 : -1
            onContItemsChanged: currentIndex = contItems.length > 0
                                                ? Math.max(0, Math.min(currentIndex, contItems.length - 1)) : -1
            function ensureCurrentVisible() {
                var item = contRepeater.itemAt(currentIndex)
                if (!item) return
                var maxX = Math.max(0, contFlick.contentWidth - contFlick.width)
                if (item.x < contFlick.contentX)
                    contFlick.contentX = Math.max(0, item.x)
                else if (item.x + item.width > contFlick.contentX + contFlick.width)
                    contFlick.contentX = Math.min(maxX, item.x + item.width - contFlick.width)
            }
            function navigate(delta) {
                if (contItems.length === 0) return false
                var next = Math.max(0, Math.min(contItems.length - 1, currentIndex + delta))
                if (next === currentIndex) return false
                currentIndex = next
                ensureCurrentVisible()
                return true
            }
            visible: hasResumeItems
            // same header as the world Continue rows — "See all ›" visibly present, not hover-gated
            WidgetHeader {
                width: parent.width; title: "Continue"
                moreLabel: "See all"
                onMoreClicked: win.openContinueSeeAll("home")
            }
            Flickable {
                id: contFlick
                width: parent.width; height: 148
                contentWidth: contRow.width; contentHeight: height
                clip: true
                flickableDirection: Flickable.HorizontalFlick
                boundsBehavior: Flickable.StopAtBounds
                activeFocusOnTab: win.televisionMode && contCol.hasResumeItems
                Accessible.role: Accessible.List
                Accessible.name: "Continue"
                Keys.onPressed: (event) => {
                    if (!win.televisionMode) return
                    if (event.key === Qt.Key_Left) event.accepted = contCol.navigate(-1)
                    else if (event.key === Qt.Key_Right) event.accepted = contCol.navigate(1)
                    else if (event.key === Qt.Key_Return || event.key === Qt.Key_Enter
                             || event.key === Qt.Key_Select || event.key === Qt.Key_Space) {
                        if (contCol.currentIndex >= 0 && contCol.currentIndex < contCol.contItems.length) {
                            const tileItem = contRepeater.itemAt(contCol.currentIndex)
                            if (tileItem) tileItem.activateResumeControl()
                            else win.resumeContinue(contCol.contItems[contCol.currentIndex])
                        }
                        event.accepted = true
                    }
                }
                Row {
                    id: contRow
                    spacing: 18
                    Repeater {
                        id: contRepeater
                        model: contCol.contItems
                        delegate: ContinueTile {
                            required property var modelData
                            required property int index
                            variant: "home"
                            entry: modelData
                            backdrop: wall
                            track: page.contentY + contFlick.contentX
                            focusManagedByCollection: true
                            keyboardFocused: contFlick.activeFocus && index === contCol.currentIndex
                            onResumeRequested: win.resumeContinue(modelData)
                            onDetailRequested: win.detailContinue(modelData)
                            onRemoveRequested: Progress.forget(modelData.kind, modelData.id)
                        }
                    }
                }
            }
        }
    }

    // ---- pinned top bar is above; everything below SCROLLS (vertical wheel/drag) ----
    Flickable {
        id: page
        objectName: "homePageFlickable"
        z: 0
        visible: !win.immersiveSurfaceOpen && !feriaLayer.open && worldStack.current === "" && !collectionsPanel.showing
        anchors.left: parent.left; anchors.right: parent.right
        anchors.leftMargin: win.wideWorldNavigationLeftInset
        y: topbar.y + topbar.height + 10
        height: win.height - y
        contentWidth: width
        contentHeight: contentCol.implicitHeight + 40
        clip: true
        flickableDirection: Flickable.VerticalFlick
        boundsBehavior: Flickable.StopAtBounds
        ScrollBar.vertical: HouseScrollBar { flick: page }   // gold sliver, same as every page
        KeyboardSpatialNavigator {
            id: homePageSpatialNav
            root: page
            onBoundaryRequested: (key, fromItem) => {
                if (key === Qt.Key_Up && topbar.visible)
                    homeTopSpatialNav.moveFrom(fromItem, key)
            }
        }
        Keys.onReleased: function(event) { homePageSpatialNav.handleRelease(event) }
        // the HOME page never had the eased wheel — the one surface scrolled most was the
        // one raw Flickable left (Hemanth: rough on the hand, 2026-07-12)
        ScrollGlide { id: homeGlide; flick: page }

        function isInsidePage(item) {
            var p = item
            while (p) {
                if (p === page) return true
                p = p.parent
            }
            return false
        }
        function revealFocusedItem(item) {
            if (!item || !page.isInsidePage(item)) return
            var point = item.mapToItem(page, 0, 0)
            if (point.y < 18)
                page.contentY = Math.max(0, page.contentY + point.y - 18)
            else if (point.y + item.height > page.height - 18)
                page.contentY = Math.min(Math.max(0, page.contentHeight - page.height),
                                         page.contentY + point.y + item.height - page.height + 18)
        }
        function moveVerticalFocus(forward) {
            var from = win.activeFocusItem
            if (!from || !page.isInsidePage(from)) return false
            var target = from.nextItemInFocusChain(forward)
            var guard = 0
            while (target && target !== from && guard++ < 96) {
                if (target.visible && target.enabled && target.activeFocusOnTab) {
                    target.forceActiveFocus(forward ? Qt.TabFocusReason : Qt.BacktabFocusReason)
                    page.revealFocusedItem(target)
                    return true
                }
                target = target.nextItemInFocusChain(forward)
            }
            return false
        }
        Keys.priority: Keys.AfterItem
        Keys.onPressed: (event) => {
            if (win.televisionMode && event.key === Qt.Key_Up)
                event.accepted = page.moveVerticalFocus(false)
            else if (win.televisionMode && event.key === Qt.Key_Down)
                event.accepted = page.moveVerticalFocus(true)
            else
                homePageSpatialNav.handle(event)
        }

        Column {
            id: contentCol
            x: win.outerPageMargin
            width: page.width - win.outerPageMargin * 2
            topPadding: 10
            spacing: 32

            // ---- 2. UNIVERSE HERO — full-bleed banner + left scrim (the original treatment,
            //      restored by Hemanth's call 2026-07-12: "should have a full banner, just like
            //      how it was initially"). What STAYS ratified-out from the redesign round:
            //      NO dots, NO tabs, NO timer bar, NO media-count chips. A pure carousel —
            //      auto-turns (6.5s) + native swipe. Spec trail: haven docs/superpowers/specs/
            //      2026-07-12-colosseum-universe-exhibit-hero-design.md (+ this final rev).
            Glass {
                id: hero
                backdrop: wall
                track: page.contentY
                width: parent.width; height: 360; radius: 20
                tint: 0.06

                SwipeView {
                    id: heroView
                    anchors.fill: parent
                    clip: true
                    Repeater {
                        model: win.installedUniverses
                        delegate: Item {
                            id: slide
                            required property var modelData

                            // banner key-art full-bleed; a neutral plate stands in while it
                            // loads, then the left-weighted scrim keeps the words legible
                            // (proven look). The per-IP accent colour the baked list carried is
                            // gone with it — an installed universe supplies art, not a palette.
                            Rectangle {
                                anchors.fill: parent; radius: hero.radius; clip: true
                                color: "#1a1410"
                                Image {
                                    objectName: "homeUniverseBannerArt"
                                    anchors.fill: parent
                                    property string readySource: ""
                                    onStatusChanged: if (status === Image.Ready) readySource = String(source)
                                    source: page.visible || readySource === String(slide.modelData.banner || "") ? (slide.modelData.banner || "") : ""
                                    asynchronous: true; cache: true
                                    fillMode: Image.PreserveAspectCrop
                                    opacity: status === Image.Ready ? 1 : 0
                                    Behavior on opacity { NumberAnimation { duration: 300 } }
                                }
                                Rectangle {
                                    anchors.fill: parent
                                    gradient: Gradient {
                                        orientation: Gradient.Horizontal
                                        GradientStop { position: 0.0; color: Qt.rgba(0,0,0,0.86) }
                                        GradientStop { position: 0.52; color: Qt.rgba(0,0,0,0.42) }
                                        GradientStop { position: 1.0; color: Qt.rgba(0,0,0,0.06) }
                                    }
                                }
                            }

                            // content over the scrim (chips row retired — ratified 2026-07-12)
                            Column {
                                anchors.left: parent.left; anchors.bottom: parent.bottom
                                anchors.margins: 44
                                width: Math.min(620, parent.width - anchors.leftMargin * 2)
                                spacing: 12
                                Text { text: "TRIBUTE"; color: theme.gold; font.family: theme.ui; font.pixelSize: 11; font.letterSpacing: 3 }
                                Text { text: slide.modelData.name; color: theme.ink; font.family: theme.display; font.pixelSize: 48 }
                                // (the blurb line went with the baked list — the roster carries
                                // identity and art, no prose, and a faked one would be a lie)
                                Row {
                                    spacing: 12; topPadding: 6
                                    Rectangle {
                                        radius: 12; height: 46; width: exploreRow.implicitWidth + 44
                                        gradient: Gradient {
                                            GradientStop { position: 0; color: (exMa.containsMouse || exKey.interactionActive) ? Qt.rgba(1,1,1,0.23) : Qt.rgba(1,1,1,0.14) }
                                            GradientStop { position: 1; color: (exMa.containsMouse || exKey.interactionActive) ? Qt.rgba(1,1,1,0.10) : Qt.rgba(1,1,1,0.05) }
                                        }
                                        border.width: 1
                                        border.color: (exMa.containsMouse || exKey.interactionActive) ? Qt.rgba(0.94,0.77,0.29,0.85) : Qt.rgba(1,1,1,0.26)
                                        Behavior on border.color { ColorAnimation { duration: 160 } }
                                        Row {
                                            id: exploreRow; anchors.centerIn: parent; spacing: 10
                                            Text { text: "Explore the tribute"; color: theme.ink
                                                font.family: theme.ui; font.pixelSize: 14; font.weight: Font.DemiBold
                                                anchors.verticalCenter: parent.verticalCenter }
                                            Text { text: "→"; color: theme.gold; font.pixelSize: 16
                                                anchors.verticalCenter: parent.verticalCenter
                                                transform: Translate { x: (exMa.containsMouse || exKey.interactionActive) ? 3 : 0 } }
                                        }
                                        KeyboardAction {
                                            id: exKey
                                            // Only the current SwipeView delegate owns the stable semantic
                                            // identity. Inactive carousel clones otherwise make runtime focus
                                            // assertions ambiguous even though only one is a legal target.
                                            objectName: slide.SwipeView.isCurrentItem ? "homeHeroExplore" : ""
                                            anchors.fill: parent
                                            accessibleName: "Explore the tribute"
                                            pointerEnabled: false
                                            focusRadius: 12
                                            onTriggered: win.openUniverse(slide.modelData.extensionId,
                                                                          slide.modelData.name)
                                        }
                                        MouseArea {
                                            id: exMa; anchors.fill: parent
                                            hoverEnabled: true; cursorShape: Qt.PointingHandCursor
                                            onClicked: win.openUniverse(slide.modelData.extensionId,
                                                                        slide.modelData.name)
                                        }
                                        KeyboardAction {
                                            anchors.fill: parent
                                            pointerEnabled: false
                                            focusEnabled: win.televisionMode && slide.visible
                                            accessibleName: "Explore " + slide.modelData.name
                                            focusRadius: 12
                                            onTriggered: win.openUniverse(slide.modelData.extensionId,
                                                                          slide.modelData.name)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // gentle auto-advance through the collection (not visualized — ratified)
                Timer {
                    // Stands down while the player is up: this advances a carousel nobody can see
                    // behind the film, and every advance is an animation plus cover work on the
                    // GUI thread — the thread Qt Quick needs free to present video frames.
                    interval: 6500; running: page.visible && !win.immersiveSurfaceOpen; repeat: true
                    // guarded: an empty roster would turn the modulo into NaN
                    onTriggered: if (heroView.count > 0)
                                     heroView.currentIndex = (heroView.currentIndex + 1) % heroView.count
                }

                // the door to the Universes world, the single front door to every universe
                // and Tribute (Hemanth 2026-10-05; the old Hall is no longer linked from here)
                // — quiet, top-right, gold on hover
                Item {
                    id: hallDoor
                    z: 5
                    anchors.top: parent.top; anchors.right: parent.right; anchors.margins: 20
                    width: hallRow.implicitWidth + 8; height: 28
                    Row {
                        id: hallRow
                        anchors.right: parent.right; anchors.verticalCenter: parent.verticalCenter
                        spacing: 7
                        Text { text: win.installedUniverses.length + (win.installedUniverses.length === 1 ? " tribute" : " tributes")
                               color: (hallMa.containsMouse || hallKey.interactionActive) ? theme.gold : theme.inkDim
                               font.family: theme.display; font.pixelSize: 16
                               Behavior on color { ColorAnimation { duration: 120 } } }
                        Text { text: "›"
                               color: (hallMa.containsMouse || hallKey.interactionActive) ? theme.gold : theme.inkDimmer
                               font.family: theme.display; font.pixelSize: 19
                               anchors.verticalCenter: parent.verticalCenter }
                    }
                    KeyboardAction {
                        id: hallKey
                        objectName: "homeUniverseHall"
                        anchors.fill: parent
                        accessibleName: "Universes"
                        pointerEnabled: false
                        focusRadius: 8
                        onTriggered: win.openWorld("Universes")
                    }
                    MouseArea {
                        id: hallMa; anchors.fill: parent
                        hoverEnabled: true; cursorShape: Qt.PointingHandCursor
                        onClicked: win.openWorld("Universes")
                    }
                    KeyboardAction {
                        anchors.fill: parent
                        pointerEnabled: false
                        focusEnabled: win.televisionMode
                        accessibleName: "Hall of Worlds"
                        focusRadius: 8
                        onTriggered: win.openUniverseHall()
                    }
                }
            }

            // ---- 3. CONTINUE (one unified row, all mediums mixed; scrolls horizontally) ----
            //      Reserve the old rail footprint until the idle Loader resolves its data. If
            //      there is no resume history, the reservation collapses after the same check that
            //      previously hid this entire Column.
            Loader {
                id: homeContinueRailLoader
                width: parent.width
                height: !homeContinueRailLoaded
                         || (item && item.hasResumeItems)
                         ? homeContinueRailPlaceholderHeight : 0
                asynchronous: true
                onLoaded: {
                    homeContinueRailRequested = false
                    homeContinueRailLoaded = true
                }
                onStatusChanged: if (status === Loader.Error) {
                    homeContinueRailRequested = false
                    homeContinueRailLoaded = true
                }
            }

            // ---- 4. MODE-INTRO WIDGETS — the board that introduces each app AND shows what's inside.
            //      First prototype: Tankoban as a BOOKSHELF (manga covers standing on a shelf ledge).
            //      The other modes get their own widget forms next; this is the shape to react to.
            Loader {
                id: homeBookshelfLoader
                width: parent.width
                height: 400
                active: false
                asynchronous: true
                onLoaded: {
                    item.track = Qt.binding(function() { return page.contentY })
                    item.mangaBooks = Qt.binding(function() { return Catalog.topManga })
                    item.comicsBooks = Qt.binding(function() { return Catalog.topComics })
                    item.clicked.connect(function() { win.openWorld("Tankoban") })
                    item.bookClicked.connect(function() { win.openWorld("Tankoban") })
                    win.homeIntroWidgetSettled(homeBookshelfLoader)
                }
                onStatusChanged: if (status === Loader.Error) win.homeIntroWidgetSettled(homeBookshelfLoader)
            }

            // Theatre = the film-strip, Biblio = the reading desk (mock-reviewed 2026-07-04;
            // both self-load their data, so the board wiring stays declarative).
            Loader {
                id: homeTheatreStripLoader
                width: parent.width
                height: 400
                active: false
                asynchronous: true
                onLoaded: {
                    item.track = Qt.binding(function() { return page.contentY })
                    item.clicked.connect(function() { win.openWorld("Theatre") })
                    win.homeIntroWidgetSettled(homeTheatreStripLoader)
                }
                onStatusChanged: if (status === Loader.Error) win.homeIntroWidgetSettled(homeTheatreStripLoader)
            }

            Loader {
                id: homeReadingDeskLoader
                width: parent.width
                height: 400
                active: false
                asynchronous: true
                onLoaded: {
                    item.track = Qt.binding(function() { return page.contentY })
                    item.clicked.connect(function() { win.openWorld("Biblio") })
                    item.genrePicked.connect(function(name) {
                        win.openWorld("Biblio")
                        win.openBiblioGenre(name)
                    })
                    win.homeIntroWidgetSettled(homeReadingDeskLoader)
                }
                onStatusChanged: if (status === Loader.Error) win.homeIntroWidgetSettled(homeReadingDeskLoader)
            }
            Loader {
                id: homeVaultWidgetLoader
                width: parent.width
                height: 520
                active: false
                asynchronous: true
                onLoaded: {
                    item.track = Qt.binding(function() { return page.contentY })
                    item.clicked.connect(function() { win.openVaultPage() })
                    win.homeIntroWidgetSettled(homeVaultWidgetLoader)
                }
                onStatusChanged: if (status === Loader.Error) win.homeIntroWidgetSettled(homeVaultWidgetLoader)
            }
            Item { width: 1; height: 16 }   // bottom breathing room
        }
    }

    // Readiness describes the presented initial surface, not merely a live process.
    // Keep Home and loaded-world markers distinct for fresh-launch smoke consumers.
    property bool androidHomeReadyReported: false
    property bool androidWorldReadyReported: false
    property bool androidLocalOnboardingReported: false
    Timer {
        id: androidInitialSurfaceReadiness
        interval: 100
        repeat: true
        running: win.androidHost && !win.androidHomeReadyReported && !win.androidWorldReadyReported
        onTriggered: {
            if (win.androidHomeReadyReported || win.androidWorldReadyReported) return
            if (!win.visible || boot.visible) return
            if (accountHost.visible) {
                if (!win.androidLocalOnboardingReported
                        && typeof AccountController !== "undefined" && AccountController
                        && AccountController.mode === "signedOut"
                        && AccountController.onboardingRequired) {
                    win.androidLocalOnboardingReported = true
                    console.info("[boot] local onboarding visible")
                }
                return
            }
            if (worldStack.current === "") {
                if (win.desktopPresentation && page.visible && topbar.visible && page.width > 0 && page.height > 0
                        && topbar.width > 0 && topbar.height > 0) {
                    win.androidHomeReadyReported = true
                    console.info("[boot] android home ready")
                }
                return
            }
            for (var i = 0; i < worldRepeater.count; ++i) {
                var loader = worldRepeater.itemAt(i)
                if (loader && loader.mode === worldStack.current && loader.visible
                        && loader.status === Loader.Ready && loader.item) {
                    win.androidWorldReadyReported = true
                    console.info("[boot] android world ready: " + loader.mode)
                    return
                }
            }
        }
    }

    // ---- world pages: one keep-alive Loader PER visited mode, stacked over the home on the SAME
    //      wallpaper. worldStack.current picks which is visible; "" = home. Kept alive so covers
    //      don't re-fetch on return (the home's top bar + scroll hide while a world is up). ----
    // ---- Stage 2 warming: after the home screen settles, quietly pre-build the world
    //      pages the user hasn't opened yet — one at a time, only while on Home — so the
    //      first click lands on an already-painted page instead of paying the cold build.
    //      Each append builds a hidden async Loader (worldStack) and pre-caches its covers.
    Timer {
        id: warmStart
        interval: 2500          // let the home page finish its own first paint first
        running: win.worldWarmerEnabled
        repeat: false
        onTriggered: warmer.running = true
    }
    Timer {
        id: warmer
        interval: 1800          // stagger: one world at a time, easy on CPU/network
        running: false
        repeat: true
        readonly property var targets: ["Tankoban", "Theatre", "Biblio"]
        onTriggered: {
            // Yield while a world is open OR while the player is up. The player check was missing
            // and it was THE video stutter (2026-07-29): opening the player from Home leaves
            // worldStack.current === "", so this kept firing every 1.8s behind the film, and each
            // append builds a ~190-tile world page plus its cover pre-cache. Even with an async
            // Loader, component completion, bindings and image decode land on the GUI thread — and
            // Qt Quick cannot present a video frame while the GUI thread is busy. Measured: 130
            // GUI-thread stalls in a 76s playback, 10.3s blocked, worst single stall 1094ms, which
            // is exactly the hitch Hemanth reported. Everything else in this file already stands
            // down for immersiveSurfaceOpen (wallpaper animation :1423, download reveal :2328/:2337,
            // chrome :2345); the warmer was the one that did not.
            if (worldStack.current !== "" || feriaLayer.open || win.immersiveSurfaceOpen) return   // → yield, retry next tick
            var names = []
            for (var i = 0; i < openModes.count; i++) names.push(openModes.get(i).mode)
            var next = Warming.nextWarmMode(names, warmer.targets)
            if (next === "") { warmer.running = false; return }   // everything warmed → stop
            openModes.append({ mode: next })               // builds its hidden async Loader
        }
    }
    ListModel { id: openModes }
    Item {
        id: worldStack
        visible: !collectionsPanel.showing
        anchors.fill: parent
        anchors.leftMargin: win.wideWorldNavigationLeftInset
        property string current: ""                      // "" = home; else the visible mode
        Repeater {
            id: worldRepeater
            model: openModes
            delegate: Loader {
                id: worldLoader
                required property string mode
                anchors.fill: parent
                visible: worldStack.current === mode && !win.immersiveSurfaceOpen
                // Android builds a world page for several seconds on first entry. Say so
                // instead of leaving a bare wallpaper; desktop is unchanged.
                Text {
                    anchors.centerIn: parent
                    visible: Qt.platform.os === "android" && worldLoader.status !== Loader.Ready
                    text: qsTr("Loading %1…").arg(worldLoader.mode)
                    color: "#9a99a5"; font.family: "Segoe UI"; font.pixelSize: 14
                }
                // Pass the initial activation state into the component before Component.onCompleted.
                // This keeps opt-in warmers from running a world's synchronous setup while hidden.
                active: false
                // Stage 2: build off the GUI thread so instantiating a world (~190 tiles)
                // never freezes the app — the page fills in progressively, and warming
                // (below) builds it hidden ahead of the first click.
                asynchronous: true
                Component.onCompleted: {
                    // showExplicitContent too: otherwise Tankoban Discover's first page is
                    // fetched with the WorldPage default and refetched when onLoaded binds it.
                    var initialProperties = {
                        "lifecycleActive": worldStack.current === mode && !win.immersiveSurfaceOpen
                    }
                    // Vinyl's local catalogue does not expose the WorldPage filter.
                    if (mode !== "Vinyl")
                        initialProperties.showExplicitContent = contentPreferences.showExplicit
                    setSource(win.worldSourceFor(mode), initialProperties)
                    active = true
                }
                onLoaded: {
                    if (item.lifecycleActive !== undefined)
                        item.lifecycleActive = Qt.binding(function() {
                            return worldStack.current === mode && !win.immersiveSurfaceOpen
                        })
                    phoneShell.attachHostedItem(item)
                    item.medium = mode
                    item.backdrop = wall
                    item.homeRequested.connect(win.closeWorld)
                    item.mediumSelected.connect(win.openWorld)
                    if (mode === "Vinyl") {
                        item.accountClicked.connect(function(anchorRight, anchorBottom) {
                            accountFlyout.toggleAt(anchorRight, anchorBottom)
                        })
                        win.vinylWorld = item
                        item.shellDockRight = Qt.binding(function() {
                            return taskbar.visible ? taskbar.leftEdge + taskbar.closedWidth : 0
                        })
                        item.shellDockBottomExtent = Qt.binding(function() {
                            return taskbar.visible ? taskbar.bottomGap + taskbar.closedSize : 0
                        })
                        item.minimizeClicked.connect(win.minimizeShell)
                        item.fullscreenClicked.connect(win.toggleFullscreenShell)
                        item.powerClicked.connect(function() { win.requestApplicationQuit() })
                        item.playbackRequested.connect(function() {
                            if (!win.vinylProfileActive) return
                            win.claimAudio("vinyl")
                            win.registerVinylSession()
                        })
                        item.homeLanding = true
                        item.showHome()
                        win.applyVinylResume()
                        if (win.namedCollectionsOpening)
                            item.openNamedCollectionReference(win.namedCollectionsOpening)
                        return
                    }
                    item.seriesRequested.connect(win.openSeries)
                    if (item.mangaOpenById) item.mangaOpenById.connect(win.openSeries)
                    item.bookRequested.connect(win.openBook)
                    item.genreRequested.connect(win.openGenre)
                    if (item.genreIndexRequested) item.genreIndexRequested.connect(win.openGenreIndex)
                    var westernSignal = item["westernRequested"]
                    if (westernSignal) westernSignal.connect(function(title) { win.openWestern({ title: title }) })
                    var westernExploreSignal = item["westernExploreRequested"]
                    if (westernExploreSignal) westernExploreSignal.connect(win.openComicArchive)
                    var comicSeriesSignal = item["comicSeriesRequested"]
                    if (comicSeriesSignal) comicSeriesSignal.connect(win.openComicSeries)
                    var gcdSignal = item["gcdSeriesRequested"]
                    if (gcdSignal) gcdSignal.connect(win.openGcdSeries)
                    var locgPubSignal = item["locgPublisherRequested"]
                    if (locgPubSignal) locgPubSignal.connect(win.openLocgPublisher)
                    var comicBoardSignal = item["comicArchiveBoardRequested"]
                    if (comicBoardSignal) comicBoardSignal.connect(win.openComicArchiveBoard)
                    var biblioGenreSignal = item["biblio" + "GenreRequested"]
                    if (biblioGenreSignal) biblioGenreSignal.connect(win.openBiblioGenre)
                    var biblioGenreIndexSignal = item["biblio" + "GenreIndexRequested"]
                    if (biblioGenreIndexSignal) biblioGenreIndexSignal.connect(win.openBiblioGenreIndex)
                    if (item.continueResumeRequested) item.continueResumeRequested.connect(win.resumeContinue)
                    if (item.continueDetailRequested) item.continueDetailRequested.connect(win.detailContinue)
                    // the Universes world: its list is the installed roster plus the archived templates
                    if (item.universeRequested) item.universeRequested.connect(win.openRosterUniverse)
                    if (item.tributeRequested) item.tributeRequested.connect(win.openTribute)
                    if (item.installed !== undefined) item.installed = Qt.binding(function() { return win.installedUniverses })
                    if (item.collectionOpenRequested) item.collectionOpenRequested.connect(win.openCollectionEntry)
                    if (item.libraryResumeRequested) item.libraryResumeRequested.connect(win.resumeLibraryEntry)
                    if (item.libraryMarkWatchedRequested) item.libraryMarkWatchedRequested.connect(win.markLibraryWatched)
                    if (item.continueSeeAllRequested) item.continueSeeAllRequested.connect(function() {
                        win.openContinueSeeAll(mode === "Theatre" ? "video"
                                             : mode === "Biblio"  ? "book" : "tankoban")
                    })
                    if (item.wallpaperClicked) item.wallpaperClicked.connect(function() { win.openWallpaperSearch(mode) })
                    if (item.dlnaClicked) item.dlnaClicked.connect(function(anchorRight, anchorBottom) {
                        dlnaSharePopup.toggleAt(anchorRight, anchorBottom)
                    })
                    // Next Up rows (spec 2026-07-18): Theatre's direct play walks the same
                    // openMovieSession door as the series page; Tankoban's read walks the
                    // same openComicSession door as Continue resume. Guarded — only the
                    // worlds that declare the signals connect.
                    var nextUpPlay = item["playRequested"]
                    if (nextUpPlay) nextUpPlay.connect(win.openMovieSession)
                    var nextUpRead = item["nextUpReadRequested"]
                    if (nextUpRead) nextUpRead.connect(win.openComicSession)
                    // Thread the global Explicit Content preference into every world's
                    // inherited WorldPage.showExplicitContent (Task 7 Step 4). Tankoban's
                    // Discover wall reads it now; Theatre/Biblio Discover walls read it
                    // via Task 9. The property is guarded so a world that pre-dates the
                    // inherited field (none currently, but defensive) loads cleanly.
                    if (item.showExplicitContent !== undefined)
                        item.showExplicitContent = Qt.binding(function() { return contentPreferences.showExplicit })
                    // Biblio's Discover/Explore split (Task 8) reads its OWN showExplicit
                    // property — distinct from the inherited WorldPage.showExplicitContent above
                    // (Tankoban's Discover wall) — same guarded-binding shape either way.
                    if (item.showExplicit !== undefined)
                        item.showExplicit = Qt.binding(function() { return contentPreferences.showExplicit })
                    if (mode === "Theatre") {
                        item.contentPreferences = contentPreferences   // the one global preference into the deep catalogue
                        var theatreSignal = item["theatre" + "ItemRequested"]
                        if (theatreSignal) theatreSignal.connect(win.openTheatreSeries)
                        var tgSignal = item["theatre" + "GenreRequested"]
                        if (tgSignal) tgSignal.connect(win.openTheatreGenre)
                        var tgiSignal = item["theatre" + "GenreIndexRequested"]
                        if (tgiSignal) tgiSignal.connect(win.openTheatreGenreIndex)
                    }
                    item.searchClicked.connect(win.openSearch)
                    if (item.stremioClicked) item.stremioClicked.connect(win.openStremioSyncPanel)
                    if (item.trackersClicked) {
                        item.trackersClicked.connect(win.toggleSyncCenterPage)
                        item.trackersActive = Qt.binding(function() { return syncCenterLayer.active })
                    }
                    if (item.libraryRemovalRequested) item.libraryRemovalRequested.connect(win.requestTheatreRemoval)
                    if (item.fullscreenClicked) item.fullscreenClicked.connect(win.toggleFullscreenShell)
                    item.minimizeClicked.connect(win.minimizeShell)
                    item.powerClicked.connect(function() { win.requestApplicationQuit() })
                    if (item.accountClicked) item.accountClicked.connect(function(anchorRight, anchorBottom) {
                        accountFlyout.toggleAt(anchorRight, anchorBottom)
                    })
                }
            }
        }
    }

    PhoneShellHost {
        id: phoneShell
        window: win
        worldStack: worldStack
        topbar: topbar
        page: page
        contentCol: contentCol
        hero: hero
        hallDoor: hallDoor
        homeBookshelfLoader: homeBookshelfLoader
        homeTheatreStripLoader: homeTheatreStripLoader
        homeReadingDeskLoader: homeReadingDeskLoader
        homeVaultWidgetLoader: homeVaultWidgetLoader
        downloadsLayer: downloadsLayer
        extensionsLayer: extensionsLayer
        historyStatsLayer: historyStatsLayer
        syncCenterLayer: syncCenterLayer
        stremioPanel: stremioPanel
        accountFlyout: accountFlyout
        wall: wall
        escapeCommand: escapeCommand
        fullWindowPageOpen: win.fullWindowPageOpen
    }

    Loader {
        id: genreLayer
        anchors.fill: parent
        z: 45
        active: false
        visible: active
        property string genreName: ""
        source: "GenrePage.qml"
        onLoaded: {
            item.backdrop = wall
            item.genreName = genreLayer.genreName
            item.showExplicitContent = Qt.binding(function() { return contentPreferences.showExplicit })
            item.backRequested.connect(win.closeGenre)
            item.minimizeRequested.connect(win.minimizeShell)
            item.fullscreenRequested.connect(win.toggleFullscreenShell)
            item.closeRequested.connect(function() { win.requestApplicationQuit() })
            item.searchClicked.connect(win.openSearch)
            item.seriesRequested.connect(win.openSeries)
            item.exploreRequested.connect(function() { win.closeGenre(); win.openGenreIndex() })
        }
    }

    // ---- genre INDEX layer (the "Explore" directory). z below genreLayer so picking a genre opens
    //      its page over the index. ----
    Loader {
        id: genreIndexLayer
        anchors.fill: parent
        z: 44
        active: false
        visible: active
        source: "GenreIndex.qml"
        onLoaded: {
            item.backdrop = wall
            item.showExplicitContent = Qt.binding(function() { return contentPreferences.showExplicit })
            item.backRequested.connect(win.closeGenreIndex)
            item.minimizeRequested.connect(win.minimizeShell)
            item.fullscreenRequested.connect(win.toggleFullscreenShell)
            item.closeRequested.connect(function() { win.requestApplicationQuit() })
            item.searchClicked.connect(win.openSearch)
            item.genrePicked.connect(win.openGenre)
        }
    }

    // Biblio genre INDEX layer — same z as the page layer but declared FIRST, so the
    // later-declared BiblioGenrePage paints over it when both are up.
    Loader {
        id: biblioGenreIndexLayer
        anchors.fill: parent
        z: 46
        active: false
        visible: active
        source: "BiblioGenreIndex.qml"
        onLoaded: {
            item.backdrop = wall
            item.showExplicitContent = Qt.binding(function() { return contentPreferences.showExplicit })
            item.backRequested.connect(win.closeBiblioGenreIndex)
            item.minimizeRequested.connect(win.minimizeShell)
            item.fullscreenRequested.connect(win.toggleFullscreenShell)
            item.closeRequested.connect(function() { win.requestApplicationQuit() })
            item.searchClicked.connect(win.openSearch)
            item.genrePicked.connect(win.openBiblioGenre)
        }
    }

    Loader {
        id: biblioGenreLayer
        anchors.fill: parent
        z: 46
        active: false
        visible: active
        property string genreName: ""
        source: "BiblioGenrePage.qml"
        onLoaded: {
            item.backdrop = wall
            item.genreName = biblioGenreLayer.genreName
            item.showExplicitContent = Qt.binding(function() { return contentPreferences.showExplicit })
            item.backRequested.connect(win.closeBiblioGenre)
            item.minimizeRequested.connect(win.minimizeShell)
            item.fullscreenRequested.connect(win.toggleFullscreenShell)
            item.closeRequested.connect(function() { win.requestApplicationQuit() })
            item.searchClicked.connect(win.openSearch)
            item.bookRequested.connect(win.openBook)
            if (item.exploreRequested) item.exploreRequested.connect(function() {
                win.closeBiblioGenre(); win.openBiblioGenreIndex()
            })
        }
    }

    Loader {
        id: theatreGenreLayer
        anchors.fill: parent
        z: 48
        active: false
        visible: active
        property string mediaKind: "movie"
        property string genreName: ""
        source: "TheatreGenrePage.qml"
        onLoaded: {
            item.backdrop = wall
            item.mediaKind = theatreGenreLayer.mediaKind
            item.genreName = theatreGenreLayer.genreName
            item.showExplicitContent = Qt.binding(function() { return contentPreferences.showExplicit })
            item.backRequested.connect(win.closeTheatreGenre)
            item.minimizeRequested.connect(win.minimizeShell)
            item.fullscreenRequested.connect(win.toggleFullscreenShell)
            item.closeRequested.connect(function() { win.requestApplicationQuit() })
            item.searchClicked.connect(win.openSearch)
            item.itemRequested.connect(win.openTheatreSeries)
            item.exploreRequested.connect(function() {
                win.closeTheatreGenre(); win.openTheatreGenreIndex(theatreGenreLayer.mediaKind)
            })
        }
    }

    Loader {
        id: theatreGenreIndexLayer
        anchors.fill: parent
        z: 47
        active: false
        visible: active
        property string mediaKind: "movie"
        source: "TheatreGenreIndex.qml"
        onLoaded: {
            item.backdrop = wall
            item.mediaKind = theatreGenreIndexLayer.mediaKind
            item.showExplicitContent = Qt.binding(function() { return contentPreferences.showExplicit })
            item.backRequested.connect(win.closeTheatreGenreIndex)
            item.minimizeRequested.connect(win.minimizeShell)
            item.fullscreenRequested.connect(win.toggleFullscreenShell)
            item.closeRequested.connect(function() { win.requestApplicationQuit() })
            item.searchClicked.connect(win.openSearch)
            item.genrePicked.connect(function(name) {
                win.openTheatreGenre(theatreGenreIndexLayer.mediaKind, name)
            })
        }
    }

    // ---- series detail layer: opened from a Top-10 title tile, sits OVER the world page ----
    Loader {
        id: seriesLayer
        anchors.fill: parent
        z: 53     // above the universe overlay (z:52): a manga opened from a universe stacks on top, back returns to the universe
        active: false
        visible: active
        property string title: ""
        property string malId: ""             // Slice C: Discover card's MAL id, threaded to the series page
        property string seriesIdOverride: ""
        property string sourceSearchTitle: ""
        property var sourceSearchAliases: []
        property var sourceRequiredMarkers: []
        property string resumeSeriesId: ""    // Continue resume: jump straight to this chapter…
        property string resumeChapterId: ""   //   …in this series (set seriesId BEFORE the chapter)
        property string resumeVolumeId: ""    // Tankoban resume: open this VOLUME (Mode ON) instead
        property string requestedVolumeNumber: "" // temporary arc-volume landing; chapter catalogue follows
        property bool legacyWeebCentral: false
        property var exactCollectionReference: null
        source: legacyWeebCentral ? "MangaSeriesThumbnailMock.qml"
              : (viewSettings.rebuiltTitlePages ? "TankobanSeriesView.qml" : "MangaSeries.qml")
        onLoaded: {
            item.backdrop = wall
            item.malId = seriesLayer.malId
            if (item.exactCollectionReference !== undefined)
                item.exactCollectionReference = seriesLayer.exactCollectionReference
            if (item.seriesIdOverride !== undefined) item.seriesIdOverride = seriesLayer.seriesIdOverride
            if (item.sourceSearchTitle !== undefined) item.sourceSearchTitle = seriesLayer.sourceSearchTitle
            if (item.sourceSearchAliases !== undefined) item.sourceSearchAliases = seriesLayer.sourceSearchAliases
            if (item.sourceRequiredMarkers !== undefined) item.sourceRequiredMarkers = seriesLayer.sourceRequiredMarkers
            if (item.requestedVolumeNumber !== undefined)
                item.requestedVolumeNumber = seriesLayer.requestedVolumeNumber
            item.seriesTitle = seriesLayer.title
            if (seriesLayer.resumeSeriesId) item.seriesId = seriesLayer.resumeSeriesId
            if (seriesLayer.resumeChapterId) item.openChapterId = seriesLayer.resumeChapterId
            if (seriesLayer.resumeVolumeId) item.resumeTankobanVolume(seriesLayer.resumeVolumeId)
            item.backRequested.connect(win.closeSeries)
            item.minimizeRequested.connect(win.minimizeShell)
            item.fullscreenRequested.connect(win.toggleFullscreenShell)
            item.closeRequested.connect(function() { win.requestApplicationQuit() })
            if (item.openExtensionsRequested)
                item.openExtensionsRequested.connect(function() { win.openExtensionsPage("tankoban") })
            if (item.languageSettingsRequested)
                item.languageSettingsRequested.connect(function() {
                    win.openExtensionsPage("tankoban", "colosseum.well.tankoyomi")
                })
            if (item.resumeSavedRequested)
                item.resumeSavedRequested.connect(win.resumeContinue)
            // the READER's own chrome (not the page topbar): session verbs
            item.readerMinimizeRequested.connect(win.minimizeComicReader)
            item.readerFullscreenRequested.connect(win.toggleFullscreenShell)
            item.readerCloseRequested.connect(win.closeComicReader)
            item.readerBackRequested.connect(win.backFromMangaReader)
            // Rebuilt title page only: the world pills, search and a Back pill that names its place.
            if (item.worldRequested)
                item.worldRequested.connect(function(w) { win.closeSeries(); win.openWorld(w) })
            if (item.searchRequested)
                item.searchRequested.connect(function() {
                    win.closeSeries()
                    if (worldStack.current !== "Tankoban") win.openWorld("Tankoban")
                    win.openSearch()
                })
            if (item.backLabel !== undefined)
                item.backLabel = Qt.binding(function() { return worldStack.current.length ? worldStack.current : "Home" })
        }
    }

    // ---- western-comics detail layer: the GetComics shelf (ComicSeries), over the world ----
    Loader {
        id: westernLayer
        anchors.fill: parent
        z: 53     // above the universe overlay (z:52): a comic opened from a universe stacks on top, back returns to the universe
        active: false
        visible: active
        property string title: ""
        property string tagSlug: ""
        property int    tagId: 0
        property string resumeChapterId: ""   // Continue/session resume: straight into the reader
        property var    baked: null           // catalogue run {gcdId,releases,cover} OR pack {packSeriesId,releases,cover} OR universe {gcdId:0,releases,cover}
        source: "ComicSeries.qml"
        onLoaded: {
            item.backdrop = wall
            item.seriesTitle = westernLayer.title
            item.tagId = westernLayer.tagId
            // Resolve the baked IDENTITY (-> seriesId "gcd:<id>" for catalogue, or the explicit
            // packSeriesId for a downloads-backed pack shelf) BEFORE opening the reader, so
            // ComicReaderShell mounts with a STABLE seriesId and its resume reads the RIGHT
            // progress key. Opening the reader first mounted it under the transient
            // "gc:<empty-slug>" identity -> restored page 1, then saved to the OTHER key and
            // wrote page 1 over the real record (runtime-confirmed 2026-08-06). Same fix as
            // openGcdSeries() above. The pack branch (Slice 5) sets packSeriesId — an explicit
            // downloads-backed identity that needs no gcdId resolution.
            if (westernLayer.baked) {
                item.poster = westernLayer.baked.cover || item.poster
                if (westernLayer.baked.packSeriesId !== undefined
                    && String(westernLayer.baked.packSeriesId).length > 0) {
                    item.packSeriesId = westernLayer.baked.packSeriesId   // pack identity (stable, explicit)
                } else {
                    item.gcdId = westernLayer.baked.gcdId                 // catalogue identity
                }
                item.bakedReleases = westernLayer.baked.releases   // seriesId now stable (gcd:<id> or pack id)
            }
            item.tagSlug = westernLayer.tagSlug        // triggers resolve() (no-op when baked); live-mode identity
            if (westernLayer.resumeChapterId) item.openChapterId = westernLayer.resumeChapterId   // open reader LAST — identity stable
            item.backRequested.connect(win.closeWestern)
            item.minimizeRequested.connect(win.minimizeShell)
            item.fullscreenRequested.connect(win.toggleFullscreenShell)
            item.closeRequested.connect(function() { win.requestApplicationQuit() })
            item.readerMinimizeRequested.connect(win.minimizeComicReader)
            item.readerFullscreenRequested.connect(win.toggleFullscreenShell)
            item.readerCloseRequested.connect(win.closeComicReader)
            item.readerBackRequested.connect(win.closeComicReader)
        }
    }

    // ---- comic series layer: a LOCG-catalogue comic's issue list with GetComics content
    //      attached (peer of westernLayer) ----
    Loader {
        id: comicSeriesLayer
        anchors.fill: parent
        z: 50
        active: false
        visible: active
        property string title: ""
        property string cover: ""
        property string locgSid: ""          // "locg:<id>" — the catalogue entry
        property var locgMeta: ({})          // {publisher, rating, startYear…} enriches the hero
        source: "ComicSeriesPage.qml"
        onLoaded: {
            item.backdrop = wall
            item.seriesTitle = comicSeriesLayer.title
            item.cover = comicSeriesLayer.cover
            item.backRequested.connect(win.closeComicSeries)
            item.minimizeRequested.connect(win.minimizeShell)
            item.fullscreenRequested.connect(win.toggleFullscreenShell)
            item.closeRequested.connect(function() { win.requestApplicationQuit() })
            item.readerMinimizeRequested.connect(win.minimizeComicReader)
            item.readerFullscreenRequested.connect(win.toggleFullscreenShell)
            item.readerCloseRequested.connect(win.closeComicReader)
            item.readerBackRequested.connect(win.closeComicReader)
            item.locgMeta = comicSeriesLayer.locgMeta
            item.locgId = comicSeriesLayer.locgSid       // set LAST — triggers attach()
        }
    }

    // On-demand comics-catalog ingest (see comicsDbHit) — never active at startup.
    Loader {
        id: comicsDbLoader
        active: false
        source: "ComicsDbLoader.qml"
    }

    // Bakeoff-only page surface (COLOSSEUM_BAKEOFF_STRIP): topmost so the blind
    // trial shows nothing but pages — no world chrome, no identity tells.
    Loader {
        id: bakeoffStripLayer
        anchors.fill: parent
        z: 200
        active: false
        visible: active
        source: "BakeoffStripHost.qml"
    }

    // ---- Continue see-all layer: the whole resume backlog, scoped per door (home/world).
    //      z 49: above world pages, below the detail/series layers (z 50+) so a tapped tile
    //      opens its detail OVER the backlog and back returns here. ----
    Loader {
        id: continueSeeAllLayer
        anchors.fill: parent
        z: 49
        active: false
        visible: active
        property string scope: "home"
        source: "ContinueSeeAllPage.qml"
        onLoaded: {
            item.backdrop = wall
            item.scope = continueSeeAllLayer.scope
            item.backRequested.connect(win.closeContinueSeeAll)
            item.minimizeRequested.connect(win.minimizeShell)
            item.fullscreenRequested.connect(win.toggleFullscreenShell)
            item.closeRequested.connect(function() { win.requestApplicationQuit() })
            item.searchClicked.connect(win.openSearch)
            item.resumeRequested.connect(win.resumeContinue)     // same sinks the rows use
            item.detailRequested.connect(win.detailContinue)
        }
    }


    // ---- LOCG publisher grid layer: one publisher shelf's paginated series grid
    //      (tile → LOCG series list via openComicSeries) ----
    Loader {
        id: locgPublisherLayer
        anchors.fill: parent
        z: 50
        active: false
        visible: active
        property var box: ({})
        source: "LocgPublisherPage.qml"
        onLoaded: {
            item.backdrop = wall
            item.box = locgPublisherLayer.box
            item.backRequested.connect(win.closeLocgPublisher)
            item.minimizeRequested.connect(win.minimizeShell)
            item.fullscreenRequested.connect(win.toggleFullscreenShell)
            item.closeRequested.connect(function() { win.requestApplicationQuit() })
            item.seriesRequested.connect(win.openComicSeries)   // tile → LOCG series list (over this grid)
        }
    }

    // ---- GetComics Archives board layer: the publisher/franchise taxonomy ----
    Loader {
        id: comicBoardLayer
        anchors.fill: parent
        z: 49
        active: false
        visible: active
        source: "ComicArchiveBoard.qml"
        onLoaded: {
            item.backdrop = wall
            item.backRequested.connect(win.closeComicArchiveBoard)
            item.minimizeRequested.connect(win.minimizeShell)
            item.fullscreenRequested.connect(win.toggleFullscreenShell)
            item.closeRequested.connect(function() { win.requestApplicationQuit() })
            item.boxRequested.connect(win.openComicArchive)    // box → existing archive index
        }
    }

    // ---- western-comics archive index layer: series archives under an explore box
    //      (below the series detail, so a picked series opens OVER it) ----
    Loader {
        id: comicIndexLayer
        anchors.fill: parent
        z: 49
        active: false
        visible: active
        property string boxTitle: ""
        property string tagSlug: ""
        property int    tagId: 0
        property int    boxCount: 0
        source: "ComicArchiveIndex.qml"
        onLoaded: {
            item.backdrop = wall
            item.boxTitle = comicIndexLayer.boxTitle
            item.tagSlug = comicIndexLayer.tagSlug
            item.boxCount = comicIndexLayer.boxCount
            item.tagId = comicIndexLayer.tagId          // set LAST — assigning it triggers resolve()
            item.backRequested.connect(win.closeComicArchive)
            item.minimizeRequested.connect(win.minimizeShell)
            item.fullscreenRequested.connect(win.toggleFullscreenShell)
            item.closeRequested.connect(function() { win.requestApplicationQuit() })
            item.westernPicked.connect(win.openWestern)
            item.allReleasesRequested.connect(win.openWestern)
        }
    }

    // ---- Theatre detail layer: opened from a Theatre tile, sits OVER the world page ----
    Loader {
        id: theatreSeriesLayer
        anchors.fill: parent
        z: 53     // above the universe overlay (z:52): a film/show opened from a universe stacks on top, back returns to the universe
        active: false
        visible: active
        property var pendingItem: ({})
        source: viewSettings.rebuiltTitlePages ? "TheatreSeriesView.qml" : "TheatreSeries.qml"
        onLoaded: {
            item.backdrop = wall
            item.itemData = theatreSeriesLayer.pendingItem
            item.backRequested.connect(win.closeTheatreSeries)
            item.minimizeRequested.connect(win.minimizeShell)
            item.fullscreenRequested.connect(win.toggleFullscreenShell)
            item.closeRequested.connect(function() { win.requestApplicationQuit() })
            item.playRequested.connect(win.openMovieSession)
            item.playLocalRequested.connect(win.openLocalVideoSession)
            item.playArrivingRequested.connect(win.routeArrivingPlay)
            item.openItemRequested.connect(win.openTheatreSeries)
            item.libraryRemovalRequested.connect(win.requestTheatreRemoval)
            item.openExtensionsRequested.connect(function() { win.openExtensionsPage("theatre") })
            // Rebuilt title page only: the world pills, search and a Back pill that names its place.
            if (item.worldRequested)
                item.worldRequested.connect(function(w) { win.closeTheatreSeries(); win.openWorld(w) })
            if (item.searchRequested)
                item.searchRequested.connect(function() {
                    win.closeTheatreSeries()
                    if (worldStack.current !== "Theatre") win.openWorld("Theatre")
                    win.openSearch()
                })
            if (item.backLabel !== undefined)
                item.backLabel = Qt.binding(function() { return worldStack.current.length ? worldStack.current : "Home" })
        }
    }

    StremioSyncPanel {
        id: stremioPanel
        objectName: "stremioSyncOverlay"
        anchors.fill: parent
        z: 960
        syncState: typeof stremioSyncState !== "undefined" ? stremioSyncState : null
        actions: typeof StremioActions !== "undefined" ? StremioActions : null
        onCloseRequested: win.closeStremioSyncPanel()
    }

    TheatreRemovalDialog {
        id: theatreRemoval
        objectName: "theatreRemovalOverlay"
        anchors.fill: parent
        z: 961
        syncState: typeof stremioSyncState !== "undefined" ? stremioSyncState : null
        actions: typeof StremioActions !== "undefined" ? StremioActions : null
        onCloseRequested: {
            shown = false
            entry = null
        }
    }

    // ---- video player layer: above every detail/series layer (mpv under house glass) ----
    Loader {
        id: playerLayer
        objectName: "playerPageLoader"
        anchors.fill: parent
        z: 60
        active: false
        visible: win.playerOpen
        // Spread first construction across event-loop turns. After the first load this Loader stays
        // active forever, preserving the existing warm player/minimize behavior and avoiding churn.
        asynchronous: true
        // The ONE production line that selects the backend. Player2Page.qml deliberately exposes the
        // same interface as PlayerPage.qml, so every playerLayer.item.* call site below stays as-is.
        source: win.usePlayer2 ? "player2host/Player2Page.qml" : "PlayerPage.qml"
        onStatusChanged: {
            if (status === Loader.Error)
                console.error("[player] page load failed; pending playback retained for retry")
        }
        onLoaded: {
            // Say which engine is driving, every time the player opens. Without this, telling the two
            // apart means reading process paths after the fact - which is exactly what happened on the
            // first swap attempt (2026-07-25).
            console.log("[player] backend = " + (win.usePlayer2 ? "PLAYER 2" : "mpv (player 1)")
                        + "  (booted=" + Player2Available + ")")
            item.backdrop = wall
            if (item.playbackRequested)
                item.playbackRequested.connect(function() { win.claimAudio("theatre") })
            item.backRequested.connect(win.minimizePlayer)
            item.minimizeRequested.connect(win.minimizePlayer)
            item.fullscreenRequested.connect(win.toggleFullscreenShell)
            item.closeRequested.connect(win.closePlayerSession)
            // Player-2-only seams; absent on the mpv page, hence the guards. Log only: there is
            // no backend to swap to in this boot, so the page itself shows the failure.
            if (item.backendFallback)
                item.backendFallback.connect(function(reason) {
                    console.warn("[player2] declined/failed before first frame: " + reason)
                })
            if (item.backendRestartRequired)
                item.backendRestartRequired.connect(function(reason) {
                    console.warn("[player2] failed after first frame: " + reason)
                })
            // Do not start media from the Loader's own completion event. Yield one turn so Qt can
            // present the newly-created player/loading face before mpv/file-open work begins.
            Qt.callLater(win.flushPendingPlayerOpen)
        }
    }

    PlayerLoadFailure {
        anchors.fill: parent
        z: 61
        visible: win.playerOpen && playerLayer.status === Loader.Error
        onRetryRequested: win.retryPlayerLayerLoading()
        onBackRequested: win.minimizePlayer()
    }

    // ---- book detail layer: Biblio's OWN dust-jacket page over the world (above series) ----
    Loader {
        id: bookLayer
        objectName: "biblioBookRouteState"
        anchors.fill: parent
        z: 53
        active: false
        visible: active
        property var book: ({})
        source: "BiblioBook.qml"
        onLoaded: {
            item.backdrop = wall
            item.book = bookLayer.book
            item.backRequested.connect(win.closeBook)
            item.minimizeRequested.connect(win.minimizeShell)
            item.fullscreenRequested.connect(win.toggleFullscreenShell)
            item.closeRequested.connect(function() { win.requestApplicationQuit() })
            item.readRequested.connect(win.openBookSession)
            // (listenRequested retired — the reader carries audiobook playback now)
        }
    }

    // ---- the ONE audiobook engine (read-along), hoisted at the window root (never in a
    // Loader) so playback survives the reader opening/closing. The READER is the only
    // audiobook surface (standalone player retired 2026-07-18): its HUD transport pill
    // and Audio tab both drive this session. ----
    AudiobookSession {
        id: audioSession
        objectName: "vinylHandoffAudiobook"
        onPlaybackRequested: win.claimAudio("audiobook")
    }

    Connections {
        target: win.vinylWorld ? win.vinylWorld.session : null
        function onIdentityDecisionRequested(ceremony) {
            if (!win.vinylProfileActive) return
            win.pendingIdentityRoute = Object.assign({}, ceremony, {vinylImport:true})
            identityCeremonyDialog.ceremony = ceremony
            identityCeremonyDialog.open()
        }
    }
    Connections {
        target: typeof VinylLocalSource !== "undefined" ? VinylLocalSource : null
        function onProfileLeaving() {
            if (win.pendingIdentityRoute && win.pendingIdentityRoute.vinylImport) win.cancelPendingIdentityCeremony()
            win.leaveVinylProfile()
        }
        function onProfileEntered() { win.vinylProfileActive = true }
    }

    Loader {
        id: bookReaderLayer
        anchors.fill: parent
        z: 58
        active: false
        visible: active
        property string bookPath: ""
        property var bookMeta: ({})
        // The FRESH reader (Task 16 swap): reader2/ReaderShell replaces the imported TB2
        // foliate web-app. Contract mapping per the ratified plan: open(path, meta) →
        // openBook(path) (meta stays on this layer for session records), closed() → the same
        // session-aware close. minimized() (restored 2026-07-18 on Hemanth's call) parks the
        // book as a taskbar tile via minimizeBookReader — the resume seam reopens it in place.
        source: "reader2/ReaderShell.qml"
        onLoaded: {
            item.audioSession = audioSession   // the ONE shared audiobook engine → read-along Audio tab
            item.bookMeta = bookReaderLayer.bookMeta   // catalog identity → the pairing self-heal
            item.openBook(bookReaderLayer.bookPath)
            if (bookReaderLayer.bookMeta.openAudio)
                Qt.callLater(function() {
                    if (bookReaderLayer.item) bookReaderLayer.item.openAudioPanel()
                })
            item.closed.connect(win.closeBookReaderSession)
            item.minimized.connect(win.minimizeBookReader)
            item.fullscreenRequested.connect(win.toggleFullscreenShell)
        }
    }

    // ---- Vault standalone comic reader: a single loose CBZ opened from the Vault, with the
    // injected VaultPageStore — no series page behind it (execution plan Slice 8). ----
    Loader {
        id: vaultComicLayer
        anchors.fill: parent
        z: 57
        active: false
        visible: active
        property string archivePath: ""
        property string vaultId: ""
        property string title: "Comic"
        source: win.androidHost ? "" : "comicreader/VaultComicReader.qml"
        onLoaded: {
            // archivePath opens the reader synchronously. Supply its progress key
            // first so the first load can restore the saved page.
            item.vaultId = vaultComicLayer.vaultId
            item.title = vaultComicLayer.title
            item.archivePath = vaultComicLayer.archivePath
            item.minimizeRequested.connect(win.minimizeVaultComic)
            item.closeRequested.connect(win.closeVaultComic)
            item.backRequested.connect(win.closeVaultComic)
            item.fullscreenRequested.connect(win.toggleFullscreenShell)
        }
    }

    // (The standalone audiobook player layer is retired — 2026-07-18, Hemanth: the reader
    // IS the audiobook player. AudiobookSession above stays: it is the ENGINE the reader's
    // HUD transport and Audio tab drive.)

    // ---- generic world search layer: Tankoban + Theatre (SearchSurface + their own source) ----
    Loader {
        id: worldSearchLayer
        anchors.fill: parent
        z: 51
        active: false
        visible: active
        property string searchMode: ""
        property string placeholder: "Search…"
        source: "SearchSurface.qml"
        onLoaded: {
            item.backdrop = wall
            item.searchMode = worldSearchLayer.searchMode
            item.placeholder = worldSearchLayer.placeholder
            item.backRequested.connect(win.closeWorldSearch)
            item.itemRequested.connect(win.routeWorldSearchItem)
            item.minimizeRequested.connect(win.minimizeShell)
            item.fullscreenRequested.connect(win.toggleFullscreenShell)
            item.closeRequested.connect(function() { win.requestApplicationQuit() })
        }
    }

    // ---- search layer: Biblio's search surface over the world (below the book detail) ----
    Loader {
        id: searchLayer
        anchors.fill: parent
        z: 51
        active: false
        visible: active
        source: "BiblioSearch.qml"
        onLoaded: {
            item.backdrop = wall
            item.backRequested.connect(win.closeSearch)
            item.homeRequested.connect(function() { win.closeSearch(); win.closeWorld() })
            item.bookRequested.connect(win.openBook)
            item.minimizeRequested.connect(win.minimizeShell)
            item.fullscreenRequested.connect(win.toggleFullscreenShell)
            item.closeRequested.connect(function() { win.requestApplicationQuit() })
        }
    }

    // ---- Biblio series detail layer: opened from a SERIES card (above search, below the book detail) ----
    // ---- session switch glue: capture the outgoing surface, tear it down, build + restore the next ----
    Connections {
        target: Sessions
        function onActiveChanged(prevId, nextId) {
            var prev = Sessions.get(prevId)
            if (prev && prev.id) {
                Sessions.saveState(prevId, win.captureSession(prev))
                win.teardownSession(prev)
            }
            var next = Sessions.get(nextId)
            if (next && next.id) win.activateSession(next)
            else {
                // no next session: land on the world behind (Windows-like), not always home
                if (win.activeBrowserSessionId === prevId && win.browserReturnToFeria
                        && !win.parkingBrowserForWorld && feriaLayer.item) {
                    feriaLayer.item.restoreBrowserWorld()
                    feriaLayer.open = true
                    currentSurface = "Feria"
                } else currentSurface = worldStack.current || "Home"
                win.activeBrowserSessionId = ""
                refreshWallpaper()
                // a MINIMIZE (record kept, nothing became active): pop the taskbar out so the
                // user sees where the session went; it pulls back after 15 idle seconds.
                if (prevId && Sessions.get(prevId).id) taskbar.reveal()
            }
        }
    }

    // ---- Downloads page: unified local-media vault, entered from the taskbar ----
    Loader {
        id: downloadsLayer
        objectName: "downloadsLayer"
        anchors.fill: parent
        anchors.leftMargin: win.wideWorldNavigationLeftInset
        z: 56     // taskbar full-page: ABOVE every browsing/detail page (universe 52, series/book 53)
                  // so clicking Downloads always lands on top — below only the immersive surfaces
                  // (book reader 58, player 60). Was 52: any detail page silently covered it.
        active: false
        visible: active
        // DownloadsPage is a large, taskbar-only surface. Spread component creation across
        // frames so opening the download ledger does not synchronously block the world underneath.
        // The route handlers only touch the item from onLoaded, after construction completes.
        asynchronous: true
        source: "DownloadsPage.qml"
        onLoaded: {
            phoneShell.attachHostedItem(item)
            item.backdrop = wall
            item.backRequested.connect(win.closeDownloadsPage)
            item.minimizeRequested.connect(win.minimizeShell)
            item.fullscreenRequested.connect(win.toggleFullscreenShell)
            item.closeRequested.connect(function() { win.requestApplicationQuit() })
            item.searchClicked.connect(win.openSearch)
            item.openRequested.connect(win.routeDownloadItem)
            item.redownloadRequested.connect(function(downloadItem) {
                var result = LocalDownloads.redownload(downloadItem);
                item.finishMutation(result, "This file could not be queued again.");
            })
            item.openWorldRequested.connect(win.routeDownloadWorld)
            item.playArrivingRequested.connect(win.routeArrivingPlay)
            item.openAudiobookRequested.connect(win.routeDownloadedAudiobook)
        }
    }

    // ---- Vault page: "On this machine", entered from the taskbar folder door (Slice 10) ----
    // A z:56 overlay exactly like downloadsLayer: opening it hides no world (it sits ABOVE the
    // preserved Home/world/detail), so Back merely deactivates this Loader and reveals whatever the
    // user stood on. Paints from the VaultLibrary read-model. Add-folder opens the native folder
    // picker; the folder-scan ingest lands in Slice 11.
    Loader {
        id: vaultLayer
        objectName: "vaultLayer"
        anchors.fill: parent
        z: 56
        active: false
        visible: active && !win.immersiveSurfaceOpen
        // VaultPage is a large, taskbar-only surface. Spread component creation across
        // frames so opening the folder door does not synchronously block the world underneath.
        // The open/close paths tolerate item being null until onLoaded (see vaultBack()).
        asynchronous: true
        source: win.androidHost ? "" : "VaultPage.qml"
        onLoaded: {
            item.backdrop = wall
            item.backRequested.connect(win.closeVaultPage)
            win.finishNamedCollectionVaultOpen()
            item.addFolderRequested.connect(function() { vaultFolderDialog.open() })
            if (item.openMediaRequested)                      // Slice 14: folder-view row / preview door → the shared LocalLaunch open path
                item.openMediaRequested.connect(function(path) { win.openLocalMedia([path]) })
            item.viewWorldRequested.connect(win.openVaultIdentity)
            item.minimizeRequested.connect(win.minimizeShell)
            item.fullscreenRequested.connect(win.toggleFullscreenShell)
            item.closeRequested.connect(function() { win.requestApplicationQuit() })
        }
    }

    // Slice 15: the live-shelf watcher defers its upserts while an immersive surface
    // (player/reader) is open — "no watcher activity during playback beyond the debounce
    // accumulating" (behavior to preserve). The gate is C++ state (VaultLibrary.immersive);
    // QML only reports the surface fact. Null-target Binding is a no-op in tests.
    Binding {
        target: typeof VaultLibrary !== "undefined" ? VaultLibrary : null
        property: "immersive"
        value: win.immersiveSurfaceOpen
    }

    Connections {
        target: typeof Extensions !== "undefined" ? Extensions : null
        function onChanged() {
            TheatreApi.setExtensions(Extensions.installed())
            Subtitles.setExtensions(Extensions.installed())
            win.installedExtensions = Extensions.installed()
        }
    }

    // Task 9: re-push the global Explicit Content preference into TheatreApi whenever it
    // changes, so the boot-time marquee rows that read the module flag (not a Qt.binding)
    // pick up the new value on their next fetch. The page-bound properties re-evaluate on
    // their own (Qt.binding); this covers the .pragma-library side.
    Connections {
        target: contentPreferences
        function onChanged() { TheatreApi.setShowExplicit(contentPreferences.showExplicit) }
    }

    // ---- Universes: extension-backed bespoke pages + generic fallback ----
    Loader {
        id: universeLayer
        objectName: "universeLayer"
        anchors.fill: parent
        z: 52
        active: false
        visible: active
        asynchronous: true
        property string extensionId: ""
        property string universeName: ""
        // An archived universe on a shared template (Arc 58) is opened by NAME, not by an
        // installed extension: "saga" | "eras" | "studio" | "anime", empty for extensions.
        property string templatePage: ""
        // An installed universe has two faces (Arc 58): its hand-made TRIBUTE page, and — when
        // it ships a payload — the plain standard page the Universes world's banner opens.
        property bool plain: false
        readonly property string bespokeId: plain ? "" : extensionId
        readonly property var templateSources: ({ "saga": "SagaUniversePage.qml", "shelves": "ShelvesUniversePage.qml" })
        source: templatePage.length ? (templateSources[templatePage] || "SagaUniversePage.qml")
              : bespokeId === "com.colosseum.universe.dcau"
                ? "DCAUUniversePage.qml"
                : (bespokeId === "com.colosseum.universe.starwars"
                   ? "GalaxyUniversePage.qml"
                   : (bespokeId === "com.colosseum.universe.onepiece"
                      ? "OnePieceUniversePage.qml"
                      : (bespokeId === "com.colosseum.universe.cosmere"
                         ? "CosmereUniversePage.qml"
                         : "UniverseExtensionPage.qml")))
        onLoaded: {
            if (universeLayer.templatePage.length) {
                // Template pages share one contract; a page simply lacks the signals it has no use for.
                item.backdrop = wall
                item.universeName = universeLayer.universeName
                item.backRequested.connect(win.closeUniverse)
                item.minimizeRequested.connect(win.minimizeShell)
                item.fullscreenRequested.connect(win.toggleFullscreenShell)
                item.closeRequested.connect(function() { win.requestApplicationQuit() })
                if (accountHost.visible) accountHost.focusReturnItem = item
                item.watchRequested.connect(win.openTheatreSeries)
                if (item.bookRequested) item.bookRequested.connect(win.openBook)
                if (item.comicsArchiveRequested) item.comicsArchiveRequested.connect(win.openUniverseComic)
                if (item.seriesRequested) item.seriesRequested.connect(win.openSeries)
                // an edition manga (e.g. the One Piece colour edition) arrives as a whole
                // entry — same router as the arc pages, its provider/seriesId profile intact
                if (item.seriesEntryRequested) item.seriesEntryRequested.connect(win.routeUniverseSeries)
                if (item.continueResumeRequested) item.continueResumeRequested.connect(win.resumeContinue)
                if (item.continueDetailRequested) item.continueDetailRequested.connect(win.detailContinue)
                if (item.universeRequested) item.universeRequested.connect(win.openUniverseByName)
                return
            }
            item.extensionId = universeLayer.extensionId
            item.universeName = universeLayer.universeName
            if (universeLayer.bespokeId === "com.colosseum.universe.dcau" ||
                    universeLayer.bespokeId === "com.colosseum.universe.starwars" ||
                    universeLayer.bespokeId === "com.colosseum.universe.onepiece")
                item.reducedMotion = Qt.binding(function() { return win.reducedMotion })
            if (universeLayer.bespokeId === "com.colosseum.universe.onepiece")
                item.installedExtensions = Qt.binding(function() { return win.installedExtensions })
            item.backRequested.connect(win.closeUniverse)
            item.minimizeRequested.connect(win.minimizeShell)
            item.fullscreenRequested.connect(win.toggleFullscreenShell)
            item.closeRequested.connect(function() { win.requestApplicationQuit() })
            // If a dev/startup route loads a universe behind account onboarding, remember
            // that universe as the surface onboarding must return focus to when it closes.
            // Normal user navigation never opens a universe through the onboarding cover.
            if (accountHost.visible)
                accountHost.focusReturnItem = item
            else if (item.takeKeyboardFocus)
                Qt.callLater(item.takeKeyboardFocus)
            // Works open ABOVE this overlay — series/theatre/western are z:53 (> this layer's 52),
            // book is z:53 — so a clicked work paints on top and the overlay stays loaded beneath.
            // Their Esc checks sit before closeUniverse, so back closes the work first, then the
            // universe. (Replaces an earlier close-on-click that broke back-nav to the universe.)
            if (universeLayer.bespokeId === "com.colosseum.universe.onepiece") {
                item.arcPageOpen = Qt.binding(function() { return onePieceArcLayer.active })
                item.arcRequested.connect(win.openOnePieceArc)
                item.mediaRequested.connect(win.openTheatreSeries)
            } else if (universeLayer.bespokeId === "com.colosseum.universe.cosmere") {
                // The Cognitive Atlas self-sources from CosmereApi; its only content signal
                // is a resolved Biblio book opening into the reader.
                item.bookRequested.connect(win.openBook)
            } else {
                item.watchRequested.connect(win.openTheatreSeries)
                if (universeLayer.bespokeId === "com.colosseum.universe.dcau") {
                    item.comicRequested.connect(win.openGcdSeries)
                    item.continueResumeRequested.connect(win.resumeContinue)
                    item.continueDetailRequested.connect(win.detailContinue)
                } else {
                    item.bookRequested.connect(win.openBook)
                    item.comicsArchiveRequested.connect(win.openUniverseComic)
                    item.seriesRequested.connect(win.routeUniverseSeries)
                }
            }
        }
    }

    Loader {
        id: onePieceArcLayer
        anchors.fill: parent
        z: 52.5
        active: false
        visible: active
        asynchronous: true
        property var arcData: null
        sourceComponent: Component {
            OnePieceArcPage {
                arc: onePieceArcLayer.arcData
                extensionId: universeLayer.extensionId
                installedExtensions: win.installedExtensions
                reducedMotion: win.reducedMotion
            }
        }
        onLoaded: {
            item.backRequested.connect(win.closeOnePieceArc)
            item.minimizeRequested.connect(win.minimizeShell)
            item.fullscreenRequested.connect(win.toggleFullscreenShell)
            item.closeRequested.connect(function() { win.requestApplicationQuit() })
            item.watchRequested.connect(win.openTheatreSeries)
            item.seriesRequested.connect(win.routeUniverseSeries)
            item.onePaceRequested.connect(win.openOnePaceArc)
        }
    }

    // ---- Feria: its own native app, entered from the taskbar. ----
    Loader {
        id: feriaLayer
        objectName: "feriaLayer"
        anchors.fill: parent
        z: 58
        enabled: win.feriaRuntimeReady
        property bool open: false
        onOpenChanged: {
            if (open && !win.ensureFeriaRuntime()) {
                open = false
                return
            }
            if (!open && win.currentSurface === "Feria") {
                win.currentSurface = worldStack.current || "Home"
                win.refreshWallpaper()
            }
        }
        active: win.feriaAvailable && !win.feriaComingSoon && win.feriaRuntimeReady
            && (open || accountCenter.visible || (Sessions.revision, Sessions.browsers().length > 0))
        visible: open && active
        source: "feria/FeriaWorld.qml"
        Binding {
            target: feriaLayer.item
            property: "lifecycleActive"
            value: feriaLayer.open
            when: feriaLayer.item !== null
        }
        Binding {
            target: feriaLayer.item
            property: "browserDeck"
            // A Binding, not an onLoaded assignment: the deck Loader may complete after
            // this layer's item when a browser session restores at startup.
            value: feriaSessionDeck.item
        }
        Binding {
            target: feriaLayer.item
            property: "browserSuppressed"
            value: taskbar.open || yourFeriaLayer.active || accountCenter.visible || accountFlyout.visible || accountHost.visible
                || watchPartyJoinSheet.opened || openRecentPanel.visible
            when: feriaLayer.item !== null
        }
        onLoaded: {
            item.backdrop = wall
            item.sharedAccount = true
            item.browserOpenRequested.connect(function(descriptor, fresh, navigate) {
                var id = feriaSessionDeck.open(descriptor, fresh, navigate)
                if (!id.length) { item.setToast("Browser session is unavailable for this profile."); return }
                item.activateBrowserRecord(Sessions.get(id))
                if (navigate) Qt.callLater(function() {
                    if (Sessions.get(id).id) feriaSessionDeck.navigateSession(
                        id, descriptor.url, descriptor.position, descriptor.locator, descriptor.visitContext)
                })
            })
            item.browserParkRequested.connect(function(returnToFeria) {
                if (returnToFeria) win.browserReturnToFeria = true
                Sessions.switchTo("")
            })
            item.browserCloseRequested.connect(win.closeSession)
            if (win.activeBrowserSessionId.length)
                item.activateBrowserRecord(Sessions.get(win.activeBrowserSessionId))
            item.mediumSelected.connect(win.openWorld)
            item.accountRequested.connect(function(tab) {
                yourFeriaLayer.open = false
                accountCenter.open("feria", item.keyboardTarget, "feria")
            })
            item.accountDestinationRequested.connect(function() {
                win.openFeriaPage()
                yourFeriaLayer.open = false
                accountCenter.close()
            })
            item.homeRequested.connect(win.closeFeriaPage)
            item.fullscreenClicked.connect(win.toggleFullscreenShell)
            item.minimizeClicked.connect(win.minimizeShell)
            item.powerClicked.connect(function() { win.requestApplicationQuit() })
            item.accountClicked.connect(function(anchorRight, anchorBottom) {
                accountFlyout.toggleAt(anchorRight, anchorBottom)
            })
            Qt.callLater(win.restoreFeriaIfReady)
        }
    }
    Connections {
        target: typeof FeriaAccount !== "undefined" ? FeriaAccount : null
        function onProfileChanged() { win.feriaReturnSnapshot = null }
    }

    // The deck is a string-source Loader so Android (no Feria, no QtWebEngine) never
    // parses FeriaSessionDeck.qml. Shell-side faces below stay null-safe while inactive.
    Loader {
        id: feriaSessionDeck
        objectName: "feriaSessionDeck"
        active: win.feriaAvailable && !win.feriaComingSoon && win.feriaRuntimeReady
        // Required properties must exist during construction; onLoaded is too late.
        // Defer until the native enabledChanged handler has exposed Feria services.
        function loadBrowserDeck() {
            if (!active || item) return
            setSource("feria/FeriaSessionDeck.qml", {
                sessions: Sessions, accountStore: FeriaAccount, policy: FeriaBrowserPolicy
            })
        }
        onActiveChanged: {
            if (active) Qt.callLater(loadBrowserDeck)
            else source = ""
        }
        Component.onCompleted: if (active) Qt.callLater(loadBrowserDeck)
        z: 58.5
        readonly property rect viewport: feriaLayer.item ? feriaLayer.item.browserViewport
                                                        : Qt.rect(0, 160, win.width, win.height - 160)
        x: viewport.x; y: viewport.y; width: viewport.width; height: viewport.height
        // Forwarded faces for shell references (feriaConsentSurface geometry, session teardown).
        readonly property var activeEntry: item ? item.activeEntry : null
        readonly property var embeddedConsent: item ? item.embeddedConsent : false
        readonly property var embeddedDiagnostic: item ? item.embeddedDiagnostic : ""
        readonly property var entries: item ? item.entries : ({})
        function open(descriptor, fresh, navigate) {
            return item ? item.open(descriptor, fresh, navigate) : ""
        }
        function closeTab(id) { if (item) item.closeTab(id) }
        function restoreSession(id) { if (item) item.restoreSession(id) }
        function navigateSession(id, url, position, locator, ctx) { if (item) item.navigateSession(id, url, position, locator, ctx) }
        Binding {
            target: feriaSessionDeck.item
            property: "displayed"
            value: feriaLayer.open && feriaLayer.item && feriaLayer.item.viewState === "host"
                && feriaLayer.item.hostSessionId.length > 0
        }
        Binding {
            target: feriaSessionDeck.item
            property: "suppressed"
            value: taskbar.open || yourFeriaLayer.active || accountCenter.visible || accountFlyout.visible
                || accountHost.visible || watchPartyJoinSheet.opened || openRecentPanel.visible
        }
        onLoaded: {
            item.fullSizeSurface = feriaFullSizeSurface
            item.message.connect(function(id, text) {
                if (Sessions.activeId === id && feriaLayer.item) feriaLayer.item.setToast(text)
            })
            item.attachConsentSurface(feriaConsentSurface)
        }
    }

    // Connect to the lazy deck before a request starts quiescence (it may finish
    // synchronously when there are no browser sessions).
    Connections {
        target: feriaSessionDeck.item
        function onQuiesced() { win.completeApplicationQuit() }
        function onQuiescenceFailed(reason) { win.failApplicationQuit(reason) }
    }

    // Permanent hosts outlive the Feria Loader. Max moves the live page here;
    // the embedded world's geometry and anchors remain its saved restore point.
    Item {
        id: feriaFullSizeSurface
        objectName: "feriaFullSizeSurface"
        anchors.fill: parent
        anchors.topMargin: feriaConsentSurface.height
        z: 58.75
        visible: false
    }
    Item {
        id: feriaConsentSurface
        objectName: "feriaConsentSurface"
        anchors { left: parent.left; right: parent.right; top: parent.top }
        height: !feriaSessionDeck.activeEntry || !feriaSessionDeck.activeEntry.hostWindow
            ? (feriaSessionDeck.embeddedConsent || feriaSessionDeck.embeddedDiagnostic.length ? 100 : 0) : 0
        // Hidden Feria pages may ask while Theatre's z:60 player is open.
        // Keep shell consent above world surfaces and below the taskbar.
        z: 899
    }

    // ---- Extensions page: the store (Stremio-protocol addons), from the taskbar ----
    Loader {
        id: extensionsLayer
        objectName: "extensionsLayer"
        anchors.fill: parent
        z: 58     // full-page cover
        active: false
        visible: active
        // The Extensions world: House, Essentials and the Store rows (live from stremio-addons.net).
        source: "ExtensionsStorePage.qml"
        onLoaded: {
            item.backdrop = wall
            if (item.universeHallRequested)
                item.universeHallRequested.connect(function() { win.closeExtensionsPage(); win.openWorld("Universes") })
            // Same global preference Discover/genres/search read — a live binding so
            // the registry follows the shell visibility policy.
            item.showExplicit = Qt.binding(function() { return contentPreferences.showExplicit })
            win.openPendingExtensionConfiguration()
            item.backRequested.connect(win.closeExtensionsPage)
            item.minimizeRequested.connect(win.minimizeShell)
            item.fullscreenRequested.connect(win.toggleFullscreenShell)
            item.closeRequested.connect(function() { win.requestApplicationQuit() })
            item.searchClicked.connect(win.openSearch)
            if (item.takeKeyboardFocus)
                Qt.callLater(item.takeKeyboardFocus)
        }
    }

    // ---- Sync Center: the approved tracker catalogue and profile-owned controls ----
    Loader {
        id: syncCenterLayer
        objectName: "syncCenterLayer"
        anchors.fill: parent
        z: 58
        active: false
        visible: active
        source: "TrackerSyncCenterPage.qml"
        onLoaded: {
            item.backdrop = wall
            item.trackerModel = Qt.binding(function() {
                return (typeof TrackerSyncCenter !== "undefined") ? TrackerSyncCenter : null
            })
            item.stremioState = Qt.binding(function() {
                return (typeof stremioSyncState !== "undefined") ? stremioSyncState : null
            })
            item.reducedMotion = Qt.binding(function() { return win.reducedMotion })
            item.backRequested.connect(win.closeSyncCenterPage)
            item.minimizeRequested.connect(win.minimizeShell)
            item.fullscreenRequested.connect(win.toggleFullscreenShell)
            item.closeRequested.connect(function() { win.requestApplicationQuit() })
            item.mainSyncRequested.connect(win.openStremioSyncPanel)
            item.takeKeyboardFocus()
        }
    }

    Loader {
        id: historyStatsLayer
        objectName: "historyStatsLayer"
        anchors.fill: parent
        z: 58
        active: false
        visible: active
        source: "HistoryHighlightsStatsPage.qml"
        onLoaded: {
            item.backdrop = wall
            item.activityStore = Qt.binding(function() {
                return (typeof ProfileActivity !== "undefined") ? ProfileActivity : null
            })
            item.historyStore = Qt.binding(function() {
                return (typeof ProfileHistory !== "undefined") ? ProfileHistory : null
            })
            item.trackerModel = Qt.binding(function() {
                return (typeof TrackerSyncCenter !== "undefined") ? TrackerSyncCenter : null
            })
            item.reducedMotion = Qt.binding(function() { return win.reducedMotion })
            item.backRequested.connect(win.closeHistoryStatsPage)
            item.minimizeRequested.connect(win.minimizeShell)
            item.fullscreenRequested.connect(win.toggleFullscreenShell)
            item.closeRequested.connect(function() { win.requestApplicationQuit() })
            item.syncCenterRequested.connect(win.openSyncCenterPage)
            item.takeKeyboardFocus()
        }
    }

    // ---- Update page: the release chronicle, entered from the permanent taskbar item ----
    Loader {
        id: updateLayer
        objectName: "updateLayer"
        anchors.fill: parent
        z: 58
        active: false
        visible: active
        source: "UpdatePage.qml"
        onLoaded: {
            item.backdrop = wall
            item.updates = typeof Updates !== "undefined" ? Updates : null
            item.reducedMotion = Qt.binding(function() { return win.reducedMotion })
            item.backRequested.connect(win.closeUpdatePage)
            item.minimizeRequested.connect(win.minimizeShell)
            item.fullscreenRequested.connect(win.toggleFullscreenShell)
            item.closeRequested.connect(function() { win.requestApplicationQuit() })
            if (item.takeKeyboardFocus)
                Qt.callLater(item.takeKeyboardFocus)
        }
    }

    // ---- download feedback (2026-07-18, Hemanth): clicking Download anywhere pops the
    //      taskbar out so the gold jobs badge is SEEN arriving — same auto-reveal (and same
    //      15s pull-back) as a minimize. Fires only when the live-job count GROWS (a finish
    //      or cancel never pops the bar). While a reader/player owns the screen the taskbar
    //      is suppressed, so the reveal is held and fires when the shell is back — unless
    //      every job already finished by then (no stale pop for nothing). ----
    property int lastActiveDownloads: 0
    property bool pendingDownloadReveal: false
    // ONE number for the badge AND the pop: every live download, whichever engine owns
    // it. Audiobooks ride their own engine (not LocalDownloads) — folding its activeCount
    // in here is what makes an audiobook download "behave the same way as any other
    // download" (Hemanth 2026-07-20: taskbar pops, gold chip counts it).
    readonly property int totalActiveDownloads:
        ((typeof LocalDownloads !== "undefined")
            ? (LocalDownloads.revision, Number(LocalDownloads.totals.active || 0)) : 0)
        + ((typeof Audiobooks !== "undefined") ? Audiobooks.activeCount : 0)
    onImmersiveSurfaceOpenChanged: {
        ForegroundPriority.setImmersiveSurfaceOpen(win.immersiveSurfaceOpen)
        if (!immersiveSurfaceOpen && pendingDownloadReveal) {
            pendingDownloadReveal = false
            if (lastActiveDownloads > 0) taskbar.reveal()
        }
    }
    onTotalActiveDownloadsChanged: {
        var grew = totalActiveDownloads > lastActiveDownloads
        lastActiveDownloads = totalActiveDownloads
        if (!grew) return
        if (immersiveSurfaceOpen) { pendingDownloadReveal = true; return }
        taskbar.reveal()
    }

    // ---- the OS-shell taskbar: auto-hidden switcher over everything (under the boot splash) ----
    Taskbar {
        id: taskbar
        localMediaAvailable: win.localMediaAvailable
        z: 900
        visible: !win.immersiveSurfaceOpen
            && !win.vinylVideoFullscreen
            && (!win.androidHost || win.desktopPresentation)
            && !(feriaLayer.open && feriaLayer.item && feriaLayer.item.hostFullScreenActive)
        enabled: visible
        onVisibleChanged: if (!visible) open = false
        onSwitchRequested: (id) => {
            if (!win.guardNamedCollectionsNavigation(function() { Sessions.switchTo(id) })) Sessions.switchTo(id)
        }
        onCloseRequested: (id) => win.closeSession(id)
        onStartClicked: { /* Start menu is a later spec - placeholder */ }
        onOpenMediaClicked: {
            if (!win.localMediaAvailable) return
            if (!win.guardNamedCollectionsNavigation(function() { openMediaDialog.open() })) openMediaDialog.open()
        }
        onOpenRecentRequested: {
            if (!win.localMediaAvailable) return
            if (!win.guardNamedCollectionsNavigation(function() { openRecentPanel.toggle() })) openRecentPanel.toggle()
        }
        onWatchPartyJoinClicked: {
            if (!win.guardNamedCollectionsNavigation(function() { watchPartyJoinSheet.openSheet() })) watchPartyJoinSheet.openSheet()
        }
        watchPartyJoinOpen: watchPartyJoinSheet.opened
        watchPartyJoinPhase: typeof WatchPartyUi !== "undefined" ? WatchPartyUi.phase : "unavailable"
        watchPartyJoinErrorCategory: typeof WatchPartyUi !== "undefined"
                                     ? WatchPartyUi.errorCategory : "unavailable"
        downloadsBadge: win.totalActiveDownloads
        downloadsActive: downloadsLayer.active
        onDownloadsClicked: !downloadsLayer.active ? win.openDownloadsPage() : win.closeDownloadsPage()
        collectionsActive: collectionsPanel.showing
        onCollectionsClicked: collectionsPanel.showing ? win.closeNamedCollectionsPage() : win.openNamedCollectionsPage()
        vaultActive: vaultLayer.active
        onVaultClicked: !vaultLayer.active ? win.openVaultPage() : win.closeVaultPage()
        extensionsActive: extensionsLayer.active
        onExtensionsClicked: !extensionsLayer.active ? win.openExtensionsPage() : win.closeExtensionsPage()
        historyStatsActive: historyStatsLayer.active || yourFeriaLayer.active
        feriaContext: feriaLayer.open
        onHistoryStatsClicked: {
            if (feriaLayer.open) {
                if (yourFeriaLayer.active) win.closeYourFeriaPage()
                else win.openYourFeriaPage("history")
            } else {
                if (historyStatsLayer.active) win.closeHistoryStatsPage()
                else win.openHistoryStatsPage()
            }
        }
    }

    // Slice 6: the account-optional Room ID door lives outside immersive Player 1.
    // It joins room membership only; playback readiness remains false until Player 1
    // positively loads the authoritative room source.

    Connections {
        target: typeof WatchPartyUi !== "undefined" ? WatchPartyUi : null
        function onRoomActivated(roomId) {
            void roomId
            win.openWatchPartyRoomSource()
        }
    }

    WatchPartyJoinSheet {
        id: watchPartyJoinSheet
        controller: typeof WatchPartyUi !== "undefined" ? WatchPartyUi : null
        x: Math.round((win.width - width) / 2)
        y: Math.round((win.height - height) / 2)
    }

    // ── Vault launch entry points (execution plan Slice 8): Open Media…, drag-drop, Ctrl+O ──
    // The taskbar Open Media control, an app-wide file DropArea, and Ctrl+O all funnel into
    // win.openLocalMedia(). localLaunchState is the invisible automation surface (Lanista reads
    // lastRouteKind / lastRejectCategory / openCount by objectName).
    Item {
        id: localLaunchState
        objectName: "localLaunchState"
        visible: false
        property string lastRouteKind: ""
        property string lastRejectCategory: ""
        property int openCount: 0
    }

    FileDialog {
        id: openMediaDialog
        title: "Open Media"
        fileMode: FileDialog.OpenFiles
        nameFilters: phoneShell.openMediaNameFilters
        onAccepted: {
            if (!win.localMediaAvailable) return
            var arr = []
            for (var i = 0; i < selectedFiles.length; i++) arr.push("" + selectedFiles[i])
            win.openLocalMedia(arr)   // multi-select opens the FIRST; the Next-to-Open tray is Slice 20
        }
    }

    // Vault Add-folder picker (Slice 10). Opening the native folder picker is live now; what the app
    // DOES with the chosen folder — canonicalize · add as a Vault root · scan · shelve — is Slice 11.
    // vaultState is the invisible automation surface (a Lanista replay reads pageOpen / lastAddedFolder).
    Item {
        id: vaultState
        objectName: "vaultState"
        visible: false
        property bool pageOpen: vaultLayer.active
        property string lastAddedFolder: ""
    }

    // Data-vault Slice 3 (2026-08-22): catalogVaultState is the invisible automation surface for
    // CatalogVaultClient's fetch progress + the four catalogs' live ready state. On a dev machine
    // every catalog resolves locally so CatalogVault never fetches and readyCount sits at 4 from
    // boot; on a fresh install fetching flips true and readyCount climbs from 0 to 4 as each db
    // lands. readyCount is wired through Connections (not a plain binding) because ready() is a
    // Q_INVOKABLE method shadowing the Q_PROPERTY of the same name — calling it in a binding
    // expression does NOT register as a live dependency, so a bare `MalCatalog.ready()` read would
    // freeze at its first value and never notice a later readyChanged (see MangaSeries.qml's
    // resolve() for the same house convention: reads call .ready(), reactivity rides Connections).
    Item {
        id: catalogVaultState
        objectName: "catalogVaultState"
        visible: false
        property bool fetching: (typeof CatalogVault !== "undefined") ? CatalogVault.fetching : false
        property string tag: (typeof CatalogVault !== "undefined") ? CatalogVault.currentTag : ""
        property int _readyRev: 0
        readonly property int readyCount: {
            var _rev = catalogVaultState._readyRev
            var n = 0
            if (typeof MalCatalog !== "undefined" && MalCatalog && MalCatalog.ready()) n++
            if (typeof TankobanCatalog !== "undefined" && TankobanCatalog && TankobanCatalog.ready()) n++
            if (typeof ComicsCatalog !== "undefined" && ComicsCatalog && ComicsCatalog.ready()) n++
            if (typeof ImdbCatalog !== "undefined" && ImdbCatalog && ImdbCatalog.ready()) n++
            return n
        }
        Connections {
            target: (typeof MalCatalog !== "undefined") ? MalCatalog : null
            function onReadyChanged() { catalogVaultState._readyRev++ }
        }
        Connections {
            target: (typeof TankobanCatalog !== "undefined") ? TankobanCatalog : null
            function onReadyChanged() { catalogVaultState._readyRev++ }
        }
        Connections {
            target: (typeof ComicsCatalog !== "undefined") ? ComicsCatalog : null
            function onReadyChanged() { catalogVaultState._readyRev++ }
        }
        Connections {
            target: (typeof ImdbCatalog !== "undefined") ? ImdbCatalog : null
            function onReadyChanged() { catalogVaultState._readyRev++ }
        }
    }

    FolderDialog {
        id: vaultFolderDialog
        title: "Add a folder to your Vault"
        onAccepted: {
            vaultState.lastAddedFolder = "" + selectedFolder
            // C++ owns it: add the folder as an unconfirmed root and census it off-thread; the
            // confirmation card rises on scanFinished (Slice 11).
            if (typeof VaultLibrary !== "undefined")
                VaultLibrary.addFolder("" + selectedFolder)
        }
    }

    FileDialog {
        id: accountExportDialog
        title: qsTr("Save Colosseum account export")
        fileMode: FileDialog.SaveFile
        nameFilters: [qsTr("JSON files (*.json)")]
        defaultSuffix: "json"
        onAccepted: {
            if (typeof AccountLifecycle !== "undefined" && AccountLifecycle)
                AccountLifecycle.exportAccountData(selectedFile)
        }
    }

    // App-wide file drop. Sits LOW (z:5) so an open player/reader — and PlayerPage's own subtitle
    // DropArea — claim drops on their surface first; only the general app surface routes a dropped
    // media file here. A dropped FOLDER explains + offers the picker (the folder gesture is Slice 10).
    DropArea {
        id: appFileDrop
        anchors.fill: parent
        z: 5
        keys: ["text/uri-list"]
        onDropped: (drop) => {
            if (!win.localMediaAvailable) { drop.accepted = false; return }
            if (!drop.hasUrls) { drop.accepted = false; return }
            var files = []
            var anyFolder = false
            for (var i = 0; i < drop.urls.length; i++) {
                var u = "" + drop.urls[i]
                if (LocalLaunch.isDir(u)) anyFolder = true
                else files.push(u)
            }
            drop.accepted = true
            if (files.length === 0 && anyFolder) { win.showFolderDropExplain(); return }
            win.openLocalMedia(files)
        }
    }

    Shortcut {
        sequences: openMediaCommand.sequences
        enabled: win.localMediaAvailable
        context: Qt.ApplicationShortcut
        onActivated: openMediaCommand.invoke("shortcut")
    }

    // Vault ux uplift S15: a global shortcut opens the Vault from anywhere, via the same
    // door function the taskbar folder door uses (the layer-priority chain is respected —
    // openVaultPage already deactivates the other taskbar layers; Escape's law closes it).
    Shortcut {
        sequences: openVaultCommand.sequences
        context: Qt.ApplicationShortcut
        onActivated: openVaultCommand.invoke("shortcut")
    }

    // Arc 41 essentials: direct doors for utility pages.
    Shortcut {
        sequences: openDownloadsCommand.sequences
        context: Qt.ApplicationShortcut
        onActivated: openDownloadsCommand.invoke("shortcut")
    }
    Shortcut {
        sequences: openExtensionsCommand.sequences
        context: Qt.ApplicationShortcut
        onActivated: openExtensionsCommand.invoke("shortcut")
    }

    // ── Open Recent panel (Slice 9): the Open Media control remembers ──
    // A same-window popup (so the bridge can see it) that pops up above the taskbar dock near the
    // Open Media control. Lists recently opened local files for one-click reopen; a dead file is
    // shown dimmed and offers nothing; Clear wipes the shortcuts (never reading progress).
    // Click-away MouseArea below (z:905) closes it; the panel (z:906) sits above it.
    MouseArea {
        anchors.fill: parent
        z: 905
        visible: openRecentPanel.open
        onClicked: openRecentPanel.open = false
    }
    OpenRecentPanel {
        id: openRecentPanel
        objectName: "openRecentPanel"
        z: 906
        visible: opacity > 0.01
        opacity: 0
        property bool open: false
        x: (Math.max(18, Math.min(80, parent.width * 0.045))) + 58
        // hug the dock (Windows-taskbar-preview feel): the closed dock top is a deterministic
        // parent.height - (closedSize 64 + bottomGap 16) = parent.height - 80, so sit the panel
        // bottom ~2px above it (Hemanth 2026-08-09; tunable ±6px on eyes-on).
        y: parent.height - height - 82
        Behavior on opacity { NumberAnimation { duration: 140 } }

        function refresh() { model = (typeof LocalLaunch !== "undefined") ? LocalLaunch.recentItems() : [] }
        function toggle() { open = !open }
        onOpenChanged: { if (open) refresh(); opacity = open ? 1 : 0 }
        Component.onCompleted: refresh()
        Connections {
            target: (typeof LocalLaunch !== "undefined") ? LocalLaunch : null
            function onRecentChanged() { openRecentPanel.refresh() }
        }
        onReopenRequested: (entry) => { win.reopenRecent(entry); openRecentPanel.open = false }
        onClearRequested: if (typeof LocalLaunch !== "undefined") LocalLaunch.clearRecent()
    }

    // Slice 20: explicit multi-file queue. The first selected file is dispatched immediately;
    // these rows never auto-advance and are not part of Open Recent until opened here.
    NextToOpenTray {
        id: nextToOpenTray
        objectName: "nextToOpenTray"
        z: 907
        visible: stagedCount > 0
        x: parent.width - width - 42
        y: parent.height - height - 92
        model: (typeof LocalLaunch !== "undefined") ? LocalLaunch.nextToOpenItems() : []
        function refresh() {
            model = (typeof LocalLaunch !== "undefined") ? LocalLaunch.nextToOpenItems() : []
        }
        Connections {
            target: (typeof LocalLaunch !== "undefined") ? LocalLaunch : null
            function onNextToOpenChanged() { nextToOpenTray.refresh() }
        }
        onOpenRequested: (index, entry) => win.openNextToOpen(index)
        onRemoveRequested: (index, entry) => win.removeNextToOpen(index)
    }

    Connections {
        target: (typeof LocalLaunch !== "undefined") ? LocalLaunch : null
        function onOpenReady(result) { win.dispatchLocalRoute(result) }
        function onRouteInfoReady(result) { win.dispatchLocalRoute(result) }
        function onOpenNextToOpenReady(result) { win.dispatchLocalRoute(result) }
    }

    // Slice 21: launch sessions use the same seedable ceremony component as VaultPage.
    LocalIdentityDialog {
        id: identityCeremonyDialog
        anchors.centerIn: parent
        z: 960
        onChoiceMade: (relationship, choice) => win.decidePendingIdentity(choice)
        onCancelRequested: win.cancelPendingIdentityCeremony()
    }

    // A quiet, no-color status pill for local-open feedback: a categorized rejection, or the
    // folder-drop explain with a "Select Media Files…" action. Grays/white only (house rule).
    Rectangle {
        id: localLaunchToast
        objectName: "localLaunchToast"
        z: 950
        anchors.horizontalCenter: parent.horizontalCenter
        y: parent.height - height - 96
        width: Math.min(parent.width - 96, toastRow.implicitWidth + 40)
        height: 52
        radius: 12
        color: Qt.rgba(0.05, 0.05, 0.07, 0.95)
        border.width: 1
        border.color: Qt.rgba(1, 1, 1, 0.16)
        opacity: 0
        visible: opacity > 0.01
        property string message: ""
        property bool showPick: false
        Behavior on opacity { NumberAnimation { duration: 180 } }
        function flash(msg, withPick) {
            message = msg; showPick = !!withPick; opacity = 1; toastTimer.restart()
        }
        Timer { id: toastTimer; interval: 4600; onTriggered: localLaunchToast.opacity = 0 }
        Row {
            id: toastRow
            anchors.centerIn: parent
            spacing: 18
            Text {
                text: localLaunchToast.message
                color: "#e9e9ec"; font.pixelSize: 14
                anchors.verticalCenter: parent.verticalCenter
            }
            Text {
                visible: localLaunchToast.showPick
                text: "Select Media Files…"
                color: "#ffffff"; font.pixelSize: 14; font.underline: true
                anchors.verticalCenter: parent.verticalCenter
                MouseArea {
                    anchors.fill: parent
                    cursorShape: Qt.PointingHandCursor
                    onClicked: { localLaunchToast.opacity = 0; if (win.localMediaAvailable) openMediaDialog.open() }
                }
            }
        }
    }

    Loader {
        id: wallpaperLayer
        anchors.fill: parent
        z: 920
        active: false
        visible: active
        property string targetWorld: "Home"
        source: "WallpaperSearch.qml"
        onLoaded: {
            item.backdrop = wall
            item.targetWorld = wallpaperLayer.targetWorld
            item.inheritedImageUrl = win.wallpaperSource
            item.closeRequested.connect(win.closeWallpaperSearch)
            item.minimizeRequested.connect(win.minimizeShell)
            item.fullscreenRequested.connect(win.toggleFullscreenShell)
            item.quitRequested.connect(function() { win.requestApplicationQuit() })
            item.applyRequested.connect(function(scope, world, pick) {
                if (scope === "all") win.setWallpaperEverywhere(pick)
                else win.setWallpaperPick(world, pick)
                item.inheritedImageUrl = win.wallpaperSource
                win.closeWallpaperSearch()
            })
            item.forceActiveFocus()
        }
        onActiveChanged: if (active && item) {
            item.targetWorld = wallpaperLayer.targetWorld
            item.inheritedImageUrl = win.wallpaperSource
            item.forceActiveFocus()
        }
    }

    // ---- OS-style boot loader: prefetch covers, then fade away to reveal the shell with art warm ----
    BootSplash {
        id: boot
        prefetchEnabled: BootSplashPrefetchEnabled
        // Automation identity (Lanista): scenarios wait for `visible == false` here before
        // driving anything — the first pilot run proved every click lands "green" on the
        // occluded tree while this splash still owns the screen (vacuous pass, 2026-08-06).
        objectName: "bootSplash"
        anchors.fill: parent
        z: 1000
        onFinished: { phoneShell.enterAndroidStartWorld(); bootFade.start() }
        NumberAnimation { id: bootFade; target: boot; property: "opacity"; to: 0; duration: 400
            onFinished: boot.visible = false }
    }
    Connections {
        target: boot
        function onVisibleChanged() {
            if (boot.visible)
                return
            win.armStartupIdleWork()
            // Onboarding is the topmost startup surface and must retain first focus. Otherwise
            // Android TV enters through TopBar; desktop dead-focus recovery keeps Arc 41 ignition.
            if (accountHost.visible)
                accountHost.focusFirstInside()
            else if (win.televisionMode)
                Qt.callLater(function() { topbar.focusFirst() })
            else if (win.keyboardFocusDead)
                keyboardIgnition.forceActiveFocus()
        }
    }

    // Account identity flyout, dropped from the topbar medallion.
    AccountCenter {
        id: accountCenter
        objectName: "accountCenter"
        onMinimizeRequested: win.minimizeShell()
        onFullscreenRequested: win.toggleFullscreenShell()
        onQuitRequested: win.requestApplicationQuit()
        feriaController: feriaLayer.item
        feriaEnabled: win.feriaAvailable && !win.feriaComingSoon
        onFeriaActivityRequested: function(section) { win.openYourFeriaPage(section) }
        controller: typeof AccountController !== "undefined" ? AccountController : null
        recoveryPresenter: typeof AccountRecoveryPresenter !== "undefined" ? AccountRecoveryPresenter : null
        privacyDataExportBusy: typeof AccountLifecycle !== "undefined"
            && AccountLifecycle ? AccountLifecycle.exportBusy : false
        privacyAccountDeletionFlowBusy: typeof AccountLifecycle !== "undefined"
            && AccountLifecycle ? AccountLifecycle.deletionBusy : false
        onPrivacyDataExportRequested: {
            privacyErrorMessage = ""
            privacyStatusMessage = ""
            accountExportDialog.open()
        }
        onPrivacyDataExportCancelRequested: {
            if (typeof AccountLifecycle !== "undefined" && AccountLifecycle)
                AccountLifecycle.cancelExport()
        }
        onPrivacyAccountDeletionFlowRequested: function(currentPassword) {
            privacyErrorMessage = ""
            privacyStatusMessage = ""
            if (typeof AccountLifecycle !== "undefined" && AccountLifecycle)
                AccountLifecycle.deleteAccount(currentPassword)
        }
        initial: {
            const who = (typeof AccountController !== "undefined" && AccountController)
                        ? AccountController.username : "";
            return who.length > 0 ? who.charAt(0).toUpperCase() : "?";
        }
    }

    Connections {
        target: typeof AccountLifecycle !== "undefined" ? AccountLifecycle : null
        function onExportSucceeded(path, itemCount) {
            accountCenter.privacyErrorMessage = ""
            accountCenter.privacyStatusMessage = qsTr("Exported %1 account records to %2.")
                .arg(itemCount).arg(path)
        }
        function onExportFailed(message) {
            accountCenter.privacyStatusMessage = ""
            accountCenter.privacyErrorMessage = message
        }
        function onDeletionSucceeded() {
            accountCenter.privacyErrorMessage = ""
            accountCenter.privacyStatusMessage = qsTr("The Colosseum account was deleted. Local media files were preserved.")
            accountCenter.close()
        }
        function onDeletionFailed(message, retryAvailable) {
            accountCenter.privacyStatusMessage = ""
            accountCenter.privacyErrorMessage = retryAvailable
                ? message + qsTr(" Colosseum saved the recovery request and will retry safely.")
                : message
        }
    }

    AccountFlyout {
        id: accountFlyout
        objectName: "accountFlyout"
        controller: typeof AccountController !== "undefined" ? AccountController : null
        initial: {
            const who = (typeof AccountController !== "undefined" && AccountController)
                        ? AccountController.username : "";
            return who.length > 0 ? who.charAt(0).toUpperCase() : "?";
        }
    }

    // "Share on your Wi-Fi" (DLNA) flyout, opened from the top-bar access-point glyph on home
    // and on every world while sharing runs. Same plain-layer shape as the account flyout.
    DlnaSharePopup {
        id: dlnaSharePopup
        objectName: "dlnaSharePopup"
        backdrop: wall
    }

    // Account onboarding + session surfaces (Bundle 8C adoption, 2026-08-16).
    // The host is invisible unless an account flow is actually live (signed-out
    // gate after boot, device approval, recovery, sign-out warning). Controller
    // and recovery presenter are context properties owned by AccountRuntime.
    AccountOnboardingHost {
        id: accountHost
        objectName: "accountHost"
        anchors.fill: parent
        z: 900   // above all chrome; below the boot splash (1000)
        topInset: 0   // full-bleed cover: no app chrome peeks above the flow
        controller: typeof AccountController !== "undefined" ? AccountController : null
        recoveryPresenter: typeof AccountRecoveryPresenter !== "undefined" ? AccountRecoveryPresenter : null
        backdrop: wall
    }

    // One shell-wide cover turns the full-monitor geometry jump into a deliberate beat.
    // Every entry point (F11, global chrome, player, book, comic) reaches this same gate.
    FullscreenTransitionShield {
        id: fullscreenTransition
        // Named so automation can wait out the shell-mode flip instead of racing it: the
        // shield animates and holds a 250ms settle timer, so a get-state fired straight
        // after F11 reads the OLD window state and reports a phantom failure.
        objectName: "fullscreenTransition"
        onTransitioningChanged: if (!transitioning) win.syncVinylVideoWindowMode()
        anchors.fill: parent
        onApplyRequested: WindowMode.toggleShellMode(win)
    }
}
